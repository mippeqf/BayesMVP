



# # |  |  | ------------- Test Manifold stuff --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


 


 

BayesMVP_sample <- function(y, 
                            autodiff. = TRUE,
                            seed,
                            num_chunks = NULL,
                            metric_type = "Empirical",
                            corr_param,
                            prior_only = FALSE,
                            corr_force_positive,
                            corr_pos_offset,
                            prior_mean_vec,
                            prior_sd_vec,
                            lkj_cholesky_eta,
                            corr_prior_beta = FALSE,
                            corr_prior_normal = FALSE,
                            prior_for_corr_a,
                            prior_for_corr_b,
                            known_values_indicator_list = NULL,
                            known_values_list = NULL,
                            ub_corr =NULL,
                            lb_corr = NULL,
                            LT_b_gamma_priors_shape = NULL,
                            LT_b_gamma_priors_scale = NULL,
                            LT_known_bs_indicator = NULL,
                            LT_known_bs_values = NULL,
                            prev_prior_a = 1.5,
                            prev_prior_b = 1.5,
                            n_chains = parallel::detectCores()/2, 
                            n_burnin = 500, 
                            n_iter = 1000,
                            learning_rate_main = 0.10,
                            clip_iter = n_burnin * 0.2, 
                            adapt_interval_width = 25,
                            partial_float = FALSE, 
                            NT_us = TRUE, 
                            lb_phi_approx = -5,
                            ub_phi_approx = +5, 
                            rough_approx = FALSE,  
                            Phi_exact_indicator_if_not_using_rough_approx = TRUE, 
                            HMC = FALSE, 
                            Euclidean_M_main = TRUE, 
                            dense_G_indicator = FALSE, 
                            smooth_M_main = FALSE, 
                            kappa_val = 8,
                            fix_rho = FALSE, 
                            override_Euclidean_main = TRUE, 
                            learning_rate_us = learning_rate_main, 
                            max_eps = 0.50,
                            max_depth = 10,
                            adapt_M_main = TRUE,
                            soft_abs = FALSE,
                            soft_abs_alpha = NA, 
                            eps = 1, 
                            tau_main = 1, 
                            main_L_manual = FALSE, 
                            L_main_if_manual = 1, 
                            diag_metric = TRUE, 
                            MALA_main = FALSE, 
                            max_depth_main = 10, 
                            tau_main_jittered = TRUE, ## 
                            adapt_delta = 0.80, ## 
                            u_Euclidean_metric_const = TRUE, ## 
                            smooth_M_us = FALSE, ##
                            adapt_M_us = TRUE,  ## 
                            main_eps_manual = FALSE, 
                            L_main = 1, 
                            override_Euclidean_us = TRUE  
                            ) {
                            
  

  
  
  
  {
    
    
    Euclidean_M_main = TRUE
    
    # 
    # if  (Boom::IsEven(N) == FALSE) {
    #   N_artificial_even <- N + 1
    # }

    # if  (Boom::is.even(num_chunks) == FALSE) {
    #   num_chunks_even <- num_chunks + 1
    # }

   # num_chunks <- num_chunks_even

    
   #  
   #  N <- nrow(y)
   #  
   # # N  <- N_artificial_even
   #  
   #   N_artificial <- N
   #   chunks_diff <- N - floor(N / num_chunks) *  num_chunks   
   #  
   # 
   #   
   #   # if (chunks_diff != 0) { 
   #   #   
   #   #   N_artificial <- N
   #   #   num_chunks_artificial <- num_chunks
   #   #   
   #   #   while (chunks_diff != 0) {
   #   #     
   #   #     num_chunks_artificial <- num_chunks_artificial + 1
   #   #     chunks_diff <- N_artificial - floor(N_artificial/ num_chunks_artificial) *  num_chunks_artificial  
   #   #     
   #   #   }
   #   #   
   #   #   
   #   # }
   #   # 
   #   
   #   
   #   
   #   
   #   if (chunks_diff != 0) {
   # 
   #     N_artificial <- N
   # 
   #         while (chunks_diff != 0) {
   # 
   #              N_artificial <- N_artificial + 1
   #              chunks_diff <- N_artificial - floor(N_artificial/ num_chunks) *  num_chunks
   # 
   #         }
   # 
   # 
   #   }
   #   
     
     # if  (Boom::IsEven (N_artificial) == FALSE) {
     #   N_artificial <- N_artificial + 1
     # }
     # 
     # 
     # chunks_diff <- N_artificial - floor(N_artificial/ num_chunks) *  num_chunks
     # 
     # if (chunks_diff != 0) { 
     #       
     #     #  N_artificial <- N
     #       
     #       while (chunks_diff != 0) {
     #         
     #         N_artificial <- N_artificial + 1
     #         chunks_diff <- N_artificial - floor(N_artificial/ num_chunks) *  num_chunks  
     #         
     #       }
     #       
     #       
     # }
     # 
    #  
    #  
    #  
    #  
    #  
    #  dim <- dim(y)[2]
    # 
    #  y_new <- array(dim = c(N_artificial, dim))
    # 
    #  y_new[1:N, ] <- y
    # 
    #  y_indicator <- rep(NA, N_artificial)
    # 
    #  y_indicator[1:N] <- 1
    # 
    # 
    #  if (N_artificial > N) {
    #    try({
    #      y_new[(N+1):N_artificial, ] <- 0
    #    })
    #    try({
    #      y_indicator[(N+1):N_artificial] <-   0
    #    })
    #  }
    # 
    #  #
    #  floor(N_artificial / num_chunks)
    # 
    # 
    # ### y <- y_new
    # 
    #  ###N <- nrow(y)



# 
# 
#       chunk_counter = 0;
#       N_artifical =  N;
#       chunk_size  = floor( N_artifical / num_chunks ) ;
#       chunk_size_length =  chunk_size;
#       last_chunk_size = N_artifical - ( chunk_size * num_chunks) ;  last_chunk_size
# 
# 
# 
#       last_nc_index = num_chunks;
# 
# 
#       if (last_chunk_size != 0) {
#         last_nc_index = num_chunks + 1;
#       }
# 
# 
#       for (nc in 0:(last_nc_index - 1)) {
# 
#         start_chunk_index =   chunk_size * chunk_counter;
# 
#         if (nc ==  num_chunks)  {
#           chunk_size_length = last_chunk_size;
#           start_chunk_index = ( chunk_size * num_chunks );
#         }
# 
#         print(paste("start_chunk_index", start_chunk_index))
#         print(paste("chunk_size_length", chunk_size_length))
# 
# 
#         chunk_counter = chunk_counter + 1
#       }
#       
      
      
    # source("~/Documents/Work/PhD_Chapter_1_work/BayesLCM/R/lcmMVPbetav3/R/R_fn_adapt_eps_ADAM.R")
    # source("~/Documents/Work/PhD_Chapter_1_work/BayesLCM/R/lcmMVPbetav3/R/R_fn_adapt_tau_ADAM_2.R")
    # source("~/Documents/Work/PhD_Chapter_1_work/BayesLCM/R/lcmMVPbetav3/R/Rcpp_wr_fn_EHMC_single_iter.R")
    # source("~/Documents/Work/PhD_Chapter_1_work/BayesLCM/R/lcmMVPbetav3/R/R_fn_find_initial_eps.R")
    # 
    # # source("~/Documents/Work/PhD_Chapter_1_work/BayesLCM/R/lcmMVPbetav3/R/AdptEmpFisher_MHstep_MAIN_ALL_v3.R") # for standard param
    # # source("~/Documents/Work/PhD_Chapter_1_work/BayesLCM/R/lcmMVPbetav3/R/AdptEmpFisher_sample_MAIN_ALL_v4.R") # for standard param
    # 
    # source("~/Documents/Work/PhD_Chapter_1_work/BayesLCM/R/lcmMVPbetav3/R/MHstep_MAIN_ALL_GHK_v1.R") # for GHK param
    # source("~/Documents/Work/PhD_Chapter_1_work/BayesLCM/R/lcmMVPbetav3/R/sample_MAIN_ALL_GHK_v1.R") # for GHK param
    # 
    # source("~/Documents/Work/PhD_Chapter_1_work/BayesLCM/R/lcmMVPbetav3/R/wrapper_fn_Rcpp_fn_ELMC_multiple_leapfrogs_EUC_EFISH_HI_with_MIXED_M_v2.R")
    # source("~/Documents/Work/PhD_Chapter_1_work/BayesLCM/R/lcmMVPbetav3/R/wrp_fn_Rcpp_fn_ELMC_single_iter_v1.R")
    
    
    
    colourise <- function(text, fg = "black", bg = NULL) {
      term <- Sys.getenv()["TERM"]
      colour_terms <- c("xterm-color","xterm-256color", "screen", "screen-256color")
      
      if(rcmd_running() || !any(term %in% colour_terms, na.rm = TRUE)) {
        return(text)
      }
      
      col_escape <- function(col) {
        paste0("\033[", col, "m")
      }
      
      col <- .fg_colours[tolower(fg)]
      if (!is.null(bg)) {
        col <- paste0(col, .bg_colours[tolower(bg)], sep = ";")
      }
      
      init <- col_escape(col)
      reset <- col_escape("0")
      paste0(init, text, reset)
    }
    
    .fg_colours <- c(
      "black" = "0;30",
      "blue" = "0;34",
      "green" = "0;32",
      "cyan" = "0;36",
      "red" = "0;31",
      "purple" = "0;35",
      "brown" = "0;33",
      "light gray" = "0;37",
      "dark gray" = "1;30",
      "light blue" = "1;34",
      "light green" = "1;32",
      "light cyan" = "1;36",
      "light red" = "1;31",
      "light purple" = "1;35",
      "yellow" = "1;33",
      "white" = "1;37"
    )
    
    .bg_colours <- c(
      "black" = "40",
      "red" = "41",
      "green" = "42",
      "brown" = "43",
      "blue" = "44",
      "purple" = "45",
      "cyan" = "46",
      "light gray" = "47"
    )
    
    rcmd_running <- function() {
      nchar(Sys.getenv('R_TESTS')) != 0
    }
  }
  
  
                            
 

{
  options(scipen = 99999)
  options(max.print = 1000000)
  options(mc.cores = n_chains)
  numerical_diff_e = 0.01
}



{
  
  
 
 
  
  {
    
    
    {
      try({
        stopCluster(cl)
      }, silent = TRUE)
      
      
      
      #   plan(multisession, workers = n_chains)
      cl <- parallel::makeCluster(n_chains, outfile="") # FORK only works with linux
      doParallel::registerDoParallel(cl)
      
    }
    
    
    comb <- function(x, ...) {
      lapply(seq_along(x),
             function(i) c(x[[i]], lapply(list(...), function(y) y[[i]])))
    }
    
    #   doRNG::registerDoRNG(seed = seed)
    
    
    # seed <- seed_manual  ##################################
    
    set.seed(seed)
    doRNG::registerDoRNG(seed = seed)
  }
  
  
  
}





# |   ------------- Test Manifold stuff  - initialise -----------------------------------------------------


{
  
  tau_main  <- 1
  
  kk <- 1
  
  n_params_main <- (n_class - 1)  + n_class * choose(n_tests, 2) + n_class * (n_covariates + 1)  * n_tests 
  n_us <- 1 * N * n_tests 
  n_params <- n_params_main + n_us 
  
  n_corrs <- n_class * 0.5 * n_tests * (n_tests - 1)
  n_coeffs <- n_class * n_tests * 1
  
  index_us <- 1:n_us
  index_main <- (n_us+1):n_params
  
  
 beta1_adam <- 0 ;  beta2_adam <-   0.95 ;  eps_adam <- 10^(-8)
#  beta1_adam <- 0 ;  beta2_adam <-   0.50 ;  eps_adam <- 10^(-3)
  
  accept <- c()
  snaper_w <- rep(0.0001, n_params)
  snaper_s <- rep(1, n_params)
  snaper_m <- rep(1, n_params)
 #  tau <- 1
  eps_m_adam <-  eps_v_adam <- 1
  tau_m_adam <- tau_v_adam <- 1
  h_bar <- eps
  dense_M <- F
  
  eigen_max <- sqrt(sum(snaper_w^2))
  eigen_vector <- snaper_w/eigen_max # same as z 
  
  
  eigen_max_main <- sqrt(sum(snaper_w^2))
  eigen_vector_main <- snaper_w/eigen_max_main # same as z 
  
  error_count <- 0 
  L_main_vec <- c()
  p_jump_main_vec <- c()
  
  L_main_ii <- 1
  
  eps_us <- eps <- eps_ii <- 1
  
  index_subset <- 1:n_params
  
  min_ess_sec_vec <- c()
  min_ess_grad_vec <- min_ess_grad_sampling_vec <- c()
  
  
  m_sq <- v_sq <- cov_sq <- 1
  m_sq_us <- v_sq_us <- cov_sq_us <- 1
  
  L_us_ii = 1
  
  velocity  <- rep(0.01, n_params)
  velocity_prop <-   rep(0.01, n_params)
  velocity_0 <-   rep(0.01, n_params)

  # momentum  <- rep(0.01, n_params)
  # momentum_prop <-   rep(0.01, n_params)
  # momentum_0 <-   rep(0.01, n_params)
  
  p_jump_us = 1
  
  eps_m_adam_us <- eps_v_adam_us <-  eps_us
  
 
 # momentum <- momentum_0
#   grad_prop <- grad
  # 
  
  eps_ii_vec <- c()
  
  tau_m_adam_us <- 10
  tau_v_adam_us <- 0
  
  tau_m_adam_main <- 10
  tau_v_adam_main <- 0
  

  
  
  adapt_delta <-  adapt_delta
  
  
   trace_theta_test <- array(dim  = c(n_chains, 1 + n_burnin, n_params_main))

   
   theta_vec <-     rep(0.01, n_params)
 #   theta_vec[(n_us + 1):(n_us+n_corrs)] <- rnorm(n = n_corrs, mean = 0.20, sd = 0.01)
#  if (corr_force_positive == TRUE)  theta_vec[(n_us + 1):(n_us+n_corrs)] <- rnorm(n = n_corrs, mean = -3, sd = 0.00000001)
  if (corr_force_positive == TRUE)  theta_vec[(n_us + 1):(n_us+n_corrs)] <- rnorm(n = n_corrs, mean = -3, sd = 0.00001)
 #   if (corr_force_positive == TRUE)  theta_vec[(n_us + 1):(n_us+n_corrs)] <- rnorm(n = n_corrs, mean = -5.001, sd = 0.00000001)
  #  else                              theta_vec[(n_us + 1):(n_us+n_corrs)] <- rnorm(n = n_corrs, mean = 0 , sd = 0.00000001)
 #  else                              theta_vec[(n_us + 1):(n_us+n_corrs)] <- rnorm(n = n_corrs, mean = -2 , sd = 0.00000001)
  else    theta_vec[(n_us + 1):(n_us+n_corrs)] <- rep(0.01, n_corrs)
    # theta_vec[(n_us + 1):(n_us+n_corrs)] <- rnorm(n = n_corrs, mean = 0.01, sd = 0.00000001)
    
#   theta_vec[(n_us + 1):(n_us+n_corrs)] <-  seq(from = -3, to = -1, length = 2*n_tests)
  
 #  theta_vec[(n_us + 1):(n_us+n_corrs)] <- rnorm(n = n_corrs, mean = -3, sd = 0.000000001)
  
  theta_vec[   (n_us + n_corrs + 1):(n_us + n_corrs + n_coeffs/2)  ] <- rep(-1, n_coeffs/2)
  theta_vec[(n_us + n_corrs + 1 + n_coeffs/2):(n_us + n_corrs + n_coeffs)] <- rep(1, n_coeffs/2)
  #  log_posterior_iter_0 <- log_posterior[kk]
   
  theta_vec[n_params] =  -0.6931472  # this is equiv to starting val of p = 0.20!  since: 0.5 * (tanh( -0.6931472) + 1)  = -0.6931472
  
  
  
   # theta_vec <-  theta_vec
  theta_vec_prop <-  theta_vec
  theta_vec_initial <- theta_vec
  #theta_vec_inc_p <- theta_vec
  
  p_jump_vec <- c()
  # theta_mean <- theta_vec
  # theta_var <- rep(0.0001, n_params)
  
 
  
  # if (test_manifold_stuff == TRUE) 
  n_leapfrog_vec <- c()
  
  window_index <- 0 
  window_index_us <- 0
  
  M_diag_vec <- M_inv_diag_vec <- rep(1, n_params)  # initial
  M_diag_vec <- rep(1, n_params)
  M_inv_diag_vec_stored <-  rep(1, n_params)
  diag_vec_G <- M_diag_vec
    
  M_inv_dense_main_stored <- diag(n_params_main)
  M_dense_main_corr_mtx <-   diag(n_params_main)
 
  Hessian_dense_main <- Hessian_dense_main_inv <-  dense_H_initial <-  Hessian_dense_main_inv_initial <-  diag(n_params_main)
  G_dense_main <- G_inv_dense_main <-  dense_G_initial  <- diag(n_params_main)
  
  Empirical_Fisher_mat_adj <- diag(n_params_main)
  Empirical_Fisher_mat <- diag(n_params_main)
  A_dense_adj <- diag(n_params_main)
  R_diag_adj <- diag(A_dense_adj)
  M_diag_vec_adj <- rep(1, n_params)
  
  
  Empirical_Fisher_mat_adj_to_use <- Empirical_Fisher_mat_adj
  A_dense_adj_to_use <- A_dense_adj
  R_diag_adj_to_use <- R_diag_adj
  
  u_trace_index <- 0
  
  window_index_us <- 0
  
  
  
  window_index_main <- 0 
  window_index_main_2 <- 0 
  M_inv_diag_vec_main_only  <- rep(1, n_params)
  M_diag_vec_main_only <-  1 / M_inv_diag_vec_main_only
  
  L_main_vec <- c()
  L_us_vec <- c()
  
  error_count <- 0 
  
  eps_m_adam <-  eps
  eps_v_adam <- 0
  
  p_jump_us_vec <- c()
  p_jump_main_vec <- c()
  
  
  R_diag <- rep(1, n_params_main)
  A_dense <- diag(R_diag)
  Empirical_Fisher_mat <- A_dense
  G_inv_chol_dense_main <- A_dense
  
  
}

 



  
  
  
  {
    
    
    
    
    
  # set lp_and_grad function arguments needed and put them in a list, so that they can be passed on to the generic EHMC-ADAM functions
  exclude_priors = FALSE
  lkj_prior_method = 2
  grad_main = TRUE
  grad_nuisance = TRUE
  CI = CI
 
   
  homog_corr = homog_corr
  lkj_cholesky = mvr_cholesky 
  
  
 
  
  prior_coeffs_mean = prior_mean_vec
  prior_coeffs_sd = prior_sd_vec
  n_class = n_class
  n_tests = n_tests
  
  
  
  lp_and_grad_args <- list()
  lp_and_grad_args[[1]] =  exclude_priors
  lp_and_grad_args[[2]] =  lkj_prior_method
  lp_and_grad_args[[3]] =  grad_main
  lp_and_grad_args[[4]] =  grad_nuisance
  lp_and_grad_args[[5]] =  CI
  lp_and_grad_args[[6]] =  rough_approx
  lp_and_grad_args[[7]] =  homog_corr
  lp_and_grad_args[[8]] =  lkj_cholesky
  lp_and_grad_args[[9]] =  lkj_cholesky_eta
  lp_and_grad_args[[10]] =  prior_coeffs_mean
  lp_and_grad_args[[11]] =  prior_coeffs_sd
  lp_and_grad_args[[12]] =  n_class
  lp_and_grad_args[[13]] =  n_tests
 #  lp_and_grad_args[[14]] = (X)
  
  N_obs_threshold_for_using_vectorised_fn = 100000
  N_obs = N * n_tests
 
  
  
  vectorised =  TRUE # with chunking (much faster and much better scaling !!)
  
  

  
  lp_and_grad_args[[15]] = vectorised
  lp_and_grad_args[[16]] = N_obs_threshold_for_using_vectorised_fn
  lp_and_grad_args[[17]] = Phi_exact_indicator_if_not_using_rough_approx
  
  lp_and_grad_args[[18]] = lb_phi_approx
  lp_and_grad_args[[19]] = ub_phi_approx
  
  # sum_2darray <- function(a) {
  #   s = 0;
  #   for (i in 1:length(c(a))) {
  #     s = s + sum(a[i])
  #   }
  #   return(s)
  # }
  # 
  
  # n_pos <- rep(NA, length = sum_2darray(y))
  # d_pos <- rep(NA, length = length(n_pos))
  # N_pos <- length(n_pos)
  # 
  # n_neg <- rep(NA, length = N * n_tests - length(n_pos))
  # d_neg <- rep(NA, length = length(n_neg))
  # N_neg <- length(n_neg)
  # 
  # {
  #   i = 1;
  #   j = 1;
  #   for (n in 1 : N) {
  #     for (d in 1 : n_tests) {
  #       if (y[n, d] == 1) {
  #         n_pos[i] = n;
  #         d_pos[i] = d;
  #         i = i + 1;
  #       } else {
  #         n_neg[j] = n;
  #         d_neg[j] = d;
  #         j = j + 1;
  #       }
  #     }
  #   }
  # }
  
  
#  lp_and_grad_args[[20]] = y_new
  
  # lp_and_grad_args[[21]] = N_pos
  # lp_and_grad_args[[22]] = n_pos
  # lp_and_grad_args[[23]] = d_pos
  # 
  # lp_and_grad_args[[24]] = N_neg
  # lp_and_grad_args[[25]] = n_neg
  # lp_and_grad_args[[26]] = d_neg
  
  
 
  list_prior_for_corr_a <-  list_prior_for_corr_b <- list()

 
  
  for (c in 1:n_class) {
      list_prior_for_corr_a[[c]] <- prior_for_corr_a[,,c]
      list_prior_for_corr_b[[c]] <- prior_for_corr_b[,,c]
  }
  
  

  
  lp_and_grad_args[[50]] =  list_prior_for_corr_a
  lp_and_grad_args[[51]] =  list_prior_for_corr_b
  
  lp_and_grad_args[[52]] =   corr_priors_LKJ_only
  lp_and_grad_args[[53]] =   corr_param_Archakov
  lp_and_grad_args[[54]] =   use_AD_for_chol_derivs
  
    constant_1 <-     -1  
   #   constant_1 <-   0 
#     constant_1 <-    1
  lp_and_grad_args[[55]] =  constant_1
  lp_and_grad_args[[56]] = 1e-6
  lp_and_grad_args[[57]] =  FALSE # beta corr (Archakov) prior
  lp_and_grad_args[[58]] = FALSE  # normal corr (Archakov) prior
  
  lp_and_grad_args[[60]] = N
 
  
  #     fn =    lcmMVPbetav3::fn_log_posterior_full_binary_only_GHK_manual_diff_test_2
  #  fn =   lcmMVPbetav3::fn_log_posterior_and_gradient
  #    fn =  lcmMVPbetav3::fn_log_posterior_full_binary_only_GHK_manual_diff_test_1
   # fn = lcmMVPbetav2::fn_log_posterior_and_gradient_Archakov
  
  # try({ 
  #  fn = BayesMVP::fn_log_posterior_and_gradient_vectorised_chunking_NT_us_2
  # })
  # 
 

 
  
  lp_and_grad_args[[27]]  = num_chunks
   
            
            if (is.null(ub_corr)) {                                                                                                                          
                            ub_corr <- list()                                                                                                                            
                            for (c in 1:n_class) {                                                                                                                       
                                  ub_corr[[c]] <- diag(n_tests)                                                                                                            
                                  ub_corr[[c]][, ] <- +1                                                                                                                   
                              }                                                                                                                                            
            }
  
            if (is.null(lb_corr)) {                                                                                                                          
                  lb_corr <- list()                                                                                                                            
                  for (c in 1:n_class) {                                                                                                                       
                        lb_corr[[c]] <- diag(n_tests)                                                                                                            
                        lb_corr[[c]][, ] <- -1                                                                                                                   
                    }                                                                                                                                            
            }
  
            for (c in 1:n_class) {                                                                                                                           
                  if (corr_force_positive == TRUE)                                                                                                             
                        lb_corr[[c]][, ] <- 0                                                                                                                    
                    else lb_corr[[c]][, ] <- -1                                                                                                                  
            }
  
  
  
  lp_and_grad_args[[30]]  <- corr_force_positive 
  
  #corr_normal_prior_sd <- list()
  # for (c in 1:n_class) {
  #    corr_normal_prior_sd[[c]] <-  array(0.25, dim = c(n_tests, n_tests))
  # }
  
  # corr_normal_prior_sd[[1]] <-  array(0.0001, dim = c(n_tests, n_tests))
  # corr_normal_prior_sd[[2]] <-  array(0.10, dim = c(n_tests, n_tests))
  
  lp_and_grad_args[[31]]  <-  corr_normal_prior_sd
  

  lp_and_grad_args[[41]]  <- NT_us # NT_us
  
  lp_and_grad_args[[46]] <- partial_float   
  
            if (corr_param == "Arch") {                                                                                                                      
                    if (prior_only == TRUE)       model_number <- 9                                                                                                                        
                    else model_number <- 4                                                                                                                       
           }     else if (corr_param == "Chol_Nump") {                                                                                                            
                    if (prior_only == TRUE)         model_number <- 6                                                                                                                        
                    else model_number <- 8                                                                                                                       
            }     else if (corr_param == "Chol_Stan") {                                                                                                            
                    if (prior_only == TRUE)       model_number <- 3                                                                                                                        
                    else model_number <- 1                                                                                                                       
            }    else if (corr_param == "Chol_Schur") {                                                                                                           
                    if (prior_only == TRUE)          model_number <- 10                                                                                                                       
                    else model_number <-     11 #  11                                                                                                                     
            }   else if (corr_param == "latent_trait") {                                                                                                         
                  model_number <- 12                                                                                                                           
            }
  
  
           #  model_number <- 20 # for testing / debug
            # 
            model_number <- 11 # Schur, AD (depending on pkg - check)
  
  
            lp_and_grad_args[[61]] <- model_number                                                                                                           
            lp_and_grad_args[[62]] <- prior_only                                                                                                             
            lp_and_grad_args[[64]] <- corr_pos_offset                                                                                                        
            lp_and_grad_args[[65]] <- lb_corr                                                                                                                
            lp_and_grad_args[[66]] <- ub_corr    
            
 
            
    
            
            if (is.null(known_values_indicator_list)) {                                                                                                      
                  known_values_indicator_list <- list()                                                                                                        
                  known_values_list <- list()                                                                                                                  
                  for (c in 1:n_class) {                                                                                                                       
                        known_values_indicator_list[[c]] <- diag(n_tests)                                                                                        
                        known_values_list[[c]] <- diag(n_tests)                                                                                                  
                    }                                                                                                                                            
            }          
            
            lp_and_grad_args[[71]] <- 1                                                                                                                      
            lp_and_grad_args[[72]] <- 1   
            lp_and_grad_args[[73]] <- known_values_indicator_list                                                                                            
            lp_and_grad_args[[74]] <- known_values_list      
            lp_and_grad_args[[75]] <- 2
            
            lp_and_grad_args[[81]] <- prev_prior_a                                                                                                           
            lp_and_grad_args[[82]] <- prev_prior_b  
            
            if (is.null(LT_b_gamma_priors_shape)) {  
              LT_b_gamma_priors_shape <- array(1, dim = c(n_class, n_tests))
            }
            if (is.null(LT_b_gamma_priors_scale)) {  
              LT_b_gamma_priors_scale <- array(1, dim = c(n_class, n_tests))
            }
            
            lp_and_grad_args[[91]] <- LT_b_gamma_priors_shape  
            lp_and_grad_args[[92]] <- LT_b_gamma_priors_scale  
            
            if (is.null(LT_known_bs_indicator)) {  
              LT_known_bs_indicator <- array(0, dim = c(n_class, n_tests))
            }
            if (is.null(LT_known_bs_values)) {  
              LT_known_bs_values    <- array(0.00001, dim = c(n_class, n_tests))
            }
              
            lp_and_grad_args[[93]] <- LT_known_bs_indicator  
            lp_and_grad_args[[94]] <- LT_known_bs_values  
            

            
            
            known_corr_index_vec <- rep(0, n_corrs)
            
            if (corr_param != "latent_trait") {
                      at_least_one_corr_known_indicator <- 0 
                      counter <- 1
                      corr_index = n_us + 1
                      for (c in 1:n_class) {
                        for (i in 2:n_tests) {
                          for (j in 1:(i-1)) {
                            if (known_values_indicator_list[[c]][i, j] == 1)   {
                              known_corr_index_vec[counter] <- corr_index
                              at_least_one_corr_known_indicator <- 1
                            }
                            corr_index <- corr_index + 1
                            counter <- counter + 1
                          }
                        }
                      }
            } else { 
                at_least_one_corr_known_indicator <- 0 
                    counter <- 1
                    corr_index = n_us + 1
                    for (c in 1:n_class) {
                      for (i in 1:n_tests) {
                          if (LT_known_bs_indicator[c, i] == 1)   {
                            known_corr_index_vec[counter] <- corr_index
                            at_least_one_corr_known_indicator <- 1
                          }
                          corr_index <- corr_index + 1
                          counter <- counter + 1
                      }
                    }
                    
                    known_corr_index_vec[(counter:n_corrs)] <- (n_us + 1 + n_class*n_tests):(n_us + n_corrs)
                    
            }
            
            
            
            index_subset_excl_known <- index_main
            for (i_known in 1:length(known_corr_index_vec)) {
              index_subset_excl_known <-   index_subset_excl_known[index_subset_excl_known != known_corr_index_vec[i_known]]
            }
            
            
            if (model_number == 20) {
                y_sign <- matrix(nrow = N, ncol = n_tests)
                
                for (n in 1:N) {
                  for (t in 1:n_tests) {
                    if (y[n, t] == 1) y_sign[n, t] = + 1
                    else              y_sign[n, t] = - 1
                  }
                }
                
                
               #' y <- y_sign
                
                  lp_and_grad_args[[101]] = y_sign 
            } else { 
                 lp_and_grad_args[[101]] = y[1:2, 1:2]
            }
            
          
            lp_and_grad_args[[102]] = 0 #  rep(1, N)
           ### y <- y_new
            
            CDA <-    FALSE
           # N / log(N)
            CDA_r <- array(1, dim = c(n_class, n_tests))
            CDA_b <- -3.7 * (sqrt(CDA_r) - 1) ; CDA_b
            
           # CDA_b <- array(0, dim = c(n_class, n_tests))
            
            lp_and_grad_args[[106]] = CDA
            lp_and_grad_args[[107]] = CDA_r
            lp_and_grad_args[[108]] = CDA_b
            
            
            try({ 
              fn = BayesMVP::fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float
            })
            
            outs_manual_grad <- fn(theta = theta_vec, 
                                   y = y, 
                                   lp_and_grad_args)       
            
            log_posterior <- outs_manual_grad[1]                                                                                                             
            log_posterior                                                                                                                                    
            grad <- head(outs_manual_grad[-1], n_params) 
            
            grad_prop <- grad
            
            
            
            
            individual_log_lik = outs_manual_grad[(n_params + 2):((n_params + 1 + N))]
            

            
            
            
            
            
            
            
            
            
           # -------------------------------------------------------------------------
#      ## lcmMVPbetav2::
# #      ## BayesMVP
# # # 
# # #
#             theta_vec <- rnorm(n = length(theta_vec), 0, 0.01)
# 
# 
#             fn = BayesMVP::fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float_debug
#             # fn = fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float_debug
# 
#             #  tic()
#             #  for (jjj in 1:1000)
#             outs_manual_grad <- fn(theta = theta_vec,
#                                    y = y,
#                                    lp_and_grad_args)
#             #toc()
# 
#             outs_manual_grad[[17]]
#             #  mat = outs_manual_grad[[17]] ; mat
# 
#             log_posterior_debug <- outs_manual_grad[1]
#             log_posterior_debug
# 
#             grad_debug <- head(outs_manual_grad[-1], n_params)
#             grad_debug  <- tail(grad_debug, 41) ; grad_debug
# 
# 
# 
# #
#                         u_array_2 = outs_manual_grad[[2]]
#                         prob_2 = outs_manual_grad[[3]]
#                         Z_std_norm_2 = outs_manual_grad[[4]]
#                         Bound_Z_2 = outs_manual_grad[[6]]
#                         y_sign_2 = outs_manual_grad[[8]]
#                         prob_n_2 = outs_manual_grad[[9]]
#                         lp_array_2 = outs_manual_grad[[10]]
#                         phi_Z_2 = outs_manual_grad[[13]]
#                         common_grad_term_1_2 = outs_manual_grad[[15]]
#                         y_m_ysign_x_u_array_2 = outs_manual_grad[[16]]
# 
# 
# #
# #
# # # #
# # # # #
# # # #
# ##  theta_vec <- rnorm(n = length(theta_vec), 0, 0.10)
#             fn = BayesMVP::fn_log_posterior_and_gradient_Chol_Schur_AD
# 
#             #  for (jjj in 1:1000)
#             outs_manual_grad <- fn(theta = theta_vec,
#                                    y = y,
#                                    lp_and_grad_args)
#             #toc()
# 
# 
#             #  mat = outs_manual_grad[[17]] ; mat
# 
#             log_posterior_AD <- outs_manual_grad[1]
#             log_posterior_AD
# 
#             grad_AD <- head(outs_manual_grad[-1], n_params)
#             grad_AD  <- tail(grad_AD, 41) ; grad_AD
# 
# 
# 
#             log_posterior_AD - log_posterior_debug
#             grad_AD - grad_debug
#             sum(  grad_AD - grad_debug)
# 
# 
#             lp_and_grad_args[[27]]  = 1
#             lp_and_grad_args[[102]] = 0
# 
# 
# 
#              fn = BayesMVP::fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float
# #             fn = fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float
# 
#            #  tic()
#            #  for (jjj in 1:1000)
#                outs_manual_grad <- fn(theta = theta_vec,
#                                       y = y,
#                                       lp_and_grad_args)
#              #toc()
# 
#           #     outs_manual_grad[[17]]
# 
#           #  mat = outs_manual_grad[[17]] ; mat
# 
# #               # u_array = outs_manual_grad[[2]]
# #                prob = outs_manual_grad[[3]]
# #                Z_std_norm = outs_manual_grad[[4]]
# #                            Bound_Z = outs_manual_grad[[6]]
# #                            y_sign = outs_manual_grad[[8]]
# #                            prob_n = outs_manual_grad[[9]]
# #                            lp_array = outs_manual_grad[[10]]
# #                            # phi_Z = outs_manual_grad[[13]]
# #                            common_grad_term_1 = outs_manual_grad[[15]]
# #                            y_m_ysign_x_u_array = outs_manual_grad[[16]]
# # 
# # 
# #                            prob[[1]] - prob_2[[1]]
# #                            Z_std_norm[[1]] - Z_std_norm_2[[1]]
# #                            Bound_Z[[1]] - Bound_Z_2[[1]]
# #                            prob_n  - prob_n_2
# #                            lp_array  - lp_array_2
# #                            common_grad_term_1  - common_grad_term_1_2[[2]]
# #                            y_m_ysign_x_u_array  - y_m_ysign_x_u_array_2
# # 
# # #
# #                outs_manual_grad[[17]]
# #
#                log_posterior_test <- outs_manual_grad[1]
#                log_posterior_test
# 
#                grad_test <- head(outs_manual_grad[-1], n_params)
#                grad_test  <- tail(grad_test, 41) ; grad_test
# 
# 
# 
#                log_posterior_test - log_posterior_debug
#                grad_test - grad_debug
#                sum(  grad_test - grad_debug)
# 
#                log_posterior_test
#                log_posterior_debug
# # #                
# # #                grad_test
# # #                grad_debug
# # # 
# # # 
# # # 
# # # 
# # #             grad_0  <- tail(grad[1:n_params], 41) ; grad_0
# # #             # log_posterior_0 <- log_posterior
# # # 
# # #             u_array = outs_manual_grad[[2]]
# # #             prob = outs_manual_grad[[3]]
# # #             Z_std_norm = outs_manual_grad[[4]]
# # #             Bound_Z = outs_manual_grad[[6]]
# # #             y_sign = outs_manual_grad[[8]]
# # #             prob_n = outs_manual_grad[[9]]
# # #             lp_array = outs_manual_grad[[10]]
# #             phi_Z = outs_manual_grad[[13]]
# #             common_grad_term_1 = outs_manual_grad[[15]]
# # # #             y_m_ysign_x_u_array = outs_manual_grad[[16]]
# # # #
# #
#             
#             
#             
#             
            
            
            
            
            
            
            
            
#             
# # #             
# #             
#             
#             
# # 
#             fn = BayesMVP::fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float_debug
# 
#             #  tic()
#             #  for (jjj in 1:1000)
#             outs_manual_grad <- fn(theta = theta_vec,
#                                    y = y,
#                                    lp_and_grad_args)
#             #toc()
# 
# 
# # 
# # 
# #             u_array_2 = outs_manual_grad[[2]]
# #             prob_2 = outs_manual_grad[[3]]
# #             Z_std_norm_2 = outs_manual_grad[[4]]
# #             Bound_Z_2 = outs_manual_grad[[6]]
# #             y_sign_2 = outs_manual_grad[[8]]
# #             prob_n_2 = outs_manual_grad[[9]]
# #             lp_array_2 = outs_manual_grad[[10]]
# #             phi_Z_2 = outs_manual_grad[[13]]
# #             common_grad_term_1_2 = outs_manual_grad[[15]]
# #             y_m_ysign_x_u_array_2 = outs_manual_grad[[16]]
# # 
# # 
# #             u_array  - u_array_2  # fine
# #             prob[[1]] - prob_2[[1]]
# #             Z_std_norm[[1]] - Z_std_norm_2[[1]]
# #             Bound_Z[[1]] - Bound_Z_2[[1]]
# #             y_sign - y_sign_2 # fine
# #             prob_n - prob_n_2
# # 
# 
# 
#             fn = fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float
# 
# 
#             outs_manual_grad <- fn(theta = theta_vec,
#                                    y = y,
#                                    lp_and_grad_args)
#             # toc()
# 
# 
# 
#             #  mat = outs_manual_grad[[17]] ; mat
# 
#             log_posterior <- outs_manual_grad[1]
#             log_posterior
#             grad <- head(outs_manual_grad[-1], n_params)
# 
#             grad_1 <- tail(grad[1:n_params], 41) ; grad_1
#             log_posterior_1 <- log_posterior
# 
# 
#             grad_0 - grad_1
# 
# 
# 
#             lp_and_grad_args[[27]]  = 1
#             lp_and_grad_args[[102]] = rep(1, N)
# 
# 
# 
#             fn = lcmMVPbetav2::fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD
#            #  fn = fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD
# 
#             outs_manual_grad <- fn(theta = theta_vec,
#                                    y = y,
#                                    lp_and_grad_args)
# 
#             outs_manual_grad <- outs_manual_grad[[1]]
# 
#            # outs_manual_grad[[1]]
# 
#            ###  outs_manual_grad[[17]][[2]] - mat[[2]]
# 
#             log_posterior_2 <- outs_manual_grad[1]
#             log_posterior_2
#             # grad <- head(outs_manual_grad[-1], n_params)
# 
# 
#             grad_2 <- tail(grad[1:n_params], 41) ; grad_2
#             log_posterior_2 <- log_posterior
# 
# 
# 
#             log_posterior_0 - log_posterior_2
#             grad_0 - grad_2
# 
#             log_posterior_1 - log_posterior_2
#             grad_1 - grad_2
# 
#             log_posterior_1
#             log_posterior_2
# 
#             grad_1
# # #             grad_2
# # #
# # # #
# 
# 
# #             
# # 
# #             ### lp_and_grad_args[[101]] = 0 #    y
# #             lp_and_grad_args[[102]] = 0
# 
# # 
# #             # 
#             # 
#             # 
#             # 
#             # log_posterior
#             # 
            # #
            # chunk_size  = floor( N /    lp_and_grad_args[[27]]   )    ; chunk_size
            # 
            # chunk_size * 3
            # 
            # last_chunk_size =  N - chunk_size *   lp_and_grad_args[[27]]   ; last_chunk_size
            # 
            # 
            # chunk_size *   lp_and_grad_args[[27]]   +  last_chunk_size
            # 
            
            # # 
            # outs_AD <-  lcmMVPbetav2::fn_log_posterior_and_gradient_Chol_Schur_AD(theta = theta_vec,
            #                                             y = y,
            #                                             lp_and_grad_args)
            # 
            # 
            # 
            # outs_AD[1]
            # grad_AD <- head(outs_AD[-1], n_params)
            # 
            # tail(grad_AD, 31)
            # outs_MD <-  lcmMVPbetav2::fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD(theta = theta_vec,
            #                                                    y = y,
            #                                                    lp_and_grad_args)
            # 
            # grad_MD[1]
            # grad_MD <- head(outs_MD[-1], n_params)
            # 
            # tail(grad_MD, 31)
            # 
            # 
            
  
  }

  
  
 
  # -------------------------------------------------------------------------

  if (is.null(adapt_interval_width)) {

        {
          interval <- 1
 
          if (n_burnin < 301) {
            adapt_interval_width <- n_burnin / 10
          } else { 
            adapt_interval_width <- 25
          }
          
          
         #  adapt_interval_width <- n_burnin
          
            seq_burnin <- 1:n_burnin
            partitions <- split(seq_burnin, ceiling(seq_along(seq_burnin)/adapt_interval_width))
            n_adapt_intervals <-  length(partitions)  ; n_adapt_intervals
        
        }
    
  } else { 
    
    {
      interval <- 1
      
      seq_burnin <- 1:n_burnin
      partitions <- split(seq_burnin, ceiling(seq_along(seq_burnin)/adapt_interval_width))
      n_adapt_intervals <-  length(partitions)  ; n_adapt_intervals
      
    }
    
    
  }
  


{

  tictoc::tic("burnin timer")
  
for (interval in 1:n_adapt_intervals) {   

  gc(reset = TRUE)
  
{



  
  # run in parallel
  
  set.seed(seed)
  
  non_BCA_burnin_outs <- doRNG::`%dorng%`(
    foreach::foreach(kk = 1:n_chains, 
                     .packages = c("Rcpp",
                                   "rstan",
                                  # "lcmMVPbetav2",
                                  # "lcmMVPbetav3",
                                  "float",
                                   "Matrix", 
                                   "matrixStats",
                                   "LaplacesDemon", 
                                   "bdsmatrix"), 
                     .combine = 'comb', 
                     .multicombine = TRUE,
                     .init = list(list(),   list(),  list(),  list(), list(),
                                  list(),   list(),  list() , list(), list(),
                                  list(),   list(),  list(),  list(), list(),  
                                  list(),   list(),  list(),  list(), list(), 
                                  list(),   list(),  list(),  list(), list(),
                                  list(),   list(),  list(),  list(), list(), 
                                  list(),   list(),  list(),  list(), list(), 
                                  list(),   list(),  list(),  list(), list())
    ),
    {
      
      
      options(mc.cores = parallel::detectCores())
      
 
 
      # |   ------------- Test Manifold stuff - start of iteration loop  -----------------------------------------------------
      
      
      
 
      ii <- 1
      partition_width <- length(partitions[[interval]])
     
      
      
    for (ii in  partitions[[interval]][1]:partitions[[interval]][partition_width] ) {
          
          if  ((ii ==  partitions[[interval]][1]) && ii != 1) {
              # reset initial values
             theta_vec <- theta_initial_values_per_chain[, kk]  
             grad <-   grad_initial_values_per_chain[, kk]  
             log_posterior <- log_posterior_initial_values_per_chain[kk]  
          }
          
          

             
          { 
            
            

            
          }
     
            
             
             # gc(reset = TRUE)
        
             eta_w <- 3 
             
             kappa <- 8
             eta_m <- 1/(ceiling(ii/kappa)+1)
 
              
              # | ----------------- Test Manifold stuff - adapt M (for u's) ---------------------------------------------------------------------------------------
              
           
 
                adapt_window_apply_prop <- c(0.2, 0.3, 0.4, 0.6, 0.8) # when to apply new metric 
                adapt_window_apply <-  round(adapt_window_apply_prop * n_burnin, 0) ; adapt_window_apply  # when to apply new metric  
              
 
              if   (  (adapt_M_us == TRUE) &&  (override_Euclidean_us == TRUE)  )   {
                {
                  
                  
                  try({
 
                          if  (  (ii %in% tail(  partitions[[interval]], 1) )  && (ii >= n_burnin*0.2 )  )  { 
                              M_inv_diag_vec_stored[index_us] <-   snaper_s[index_us]  # using "online" variance estimate
                          }
                      
                      if (ii %in% adapt_window_apply[c(-1)]) { 
                        
                        message(cat(colourise( paste("Adapting Metric (M) for NUISANCE parameters " ), "green"), "\n"))
                        
                        # if (NT_us == FALSE) {
                          M_inv_diag_vec[index_us] <- M_inv_diag_vec_stored[index_us]
                          M_diag_vec[index_us] <-  1 / M_inv_diag_vec[index_us]
                          
                          if (u_Euclidean_metric_const == TRUE) {
                            M_diag_vec[index_us] <-  rep(median(M_diag_vec[index_us]), n_us)
                            M_inv_diag_vec[index_us] <- 1 / M_diag_vec[index_us]
                          }
                      }
                    
                  })
                }
              }
              
              
                
              
              
              # | ----------------- Test Manifold stuff - adapt M (for main - if EUCLIDEAN metric) ---------------------------------------------------------------------------------------
              
              if (ii < 2) { 
                
                M_dense_main <-  diag(rep(1, n_params_main))
                M_inv_dense_main <-   diag(rep(1, n_params_main)) 
                M_inv_dense_main_stored <- M_inv_dense_main
                M_dense_CHOL_main <- t(chol(M_dense_main))
                M_dense_main_corr_mtx <- diag(rep(1, n_params_main))
                M_dense_sqrt <-  expm::sqrtm(M_dense_main)
                M_inv_dense_main_chol <- t(chol(M_inv_dense_main))
                
              }
              
              
              {
 
                adapt_window_apply_prop <- c(0.2, 0.3, 0.4, 0.6, 0.8) # when to apply new metric 
                adapt_window_apply <-  round(adapt_window_apply_prop * n_burnin, 0) ; adapt_window_apply  # when to apply new metric  
                
            
                
                if   (  (adapt_M_main == TRUE)  && (metric_type == "Empirical"))  {
                  
                
                  try({

                    if (smooth_M_main == FALSE) {

                                 if  (  (ii %in% tail(  partitions[[interval]], 1) )  && (ii >= n_burnin*0.2 )  )  {

                                        adapt_window_sequence_main <-    partitions[[interval]] # (adapt_window_apply[window_index_main] + 1):(adapt_window_apply[window_index_main+1]-1)

                                      ##   M_inv_diag_vec <- 1 / M_diag_vec
                                        M_inv_diag_vec_current_interval <- M_inv_diag_vec_stored

                                        for (iiiii in 1:n_params_main) {
                                          M_inv_diag_vec_current_interval[iiiii + n_us] <- sd(  trace_theta_test[kk, adapt_window_sequence_main, iiiii], na.rm = T )^2
                                        }

                                      #  if (dense_G_indicator == TRUE) {


                                          try({

                                          if (ii < clip_iter) {
                                               M_inv_dense_main_current_interval <-  diag(M_inv_diag_vec_current_interval[index_main]) # cov(  trace_theta_test[kk, 1:(ii-1),  ] , use = "complete" )
                                          } else {
                                          #else                 M_inv_dense_main_current_interval <- cov(  trace_theta_test[kk, clip_iter:(ii-1),  ] , use = "complete" )
                                            if ((adapt_window_sequence_main[1] - (n_burnin/10)) > 1) {
                                              try({
                                               M_inv_dense_main_current_interval <- cov(  trace_theta_test[kk,  (adapt_window_sequence_main[1] - (n_burnin/10)):(tail(adapt_window_sequence_main, 1)),  ] ,
                                                                                          use = "complete" )
                                              }, silent = TRUE)
                                            } else {
                                            try({
                                               M_inv_dense_main_current_interval <-   diag(M_inv_diag_vec_current_interval[index_main])  # cov(  trace_theta_test[kk,  (clip_iter-1):(tail(adapt_window_sequence_main, 1)),  ] ,
                                                                                                                                           #      use = "complete" )
                                            }, silent = TRUE)
                                           }

                                          }

                                         #  M_inv_dense_main_current_interval <- cov(  trace_theta_test[kk, adapt_window_sequence_main,  ] , use = "complete" )

                                        #    M_inv_dense_main_current_interval <-  as.matrix(forceSymmetric(  M_inv_dense_main_current_interval ))
                                          })

                                     #   }

                                        if  (  tail(M_inv_diag_vec_stored, 1) != 1  ) {
                                         #   weight_current <- 0.50
                                           weight_current <- 0.60
                                          # weight_current <- 0.75
                                            M_inv_diag_vec_stored[index_main] <- (1 - weight_current)*M_inv_diag_vec_stored[index_main] + weight_current*M_inv_diag_vec_current_interval[index_main]
                                            M_inv_dense_main_stored <-           (1 - weight_current)*M_inv_dense_main_stored           + weight_current*M_inv_dense_main_current_interval
                                        } else { ##  first adaptation stage
                                          M_inv_diag_vec_stored[index_main] <- M_inv_diag_vec_current_interval[index_main]
                                          M_inv_dense_main_stored  <- M_inv_dense_main_current_interval
                                        }


                                        M_dense_main <- BayesMVP::Rcpp_solve(M_inv_dense_main)
                                        M_inv_dense_main_chol <- t(chol(M_inv_dense_main))



                                 }

                                     if (ii %in% adapt_window_apply[c(-1)]) {

                                           message(cat(colourise( paste("Adapting Metric (M) for MAIN parameters " ), "green"), "\n"))

                                           M_inv_diag_vec[index_main] <- M_inv_diag_vec_stored[index_main]
                                           M_diag_vec[index_main] <-  1 / M_inv_diag_vec[index_main]

                                           if (dense_G_indicator == TRUE) {

                                                    M_inv_dense_main <-    M_inv_dense_main_stored
                                                    M_inv_dense_main_chol <- t(chol(M_inv_dense_main))

                                                 if (is.positive.definite(M_inv_dense_main) == FALSE) {
                                                   M_inv_dense_main <- as.matrix(nearPD(M_inv_dense_main, keepDiag = TRUE)$mat)
                                                   M_inv_dense_main <-  as.matrix(forceSymmetric(  M_inv_dense_main ))
                                                   M_inv_dense_main_chol <- t(chol(M_inv_dense_main))
                                                 }
                                                 try({

                                                     M_dense_main <- BayesMVP::Rcpp_solve(M_inv_dense_main)
                                                     M_dense_main <- as.matrix(forceSymmetric(  M_dense_main ))
                                                     M_dense_main_corr_mtx <- cov2cor(M_dense_main)

                                                       #  if (ii ==  (adapt_window_apply[c(-1)][1] + 1) )  {
                                                            M_dense_sqrt <-  expm::sqrtm(M_dense_main)
                                                       #  }

                                                 })

                                           }
                                     }

                    } else {

                        if (ii < n_burnin) {
                          if (ii >  25) {
                                M_inv_diag_vec[index_main] <- snaper_s[index_main]  # using "online" variance estimate
                                M_diag_vec[index_main] <-  1 / M_inv_diag_vec[index_main]

                                M_inv_diag_vec_stored = M_inv_diag_vec
                          }
                        }

                   }



                  })
                  
                  
                }
              }
              
 
              
 
                # if (ii < n_burnin * 0.5) {
                #   if (ii >  5) {
                #     M_inv_diag_vec[index_main] <- snaper_s[index_main]  # using "online" variance estimate
                #     M_diag_vec[index_main] <-  1 / M_inv_diag_vec[index_main]
                #     
                #    #   M_inv_diag_vec_stored = M_inv_diag_vec
                #   }
                # }
            
            
          
          
          
          # | -----------------------------------   PROPOSAL FOR  MAIN (or ALL) parameters-----------------------------------------------------------------------------------------------------------------------------------------
          
 
          # 
          # #
          try({
            
            
            
            # find initial epsilon
            if (ii == 1)  {
              
              # # 
              # # 
              # eps <- BayesMVP::R_fn_EHMC_find_initial_eps(theta. = theta_vec,
              #                                   indiactor_mixed_M. = FALSE,
              #                                   HMC. = HMC,
              #                                   index_subset. = index_subset,
              #                                   index_subset_main_dense. = index_main,
              #                                   y. = y,
              #                                   L. = 1,
              #                                   eps. = eps,
              #                                   velocity_0. = velocity,
              #                                   momentum_0. = velocity,
              #                                   testing. = FALSE,
              #                                   M_diag_vec. = M_diag_vec,
              #                                   M_main_dense. = diag(n_params_main),
              #                                   M_inv_dense_main.  = diag(n_params_main),
              #                                   M_Chol_main_dense. = diag(n_params_main),
              #                                   grad_x_initial. = grad,
              #                                   log_posterior_initial. = log_posterior,
              #                                   lp_and_grad_args. =  lp_and_grad_args,
              #                                   n_us. = n_us,
              #                                   n_params_main. = n_params_main)
              # 
              # 
              # #
              eps  <- eps
              
             eps <- 0.01
            }
            
            
            
            
            
            {
              

              
              if (MALA_main == TRUE) {
                L_main <- L_main_ii <-  1 ; tau_main <- eps
              } else {
                
                if (ii < clip_iter) {       # clip first phase of burn-in to MALA
                  
                  L_main_ii <- 1
                  L_main <- 1 ### 
                  tau_main <- eps
                  tau_main_ii <- tau_main
                  
                } else {
                  
                  # eigen_max_main
                  # eigen_max
                  # if (ii %in% c( (clip_iter - 5):(clip_iter + 5))) {tau_main= 100 * eps }
                 #  if (ii %in% c( (clip_iter - 5):(clip_iter + 5))) {tau_main=  sqrt(eigen_max) }
              #   #  if (ii %in% c( (clip_iter - 5):(clip_iter + 5))) {tau_main= 2 * sqrt(eigen_max) }
               #  if (ii %in% c( (clip_iter - 5):(clip_iter + 5))) {tau_main =  eps * 50 }
                  
                  
                  
              if ( max(clip_iter, 50) == 50) { 
                    
                    if (ii %in% c(clip_iter:50)) { 
                      
                    
                      L_main <- 20  ; 
                      tau_main <- eps * L_main 
                      tau_main_ii  <- runif(n = 1, min = 0, max = 2 * tau_main)
                      L_main_ii <-   ceiling(tau_main_ii / eps)
                  
                      
                    }
                    
                    
                    
                  }
                  
                  
                if (ii %in% c( (max(clip_iter, 50) + 1):(max(clip_iter, 50) + (n_burnin/2)))) {
                  
                  # tau_target =  2 *   sqrt(eigen_max_main) 
                 # tau_target =  1.7 *   sqrt(eigen_max_main) # 1.35
                  tau_target =  1.6 *   sqrt(eigen_max_main) 
                 #  tau_target =  1.5 *   sqrt(eigen_max_main)
               #   tau_target =  1.25 *   sqrt(eigen_max_main)
                 # tau_target =  1 *   sqrt(eigen_max_main) 
                  tau_target_interval = seq(from = eps, to = tau_target, length =  (n_burnin/2) + 5)
                  
                  iii = ii - max(clip_iter, 50) 
                  
                  tau_main = tau_target_interval[iii]
                  
                  }     # //// this seems to work well for N = 500 dataset. 
                  
                #  if (ii %in% c( (clip_iter - 5):(clip_iter + 5))) {tau_main=  2 *   (eigen_max) }
                  if (tau_main<eps) { tau_main=eps }
                  
                  
                  if  (  (main_L_manual == TRUE) )  {
                    
                    if (tau_main_jittered == TRUE) {
                      L_main <-   L_main_if_manual
                      tau_main_ii  <- runif(n = 1, min = 0, max = 2 * tau_main)
                      L_main_ii <-   ceiling(tau_main_ii / eps)
                    } else {
                      L_main <-    L_main_if_manual #  ceiling(tau_main_ii / eps)
                      L_main_ii <-   L_main
                      tau_main_ii  <-     tau_main
                    }
                    
                  }  else { 
                    
                    if (tau_main_jittered == TRUE) {         # draw jittered  tau (and hence L)
                      tau_main_ii  <- runif(n = 1, min = 0, max = 2 * tau_main)
                      L_main <-   ceiling(tau_main / eps)
                      L_main_ii <-   ceiling(tau_main_ii / eps)
                    } else {
                      tau_main_ii  <-  tau_main
                      L_main <-   ceiling(tau_main / eps)
                      L_main_ii <-  L_main
                    }
                    
                  }
                  
                }
                
                
                
                if (MALA_main == 1) {
                  L_main_ii <- 1
                  L_main <- 1
                }
              }
              
              
              if (main_eps_manual == TRUE) {
                eps_main  <- eps_main_if_manual
                eps_main_ii <- eps_main
              }
              
              
              
              
              
            }
            
            
          })
          
          
          {
            
            
            # if (ii < ( round(n_burnin*0.15, 0) ) ) {
            #   max_eps <- 0.01
            # }
            
            try({
              if (eps > max_eps) {
                eps_ii <- eps <- max_eps
              } else {
                eps_ii <- eps
              }
            })
            
            
            
            rhmc_outs_main  <-    NA
            
          }
          
          
          try({
            
            if (L_main_ii > 2^max_depth) {
              #  break
              L_main_ii <- 2^max_depth
              L_main <- 2^max_depth
              tau_main <- L_main * eps
            }
            L_main_vec[ii] <- L_main_ii
            
          })
          
          
          
          
          grad_main = TRUE
          grad_nuisance = TRUE
          
          
          lp_and_grad_args[[3]] = grad_main
          lp_and_grad_args[[4]] =  grad_nuisance
          
        #   index_subset = seq(from = 1, to = n_params)
          
          EHMC_single_iter_R_fn_output_main <- NA
          
          
          try({
 
            
            
            # if (ii == 1) { 
            #   R_diag <- rep(1, n_params_main)
            #   A_dense <- diag(R_diag)
            #   Empirical_Fisher_mat <- A_dense
            #   
            #   G_dense_main <-  diag(n_params_main) #  rep(1, n_params_main)
            #   G_inv_dense_main <-    diag(n_params_main) 
            #   G_inv_chol_dense_main <-    diag(n_params_main) 
            # }
            
            # if   ( (Euclidean_M_main == TRUE) && (dense_G_indicator == FALSE) ) {
            #   
            #         largest_var <- 1 #  max(1 / M_diag_vec)
            #         M_diag_vec_adj <-  M_diag_vec * largest_var
            #   
            #         G_dense_main <- diag( M_diag_vec_adj[index_main])
            #         G_inv_dense_main <- diag( 1 / M_diag_vec_adj[index_main])
            #         
            #         M_dense_main_adj <- G_dense_main
            #         M_inv_dense_main_adj <-  G_inv_dense_main
            #           
            # } else if  ( (Euclidean_M_main == FALSE)   )  { 
            #   
            #       M_us_and_with_EF_main <- c(M_diag_vec[index_us], diag(Empirical_Fisher_mat) )
            #       largest_var <-  1 # max(1 / M_us_and_with_EF_main)
            #       M_diag_vec_adj <-  M_us_and_with_EF_main * largest_var
            #     
            #       Empirical_Fisher_mat_adj <- Empirical_Fisher_mat
            #       A_dense_adj <- BayesMVP::Rcpp_solve(Empirical_Fisher_mat_adj)
            #       R_diag_adj <- diag(A_dense_adj)
            #    
            #      #  if (ii %in% adapt_window_apply[c(-1)]) {  # windowed (comment out for smooth / non-windowed)
            #               Empirical_Fisher_mat_adj_to_use <- Empirical_Fisher_mat_adj  
            #               A_dense_adj_to_use <- A_dense_adj    
            #               R_diag_adj_to_use <- R_diag_adj   
            #      #  }
            #         
            #         G_dense_main <- Empirical_Fisher_mat_adj_to_use
            #         G_inv_dense_main <- A_dense_adj_to_use
            #         
            #         if (dense_G_indicator == FALSE) { 
            #             G_dense_main <- diag(diag(Empirical_Fisher_mat_adj_to_use))
            #             G_inv_dense_main <- diag(diag(A_dense_adj_to_use))
            #         }
            #         
            # 
            #         M_dense_main_adj <- diag(n_params_main)
            #         M_inv_dense_main_adj <- diag(n_params_main)
            #         
            # } else if     ( (Euclidean_M_main == TRUE) && (dense_G_indicator == TRUE) )  { 
              
                    largest_var <-   1  # max(1 / M_diag_vec)
                    M_diag_vec_adj <-  M_diag_vec * largest_var
                    sqrt_adj_vars <- sqrt(M_diag_vec_adj[index_main])
                    
                   
                  
                    num =  ceiling(n_burnin/100)  ;  num # 3 #  10 # 5 # round(n_burnin/100, 0)
                    
                    if (n_burnin < 500)   num =  5;
                    
                    if (metric_type == "Hessian") {
                      
                         if   ((ii %in% c(round(n_burnin/5), n_burnin - round(n_burnin/5))) && (ii %% num) == 0) {
                     #   if (ii %in%  c(adapt_window_apply[c(-1)] )) {
                              
                              # 
                       
                               if (ii > (n_burnin/10)) {
                                  theta_vec_us <- head(snaper_m, n_us)
                                  theta_vec_main <- snaper_m[index_main]
                               } else { 
                                  theta_vec_us <- head(theta_vec, n_us)
                                  theta_vec_main <- theta_vec[index_main]
                               }
                           
                           
                           theta_vec_us <- head(snaper_m, n_us)
                           theta_vec_main <- snaper_m[index_main]
                               
                          #  
                          #  try({
                          #  for (iiiii in 1:n_params_main) {
                          #  #   theta_vec_main[iiiii] <- median(  trace_theta_test[kk, (ii - 10):(ii-1), iiiii], na.rm = T )
                          # #   theta_vec_main[iiiii] <- median(  trace_theta_test[kk, (ii - 25):(ii-1), iiiii], na.rm = T )
                          #   #  theta_vec_main[iiiii] <- median(  trace_theta_test[kk, (ii - 50):(ii-1), iiiii], na.rm = T )
                          #    theta_vec_main[iiiii] <- median(  trace_theta_test[kk, (ii - 100):(ii-1), iiiii], na.rm = T )
                          #    # theta_vec_main[iiiii] <-  matrixStats::colMedians(  trace_theta_test[, (ii - 10):(ii-1), iiiii], na.rm = T )
                          #  }
                          #  })
                           
                           
                           
                           
                             
                              theta_vec_main_inc <- theta_vec_main
                              Hessian <- array(0, dim = c(n_params_main, n_params_main))
                              
                              
                              outs_manual_grad <- BayesMVP::fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float(theta = c(theta_vec_us, theta_vec_main_inc),
                                                                                                                   y = y,
                                                                                                                   lp_and_grad_args)
                              
                              grad <- -  head(outs_manual_grad[-1], n_params)
                              
                              
                              for (i_param in 1:n_params_main) {
                                
                                theta_vec_main_inc[i_param] <-        theta_vec_main[i_param] + 0.001
                                
                                outs_manual_grad <- BayesMVP::fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float(theta = c(theta_vec_us, theta_vec_main_inc),
                                                                                                                     y = y,
                                                                                                                     lp_and_grad_args)
                                
                                grad_numdiff <- -  head(outs_manual_grad[-1], n_params)
                                
                                Hessian[i_param, ] <- ( grad_numdiff[index_main] - grad[index_main] ) /  0.001
                                
                                theta_vec_main_inc = theta_vec_main # reset
                                
                              }
                              
                              Hessian <-   Hessian
                              
                              Chol_neg_Hessian <- NULL
                              
                              try({
                                Chol_neg_Hessian <- t(chol(Hessian))
                              }, silent = TRUE)
                              
                              if (is.null(Chol_neg_Hessian)) {
                                pd_indicator <- 0
                              } else {
                                pd_indicator <- 1
                              }
                              
                              
                              try({
                                if (pd_indicator == 0) {
                                  Hessian <-  as.matrix(nearPD(Hessian)$mat)
                                  Hessian <- as.matrix(Matrix::forceSymmetric(Hessian))
                                }
                              },silent = TRUE)
                              
                              
                              
                              
                     
                            #    M_dense_main <- (1-eta_m)*M_dense_main + eta_m*Hessian
                            
                           #    hess_adapt_weight <- 0.25 # 0.50 # 0.90 # 0.75
                               hess_adapt_weight <-  0.50 
                             #   hess_adapt_weight <-  0.75
                               M_dense_main <- (1-hess_adapt_weight)*M_dense_main + hess_adapt_weight*Hessian
                              
                          #    M_dense_main <-  Hessian #  (1-eta_m)*M_dense_main + eta_m*Hessian
                              
                              Chol_neg_Hessian <- NULL
                              
                              try({
                                Chol_neg_Hessian <- t(chol(M_dense_main))
                              }, silent = TRUE)
                              
                              if (is.null(Chol_neg_Hessian)) {
                                pd_indicator <- 0
                              } else {
                                pd_indicator <- 1
                              }
                              
                              
                              try({
                                if (pd_indicator == 0) {
                                  M_dense_main <-  as.matrix(nearPD(M_dense_main)$mat)
                                  M_dense_main <- as.matrix(Matrix::forceSymmetric(M_dense_main))
                                }
                              },silent = TRUE)
                              
                              M_inv_dense_main <-    BayesMVP::Rcpp_solve(M_dense_main)
                              M_inv_dense_main_chol <- t(chol(M_inv_dense_main))
                              
                              M_dense_main_adj <-  M_dense_main # diag(sqrt_adj_vars) %*% M_dense_main_corr_mtx %*% diag(sqrt_adj_vars)
                              M_inv_dense_main_adj <-   M_inv_dense_main
                              
                              
                         } else if (ii < round(n_burnin/5)) {

                           M_dense_main <- diag(n_params_main)
                           M_inv_dense_main <- diag(n_params_main)
                           M_inv_dense_main_chol <- t(chol(M_inv_dense_main))
                           
                           M_dense_main_adj <-  M_dense_main # diag(sqrt_adj_vars) %*% M_dense_main_corr_mtx %*% diag(sqrt_adj_vars)
                           M_inv_dense_main_adj <-   M_inv_dense_main
                           
                         }  else { 
                           
                           M_dense_main_adj <-  M_dense_main # diag(sqrt_adj_vars) %*% M_dense_main_corr_mtx %*% diag(sqrt_adj_vars)
                           M_inv_dense_main_adj <-   M_inv_dense_main
                           
                         }
                            
                    
                    } else {

   
                      

                      
                        if ( (ii > 0.5 * n_burnin) ) {
                          M_dense_main_adj <-  M_dense_main # diag(sqrt_adj_vars) %*% M_dense_main_corr_mtx %*% diag(sqrt_adj_vars)
                          M_inv_dense_main_adj <-    M_inv_dense_main  #  BayesMVP::Rcpp_solve(M_dense_main_adj)
                        } else {
                          M_dense_main_adj <-  diag(M_diag_vec[index_main]) # diag(diag(M_dense_main))
                          M_inv_dense_main_adj <-     diag(1 / M_diag_vec[index_main])  #  BayesMVP::Rcpp_solve(M_dense_main_adj)
                        }

                    }

                    
                    # G_dense_main <- M_dense_main_adj
                    # G_inv_dense_main <- M_inv_dense_main_adj
                    

                    
                    M_diag_vec[index_main] <- diag(M_dense_main_adj)
                    M_inv_diag_vec[index_main] <- 1/   M_diag_vec[index_main] 

                
            # }
            

            
            
            # M_dense_main_adj <-  diag(M_diag_vec[index_main]) # diag(diag(M_dense_main))
            # M_inv_dense_main_adj <-     diag(1 / M_diag_vec[index_main])  #  BayesMVP::Rcpp_solve(M_dense_main_adj)
            
            # for (m in 1:length(M_diag_vec_adj)) {
            #   if ( (1/M_diag_vec_adj)[m] < 0.0001   )  {  
            #     M_diag_vec_adj[m] = 1 
            #   }
            # }
            
            if (main_L_manual == TRUE) {
            
                L_main <- L_main_if_manual
                L_main_ii <-  runif(n = 1, min = 1, max = 2*L_main)
            
            }
            
   
            L_main_vec[ii] <- L_main_ii
            
            # BayesMVP:: 
            # lcmMVPbetav2::
         
            rhmc_outs_main  <-         BayesMVP::LMC_single_iteration_subset_only_diag_or_dense_G_simple(
                                                                                              theta. = theta_vec,
                                                                                              autodiff. = autodiff.,
                                                                                              Euclidean_M_main. = Euclidean_M_main,
                                                                                              dense_G_indicator. = dense_G_indicator,
                                                                                              n_burnin. = n_burnin,
                                                                                              lp_and_grad_args. = lp_and_grad_args,
                                                                                              iter. = ii,
                                                                                              velocity_0. = velocity_0,
                                                                                              M_main_vec_if_Euclidean. = M_diag_vec[index_main],
                                                                                              M_us_vec_if_Euclidean. =  M_diag_vec[index_us],
                                                                                              M_dense_main. = M_dense_main_adj,
                                                                                              M_inv_dense_main. = M_inv_dense_main_adj,
                                                                                              M_inv_dense_main_chol. = M_inv_dense_main_chol,
                                                                                              numerical_diff_e. = numerical_diff_e,
                                                                                              L. =    L_main_ii,
                                                                                              epsilon. = eps,
                                                                                              grad_initial. =   grad,
                                                                                              log_posterior_initial. =  log_posterior,
                                                                                              y. = y,
                                                                                              NT_us. = NT_us, 
                                                                                              individual_log_lik_initial. = individual_log_lik, 
                                                                                              index_main. = index_main)
 
            
            rhmc_outs_main$p_jump  
            
            
            #   if   (  EHMC_single_iter_R_fn_output_main$outs[2, 1]  ==  1  )   {
            if   (   rhmc_outs_main$div   ==  1   )   {
              
              #   if (EHMC_single_iter_R_fn_output_main$div == 1) {
              if   (      rhmc_outs_main$div   ==  1  )   {
                p_jump  <-  0
                
                print(paste("ERROR - MAIN PARAMS - CHAIN - DIV", kk))
                if (ii < n_burnin) {
              #    eps <-  0.50 * eps
                }
                
                error_count <- error_count + 1
                
                # if (error_count > 100) {
                #   break
                # }
                
              } else { 
                p_jump  <-  0
                
                print(paste("ERROR - MAIN PARAMS - CHAIN", kk))
                if (ii < n_burnin) {
                #  eps <-  0.95 * eps
                }
              }
              
            } else {
              
 
              
              p_jump  <- rhmc_outs_main$p_jump ;  p_jump #print(p_jump)
              accept <-   rhmc_outs_main$accept 
              

                theta_vec_initial <- theta_vec
                theta_vec <- rhmc_outs_main$theta  
                theta_vec_prop <- rhmc_outs_main$prop
             
              grad_initial <-  grad
              grad <- rhmc_outs_main$grad_x 
              grad_prop <- rhmc_outs_main$grad_prop
              
              log_posterior    <- rhmc_outs_main$log_posterior 
              log_posterior_prop    <- rhmc_outs_main$log_posterior_prop
              log_posterior_initial    <- rhmc_outs_main$log_posterior_0
              
              velocity <-  rhmc_outs_main$velocity
              velocity_prop <-  rhmc_outs_main$velocity_prop
              velocity_0 <-  rhmc_outs_main$velocity_0
              
              
              # momentum <-  rhmc_outs_main$momentum
              # momentum_prop <-  rhmc_outs_main$momentum_prop
              # momentum_0 <-  rhmc_outs_main$momentum_0
              
             #   diag_vec_G <-  rhmc_outs_main$G_full_diag_vec  
              
              # dense_Hessian_main = rhmc_outs_main$dense_Hessian_main
              # G_dense_main = rhmc_outs_main$G_dense_main
              # G_inv_dense_main = rhmc_outs_main$G_inv_dense_main
              # G_inv_chol_dense_main =   rhmc_outs_main$G_inv_chol_dense_main
              # neg_Hessian_accepted =  rhmc_outs_main$neg_Hessian_accepted 
              # 
              individual_log_lik = rhmc_outs_main$individual_log_lik
              
              
              
              
              
              

              
              
              
              
 
              
              
            }
          })
          
          
          
          
          
          #  # | -------------------------  Tau Adaptation - for MAIN (or ALL) parameters ------------------------------------------------------------------------

          if (main_L_manual == FALSE)  {
          if   ( (ii < n_burnin)  ) {
            
            try({ 
              if (MALA_main == FALSE) {
                  
                  if (ii < 5) theta_mean_across_chains <- theta_vec
                  
                  if (ii < 2) {
                    snaper_m <- theta_vec
                  }
                  

                  
                  snaper_m <- (1-eta_m)*snaper_m + eta_m*theta_vec
                  snaper_s <- (1-eta_m)*snaper_s + eta_m* ( theta_vec  - snaper_m)^2   # update s (and M, if smooth) 
 
                  sqrt_M_pos <-   sqrt(M_diag_vec)
                  sqrt_M_prop <-   sqrt_M_pos
 
 
                index_subset =  index_main
                
                # if (corr_param == "latent_trait") { 
                #   index_subset = c( (n_us+1):(n_us + 2 * n_tests), (n_us+1+n_corrs):n_params)
                #   index_subset_excl_known  <- index_subset
                # }
                if (at_least_one_corr_known_indicator == 1) { 
                  index_subset = index_subset_excl_known
                  index_subset_known <-   index_main[is.na(pmatch(index_main, index_subset_excl_known ))]
                  theta_vec_initial[index_subset_known] <- rnorm(n = length(index_subset_known))
                  theta_vec[index_subset_known] <- rnorm(n = length(index_subset_known))
                  velocity[index_subset_known] <- rnorm(n = length(index_subset_known))
                  velocity_0[index_subset_known] <- rnorm(n = length(index_subset_known))
                }
 
                
                
              
                
                
                   if (ii > eta_w & eigen_max_main > 0) {
                     
                      x_c <-  sqrt_M_pos * ( theta_vec - snaper_m) 
                      if (dense_G_indicator == TRUE)  {
                       #   M_chol <- t(chol(M_dense_main))
                        if ( (ii > 0.5 * n_burnin) ) {
                          #   M_chol <-   diag(sqrt(M_diag_vec[index_main])) # M_dense_sqrt  # expm::sqrtm(M_dense_main)
                            M_chol <-    M_dense_sqrt  # expm::sqrtm(M_dense_main)
                        } else { 
                           M_chol <-  diag(sqrt(M_diag_vec[index_main]))
                        }
                        
                         x_c[index_main] <-  c(M_chol %*% ( theta_vec - snaper_m)[index_main])
                      }
                      current_w <- x_c * sum( x_c * eigen_vector) 
                      snaper_w <- snaper_w * ((ii-eta_w)/(ii+1)) +  ((eta_w+1)/(ii+1)) * current_w
                      
                      eigen_max <- sqrt(sum(snaper_w^2))
                      eigen_vector  <- snaper_w/eigen_max # same as z
                      
                      eigen_max_main <- sqrt(sum(snaper_w[index_main]^2))
                      eigen_vector_main  <- snaper_w[index_main]/eigen_max_main # same as z
                   }
                
 
                  # update tau
                    pos_c_array  <- eigen_vector  * sqrt_M_pos * (theta_vec_initial - snaper_m)  
                    if (dense_G_indicator == TRUE)   pos_c_array[index_main]  <-  c(eigen_vector[index_main] %*% M_chol %*% (theta_vec_initial - snaper_m)[index_main])
                    pos_c_array <-  ifelse(is.infinite(pos_c_array ), 0,    pos_c_array  )  
                    pos_c_per_chain <- sum( pos_c_array[index_subset]  , na.rm = T  )   #   = sqrt( phi(x_{0})  )
                    
                    prop_c_array  <- eigen_vector * sqrt_M_prop * (theta_vec - snaper_m)  
                    if (dense_G_indicator == TRUE)   prop_c_array[index_main]  <-  c(eigen_vector[index_main] %*% M_chol %*% (theta_vec - snaper_m)[index_main])
                    prop_c_array <-  ifelse(is.infinite(prop_c_array), 0,    prop_c_array  ) 
                    prop_c_per_chain <- sum( prop_c_array[index_subset]  , na.rm = T  )    # = sqrt(  phi(x_{tau})  )
                    
                    diff_sq <- ((prop_c_per_chain)^2-(pos_c_per_chain)^2) # = phi(x_{tau})  - phi(x_{0})
                    m_sq_per_chain <-  (pos_c_per_chain^2+prop_c_per_chain^2)/2 # (1-eta_m)*m_sq_per_chain + eta_m*(pos_c_per_chain[kk]^2+prop_c_per_chain[kk]^2)/2
                    
                    pos_c_grad_per_chain <-  2 *   pos_c_per_chain * sqrt_M_pos * eigen_vector  # = grad_phi(X_{0})
                    prop_c_grad_per_chain <-   2 *   prop_c_per_chain * sqrt_M_prop * eigen_vector  # = grad_phi(X_{tau})
                    if (dense_G_indicator == TRUE) {
                      pos_c_grad_per_chain[index_main] <-  2 *   c(pos_c_per_chain[index_main] %*% M_chol %*% eigen_vector[index_main])  # = grad_phi(X_{0})
                      prop_c_grad_per_chain[index_main] <-   2 *   c(prop_c_per_chain[index_main] %*% M_chol %*% eigen_vector[index_main])  # = grad_phi(X_{tau})
                    }
 
                    if (ii > eta_w & eigen_max_main > 0) {
                      v_sq_per_chain <-    (0.5*((pos_c_per_chain^2-m_sq)^2+(prop_c_per_chain^2-m_sq)^2))  
                      cov_sq_per_chain <-    ((pos_c_per_chain^2-m_sq)*(prop_c_per_chain^2-m_sq))
                      
                      m_sq  <- m_sq * (1 - eta_m) +     (m_sq_per_chain) * eta_m
                      v_sq <- v_sq * ((ii-eta_w)/(ii+1)) +     (v_sq_per_chain) * ((eta_w+1)/(ii+1))
                      cov_sq <- cov_sq * ((ii-eta_w)/(ii+1)) +     (cov_sq_per_chain) * ((eta_w+1)/(ii+1))
                      
                      
                      if (fix_rho == TRUE) {
                        rho <-  1
                      } else {
                        rho <-  cov_sq   / v_sq
                      }
                      
                    }
 


                 #   tau_noisy_grad_val =  2*diff_sq*(prop_c_per_chain*v_c + pos_c_per_chain*v_0)-(0.5*(1+min(1,rho))/(tau_main))*(diff_sq)^2
                    if (ii > eta_w & eigen_max_main > 0) {
                 #  tau_noisy_grad_val = diff_sq*( sum(prop_c_grad_per_chain  * ( 1 / (sqrt_M_pos^2)  ) *  momentum_prop )  +  sum(pos_c_grad_per_chain  * ( 1 / (sqrt_M_pos^2)  ) * momentum_0 ) )-(0.5*(1+min(1,rho))/(tau_main))*(diff_sq)^2
                  tau_noisy_grad_val = diff_sq*( sum(prop_c_grad_per_chain[index_subset]  * velocity[index_subset] )  +  sum(pos_c_grad_per_chain[index_subset]  * velocity_0[index_subset]  ) ) - 
                                        (0.5*(1+min(1,rho))/(tau_main_ii))*(diff_sq)^2 
                    
                    tau_noisy_grad <- ifelse(is.na(tau_noisy_grad_val), 0, tau_noisy_grad_val)
                    
                    if ( ii %% 20 == 0) {
                      print(paste("mean rho = ", round(mean(rho), 3)))
                    }
                    
                    tau_m_adam <- beta1_adam*tau_m_adam + (1-beta1_adam)*tau_noisy_grad
                    tau_v_adam <- beta2_adam*tau_v_adam + (1-beta2_adam)*tau_noisy_grad^2
                    tau_m_hat <-  tau_m_adam/(1-beta1_adam^ii)
                    tau_v_hat <-  tau_v_adam/(1-beta2_adam^ii)
                    # note: actual LR will be ~ LR at start of burnin and decrease to 0.05*LR at end of burnin (i.e. the LR will smoothly decrease as iterations decrease)
                    # current_alpha <- learning_rate_main  * (1 - (((1 - learning_rate_main)*ii)/n_burnin.) )
                    
                  #   current_alpha <- learning_rate_main  * (1 - 0.95*ii/n_burnin)
                    current_alpha <- learning_rate_main *(  1-(1 - learning_rate_main)*ii/(n_burnin) )
                    log_tau_val <- log(abs(tau_main)) + current_alpha*tau_m_hat/(sqrt(tau_v_hat) + eps_adam)
                    log_tau <- ifelse(is.na(log_tau_val), log_tau, log_tau_val)
                    tau_main <- exp(log_tau)
                    }
                    
                    
                    index_subset = index_main
                    
              }
                    
 
              
              
            })
            
          }
          } else {
            theta_mean_across_chains <- theta_vec
           # tau_main <-  L_main_if_manual * eps
            L_main <- L_main_if_manual
            L_main_ii <- L_main_if_manual
          }   
 
            
            
  
          
          try({ 
            {
              p_jump_vec[ii] <- p_jump
 
              
              theta_mean <-  snaper_m
              theta_var <-  snaper_s
              
              try({
                trace_theta_test[kk, ii, ] <-   theta_vec[index_main] # for main params store all post-burnin iterations
              })
              
              
            }
          })
          
          # | ------------ Manifold tests -Adaptation of epsilon  using ADAM ---------------------------------------------------------------
          
          try({ 
            if (main_eps_manual == FALSE) {
              
              adapt_eps_outs <-   BayesMVP::R_fn_adapt_eps_ADAM(eps. = eps,
                                                       eps_m_adam. = eps_m_adam,
                                                       eps_v_adam. = eps_v_adam,
                                                       iter. = ii,
                                                       n_burnin. = n_burnin,
                                                       learning_rate. = learning_rate_main, 
                                                       p_jump. = p_jump,
                                                       adapt_delta. = adapt_delta,
                                                       beta1_adam. = beta1_adam,
                                                       beta2_adam. = beta2_adam,
                                                       eps_adam. = eps_adam,
                                                       L_manual. = main_L_manual,
                                                       L_ii. = L_main_ii)
              
              eps <- adapt_eps_outs$eps
              eps_m_adam <- adapt_eps_outs$eps_m_adam
              eps_v_adam <- adapt_eps_outs$eps_v_adam
            }
            
            
            
            p_jump_main_vec[ii] <- p_jump
            
            
            eps_mean_main <- eps
            
          })
          
          try({
            
            if (ii %% 10 == 0) { 
              
              message(  paste( round( (ii/ (n_iter + n_burnin)) * 100, 1), "% done - chain", kk)  )
 
            }
            
            if (ii %% 20 == 0) { 
              
              print(paste("mean acceptance prob (main) = ", round(mean(p_jump_main_vec), 2)))
              
              print(paste("tau = ", round(tau_main, 3)))
              print(paste("eps = ", round(eps, 4)))
              print(paste("L_mean (main) = ", ceiling(tau_main / eps )) )
              print(paste("L_main_ii (main) = ", L_main_ii))
              
              
              
            }
            
          })
          
 
          
 
          
        }   # | ------------   Manifold tests -    end of iterations (ii loop) -----------------------------------------------------------       
        
 
        
        
  
      
      #W#     output_list <- list()
      
      try({   L_main_mean <- mean(L_main_vec, na.rm = TRUE)  })
      try({   L_main_mean_samp <- mean(L_main_vec[(n_burnin+1):(n_iter + n_burnin)] )  })
 
      

      
      
      try({ 
        return(list(trace_theta_test = trace_theta_test, 
                    eps_mean_main =  eps, # eps_mean_main,
                    L_main_mean =  L_main_mean,
                    1,
                    time_burnin = 0, # 5
                    time_sampling = 0,
                    L_main_mean_samp,
                    trace_theta_test_full = 0 ,
                    diag_vec_G = 0,
                    tau_main = tau_main, # 10 
                    theta_vec = theta_vec, 
                    A_dense = 0, 
                    R_diag = 0,
                    Empirical_Fisher_mat = 0,
                    G_dense_main = G_dense_main, # 15
                    L_main = L_main,
                    M_diag_vec = M_diag_vec, 
                    snaper_m = snaper_m,  #####
                    snaper_s = snaper_s, 
                    snaper_w = snaper_w, # 20
                    m_sq = m_sq, 
                    v_sq = v_sq, 
                    cov_sq = cov_sq, 
                    tau_m_adam = tau_m_adam, 
                    tau_v_adam = tau_v_adam,  # 25
                    theta_vec_initial = theta_vec_initial, 
                    grad = grad, 
                    log_posterior = log_posterior, 
                    M_inv_diag_vec_stored = M_inv_diag_vec_stored,
                    M_inv_dense_main_stored = M_inv_dense_main_stored, # 30
                    M_dense_main = M_dense_main,
                    M_inv_dense_main = M_inv_dense_main,
                    M_dense_main_corr_mtx = 0, 
                    Empirical_Fisher_mat_adj_to_use = 0,
                    A_dense_adj_to_use = 0, # 35
                    R_diag_adj_to_use = 0,
                    theta_mean_across_chains = theta_mean_across_chains ,
                    eigen_vector = eigen_vector,
                    1,
                    1 # 40
        ))
      })
      
    } )  # | ------------   Manifold tests -   end of "foreach" loop -----------------------------------------------------------
  
  

 
}
  
  
  for (kk in 1:n_chains) {
      trace_theta_test[kk, partitions[[interval]],   ] <-  non_BCA_burnin_outs[[1]][[kk]][kk, partitions[[interval]],    ]
  }
  

  # non_BCA_burnin_outs[[3]]
  
  mean_L_burnin <- non_BCA_burnin_outs[[3]]
  mean_L_burnin <- mean(unlist(mean_L_burnin), na.rm = TRUE) # mean 
  
  ## reset adaptation params 
  # Get mean epsilon
  eps_per_chain <- non_BCA_burnin_outs[[2]]
  eps <- mean(unlist(eps_per_chain), na.rm = TRUE) # mean 
 #  eps <- median(unlist(eps_per_chain), na.rm = TRUE) # median 
  
  # Get mean L
  L_per_chain <-    non_BCA_burnin_outs[[16]]
  L_main <- L <- mean(unlist(L_per_chain), na.rm = TRUE) # mean 
 #  L_main <- L <- median(unlist(L_per_chain), na.rm = TRUE) # median 
  
  # Get mean tau
  if (main_L_manual == FALSE) {
    tau_per_chain <-    non_BCA_burnin_outs[[10]]
    tau_main <- tau <- mean(unlist(tau_per_chain), na.rm = TRUE) # mean 
   #  tau_main <- tau <- median(unlist(tau_per_chain), na.rm = TRUE) # median 
  } else { 
    tau_main <- tau <-  L_main * eps 
  }
  
  
  # # Get mean  G (diag, all params) - should be adjusted for max variance
  # diag_vec_G_per_chain <- non_BCA_burnin_outs[[9]]
  # diag_vec_G <-  Reduce("+", diag_vec_G_per_chain)/ length(diag_vec_G_per_chain)
  # #  diag_vec_G[index_us] <- 1 # shouldnt need to do this
  
  # Get mean  M  (diag, all params) - should NOT be adjusted for max variance
  M_diag_vec_per_chain <- non_BCA_burnin_outs[[17]]
  M_diag_vec <-  Reduce("+", M_diag_vec_per_chain)/ length(M_diag_vec_per_chain)
  #  M_diag_vec[index_us] <- 1 # shouldnt need to do this
  
  # # Get mean A_dense (main params only)
  # A_dense_per_chain <- non_BCA_burnin_outs[[12]]
  # A_dense <-  Reduce("+", A_dense_per_chain)/ length(A_dense_per_chain)
  # A_dense <-  as.matrix( forceSymmetric(A_dense) )
  # 
  # # Get mean R_diag (main params only)
  # R_diag_per_chain <- non_BCA_burnin_outs[[13]]
  # R_diag <-  Reduce("+", R_diag_per_chain)/ length(R_diag_per_chain)
  # 
  # # Get mean Empirical_Fisher_mat (main params only)
  # Empirical_Fisher_mat_per_chain <- non_BCA_burnin_outs[[14]]
  # Empirical_Fisher_mat <-  Reduce("+", Empirical_Fisher_mat_per_chain)/ length(Empirical_Fisher_mat_per_chain)
  # Empirical_Fisher_mat <-  as.matrix( forceSymmetric(Empirical_Fisher_mat) )
  # 
  # # Get mean G_dense_main (main params only)
  # G_dense_main_per_chain <- non_BCA_burnin_outs[[15]]
  # G_dense_main <-  Reduce("+", G_dense_main_per_chain)/ length(G_dense_main_per_chain)
  # G_dense_main <-  as.matrix( forceSymmetric(G_dense_main) )
  # 
  # if (dense_G_indicator == TRUE) {
  #   G_inv_dense_main <- BayesMVP::Rcpp_solve(G_dense_main)  
  #   G_inv_dense_main <-  as.matrix( forceSymmetric(G_inv_dense_main) )
  # }
  # 
  # G_inv_chol_dense_main <- t(chol(G_inv_dense_main))
  
  # means of other ADAM adaptation params 
  snaper_m <-  Reduce("+",  non_BCA_burnin_outs[[18]])/ length( non_BCA_burnin_outs[[18]])
  snaper_s <-  Reduce("+",  non_BCA_burnin_outs[[19]])/ length( non_BCA_burnin_outs[[19]])
  snaper_w <-  Reduce("+",  non_BCA_burnin_outs[[20]])/ length( non_BCA_burnin_outs[[20]])
  m_sq <-  Reduce("+",  non_BCA_burnin_outs[[21]])/ length( non_BCA_burnin_outs[[21]])
  v_sq <-  Reduce("+",  non_BCA_burnin_outs[[22]])/ length( non_BCA_burnin_outs[[22]])
  cov_sq <-  Reduce("+",  non_BCA_burnin_outs[[23]])/ length( non_BCA_burnin_outs[[23]])
  tau_m_adam <-  Reduce("+",  non_BCA_burnin_outs[[24]])/ length( non_BCA_burnin_outs[[24]])
  tau_v_adam <-  Reduce("+",  non_BCA_burnin_outs[[25]])/ length( non_BCA_burnin_outs[[25]])
  
  
  # Get starting values for each chain
  theta_initial_values_per_chain <- array(dim = c(n_params, n_chains))
  grad_initial_values_per_chain <- array(dim = c(n_params, n_chains))
  log_posterior_initial_values_per_chain <- rep(NA, n_chains)
  
  # str(trace_theta_test_per_chain[,,,kk])
  # str( non_BCA_burnin_outs[[1]])
  dim_1 <-  dim( non_BCA_burnin_outs[[1]][[1]])[1]
 #   trace_theta_test_per_chain <-  array(dim = c( dim_1 , n_burnin + 1, n_params_main, n_chains))
  
  for (kk in 1:n_chains) {
    theta_initial_values_per_chain[, kk] <- non_BCA_burnin_outs[[11]][[kk]]
    grad_initial_values_per_chain[, kk] <- non_BCA_burnin_outs[[27]][[kk]]
    log_posterior_initial_values_per_chain[kk] <-  non_BCA_burnin_outs[[28]][[kk]]
   #  trace_theta_test_per_chain[,,,kk] <- non_BCA_burnin_outs[[1]][[kk]]
  }
  
 
  # Get mean  M  (diag, all params) - should NOT be adjusted for max variance
  M_inv_diag_vec_stored_per_chain <- non_BCA_burnin_outs[[29]]  #  Empirical_Fisher_mat_adj_to_use <- Empirical_Fisher_mat_adj
  M_inv_diag_vec_stored <-  Reduce("+", M_inv_diag_vec_stored_per_chain)/ length(M_inv_diag_vec_stored_per_chain)
  #  M_diag_vec[index_us] <- 1 # shouldnt need to do this
 
  
  M_inv_dense_main_stored_per_chain <- non_BCA_burnin_outs[[30]]
  M_inv_dense_main_stored <-  Reduce("+", M_inv_dense_main_stored_per_chain)/ length(M_inv_dense_main_stored_per_chain)
  M_inv_dense_main_stored <-  as.matrix( forceSymmetric(M_inv_dense_main_stored) )
  
  M_dense_main_per_chain <- non_BCA_burnin_outs[[31]]
  M_dense_main <-  Reduce("+", M_dense_main_per_chain)/ length(M_dense_main_per_chain)
  M_dense_main <-  as.matrix( forceSymmetric(M_dense_main) )
  
  M_inv_dense_main <- BayesMVP::Rcpp_solve(M_dense_main)
  M_inv_dense_main_chol <- t(chol(M_inv_dense_main))
  
  M_dense_sqrt <- expm::sqrtm(M_dense_main)
 
  
  # M_inv_dense_main_per_chain <- non_BCA_burnin_outs[[32]]
  # M_inv_dense_main <-  Reduce("+", M_inv_dense_main_per_chain)/ length(M_inv_dense_main_per_chain)
  # M_inv_dense_main <-  as.matrix( forceSymmetric(M_inv_dense_main) )
  
  # 
  # M_dense_main_corr_mtx_per_chain <-  non_BCA_burnin_outs[[33]]
  # M_dense_main_corr_mtx <-  Reduce("+", M_dense_main_corr_mtx_per_chain)/ length(M_dense_main_corr_mtx_per_chain)
  # M_dense_main_corr_mtx <-  as.matrix( forceSymmetric(M_dense_main_corr_mtx) )
  
  
  # Empirical_Fisher_mat_adj_to_use_per_chain <-  non_BCA_burnin_outs[[34]]
  # Empirical_Fisher_mat_adj_to_use <-  Reduce("+", Empirical_Fisher_mat_adj_to_use_per_chain)/ length(Empirical_Fisher_mat_adj_to_use_per_chain)
  # Empirical_Fisher_mat_adj_to_use <-  as.matrix( forceSymmetric(Empirical_Fisher_mat_adj_to_use) )
  # 
  # A_dense_adj_to_use_per_chain <-  non_BCA_burnin_outs[[35]]
  # A_dense_adj_to_use <-  Reduce("+", A_dense_adj_to_use_per_chain)/ length(A_dense_adj_to_use_per_chain)
  # A_dense_adj_to_use <-  as.matrix( forceSymmetric(A_dense_adj_to_use) )
  # 
  # 
  # R_diag_adj_to_use_per_chain <- non_BCA_burnin_outs[[36]]
  # R_diag_adj_to_use <-  Reduce("+", R_diag_adj_to_use_per_chain)/ length(R_diag_adj_to_use_per_chain)

  
  
  
  theta_mean_per_chain <- non_BCA_burnin_outs[[37]]
  theta_mean_across_chains <-  Reduce("+", theta_mean_per_chain)/ length(theta_mean_per_chain)
  
  largest_var <-   1  # max(1 / M_diag_vec)
  M_diag_vec_adj <-  (1 / M_inv_diag_vec_stored) * largest_var
  
  
  # #update mean w (using median theta across chains)
  # eta_w <- 3
  # if (ii > eta_w & eigen_max >  0) {
  #   
  #   eigen_vector_per_chain <- theta_vec_per_chain <- x_c_per_chain <- snaper_w_per_chain_current_iter <- array(dim = c(n_chains, n_params))
  #   
  #   for (kkk in 1:n_chains) {
  #     theta_vec_per_chain[kkk, ] <- non_BCA_burnin_outs[[11]][[kkk]]
  #     eigen_vector_per_chain[kkk, ] <- non_BCA_burnin_outs[[38]][[kkk]]
  #     x_c_per_chain[kkk, ] <-  sqrt(M_diag_vec_adj) * ( theta_vec_per_chain[kkk, ] - snaper_m) # update centered and scaled x
  #     #  snaper_z <- snaper_w / eigen_max # update z
  #     snaper_w_per_chain_current_iter[kkk, ] <- sum(eigen_vector_per_chain[kkk, ] *   x_c_per_chain[kkk, ]) * x_c_per_chain[kkk, ]
  #   }
  #   
  #   snaper_w <- snaper_w * ((ii-eta_w)/(ii+1)) +    snaper_w_per_chain_current_iter[kkk, ] * ((eta_w+1)/(ii+1))
  #   
  #   
  # }
  
  
  
  
  print(tau_main)
  print(L_main)
  print(eps)
  
  

  
  #   tictoc::tic("burnin timer")
  

  

} # end of for loop for intervals 


print(tictoc::toc(log = TRUE))
log.txt <- tictoc::tic.log(format = TRUE)
tictoc::tic.clearlog()
time_burnin <- unlist(log.txt)

try({  
  time_burnin <- as.numeric( substr(start = 0, stop = 100,  strsplit(  strsplit(time_burnin, "[:]")[[1]], "[s]")[[2]][1] ) )
})




}




# |-----------------   Get non-BCA burnin summary params ---------------------------------------
  { 
    
    
    M_inv_dense_main =  BayesMVP::Rcpp_solve(M_dense_main)
    
    ## reset adaptation params 
    # Get mean epsilon
    eps_per_chain <- non_BCA_burnin_outs[[2]]
    eps <- mean(unlist(eps_per_chain), na.rm = TRUE) # mean 
      #  eps <- median(unlist(eps_per_chain), na.rm = TRUE) # median 
    
    # Get mean L
    L_per_chain <-    non_BCA_burnin_outs[[16]]
    L_main <- L <- mean(unlist(L_per_chain), na.rm = TRUE) # mean 
   #  L_main <- L <- median(unlist(L_per_chain), na.rm = TRUE) # median 
    
    # Get mean tau
    if (main_L_manual == FALSE) {
      tau_per_chain <-    non_BCA_burnin_outs[[10]]
     tau_main <- tau <- mean(unlist(tau_per_chain), na.rm = TRUE) # mean 
        # tau_main <- tau <- median(unlist(tau_per_chain), na.rm = TRUE) # median 
    } else { 
      tau_main <- tau <-  L_main * eps 
    }
    

      # Get mean  G (diag, all params) - should be adjusted for max variance
      diag_vec_G_per_chain <- non_BCA_burnin_outs[[9]]
      diag_vec_G <-  Reduce("+", diag_vec_G_per_chain)/ length(diag_vec_G_per_chain)
    #  diag_vec_G[index_us] <- 1 # shouldnt need to do this
      
      # Get mean  M  (diag, all params) - should NOT be adjusted for max variance
      M_diag_vec_per_chain <- non_BCA_burnin_outs[[17]]
      M_diag_vec <-  Reduce("+", M_diag_vec_per_chain)/ length(M_diag_vec_per_chain)
     #  M_diag_vec[index_us] <- 1 # shouldnt need to do this
      
      
      M_dense_main_per_chain <- non_BCA_burnin_outs[[31]]
      M_dense_main <-  Reduce("+", M_dense_main_per_chain)/ length(M_dense_main_per_chain)
      M_dense_main <-  as.matrix( forceSymmetric(M_dense_main) )
      
      M_inv_dense_main <- BayesMVP::Rcpp_solve(M_dense_main)
      M_inv_dense_main_chol <- t(chol(M_inv_dense_main))
      
      M_dense_sqrt <- expm::sqrtm(M_dense_main)
      
      
      # # Get mean A_dense (main params only)
      # A_dense_per_chain <- non_BCA_burnin_outs[[12]]
      # A_dense <-  Reduce("+", A_dense_per_chain)/ length(A_dense_per_chain)
      # A_dense <-  as.matrix( forceSymmetric(A_dense) )
      # if (is.positive.definite(A_dense) == FALSE) {
      #   A_dense <-  as.matrix(nearPD(A_dense)$mat)
      #   A_dense <-  as.matrix( forceSymmetric(A_dense) )
      # }
      # 
      # # Get mean R_diag (main params only)
      # R_diag_per_chain <- non_BCA_burnin_outs[[13]]
      # R_diag <-  Reduce("+", R_diag_per_chain)/ length(R_diag_per_chain)
      # 
      # # Get mean Empirical_Fisher_mat (main params only)
      # Empirical_Fisher_mat_per_chain <- non_BCA_burnin_outs[[14]]
      # Empirical_Fisher_mat <-  Reduce("+", Empirical_Fisher_mat_per_chain)/ length(Empirical_Fisher_mat_per_chain)
      # Empirical_Fisher_mat <-  as.matrix( forceSymmetric(Empirical_Fisher_mat) )
      # if (is.positive.definite(Empirical_Fisher_mat) == FALSE) {
      #   Empirical_Fisher_mat <-  as.matrix(nearPD(Empirical_Fisher_mat)$mat)
      #   Empirical_Fisher_mat <-  as.matrix( forceSymmetric(Empirical_Fisher_mat) )
      # }
      # 
      # Get mean G_dense_main (main params only)
      # G_dense_main_per_chain <- non_BCA_burnin_outs[[15]]
      # G_dense_main <-  Reduce("+", G_dense_main_per_chain)/ length(G_dense_main_per_chain)
      # G_dense_main <-  as.matrix( forceSymmetric(G_dense_main) )
      # if (is.positive.definite(G_dense_main) == FALSE) {
      #   G_dense_main <-  as.matrix(nearPD(G_dense_main)$mat)
      #   G_dense_main <-  as.matrix( forceSymmetric(G_dense_main) )
      # }
      # 
      # G_inv_dense_main <- BayesMVP::Rcpp_solve(G_dense_main)  
      # G_inv_dense_main <-  as.matrix( forceSymmetric(G_inv_dense_main) )
      # if (is.positive.definite(G_inv_dense_main) == FALSE) {
      #   G_inv_dense_main <-  as.matrix(nearPD(G_inv_dense_main)$mat)
      #   G_inv_dense_main <-  as.matrix( forceSymmetric(G_inv_dense_main) )
      # }
      # 
      # G_inv_chol_dense_main <- t(chol(G_inv_dense_main))
      # 
      # Get starting values for each chain
      theta_initial_values_per_chain <- array(dim = c(n_params, n_chains))
      

      
      
      for (kk in 1:n_chains) {
         theta_initial_values_per_chain[, kk] <- non_BCA_burnin_outs[[11]][[kk]]
      }
      
      # theta_initial_values_mean <- apply(theta_initial_values_per_chain, 1, mean)
      # 
      # for (kk in 1:n_chains) {
      #   theta_initial_values_per_chain[, kk] <-  theta_initial_values_mean # non_BCA_burnin_outs[[11]][[kk]]
      # }
      # 
 
      print(L_main)
      print(eps)
      
  }
    
  
  
  if (main_L_manual == TRUE) {
    
    L_main <- L_main_if_manual
    L_main_ii <- L_main_if_manual
    
  }






#  ||||||||||||||||||||||||||||||||||||||| --------------------------   Post-burnin  ------------------------------------------------------------

  
  
  iter_outs =  <-   BayesMVP::Rcpp_fn_run_leapfrog_integrator_non_parellel_test( n_iter_test = n_iter,
                                                                                 tau = tau_main,
                                                                                     theta_initial = theta_vec,
                                                                                     y = y,
                                                                                     dense_G_indicator = TRUE,
                                                                                     numerical_diff_e = 0.0001,
                                                                                     L = L_main,
                                                                                     eps = eps,
                                                                                     grad = rep(0, n_params),
                                                                                     #  numerical_diff_e = 0.0001,
                                                                                     log_posterior = 0,
                                                                                     M_main_vec_if_Euclidean = rep(1, n_params_main),
                                                                                     M_inv_us_vec_if_Euclidean = rep(1, n_us),
                                                                                     M_dense_main  = diag(rep(1, n_params_main)),
                                                                                     M_inv_dense_main  = diag(rep(1, n_params_main)),
                                                                                     M_inv_dense_main_chol  = diag(rep(1, n_params_main)),
                                                                                     n_us = n_us,
                                                                                     n_params_main = n_params_main,
                                                                                     exclude_priors,
                                                                                     CI,
                                                                                     lkj_cholesky_eta,
                                                                                     prior_coeffs_mean,
                                                                                     prior_coeffs_sd,
                                                                                     n_class,
                                                                                     n_tests,
                                                                                     5,
                                                                                     num_chunks, # chunks
                                                                                     corr_force_positive,
                                                                                     list_prior_for_corr_a,
                                                                                     list_prior_for_corr_b,
                                                                                     corr_prior_beta,
                                                                                     FALSE,
                                                                                     lb_corr,
                                                                                     ub_corr,
                                                                                     known_values_indicator_list,
                                                                                     known_values_list,
                                                                                     prev_prior_a,
                                                                                     prev_prior_b,
                                                                                     CDA,
                                                                                     CDA_r,
                                                                                     CDA_b)
  
  
  
  
  
  {
 
    p_jump_main_vec <- c()
    # n_iter <- 200
   #   n_iter <- 250
    
    # if (N <= 4000) { 
    #    n_iter <- 1000
    # } else if (N == 16000) { 
    #   n_iter <- 1000
    # } else { 
    #  #  n_iter <- 200
    #   n_iter <- 1000
    # }
    # 
    #  n_iter <- 100
    
    
    # if (seed == 3) { 
    #   n_iter <- 1000
    # }
    
    
   #   n_iter <- 1000
    trace_theta_test <- array(dim  = c(1, n_iter, n_params_main))
    trace_individual_log_lik <-  array(0, dim  = c( n_iter, N))
   # trace_Z_subset <- array(dim  = c(1, n_iter, 1000))
    error_count <- 0
    
    
    tictoc::tic("post-burnin timer")
    
    # run in parallel
    
    set.seed(seed)
    
    xx <- doRNG::`%dorng%`(
      foreach::foreach(kk = 1:n_chains, 
                       .packages = c("Rcpp",
                                     "rstan",
                                     "posterior",
                                    # "lcmMVPbetav2",
                                    # "lcmMVPbetav3",
                                     "Matrix", 
                                     "float",
                                     "LaplacesDemon", 
                                     "bdsmatrix"), 
                       .combine = 'comb', 
                       .multicombine = TRUE,
                       .init = list(list(), list(),  list(), list(), list(), list(),   list(), list(), list(), list(), list())
      ),
      {
        
        
        
        
        
 
        
        # |   ------------- Test Manifold stuff - start of iteration loop  -----------------------------------------------------
        
 
        
        
        
        ii <- 1
        {
          for (ii in 1:(n_iter)) {
            
            
            
            if (ii %% (100 + kk) == 0) { 
              gc(reset = TRUE)
            }
            
 
            
            # | -----------------------------------   PROPOSAL FOR  MAIN (or ALL) parameters-----------------------------------------------------------------------------------------------------------------------------------------
 
 
            if (ii == 1)  { 
              theta_vec <-   theta_initial_values_per_chain[, kk]
            }
            
            
            grad_main = TRUE
            grad_nuisance = TRUE
            
            
            lp_and_grad_args[[3]] = grad_main
            lp_and_grad_args[[4]] =  grad_nuisance
            
            index_subset = seq(from = 1, to = n_params)
            
            EHMC_single_iter_R_fn_output_main <- NA
            p_jump  <-  0
            
            
            try({
              
              tau_main_ii <- runif(n = 1, min = 0, max= 2 * tau_main)
              L_main_ii <- ceiling(tau_main_ii / eps)
   
 
              
              
              # if   ( (Euclidean_M_main == TRUE) && (dense_G_indicator == FALSE) ) {
              #           
              #           largest_var <- 1   # max(1 / M_diag_vec)
              #           M_diag_vec_adj <-  M_diag_vec * largest_var
              #           
              #           G_dense_main <- diag( M_diag_vec_adj[index_main])
              #           G_inv_dense_main <- diag( 1 / M_diag_vec_adj[index_main])
              #           
              #           M_dense_main_adj <- G_dense_main
              #           M_inv_dense_main_adj <-  G_inv_dense_main
              #   
              # } else if  ( (Euclidean_M_main == FALSE)   )  { 
              #   
              # 
              #           M_us_and_with_EF_main <- c(M_diag_vec[index_us], diag(Empirical_Fisher_mat) )
              #           largest_var <-  1 # max(1 / M_us_and_with_EF_main)
              #           M_diag_vec_adj <-  M_us_and_with_EF_main * largest_var
              #           
              #           Empirical_Fisher_mat_adj <- Empirical_Fisher_mat
              #           A_dense_adj <- BayesMVP::Rcpp_solve(Empirical_Fisher_mat_adj)
              #           R_diag_adj <- diag(A_dense_adj)
              #           
              #           Empirical_Fisher_mat_adj_to_use <- Empirical_Fisher_mat  #### 
              #           A_dense_adj_to_use <- A_dense   #### 
              #           R_diag_adj_to_use <- R_diag   ####  
              #           
              #           G_dense_main <- Empirical_Fisher_mat_adj_to_use
              #           G_inv_dense_main <- A_dense_adj_to_use
              #           
              #           if (dense_G_indicator == FALSE) { 
              #             G_dense_main <- diag(diag(Empirical_Fisher_mat_adj_to_use))
              #             G_inv_dense_main <- diag(diag(A_dense_adj_to_use))
              #           }
              #           
              #           M_dense_main_adj <- diag(n_params_main)
              #           M_inv_dense_main_adj <- diag(n_params_main)
              #   
              # } else if     ( (Euclidean_M_main == TRUE) && (dense_G_indicator == TRUE) )  { 
              #   
              #           largest_var <-  1 # max(1 / M_diag_vec)
              #           M_diag_vec_adj <-  M_diag_vec * largest_var
              #           sqrt_adj_vars <- sqrt(M_diag_vec_adj[index_main])
              #           
              #           M_dense_main_adj <-  M_dense_main  #  diag(sqrt_adj_vars) %*% M_dense_main_corr_mtx %*% diag(sqrt_adj_vars)
              #           M_inv_dense_main_adj <-  M_inv_dense_main #   BayesMVP::Rcpp_solve(M_dense_main_adj)
              #           
              #           G_dense_main <- M_dense_main_adj
              #           G_inv_dense_main <- M_inv_dense_main_adj
              #   
              # }
              
 
              
              if (main_L_manual == TRUE) {
                
                L_main <- L_main_if_manual
                L_main_ii <-  runif(n = 1, min = 1, max = 2*L_main)
                
              }
              
              
              M_dense_main_adj <-   diag(diag(M_dense_main))
              M_inv_dense_main_adj <-      BayesMVP::Rcpp_solve(M_dense_main_adj)
              
              # BayesMVP::LMC_si
              # lcmMVPbetav2::
             
            #  print(M_dense_main[1:5, 1:5])
              rhmc_outs_main  <-            BayesMVP::LMC_single_iteration_subset_only_diag_or_dense_G_simple(
                                                                                                                theta. = theta_vec,
                                                                                                                autodiff. = autodiff.,
                                                                                                                Euclidean_M_main. = Euclidean_M_main,
                                                                                                                dense_G_indicator. = dense_G_indicator,
                                                                                                                n_burnin. = n_burnin,
                                                                                                                lp_and_grad_args. = lp_and_grad_args,
                                                                                                                iter. = ii,
                                                                                                                velocity_0. = velocity_0,
                                                                                                                #   momentum_0. = momentum_0,
                                                                                                                M_main_vec_if_Euclidean. = M_diag_vec[index_main],
                                                                                                                M_us_vec_if_Euclidean. =  M_diag_vec[index_us],
                                                                                                                M_dense_main. = M_dense_main,
                                                                                                                M_inv_dense_main. = M_inv_dense_main,
                                                                                                                M_inv_dense_main_chol. = M_inv_dense_main_chol,
                                                                                                                numerical_diff_e. = numerical_diff_e,
                                                                                                                L. =  L_main_ii,
                                                                                                               #   L. =  1, # L_main_ii,
                                                                                                                epsilon. = eps,
                                                                                                                grad_initial. =   grad,
                                                                                                                log_posterior_initial. =  log_posterior,
                                                                                                                y. = y,
                                                                                                                NT_us. = NT_us, 
                                                                                                               index_main. = index_main,
                                                                                                                individual_log_lik_initial. = individual_log_lik)
 
              
              
              #   if   (  EHMC_single_iter_R_fn_output_main$outs[2, 1]  ==  1  )   {
              if   (   rhmc_outs_main$div   ==  1   )   {
                
                #   if (EHMC_single_iter_R_fn_output_main$div == 1) {
                if   (      rhmc_outs_main$div   ==  1  )   {
                  p_jump  <-  0
                  
                  print(paste("ERROR - MAIN PARAMS - CHAIN - DIV", kk))
 
                  
                  error_count <- error_count + 1
                  
                  # if (error_count > 100) {
                  #   break
                  # }
                  
                } else { 
                  p_jump  <-  0
                  
                  print(paste("ERROR - MAIN PARAMS - CHAIN", kk))
                }
                
              } else {
                
                
                
                p_jump  <- rhmc_outs_main$p_jump ;  p_jump #print(p_jump)
                
                theta_vec_initial <- theta_vec
                theta_vec <- rhmc_outs_main$theta
                theta_vec_prop <- rhmc_outs_main$prop
                
                # theta_vec_initial[index_main]   <- theta_vec[index_main]  
                # theta_vec[index_main] <- rhmc_outs_main$theta[index_main]  
                # theta_vec_prop[index_main] <- rhmc_outs_main$prop[index_main]
                # 
                grad_initial <-  grad
                grad <- rhmc_outs_main$grad_x 
                grad_prop <- rhmc_outs_main$grad_prop
                
                log_posterior    <- rhmc_outs_main$log_posterior 
                log_posterior_prop    <- rhmc_outs_main$log_posterior_prop
                log_posterior_initial    <- rhmc_outs_main$log_posterior_0
                
                individual_log_lik = rhmc_outs_main$individual_log_lik
                
              }
            })
            
            
            
 
                try({
                  trace_theta_test[1, ii, ] <- theta_vec[index_main] # for main params store all post-burnin iterations
                #  trace_Z_subset[1, ii, ] <- theta_vec[1:1000]
                  
                 #   comment(print(length(individual_log_lik)))
                  trace_individual_log_lik[ii, ] <- individual_log_lik
                })
 
 
            
            # | ------------ Manifold tests -Adaptation of epsilon  using ADAM ---------------------------------------------------------------
            
            try({ 
              
              p_jump_main_vec[ii] <- p_jump
              
              
              eps_mean_main <- eps
              
            })
            
            try({
              
              if (ii %% 10 == 0) { 
                
                message(  paste( round( (ii/ (n_iter )) * 100, 1), "% done - chain", kk)  )
                
                if (ii %% 20 == 0) { 
                #  print(round(tail(theta_mean, 12 + 1), 2))
                 #  print(round(head(theta_vec, 10), 2))
                  
                #   print(round(tail(ess, 12 + 1), 1))
                  
                #    print(log_posterior)
                }
              }
              
              if (ii %% 20 == 0) { 
                
                print(paste("mean acceptance prob (main) = ", round(mean(p_jump_main_vec), 2)))
            #    print(paste("mean acceptance prob (main) = ", round((p_jump), 2)))
                
                print(paste("tau = ", round(tau_main, 3)))
                print(paste("eps = ", round(eps, 4)))
                print(paste("L_mean (main) = ", ceiling(tau_main / eps )) )
                print(paste("L_main_ii (main) = ", L_main_ii))
                
                
                
              }
              
            })
            
            try({
              if (ii %in% seq(from = 2, to = n_iter + n_burnin, by = 25)  ) { 
                
 
                  
                  ess <- c()
                  for (i in 1:n_params_main) {
                    ess[i] <-  ess_bulk(   t(t(trace_theta_test[1, 1:(ii - 2), i]))  )
                  }
                  
                  Min_ESS <- min(ess) ; Min_ESS
                  
                  cat(colourise( paste("Min_ESS = ", round(Min_ESS, 2)), "red"), "\n")
            
                
              }
              
            })
            
 
            
            
          }   # | ------------   Manifold tests -    end of iterations (ii loop) -----------------------------------------------------------       
          
 
          
        }
        
        #W#     output_list <- list()
        
        try({   L_main_mean <- L_main   })
        try({   L_main_mean_samp <-  L_main  })
        
        try({  
          
          
          
          
        })
        
        try({ 
          return(list(trace_theta_test = trace_theta_test, 
                      eps_mean_main =  eps, # eps_mean_main,
                      L_main_mean =  L_main_mean,
                      1,
                      time_burnin = 0, #' 5
                      time_sampling = 0,
                      L_main_mean_samp,
                      trace_theta_test_full = 0, 
                      error_count = error_count,
                      trace_Z_subset = 0,  # 10
                      trace_individual_log_lik  = trace_individual_log_lik)) # L_main_mean_samp))
        })
        
      } )   # | ------------   Manifold tests -   end of "foreach" loop -----------------------------------------------------------
    
    
    
    print(tictoc::toc(log = TRUE))
    log.txt <- tictoc::tic.log(format = TRUE)
    tictoc::tic.clearlog()
    time_post_burnin <- unlist(log.txt)
 
    
    try({  
      time_post_burnin <- as.numeric( substr(start = 0, stop = 100,  strsplit(  strsplit(time_post_burnin, "[:]")[[1]], "[s]")[[2]][1] ) )
    })
    
 
 
    
  }
  
  
  
  
  
  
  
  
  {
    
    
    
    
    
    # {
    #   
    #   file_name <- paste0("NPT",
    #                       "seed_", seed, "_",
    #                       N, "N_",
    #                       n_chains, "chains_",    n_burnin, "nB_",      n_iter, "nS_",
    #                       as.integer(tau_main_jittered), "JITT_",
    #                       adapt_delta, "AR_",
    #                       learning_rate_main, "LR_",
    #                       fix_rho, "fix_rho",
    #                       clip_iter, "clip_",
    #                       lkj_cholesky_eta[1], "_",     lkj_cholesky_eta[2], "prLKJ_",
    #                       Euclidean_M_main, "EUC_",
    #                       dense_G_indicator,  "G_dense_",
    #                       u_Euclidean_metric_const, "G_us_const"
    #   )
    #   
    #   if (main_L_manual == TRUE) {
    #     file_name <- paste0("man_L_", L_main_if_manual, file_name)
    #   }
    #   if (Euclidean_M_main == TRUE) {
    #     file_name <- paste0(    smooth_M_main, "M_smooth_", file_name)
    #   }
    #   
    #   
    #   print(paste("saving file = ", file_name))
    #   
    #   
    #   
    #   try({   saveRDS(xx,  file = file_name)   })
    #   
    #   try({  RM_LMC_external_trace <- readRDS(file_name)  })
    #   
    #   #### read external output
    #   read_external <- FALSE
    #   if (read_external == TRUE) {
    #     
    #     seed <- seed
    #     file_name_external <- "Eff_info_FALSEM_smooth_man_L_125NPTseed_3_64000N_48chains_250nB_250nS_1JITT_0.8AR_0.25LR_FALSEfix_rho50clip_6prLKJ_TRUEEUC_TRUEG_dense_TRUEG_us_const" # paste0("RM_LMC_seed_", seed, "_6piLKJ_1000N_8chains_2000n_B_4000n_S_0.05LRmain_0.8ad_400clip_TRUEjt_TRUEL_jt_us_TRUEad_M_us_FALSEstab_us_TRUEad_M_FALSEstab_TRUEEUFALSEdns_G_FALSESAb_main_100000000SAbAlmain_FALSE3rd_ord_")
    #     try({  RM_LMC_external_trace <- readRDS(file_name_external)  })
    #     
    #   }
    #   
    # }
    
    
    RM_LMC_external_trace <- xx
    
    # | ------------   Manifold tests - Calculate summary stuff -----------------------------------------------------------
    
    {
      
      
      trace_individual_log_lik_array <- array(dim = c(n_chains, n_iter, N))
        
      for (kk in 1:n_chains) {
        trace_individual_log_lik_array[kk,,]  <-  RM_LMC_external_trace[[11]][[kk]]
      }
      
      
      time_burnin <-       time_burnin # * ( n_burnin / (n_iter + n_burnin) )
      time_sampling <-     time_post_burnin  # * ( n_iter / (n_iter + n_burnin) )
      time_total <- time_burnin + time_sampling
      
      total_time_mins <- time_total/60
      total_time_hours <- total_time_mins/60
      pb_time_seconds <- time_sampling
      pb_time_mins <- pb_time_seconds/60
      pb_time_hours <- pb_time_mins/60
      
      
      L_main_mean_cumul <- 0
      L_samp_main_mean_cumul <- 0
      
      eps_main_mean_cumul <- 0
      #    eps_us_mean_cumul <- 0
      
      
      theta_manifold_main_params_array <- array(dim = c(n_chains, 0 + n_iter, n_params_main))
      
      #  str(RM_LMC_external_trace[[1]][[kk]] )
      n_divergent_per_chain <- c()
      
      for (kk in 1:n_chains) {
        #  str( theta_manifold_main_params_array[1,, ])
        theta_manifold_main_params_array[kk,, ] <-      (RM_LMC_external_trace[[1]][[kk]]  )
        n_divergent_per_chain[kk] <-  (RM_LMC_external_trace[[9]][[kk]]  )
      }
      
      n_divergent <- sum(n_divergent_per_chain)
      
      try({  theta_manifold_main_params_array[, 1:(0 + n_iter),i]  })
      
      chains_na <- c(0)
      try({  
      chains_na <-   which(is.na( rowMeans(theta_manifold_main_params_array[, 1:(0 + n_iter),1] ) ))
      })
      
      chain_set_original <- c(1:n_chains)  ;     n_chains_original <- length(chain_set_original)
      if (length(chains_na) > 0) {
        chain_set_new <- c(1:n_chains)[- c(chains_na) ] ;     n_chains_new <- length(chain_set_new)
      } else  {
        chain_set_new <- c(1:n_chains) ;  n_chains_new <- length(chain_set_new)
      }
      
      
      
      {
        chain_set <- chain_set_original ; n_chains <- n_chains_original
        
        
        
        
        for (kk in 1:n_chains) {
          L_main_mean_cumul <-   L_main_mean_cumul +  (RM_LMC_external_trace[[3]][[kk]])
          L_samp_main_mean_cumul <-   L_samp_main_mean_cumul +  (RM_LMC_external_trace[[7]][[kk]])
          eps_main_mean_cumul <- eps_main_mean_cumul +   RM_LMC_external_trace[[2]][[kk]]
        }
        
        eps_main_mean <-  eps #  eps_main_mean_cumul / n_chains ; print(eps_main_mean)
        L_main_mean <- L_main_mean_cumul / n_chains ; L_main_mean
        L_samp_main_mean <- L_main #  L_samp_main_mean_cumul / n_chains ; L_samp_main_mean
        
        
        pars_index_vec <- index_subset_excl_known - n_us
        n_params_main_effective <- length(pars_index_vec)
        n_corrs_effective <- n_params_main_effective - (1 + n_coeffs)
          
        theta_manifold_main_params_array <- array(dim = c(n_chains, n_iter, n_params_main_effective))
        
        #  str(theta_manifold_main_params_array)
        
        for (kk in 1:n_chains) {
          for (i_par in 1:n_params_main_effective) {
            theta_manifold_main_params_array[kk,, i_par] <-      (RM_LMC_external_trace[[1]][[kk]]  )[,,pars_index_vec[i_par]]
          }
        }
        
        # calc posterior medians and means for coeffs + prev
        posterior_trace_avg_between_chains <- apply(theta_manifold_main_params_array[chain_set_new,(1:(0+n_iter)),], c(2, 3), mean)
        posterior_medians <- apply(posterior_trace_avg_between_chains, c(2), median)    ; posterior_medians
        posterior_means <- apply(posterior_trace_avg_between_chains, c(2), mean)   ; posterior_means
        posterior_l95 <- apply(posterior_trace_avg_between_chains, c(2), quantile, probs = 0.025 )   ; posterior_l95
        posterior_u95 <- apply(posterior_trace_avg_between_chains, c(2), quantile, probs = 0.975 )   ; posterior_u95
        
        
        # ESS and R-hat for MAIN parameters
        ess <- rhat_vec <- nexted_rhat_vec <-  c()
        
        pars_index_vec <- index_subset_excl_known - n_us
        
        superchain_ids = seq(from = 1, to = n_chains, by = 1)
        if (n_chains > 4)  superchain_ids = c(rep(1, n_chains/2), rep(2, n_chains/2))
        if (n_chains > 15)  superchain_ids = c(rep(1, n_chains/4), rep(2, n_chains/4), rep(3, n_chains/4), rep(4, n_chains/4))
        if (n_chains > 47)  superchain_ids = c(rep(1, n_chains/8), rep(2, n_chains/8), rep(3, n_chains/8), rep(4, n_chains/8), 
                                               rep(5, n_chains/8), rep(6, n_chains/8), rep(7, n_chains/8), rep(8, n_chains/8))
        
        try({  
        for (i in 1:n_params_main_effective) {   # c(2, 4,5,7,8:16)
          ess[i] <-  sort(rstan::ess_bulk((t(   theta_manifold_main_params_array[ chain_set_new, 1:(0 + n_iter), i]  )))) ;  ess[i]
          rhat_vec[i] <-   rstan::Rhat(t((theta_manifold_main_params_array[chain_set_new, 1:(0 + n_iter), i])))
          nexted_rhat_vec[i] <-   posterior::rhat_nested(t((theta_manifold_main_params_array[chain_set_new, 1:(0 + n_iter), i])), superchain_ids = superchain_ids)
        }
        })
        
        
        try({  
        {
          
          n_chains <- n_chains_new
          
          print(sort(round(ess, 0)))
          
          Max_rhat <- max(rhat_vec, na.rm = TRUE) ; Max_rhat
          Max_rhat_nested <- max(nexted_rhat_vec, na.rm = TRUE) ; Max_rhat
          
          
          Min_ESS <- min(ess) ; # print(Min_ESS)
          Mean_ESS <- mean(ess) ; # print(Mean_ESS)
          Min_ESS_per_sec <- Min_ESS / time_total
          Min_ESS_per_sec_sampling <- Min_ESS / time_sampling
          
          if (MALA_main == TRUE) {     L_main_mean <- 1 ; L_samp_main_mean <- 1    }
          n_grad_evals_main_total  <-  mean_L_burnin * n_chains  * n_burnin  + L_main_mean * n_chains *  n_iter  
          n_grad_evals_main_sampling <-   n_iter  * n_chains * L_samp_main_mean
          
          Min_ESS_per_grad <- Min_ESS / n_grad_evals_main_total
          Min_ESS_per_grad_sampling <-  Min_ESS / n_grad_evals_main_sampling ;# print(round(Min_ESS_per_grad_sampling * 1000, 3))
          
          #    try({   min_ess_grad_sampling_vec[seed] <- Min_ESS_per_grad_sampling * 1000  })
        }
        })
        
      }
      
    }
    
    
    
     
    {




      try({
      file_list <- list(

        # basic  info
        paste("seed = ", seed),
        paste("N = ", N),
        paste("n_chains = ", n_chains),
        (paste("n_burnin = ", n_burnin)),
        (paste("n_iter = ", n_iter)),
        (paste("JITT = ", tau_main_jittered)),
        print(paste("adapt_delta  = ", adapt_delta))  ,
        (paste("learning_rate  = ", learning_rate_main)),
        (paste("fix_rho  = ", fix_rho)),
        (paste("clip_iter = ", clip_iter)),
        (paste("prLKJ_ = ", lkj_cholesky_eta)),
        (paste("Euclidean (main) = ", Euclidean_M_main)),
        (paste("Smooth (main) = ", smooth_M_main)),
        (paste("G_dense_ (main) = ", dense_G_indicator)),
        (paste("G_us_const (u's) = ", u_Euclidean_metric_const)),

        (paste( "NT_us  = ", NT_us))  ,
        (paste( "rough_approx  = ", rough_approx))    ,
        (paste( "lb_phi_approx  = ", lb_phi_approx))    ,
        (paste( "ub_phi_approx  = ", ub_phi_approx))   ,


        # efficiency stats
        (paste("Min ESS (main) = ", round(Min_ESS, 3))),
        (paste("Max Rhat (main params) = ", round(Max_rhat, 3))),

        (paste("time (total) = ", round(min(time_total), 0))),
        (paste("time (burnin) = ", round(min(time_burnin), 0))),
        (paste("time (sampling) = ", round(min(time_sampling), 0))),


        paste("total time =", round(time_total, 0), "seconds"),
        paste("total time =", floor(total_time_mins), "minutes and ", round(((total_time_mins - floor(total_time_mins))*60), 0), "seconds"),
        paste("total time =", floor(total_time_hours), "hours and ", round(((total_time_hours - floor(total_time_hours))*60), 0), "minutes"),

        paste("Sampling (post-burnin) time =", round(pb_time_seconds, 0), "seconds"),
        paste("Sampling (post-burnin) time =", floor(pb_time_mins), "minutes and ", round(((pb_time_mins - floor(pb_time_mins))*60), 0), "seconds"),
        paste("Sampling (post-burnin) time =", floor(pb_time_hours), "hours and ", round(((pb_time_hours - floor(pb_time_hours))*60), 0), "minutes"), # 20

        (paste("Min ESS / sec = ", round((Min_ESS_per_sec), 4)))        ,
        (paste("Min ESS / sec (sampling only)  = ", round((Min_ESS_per_sec_sampling), 4)))         ,

        (paste("Min ESS / grad = (total) ", round((Min_ESS_per_grad*1000), 2))),
        (paste("Min ESS / grad (sampling only) = ", round((Min_ESS_per_grad_sampling*1000), 2)))     ,

        # other stats
        (paste("eps (sampling) = ", eps)),
        (paste("L (sampling) = ", L_main)),
        (paste("divergences = ", n_divergent))

      )

      saveRDS(file_list, file = paste0("Eff_info_", file_name))
      })


    }
    
    
    
    
    
    
    {
      
      #  (tanh( -0.74) + 1) / 2
      #   plot(theta_manifold_array[1,1])
      
      
      try({ 
      {
        
        print(paste("seed = ", seed))
        print(paste("| ---------------   N = ", N))
        print(paste("clip_iter = ", clip_iter))
        print(paste("n_chains = ", n_chains))
        print(paste("n_burnin = ", n_burnin))
        print(paste("n_iter = ", n_iter))
        
        
        print(paste("learning_rate (main) = ", learning_rate_main))
        print(paste("adapt_interval_width   = ", adapt_interval_width))
        try({   print(paste("adapt_delta (main) = ", adapt_delta))  })
        
        
        print(paste("n_divergent = ", round(n_divergent, 0)))
        
        print(paste("SoftAbs  = ", soft_abs))
        print(paste("SoftAbs_alpha_ = ", soft_abs_alpha))
        
        print(paste("corr_force_positive = ", corr_force_positive))
        print(paste("priorLKJ = ", lkj_cholesky_eta))
     
        
        
        print(cat("posterior medians (coeffs - D+) - prob scale",  round(pnorm(posterior_medians)[-c(1:n_corrs_effective)], 3)[(((n_class/2)*n_tests)+ 1):(n_class*n_tests)] ))
        print(cat("posterior medians (coeffs - D-) - prob scale", head(round(1 - pnorm(posterior_medians)[-c(1:n_corrs_effective)], 3), 1 *  n_tests)  ))
        print(cat("posterior medians (prev)", tail(round(   (tanh(  posterior_medians[-c(1:n_corrs_effective)]   ) + 1)/2      , 3), 1)  ))
        # print(cat("posterior means (coeffs - D+)", round(posterior_means[-c(1:n_corrs)], 2)[(((n_class/2)*n_tests)+ 1):(n_class*n_tests)] ))
        # print(cat("posterior means (coeffs - D-)", head(round(posterior_means[-c(1:n_corrs)], 2), 1 * n_tests) ))
        # print(cat("posterior means (prev)", tail(round(posterior_means[-c(1:n_corrs)], 2), 1)  ))
        
        
        
        cat(colourise(      (paste( "NT_us  = ", NT_us))      , "blue"), "\n")
        cat(colourise(      (paste( "rough_approx  = ", rough_approx))      , "blue"), "\n")
        cat(colourise(      (paste( "lb_phi_approx  = ", lb_phi_approx))      , "blue"), "\n")
        cat(colourise(      (paste( "ub_phi_approx  = ", ub_phi_approx))      , "blue"), "\n")
        
        cat(colourise(      (paste( "Euclidean (main) = ", Euclidean_M_main))      , "blue"), "\n")
        cat(colourise(      (paste( "L_jitter (main) = ", tau_main_jittered))      , "blue"), "\n")
        
        cat(colourise(    (paste("mean L (main - burnin) = ", round(mean_L_burnin, 0)))        , "blue"), "\n")
        cat(colourise(    (paste("mean L (main - sampling) = ", round(L_main, 0)))        , "blue"), "\n")
        
        cat(colourise(    (paste("mean epsilon (main) = ", round(eps, 4)))          , "blue"), "\n")
        
        cat(colourise(    paste( "Dense_G (main) = ", dense_G_indicator )      , "blue"), "\n")
        cat(colourise(    paste( "smooth_M_main = ",  smooth_M_main)      , "blue"), "\n")
        
        cat(colourise(    paste( "adapt_M_us = ", adapt_M_us)      , "green"), "\n")
        # cat(colourise(    paste( "smooth_M_us = ",  smooth_M_main)      , "green"), "\n")
        cat(colourise(    paste( "u_Euclidean_metric_const (median(Var(U's))) = ", u_Euclidean_metric_const)      , "green"), "\n")
        
        print(paste("Min ESS (main) = ", round(Min_ESS, 0)))
        print(paste("Max Rhat (main params) = ", round(Max_rhat, 3)))
        print(paste("Max n-Rhat (main params) = ", round(Max_rhat_nested, 3)))
        
        print(paste("time (total) = ", round((time_total/60), 3)))
        print(paste("time (sampling) = ", round((time_sampling/60), 3)))
        
        cat(colourise(        (paste("Min ESS / sec (total) = ", round((Min_ESS_per_sec), 4)))            , "purple"), "\n")
        cat(colourise(        (paste("Min ESS / sec (sampling only)  = ", round((Min_ESS_per_sec_sampling), 4)))            , "purple"), "\n")
        
        cat(colourise(       (paste("Min ESS / grad (total) = ", round((Min_ESS_per_grad*1000), 4)))             , "red"), "\n")
        cat(colourise(       (paste("Min ESS / grad (sampling only) = ", round((Min_ESS_per_grad_sampling*1000), 4)))             , "red"), "\n")
        
      }
      })
 
      
    }
    
    
    
  }
  
  try({
    stopCluster(cl)
  }, silent = TRUE)
  
  # posterior_means <- apply(posterior_trace_avg_between_chains, c(2), mean)   ; posterior_means
  # posterior_l95 <- apply(posterior_trace_avg_between_chains, c(2), quantile, probs = 0.025 )   ; posterior_l95
  # posterior_u95 <- apply(posterior_trace_avg_between_chains, c(2), quantile, probs = 0.975 )   ; posterior_u95
  
  return(list(outs = xx ,
              trace_array = theta_manifold_main_params_array, 
              trace_individual_log_lik_array = trace_individual_log_lik_array,
              L_burnin = round(mean_L_burnin, 0),
              L_sampling = round(L_main, 0),
              min_ESS = round(Min_ESS, 0),
              Max_rhat = Max_rhat,
              Max_rhat_nested = Max_rhat_nested,
              time_total = round((time_total/60), 3),
              time_sampling = round((time_sampling/60), 3),
              Min_ESS_per_sec_overall = round((Min_ESS_per_sec), 4),
              Min_ESS_per_sec_sampling = round((Min_ESS_per_sec_sampling), 4),
              Min_ESS_per_grad_overall = round((Min_ESS_per_grad*1000), 4),
              Min_ESS_per_grad_sampling = round((Min_ESS_per_grad_sampling*1000), 4),
              time_burnin = round((time_total/60), 3) - round((time_sampling/60), 3),
              n_divs =  round(n_divergent, 0)
              )) 
}




















# 
# 
# 




 