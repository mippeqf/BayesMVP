
# MVP-GHK - Single iteration (calls Rcpp or R leapfrog integrator function)  --------------------------------------------------------------------
LMC_single_iteration_wo_list_R        <- function(theta.,
                                                                           autodiff.,
                                                                           Euclidean_M_main.,
                                                                           dense_G_indicator.,
                                                                           n_burnin.,
                                                                           iter.,
                                                                           velocity_0.,
                                                                           M_main_vec_if_Euclidean.,
                                                                           M_us_vec_if_Euclidean.,
                                                                           M_dense_main., ##
                                                                           M_inv_dense_main., ##
                                                                           M_inv_dense_main_chol., ## 
                                                                           numerical_diff_e.,
                                                                           L.,
                                                                           epsilon.,
                                                                           grad_initial.,
                                                                           log_posterior_initial.,
                                                                           y.,
                                                                           index_main.,
                                                                           NT_us.,
                                                                           individual_log_lik_initial.,
                                                                           CI.,
                                                                           lkj_cholesky_eta.,
                                                                           prior_coeffs_mean. ,
                                                                           prior_coeffs_sd.,
                                                                           ub_threshold_phi_approx.,
                                                                           n_chunks.,
                                                                           corr_force_positive.,
                                                                           prior_for_corr_a.,
                                                                           prior_for_corr_b.,
                                                                           corr_prior_beta. ,
                                                                           corr_prior_norm. ,
                                                                           lb_corr.,
                                                                           ub_corr.,
                                                                           known_values_indicator.,
                                                                           known_values.,
                                                                           prev_prior_a.,
                                                                           prev_prior_b.,
                                                                           Phi_type., 
  
) {
  
  

  
  { 
  
    n_class = 2 # lp_and_grad_args.[[12]];
    n_tests = lp_and_grad_args.[[13]];
    
    N =  nrow(y.)
    n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
    n_coeffs = n_class * n_tests * 1;
    n_us =  1 *  N * n_tests;
    
    n_params = length(theta.)
    n_params_main = n_params - n_us;
    
    index_us. = 1:n_us
  
  
  theta_vec_initial <- theta.
  prop <-  theta.
  
  
  grad_x <-  grad_initial.
  grad_prop = grad_initial.

  index_subset <-  1:n_params # index_main.
 
  velocity <- velocity_0.
  velocity_prop <- velocity_0.
    
  leapfrog_outs <- NA
  
  individual_log_lik = individual_log_lik_initial.
  individual_log_lik_proposed = individual_log_lik_initial.
    
  U_x_initial =  - log_posterior_initial.  

  log_posterior = log_posterior_initial.
  

  
  }


 
  
 try({

          leapfrog_outs <-     BayesMVP::Rcpp_fn_wo_list_ELMC_multiple_leapfrogs_EUC_EFISH_HI_with_MIXED_M_NT_us(  1,
                                                                                                                   theta. ,
                                                                                                                   y.,
                                                                                                                   X.,
                                                                                                                   dense_G_indicator,
                                                                                                                   0.0001,
                                                                                                                   L.,
                                                                                                                   epsilon.,
                                                                                                                   log_posterior_initial.,
                                                                                                                   M_main_vec_if_Euclidean.,
                                                                                                                   M_inv_us_vec_if_Euclidean.,
                                                                                                                   dense_G_indicator.,
                                                                                                                   M_dense_main., ##
                                                                                                                   M_inv_dense_main., ##
                                                                                                                   M_inv_dense_main_chol., ## 
                                                                                                                   n_us,
                                                                                                                   n_params_main,
                                                                                                                   FALSE, # exclude_priors
                                                                                                                   CI.,
                                                                                                                   lkj_cholesky_eta.,
                                                                                                                   prior_coeffs_mean. ,
                                                                                                                   prior_coeffs_sd.,
                                                                                                                   n_class,
                                                                                                                   n_tests,
                                                                                                                   ub_threshold_phi_approx.,
                                                                                                                   n_chunks.,
                                                                                                                   corr_force_positive.,
                                                                                                                   prior_for_corr_a.,
                                                                                                                   prior_for_corr_b.,
                                                                                                                   corr_prior_beta. ,
                                                                                                                   corr_prior_norm. ,
                                                                                                                   lb_corr.,
                                                                                                                   ub_corr.,
                                                                                                                   known_values_indicator.,
                                                                                                                   known_values.,
                                                                                                                   prev_prior_a.,
                                                                                                                   prev_prior_b.,
                                                                                                                   Phi_type., 
                                                                                                                   11);
                                                                                                                   
                                                                                                                   
                          


  })


      
 
               try({
                 
               #  div = leapfrog_outs$div
                 
                 theta.[index_subset] <-   leapfrog_outs$theta[index_subset]
                 prop <-  theta.

                 grad_x[index_subset] <-    leapfrog_outs$grad_x[index_subset]
                 grad_prop <- grad_x
                 grad_initial.[index_subset] <-    leapfrog_outs$grad_0[index_subset]

                 log_posterior <-  leapfrog_outs$log_posterior
                 log_posterior_prop = log_posterior
                 U_x <- - log_posterior  
                 log_posterior_initial. <- leapfrog_outs$log_posterior_0
                 U_x_initial  =   - log_posterior_initial.  

                 velocity[index_subset] <-  leapfrog_outs$velocity[index_subset]
                 velocity_0.[index_subset] <- leapfrog_outs$velocity_0[index_subset]
                 velocity_prop <- velocity

                     individual_log_lik_proposed = leapfrog_outs$individual_log_lik
                     individual_log_lik = individual_log_lik_proposed
               })
        
 


  
  if ((any(is.na(theta.))) || (any(is.na(grad_x))) )  {

    comment(print(paste("div - main")))

          div <- 1
          p_jump <- 0
          grad_x <- grad_initial.
          grad_prop <- grad_x
         # grad_0 <- grad_initial.

          U_x  <- U_x_initial
          log_posterior <- log_posterior_initial.
          theta. <- theta_vec_initial

          velocity <- velocity_0. 



          log_ratio <- -1000000

  } else {
    
    div = 0 
 
                 
                 energy_old <- U_x_initial
                 energy_old = energy_old   +  0.5 *  sum(   c( BayesMVP::Rcpp_mult_mat_by_col_vec(mat = M_dense_main., colvec =    velocity_0.[index_main.]) )  * velocity_0.[index_main.]  )
                 energy_old = energy_old   +  0.5 *  sum(velocity_0.[index_us.]^2 * (  M_us_vec_if_Euclidean.[index_us.] )  )

              #   comment(print(M_dense_main.))
               #  comment(print(velocity_0[index_main.]))
                 
                 
                 U_x <- - log_posterior  
                energy_new <- U_x
                energy_new = energy_new  + 0.5 *  sum(   c( BayesMVP::Rcpp_mult_mat_by_col_vec(mat = M_dense_main., colvec =    velocity[index_main.]) )  * velocity[index_main.]  )
                energy_new = energy_new  + 0.5 *  sum(velocity[index_us.]^2 *   (  M_us_vec_if_Euclidean.[index_us.] )  )



           log_ratio <-  - energy_new + energy_old   #  + delta_log_det


           p_jump_new <-  min(1, exp(  + log_ratio)) ; p_jump_new



          p_jump <- p_jump_new  ; p_jump
          
          
          
          
          
          
          
          if   (  (is.na(p_jump)) ||  (is.null(p_jump)) )  { 
            p_jump <- 0
            comment(print("aaaaaaaaaaaaaa - MAIN"))
            comment(print(U_x))
            comment(print(U_x_initial))
          }
          
  }
  
  
  

  ### MH step   
 # if (rexp(1) < Delta) { # reject proposal
 if  ( (runif(n = 1, 0, 1) > p_jump) || (div == 1)  )  { # reject proposal
   
                accept <- 0
                
                theta. <- theta_vec_initial
                grad_x <- grad_initial.
                
                U_x  <- U_x_initial 
                log_posterior <- log_posterior_initial.
 
                velocity <- velocity_0.
                  
                  individual_log_lik = individual_log_lik_initial.
       
                
  } else {    # accept proposal
    
                accept <- 1
                theta.  <- theta.
                   
                individual_log_lik = individual_log_lik_proposed
                
  } 
  
  

 
 
  
  return(list(
    
    theta_vec_initial = theta_vec_initial ,
    theta = theta., # final parameter vector 
    prop = prop,
    
    log_ratio = log_ratio,
    
    log_posterior =  log_posterior,
    log_posterior_prop = log_posterior_prop,
    log_posterior_0 =  log_posterior_initial.,
 
   div = div,
   
    U_x = U_x, # U_x,
 
    p_jump = p_jump,
    accept = accept,
   
    grad_x = grad_x,
    grad_prop = grad_prop,
    grad_0 = grad_initial.,
    

    velocity = velocity,
    velocity_0 = velocity_0.,
   velocity_prop = velocity_prop,

 individual_log_lik = individual_log_lik
   

  ))
  
}








