
 
// #include <random>
// #include <xoshiro.h>
// #include <dqrng_distribution.h>
// #include <dqrng_generator.h>

// [[Rcpp::depends(RcppProgress)]]
// [[Rcpp::depends(RcppZiggurat)]]

// [[Rcpp::depends(StanHeaders)]]  
// [[Rcpp::depends(BH)]] 
// [[Rcpp::depends(RcppParallel)]] 
// [[Rcpp::depends(RcppEigen)]]  

#include <omp.h>

#include <progress.hpp>
#include <progress_bar.hpp>
#include <R_ext/Print.h>

#include <stan/math/rev.hpp>
// #include <stan/math/fwd.hpp>
// #include <stan/math/mix.hpp> // then stuff from mix/ must come next
//////#include <stan/math.hpp> 

 
#include <stan/math/prim/fun/Eigen.hpp>
#include <stan/math/prim/fun/typedefs.hpp>
#include <stan/math/prim/fun/value_of_rec.hpp>
#include <stan/math/prim/err/check_pos_definite.hpp>
#include <stan/math/prim/err/check_square.hpp>
#include <stan/math/prim/err/check_symmetric.hpp>
 
 
#include <stan/math/prim/fun/cholesky_decompose.hpp>
#include <stan/math/prim/fun/sqrt.hpp>
#include <stan/math/prim/fun/log.hpp>
#include <stan/math/prim/fun/transpose.hpp>
#include <stan/math/prim/fun/dot_product.hpp>
#include <stan/math/prim/fun/norm2.hpp>
#include <stan/math/prim/fun/diagonal.hpp>
#include <stan/math/prim/fun/cholesky_decompose.hpp>
#include <stan/math/prim/fun/eigenvalues_sym.hpp>
#include <stan/math/prim/fun/diag_post_multiply.hpp>
 
 
 
 
#include <stan/math/prim/prob/multi_normal_cholesky_lpdf.hpp>
#include <stan/math/prim/prob/lkj_corr_cholesky_lpdf.hpp>
#include <stan/math/prim/prob/weibull_lpdf.hpp>
#include <stan/math/prim/prob/gamma_lpdf.hpp>
#include <stan/math/prim/prob/beta_lpdf.hpp>
 
 
 
 
 

#include <RcppEigen.h> 
#include <Rcpp.h> 
 

#include <Ziggurat.h>

 // #include <random>
//#include <pcg_random.hpp>
// #include <dqrng_sample.h>
 
 
#include <unsupported/Eigen/SpecialFunctions>
 

 
#define EIGEN_USE_MKL_ALL
#include "Eigen/src/Core/util/MKL_support.h"


// [[Rcpp::plugins(openmp)]]
// [[Rcpp::plugins(cpp17)]]      

using namespace Rcpp;    
using namespace Eigen;      


static Ziggurat::Ziggurat::Ziggurat zigg;









// [[Rcpp::export]]
double    fn_sign_double( double x) { 
  
  if (x > 0) return 1;
  if (x < 0) return -1;
  return 0;
  
  
}



float    fn_sign_float( float  x) { 
  
  if (x > 0) return 1;
  if (x < 0) return -1;
  return 0;
  
}




// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    fn_sign_log_vec( Eigen::Matrix<double, -1, 1  > x) { 
  
  return( ( x.array().sign() *  x.array().abs().log() ).matrix()  ); 
  
}



Eigen::Matrix<float, -1, 1>    fn_sign_log_vec_float( Eigen::Matrix<float, -1, 1  > x) { 
  
  return( (x.array().sign() *  x.array().abs().log() ).matrix()  ); 
  
}




// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    fn_sign_log_mat( Eigen::Matrix<double, -1, 1  > x) { 
  
  return(  ( x.array().sign() *  x.array().abs().log() ).matrix()  ); 
  
}



Eigen::Matrix<float, -1, -1>    fn_sign_log_mat_float( Eigen::Matrix<float, -1, -1  > x) { 
  
  return(  (x.array().sign() *  x.array().abs().log()  ).matrix()  ); 
  
}








// [[Rcpp::export]]
double  fastpow2_1 (float p)
{
  //  float offset =  ( (p < 0) ? 1.0f : 0.0f) ;
  float clipp = (p < -126) ? -126.0f : p;
  int w = clipp;
  float z = clipp - w + ( (p < 0) ? 1.0f : 0.0f);
  union { uint32_t i; float f; } v = { uint32_t  ( (1 << 23) * ( clipp + 121.2740575f + 27.7280233f / (4.84252568f - z) - 1.49012907f * z) ) };
  
  return v.f;
}


// [[Rcpp::export]]
double  fastpow2_1_double (double p)
{
  //  float offset =  ( (p < 0) ? 1.0f : 0.0f) ;
  double clipp = (p < -126) ? -126.0f : p;
  int w = clipp;
  double z = clipp - w + ( (p < 0) ? 1.0f : 0.0f);
  union { uint32_t i; float f; } v = { uint32_t  ( (1 << 23) * ( clipp + 121.2740575f + 27.7280233f / (4.84252568f - z) - 1.49012907f * z) ) };
  
  return v.f;
}



// [[Rcpp::export]]
Eigen::Array<double, -1, 1  > fast_exp_0_Eigen(  Eigen::Array<double, -1, 1  > x)
{
  for (int i = 0; i < x.rows(); ++i) {
    x(i) =  std::exp(x(i));
  }
  return x; 
}

// [[Rcpp::export]]
Eigen::Array<double, 1, -1  > fast_exp_0_Eigen_rowvec(  Eigen::Array<double, 1, -1  > x)
{
  for (int i = 0; i < x.cols(); ++i) {
    x(i) =  std::exp(x(i));
  }
  return x; 
}

// [[Rcpp::export]]
Eigen::Array<double, -1, 1  > fast_log_0_Eigen(  Eigen::Array<double, -1, 1  > x)
{
  for (int i = 0; i < x.rows(); ++i) {
    x(i) =  std::log(x(i));
  }
  return x; 
}

// [[Rcpp::export]]
Eigen::Array<double, 1, -1  > fast_log_0_Eigen_rowvec(  Eigen::Array<double, 1, -1  > x)
{
  for (int i = 0; i < x.cols(); ++i) {
    x(i) =  std::log(x(i));
  }
  return x; 
}


// [[Rcpp::export]]
Eigen::Array<double, -1, -1  > fast_exp_0_Eigen_mat(  Eigen::Array<double, -1, -1  > x)
{
  for (int j = 0; j < x.cols(); ++j) {
   for (int i = 0; i < x.rows(); ++i) {
      x(i,j) = std::exp(x(i,j));
    }
  }
  return x;
}

// [[Rcpp::export]]
Eigen::Matrix<double, -1, -1> fast_exp_0_Eigen_mat_RM(  Eigen::Matrix<double, -1, -1> x)
{
  for (int i = 0; i < x.rows(); ++i) {
    for (int j = 0; j < x.cols(); ++j) {
      x(i,j) = std::exp(x(i,j));
    }
  }
  return x;
}

// [[Rcpp::export]]
Eigen::Array<double, -1, -1  > fast_log_0_Eigen_mat(  Eigen::Array<double, -1, -1  > x)
{
  for (int j = 0; j < x.cols(); ++j) {
    for (int i = 0; i < x.rows(); ++i) {
      x(i,j) = std::log(x(i,j));
    }
  }
  return x;
}

// [[Rcpp::export]]
Eigen::Array<double, -1, -1 > fast_log_0_Eigen_mat_RM(  Eigen::Array<double, -1, -1 > x)
{
  for (int i = 0; i < x.rows(); ++i) {
    for (int j = 0; j < x.cols(); ++j) {
      x(i,j) = std::log(x(i,j));
    }
  }
  return x;
}


// [[Rcpp::export]]
double fast_exp_1(float x)  {
  float c1 = 0.0079729; 
  float c2 = 0.1385284; 
  float c3 = 2.8853900; 
  float c4 = 1.4426950; 
  
  x *= c4; //convert to 2^(x)
  int intPart = (int) x;
  x -= intPart;
  
  float xx = x * x;
  float a = x + c1 * xx * x;
  float b = c3 + c2 * xx;
  float res = (b + a) / (b - a);
  //res *= 2^(intPart);
  
  // reinterpret_cast<int &>(res) += intPart << 23; // res *= 2^(intPart)
  
  res *=  fastpow2_1(intPart) ; //  2^(intPart);
  
  //  res *= std::pow(2, intPart)  ;  
  //  res *= fastPow(2, intPart)  ; 
  
  return res ; 
}



// [[Rcpp::export]]
double fast_exp_1_double(double x)  {
  double c1 = 0.0079729; 
  double c2 = 0.1385284; 
  double c3 = 2.8853900; 
  double c4 = 1.4426950; 
  
  x *= c4; //convert to 2^(x)
  int intPart = (int) x;
  x -= intPart;
  
  double xx = x * x;
  double a = x + c1 * xx * x;
  double b = c3 + c2 * xx;
  double res = (b + a) / (b - a);
  //res *= 2^(intPart);
  
  //   reinterpret_cast<int &>(res) += intPart << 52; // res *= 2^(intPart)
  res *=  fastpow2_1_double(intPart) ; 
  //res *=  fastpow2_1(intPart) ; 
  //  res *= std::pow(2, intPart)  ;  
  //  res *= fastPow(2, intPart)  ; 
  
  return res ; 
}



// [[Rcpp::export]]
Eigen::Array<double, -1, 1  > fast_exp_1_Eigen_float(  Eigen::Array<double, -1, 1  > x)
{
  
  for (int i = 0; i < x.rows(); ++i) {
    x(i) = fast_exp_1(x(i));
  }
  
  return x; 
  
}

// [[Rcpp::export]]
Eigen::Array<double, -1, -1  > fast_exp_1_Eigen_mat_float(  Eigen::Array<double, -1, -1  > x)
{
  
  for (int i = 0; i < x.rows(); ++i) {
    for (int j = 0; j < x.cols(); ++j) {
      x(i,j) = fast_exp_1(x(i,j));
    }
  }
  return x; 
  
}

// [[Rcpp::export]]
Eigen::Array<double, -1, 1  > fast_exp_1_Eigen(  Eigen::Array<double, -1, 1  > x)
{
  for (int i = 0; i < x.rows(); ++i) {
    x(i) = fast_exp_1_double(x(i));
  }
  return x; 
}

// [[Rcpp::export]]
Eigen::Array<double, 1, -1  > fast_exp_1_Eigen_colvec(  Eigen::Array<double, 1, -1  > x)
{
  for (int i = 0; i < x.cols(); ++i) {
    x(i) = fast_exp_1_double(x(i));
  }
  return x;
}

// [[Rcpp::export]]
Eigen::Array<double, -1, -1  > fast_exp_1_Eigen_mat(  Eigen::Array<double, -1, -1  > x)
{
  for (int j = 0; j < x.cols(); ++j) {
    for (int i = 0; i < x.rows(); ++i) {
       x(i,j) = fast_exp_1_double(x(i,j)) ; 
    }
  }
  return x; 
}

// [[Rcpp::export]]
Eigen::Array<double, -1, -1 > fast_exp_1_Eigen_mat_RM(  Eigen::Array<double, -1, -1  > x)
{
  for (int i = 0; i < x.rows(); ++i) {
    for (int j = 0; j < x.cols(); ++j) {
      x(i,j) = fast_exp_1_double(x(i,j)) ;
    }
  }
  return x;
}











// [[Rcpp::export]]
Eigen::Array<double, -1, 1  > fast_exp_1_Eigen_v2(  Eigen::Array<double, -1, 1  > x)
{
  
  float c1 = 0.0079729; 
  float c2 = 0.1385284; 
  float c3 = 2.8853900; 
  float c4 = 1.4426950; 
  
  //Eigen::Array<float, -1, 1  >  x_float = x.cast<float>() ; 
  
  x *= c4; 
  
  x -=   x.round(); 
  // Eigen::Array<double, -1, 1  >  xx = x * x;
  // Eigen::Array<double, -1, 1  >  a = x + c1 * x * x * x;
  // Eigen::Array<double, -1, 1  >  b = c3 + c2 * x * x;
  // Eigen::Array<double, -1, 1  >  res = (b + a) / (b - a);
  
  //x = (b + a) / (b - a);
  
  x = ((c3 + c2 * x * x) + (x + c1 * x * x * x)) / ((c3 + c2 * x * x) - (x + c1 * x * x * x));
  
  // two_array.pow(intPart)
  
  //  res += pow(2.0, intPart); 
  
  {
    Eigen::Array<double, -1, 1  > intPart = x.round(); 
    for (int i = 0; i < x.rows(); ++i) {
      // x(i) *=   fastpow2_1(round(x(i))) ; 
      x(i) *=   fastpow2_1(intPart(i)) ; 
    }
  }
  
  return x;//.matrix();//.cast<double>();
  
}


















// [[Rcpp::export]]
double fast_exp_3 (float p)
{
  return fastpow2_1 (1.442695040f * p);
}



// [[Rcpp::export]]
Eigen::Array<double, -1, 1  > fast_exp_3_Eigen(  Eigen::Array<double, -1, 1  > x)
{
  
  for (int i = 0; i < x.rows(); ++i) {
    x(i) = fast_exp_3(x(i));
  }
  
  return x; 
  
}

// [[Rcpp::export]]
Eigen::Array<double, -1, -1  > fast_exp_3_Eigen_mat(  Eigen::Array<double, -1, -1  > x)
{
  
  for (int j = 0; j < x.cols(); ++j) {
    x.col(j)  = fast_exp_3_Eigen(x.col(j));
  }
  
  return x; 
  
}




// [[Rcpp::export]]
double  fastpow2_2 (float p)
{
  float clipp = (p < -126) ? -126.0f : p;
  union { uint32_t i; float f; } v = { uint32_t  ( (1 << 23) * ( clipp + 126.94269504f) ) };
  return v.f;
}

// [[Rcpp::export]]
double fast_exp_4 (float p)
{
  return fastpow2_2 (1.442695040f * p);
}



// [[Rcpp::export]]
Eigen::Array<double, -1, 1  > fast_exp_4_Eigen(  Eigen::Array<double, -1, 1  > x)
{
  
  for (int i = 0; i < x.rows(); ++i) {
    x(i) = fast_exp_4(x(i));
  }
  
  return x; 
  
}

// [[Rcpp::export]]
Eigen::Array<double, -1, -1  > fast_exp_4_Eigen_mat(  Eigen::Array<double, -1, -1  > x)
{
  
  for (int j = 0; j < x.cols(); ++j) {
    x.col(j)  = fast_exp_4_Eigen(x.col(j));
  }
  
  return x; 
  
}








float fast_exp_5_float(float x)
{
  constexpr float a = (1 << 23) / 0.69314718f;
  constexpr float b = (1 << 23) * (127 - 0.043677448f);
  x = a * x + b;
  
  constexpr float c = (1 << 23);
  constexpr float d = (1 << 23) * 255;
  if (x < c || x > d)
    x = (x < c) ? 0.0f : d;
  
  uint32_t n = static_cast<uint32_t>(x);
  memcpy(&x, &n, 4);
  return x;
}


// [[Rcpp::export]]
double fast_exp_5_double(double x)
{
  constexpr double a = (1ll << 52) / 0.6931471805599453;
  constexpr double b = (1ll << 52) * (1023 - 0.04367744890362246);
  x = a * x + b;
  
  constexpr double c = (1ll << 52);
  constexpr double d = (1ll << 52) * 2047;
  if (x < c || x > d)
    x = (x < c) ? 0.0 : d;
  
  uint64_t n = static_cast<uint64_t>(x);
  memcpy(&x, &n, 8);
  return x;
}



// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1  > fast_exp_5_Eigen(  Eigen::Array<double, -1, 1  > x)
{
  
  for (int i = 0; i < x.rows(); ++i) {
    x(i) = fast_exp_5_double(x(i));
  }
  
  return x.matrix();
  
}

// [[Rcpp::export]]
Eigen::Matrix<double, -1, -1  > fast_exp_5_Eigen_mat(  Eigen::Array<double, -1, -1  > x)
{
  
  for (int j = 0; j < x.cols(); ++j) {
    x.col(j)  = fast_exp_5_Eigen(x.col(j));
  }
  
  return x.matrix();
  
}




// 
// template <class To, class From> To bit_cast(const From &src) noexcept {
//   static_assert(sizeof(To) == sizeof(From), "Size mismatch");
//   To dst;
//   std::memcpy(&dst, &src, sizeof(To));
//   return dst;
// }



// 
// /// @return True if \p x is a NAN.
// bool is_nan(float x) {
//   unsigned xb = bit_cast<unsigned, float>(x);
//   xb >>= 23;
//   return (xb & 0xff) == 0xff;
// }
// 
// // Approximate the function \p exp in the range -0.004, 0.004.
// // Q = fpminimax(exp(x), 5, [|D...|], [-0.0039, 0.0039])
// double approximate_exp_pol_around_zero(float x) {
//   return 1 +
//     x * (1 + x * (0.49999999999985944576508245518198236823081970214844 +
//     x * (0.166666666666697105281258473041816614568233489990234 +
//     x * (4.1666696240209417922972789938285131938755512237549e-2 +
//     x * 8.3333337622652735310335714302709675393998622894287e-3))));
// }

// float __attribute__((noinline)) my_exp(float x) {
//   if (x >= 710) {
//     return bit_cast<float, unsigned>(0x7f800000); // Inf
//   } else if (x <= -710) {
//     return 0;
//   } else if (is_nan(x)) {
//     return x;
//   }
//   
//   // Split X into 3 numbers such that: x = I1 + (I2 << 8) + xt;
//   int Int1 = int(x);
//   x = x - Int1;
//   int Int2 = int(x * 256);
//   x = x - (float(Int2) / 256);
//   
//   return approximate_exp_pol_around_zero(x) * EXP_TABLE[Int1 + 710] * EXP_TABLE_r256[Int2 + 256];
// }



// 
// double __attribute__((noinline)) nop(double x) { return x + 1; }
// 
// double __attribute__((noinline)) fast_exp(double x) {
//   double integer = trunc(x);
//   // X is now the fractional part of the number.
//   x = x - integer;
//   
//   // Use a 4-part polynomial to approximate exp(x);
//   double c[] = { 0.28033708, 0.425302, 1.01273643, 1.00020947 };
//   
//   // Use Horner's method to evaluate the polynomial.
//   double val = c[3] + x * (c[2] + x * (c[1] + x * (c[0])));
//   return val * EXP_TABLE[(unsigned)integer + 710];
// }
// 
// 











// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    exp_stan(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  return stan::math::exp(x);
  
}

// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    log_stan(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  return stan::math::log(x);
  
}



// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    inv_logit_stan(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  return stan::math::inv_logit(x);
  
}





// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    tanh_stan(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  return stan::math::tanh(x);
  
}




// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    erfc_stan(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  return stan::math::erfc(x);
  
}



// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    Phi_stan(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  return stan::math::Phi(x);
  
}


// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    Phi_using_erfc_stan(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  double minus_sqrt_2_recip =  - 1 / stan::math::sqrt(2);
  return 0.5 *  stan::math::erfc( minus_sqrt_2_recip * x ) ; 
  
}






// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    inv_Phi_stan(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  return stan::math::inv_Phi(x);
  
}















// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    exp_Eigen(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  return  x.array().exp().matrix() ; 
  
}

// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    log_Eigen(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  return  x.array().log().matrix() ; 
  
}




// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    tanh_1_Eigen(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  return x.array().tanh().matrix() ; 
  
}



// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    fast_tanh_approx_1_Eigen(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
 
   //   return  ( 1-(2*(1/(1+ ( fast_exp_1_Eigen(x.array()*2) )))).array() ).matrix() ; 
     return  ( 1-(2*(1/(1+ ( (x.array()*2).array().exp() )))).array() ).matrix() ; 
  
}


// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    fast_tanh_approx_2_Eigen(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
    return   ( ( 2.0 / (1.0 + fast_exp_1_Eigen(-2.0*x.array()).array() ).array() ) - 1.0 ).matrix() ; 
  
}


// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>     tanh_2_Eigen(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  return   (  (1 - (-2 * x.array()).exp()).array()/(2 * (-x.array()).exp() ).array() ).matrix() ; //  )).matrix() ; 
  
}







// [[Rcpp::export]]
Eigen::Array<double, -1, 1>    fast_tanh_shifted_and_scaled_approx_Eigen(   Eigen::Array<double, -1, 1 >  x  )   { 
  
 // return   (  1 / ( 1 + fast_exp_1_Eigen(-2*x)  )  )  ; 
  return   (  1 / ( 1 + (-2*x).array().exp()  ).array()  ).array()  ; 
  
}






// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    erfc_Eigen(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  return x.array().erfc().matrix() ; 
  
}



// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    Phi_using_erfc_Eigen(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  double minus_sqrt_2_recip =  - 1 / stan::math::sqrt(2);
  return 0.5 *  ( minus_sqrt_2_recip * x ).array().erfc().matrix() ; 
  
}




// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    erfc_approx_1_eigen(   Eigen::Matrix<double, -1, 1 >  x  )   { 

  double two_div_sqrt_pi =  2 /   stan::math::sqrt( M_PI ) ; 
  
  return  (  1.0 - fast_tanh_approx_1_Eigen(  (two_div_sqrt_pi * x.array()  *  ( 1 + ( 0.08943089 * x.array() * x.array()  )    ) ).matrix() ).array() ).matrix() ;  
  
}

// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    erfc_approx_2_eigen(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  double two_div_sqrt_pi =  2 /   stan::math::sqrt( M_PI ) ; 
  
  return  (  1.0 - fast_tanh_approx_2_Eigen(  (two_div_sqrt_pi * x.array()  *  ( 1 + ( 0.08943089 * x.array() * x.array()  )    ) ).matrix() ).array() ).matrix() ;
  
}


// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>    Phi_approx_using_erfc_Eigen(   Eigen::Matrix<double, -1, 1 >  x  )   { 
  
  double minus_sqrt_2_recip =  - 1 / stan::math::sqrt(2);
  return 0.5 *  erfc_approx_2_eigen( minus_sqrt_2_recip * x ); 
  
}





 




// [[Rcpp::export]]
Eigen::Array<double, -1, 1>    inv_logit_1_Eigen(   Eigen::Array<double, -1, 1 >  x  )   { 
  
  int N = x.rows(); 
  
  for (int i = 0; i < N; i++) {
    x(i) =  ( ( 1.0 / (1.0 + exp(- x(i))  ) )  ) ; 
  }
  
  return x; 
  
}



// [[Rcpp::export]]
Eigen::Array<double, -1, 1>    fast_inv_logit_1_Eigen(   Eigen::Array<double, -1, 1 >  x  )   { 
  
  int N = x.rows(); 
  
  for (int i = 0; i < N; i++) {
    x(i) =  ( ( 1.0 / (1.0 + fast_exp_1_double(- x(i))  ) )  ) ; 
  }
  
  return x; 
  
}

// [[Rcpp::export]]
Eigen::Array<double, 1, -1>    fast_inv_logit_1_Eigen_rowvec(   Eigen::Array<double, 1, -1 >  x  )   { 
  
  int N = x.rows(); 
  
  for (int i = 0; i < N; i++) {
    x(i) =  ( ( 1.0 / (1.0 + fast_exp_1_double(- x(i))  ) )  ) ; 
  }
  
  return x;  
  
}





 


// [[Rcpp::export]]
Eigen::Array<double, -1, 1>    Phi_approx_1_Eigen(   Eigen::Array<double, -1, 1 >  x  )   { 
  
  
  int N = x.rows(); 
  
  for (int i = 0; i < N; i++) {
    double x_i =  x(i);
    x(i) =  (1.0/(1.0 +   exp(-(0.07056*x_i*x_i*x_i + 1.5976*x_i )) )) ;
  }
    
    return x; 
  
}



// [[Rcpp::export]]
Eigen::Array<double, 1, -1>    Phi_approx_1_Eigen_rowvec(   Eigen::Array<double, 1, -1 >  x  )   {


  int N = x.cols();

  for (int i = 0; i < N; i++) {
    double x_i =  x(i);
    x(i) =  (1.0/(1.0 +   exp(-(0.07056*x_i*x_i*x_i + 1.5976*x_i )) )) ;
  }

  return x;

}


 
// [[Rcpp::export]]
Eigen::Array<double, -1, 1>    fast_Phi_approx_1_Eigen(   Eigen::Array<double, -1, 1 >  x  )   { 
  
  
  int N = x.rows(); 
  
  for (int i = 0; i < N; i++) {
    double x_i =  x(i);
    x(i) =  (1.0/(1.0 +   fast_exp_1_double(-(0.07056*x_i*x_i*x_i + 1.5976*x_i )) )) ;
  }
  
  return x; 
  
}




// [[Rcpp::export]]
Eigen::Array<double, 1, -1>    fast_Phi_approx_1_Eigen_rowvec(   Eigen::Array<double, 1, -1 >  x  )   {


  int N = x.cols(); ;

  for (int i = 0; i < N; i++) {
    double x_i =  x(i);
    x(i) =  (1.0/(1.0 +   fast_exp_1_double(-(0.07056*x_i*x_i*x_i + 1.5976*x_i )) )) ;
  }

  return x;

}


// 














// [[Rcpp::export]]
double  qnorm_rcpp(double p) {
  
  double r;
  double val;
  double q = p - 0.5;
  
  if (fabs(q) <= .425) {
    r = .180625 - q * q;
    val = q * (((((((r * 2509.0809287301226727 +
      33430.575583588128105) * r + 67265.770927008700853) * r +
      45921.953931549871457) * r + 13731.693765509461125) * r +
      1971.5909503065514427) * r + 133.14166789178437745) * r +
      3.387132872796366608) / (((((((r * 5226.495278852854561 +
      28729.085735721942674) * r + 39307.89580009271061) * r +
      21213.794301586595867) * r + 5394.1960214247511077) * r +
      687.1870074920579083) * r + 42.313330701600911252) * r + 1.0);
  } else { /* closer than 0.075 from {0,1} boundary */
    if (q > 0) r = 1.0 - p;
    else r = p;
    
    r = sqrt(-log(r));
    
    if (r <= 5.) { /* <==> min(p,1-p) >= exp(-25) ~= 1.3888e-11 */
      r += -1.6;
      val = (((((((r * 0.00077454501427834140764 +
                        .0227238449892691845833) * r + .24178072517745061177) *
      r + 1.27045825245236838258) * r +
      3.64784832476320460504) * r + 5.7694972214606914055) * r + 4.6303378461565452959) * r +
      1.42343711074968357734) / (((((((r *
      0.00000000105075007164441684324 + 0.0005475938084995344946) *
      r + .0151986665636164571966) * r +
          .14810397642748007459) * r + .68976733498510000455) *
      r + 1.6763848301838038494) * r +
      2.05319162663775882187) * r + 1.);
    } else { /* very close to  0 or 1 */
      r += -5.;
      val = (((((((r * 0.000000201033439929228813265 +
        0.0000271155556874348757815) * r +
         .0012426609473880784386) * r + .026532189526576123093) *
        r + .29656057182850489123) * r +
        1.7848265399172913358) * r + 5.4637849111641143699) *
        r + 6.6579046435011037772) / (((((((r *
        0.00000000000000204426310338993978564 + 0.00000014215117583164458887)*
        r + 0.000018463183175100546818) * r +
        0.0007868691311456132591) * r + .0148753612908506148525)
                                          * r + .13692988092273580531) * r +
                                                .59983220655588793769) * r + 1.);
    }
    
    if (q < 0.0) val = -val;
  }
  return val;
  
}




// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>  qnorm_rcpp_vec( Eigen::Matrix<double, -1, 1>  p) {
  
  int N = stan::math::num_elements(p);
  
  for (int n = 0; n < N; n++) {
    p(n) = qnorm_rcpp(p(n));
  }
  
  return p;
}



// [[Rcpp::export]]
Eigen::Matrix<double, 1, -1>  qnorm_rcpp_rowvec( Eigen::Matrix<double, 1, -1>  p) {

  int N =  p.cols();

  for (int n = 0; n < N; n++) {
    p(n) = qnorm_rcpp(p(n));
  }

  return p;
}
// 




// [[Rcpp::export]]
Eigen::Matrix<double, -1, 1>  qnorm_rcpp_vec_2( Eigen::Matrix<double, -1, 1>  p) {
  
  int N = p.rows(); 
  
  for (int n = 0; n < N; n++) {
    p(n) = R::qnorm(p(n), 0, 1, true, false) ;  // qnorm_rcpp(p(n));
  }
  
  return p;
}






 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1 >    Rcpp_mult_mat_by_col_vec( Eigen::Matrix<double, -1, -1  >  mat,
                                                            Eigen::Matrix<double, -1, 1 >  colvec) {
   
   return(  mat * colvec  );
   
 }
 
 
 // [[Rcpp::export]]
 Eigen::Matrix<float, -1, 1 >    Rcpp_mult_mat_by_col_vec_float( Eigen::Matrix<float, -1, -1  >  mat,
                                                                  Eigen::Matrix<float, -1, 1 >  colvec) {
   
   return(  mat * colvec  );
   
 }
 
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, -1  >    Rcpp_mult_mat_by_mat(    Eigen::Matrix<double, -1, -1  >  mat_1,
                                                             Eigen::Matrix<double, -1, -1  >  mat_2) {
   
   return(  mat_1 * mat_2  );
   
 }
 
 
 
 
 // [[Rcpp::export]]
 double   Rcpp_det( Eigen::Matrix<double, -1, -1  >  mat) {
   
   return(   mat.determinant()   ) ;
   
 }
 
 
 
 
 // [[Rcpp::export]]
 double   Rcpp_log_det( Eigen::Matrix<double, -1, -1  >  mat) {
   
   return(  log( std::abs( mat.determinant())  )  ) ;
   
 }
 
 
 
 
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, -1  >    Rcpp_solve( Eigen::Matrix<double, -1, -1  >  mat) {
   
   return(mat.inverse());
   
 }
 
 
 
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, -1  >    Rcpp_Chol( Eigen::Matrix<double, -1, -1  >  mat) {
   
   return( mat.llt().matrixL()  );
   
 }
 
 
 
 
 
 
  



 
 
 // function for use in the log-posterior function (i.e. the function to calculate gradients for)
 stan::math::var fn_Phi_approx_FWD_AD_2(stan::math::var x) {
   stan::math::var y = 1/(1 + exp(-(0.07056*x*x*x + 1.5976*x)));
   return(y);
 }
 
 // build template
 template <typename T>
 T fn_Phi_approx_2(T x) {
   return(1/(1 + exp(-(1.702*x))));
 }
 
 // specialise template for ReturnType = double
 template <>
 double fn_Phi_approx_2(double x) {
   return(1/(1 + exp(-(1.702*x))));
 }
 
 // specialise template for ReturnType = stan::math::var (for autodiff)
 template <>
 stan::math::var fn_Phi_approx_2(stan::math::var x) {
   return(1/(1 + exp(-(1.702*x))));
 }
 
 // build template
 template <typename T>
 T fn_Phi_approx(T x) {
   return(1/(1 + exp(-(0.07056*x*x*x + 1.5976*x))));
 }
 
 // specialise template for ReturnType = double
 template <>
 double fn_Phi_approx(double x) {
   return(1/(1 + exp(-(0.07056*x*x*x + 1.5976*x))));
 }
 
 // specialise template for ReturnType = stan::math::var (for autodiff)
 template <>
 stan::math::var fn_Phi_approx(stan::math::var x) {
   return(1/(1 + exp(-(0.07056*x*x*x + 1.5976*x))));
 }
 
 // call with e.g. fn_Phi_approx<stan::math::var>(x)
 
 
 
 
 
 
 
 // function for use in the log-posterior function (i.e. the function to calculate gradients for)
 Eigen::Matrix<stan::math::var, -1, -1>	  fn_calculate_cutpoints_AD( 
     Eigen::Matrix<stan::math::var, -1, 1> log_diffs, //this is aparameter (col vec)
     stan::math::var first_cutpoint, // this is constant
     int K) {
   
   Eigen::Matrix<stan::math::var, -1, -1> cutpoints_set_full(K+1, 1);
   
   cutpoints_set_full(0,0) = -1000;
   cutpoints_set_full(1,0) = first_cutpoint;
   cutpoints_set_full(K,0) = +1000;
   
   for (int k=2; k < K; ++k) 
     cutpoints_set_full(k,0) =     cutpoints_set_full(k-1,0)  + (exp(log_diffs(k-2))) ;
   
   return cutpoints_set_full; // output is a parameter to use in the log-posterior function to be differentiated 
 }
 
 
 
 
 
 // NEED TO MAKE INTO A TEMPLATE!!!
 // function for use in the log-posterior function (i.e. the function to calculate gradients for)
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, -1>	  fn_calculate_cutpoints( 
     Eigen::Matrix<double, -1, 1> log_diffs, //this is a parameter (col vec)
     double first_cutpoint, // this is constant
     int K) {
   
   Eigen::Matrix<double, -1, -1> cutpoints_set_full(K+1, 1);
   
   cutpoints_set_full(0,0) = -1000;
   cutpoints_set_full(1,0) = first_cutpoint;
   cutpoints_set_full(K,0) = +1000;
   
   for (int k=2; k < K; ++k) 
     cutpoints_set_full(k,0) =     cutpoints_set_full(k-1,0)  + (exp(log_diffs(k-2))) ;
   
   return cutpoints_set_full; // output is a parameter to use in the log-posterior function to be differentiated 
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 // [[Rcpp::export]]
 std::vector<Eigen::Matrix<double, -1, -1 > > vec_of_mats_test(int n_rows,
                                                               int n_cols,
                                                               int n_mats) {
   
   
   std::vector<Eigen::Matrix<double, -1, -1 > > my_vec(n_mats);
   Eigen::Matrix<double, -1, -1 > mats  =   Eigen::Matrix<double, -1, -1>::Zero(n_rows, n_cols);
   
   for (int c = 0; c < n_mats; ++c) {
     my_vec[c] = mats;
   }
   
   return(my_vec); 
   
 }
 
 
 // [[Rcpp::export]]
 std::vector<Eigen::Matrix<int, -1, -1 > > vec_of_mats_test_int(int n_rows,
                                                                int n_cols,
                                                                int n_mats) {
   
   
   std::vector<Eigen::Matrix<int, -1, -1 > > my_vec(n_mats);
   Eigen::Matrix<int, -1, -1 > mats  =   Eigen::Matrix<int, -1, -1>::Zero(n_rows, n_cols);
   
   for (int c = 0; c < n_mats; ++c) {
     my_vec[c] = mats;
   }
   
   return(my_vec); 
   
 }
 
 
 
 
 // [[Rcpp::export]]
 std::vector<Eigen::Matrix<bool, -1, -1 > > vec_of_mats_test_bool(int n_rows,
                                                                  int n_cols,
                                                                  int n_mats) {
   
   
   std::vector<Eigen::Matrix<bool, -1, -1 > > my_vec(n_mats);
   Eigen::Matrix<bool, -1, -1 > mats(n_rows, n_cols);
   
   for (int c = 0; c < n_mats; ++c) {
     my_vec[c] = mats;
   }
   
   return(my_vec); 
   
 }
 
 
 
 
 
 // [[Rcpp::export]]
 std::vector<Eigen::Matrix<int, -1, -1 > > vec_of_mats_test_int_Ones( int n_rows,
                                                                      int n_cols,
                                                                      int n_mats) {
   
   std::vector<Eigen::Matrix<int, -1, -1 > > my_vec(n_mats);
   Eigen::Matrix<int, -1, -1 > mats  =   Eigen::Matrix<int, -1, -1>::Ones(n_rows, n_cols);
   
   for (int c = 0; c < n_mats; ++c) {
     my_vec[c] = mats;
   }
   
   return(my_vec); 
   
 }
 
 
 
 
 
 // [[Rcpp::export]]
 std::vector<Eigen::Matrix<double, -1, -1  , Eigen::RowMajor > > vec_of_mats_test_RM(int n_rows,
                                                                                     int n_cols,
                                                                                     int n_mats) {
   
   std::vector<Eigen::Matrix<double, -1, -1 , Eigen::RowMajor > > my_vec(n_mats);
   Eigen::Matrix<double, -1, -1, Eigen::RowMajor> mats  =   Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(n_rows, n_cols);
   
   for (int c = 0; c < n_mats; ++c) {
     my_vec[c] = mats;
   }
   
   return(my_vec);
   
 }
 
 
 
 
 
 
 
 std::vector<Eigen::Matrix<float, -1, -1 > > vec_of_mats_test_float(int n_rows,
                                                                    int n_cols,
                                                                    int n_mats) {
   
   std::vector<Eigen::Matrix<float, -1, -1 > > my_vec(n_mats);
   Eigen::Matrix<float, -1, -1 > mats  =   Eigen::Matrix<float, -1, -1>::Zero(n_rows, n_cols);
   
   for (int c = 0; c < n_mats; ++c) {
     my_vec[c] = mats;
   }
   
   return(my_vec); 
   
   
 }
 
 
 
 std::vector<Eigen::Matrix<float, -1, -1, Eigen::RowMajor > > vec_of_mats_test_float_RM(int n_rows,
                                                                                        int n_cols,
                                                                                        int n_mats) {
   
   std::vector<Eigen::Matrix<float, -1, -1 , Eigen::RowMajor > > my_vec(n_mats);
   Eigen::Matrix<float, -1, -1, Eigen::RowMajor > mats  =   Eigen::Matrix<float, -1, -1 , Eigen::RowMajor>::Zero(n_rows, n_cols);
   
   for (int c = 0; c < n_mats; ++c) {
     my_vec[c] = mats;
   }
   
   return(my_vec); 
   
   
 }
 
 
 
 
 
 
 
 
 std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > vec_of_mats_test_var(int n_rows,
                                                                            int n_cols,
                                                                            int n_mats) {
   
   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > my_vec(n_mats);
   Eigen::Matrix<stan::math::var, -1, -1 > mats  =   Eigen::Matrix<stan::math::var, -1, -1>::Zero(n_rows, n_cols);
   
   for (int c = 0; c < n_mats; ++c) {
     my_vec[c] = mats;
   }
   
   return(my_vec); 
   
 }
 
 
 std::vector<Eigen::Matrix<stan::math::var, -1, -1 , Eigen::RowMajor > > vec_of_mats_test_var_RM(int n_rows,
                                                                                                 int n_cols,
                                                                                                 int n_mats) {
   
   
   std::vector<Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor > > my_vec(n_mats);
   Eigen::Matrix<stan::math::var, -1, -1,  Eigen::RowMajor> mats  =   Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor>::Zero(n_rows, n_cols);
   
   for (int c = 0; c < n_mats; ++c) {
     my_vec[c] = mats;
   }
   
   return(my_vec); 
   
 }
 
 
 
 
 
 
 
 
  
 
 
 
 
 // input vector, outputs upper-triangular 3d array of corrs- double
 std::vector<Eigen::Matrix<stan::math::var, -1, -1> >  fn_convert_Eigen_vec_of_corrs_to_3d_array_var(
                                                                                                                         Eigen::Matrix<stan::math::var, -1, -1  >  input_vec,
                                                                                                                         int n_rows,
                                                                                                                         int n_arrays) {
   
   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >   output_array = vec_of_mats_test_var(n_rows, n_rows, n_arrays); // 1d vector to output
   
   int k = 0;
   for (int c = 0; c < n_arrays; ++c) {
     for (int i = 1; i < n_rows; ++i)  {
       for (int j = 0; j < i; ++j) { // equiv to 1 to K - 2 in R
         output_array[c](i,j) =  input_vec(i);
         k += 1;
       }
     }
   }
   
   return output_array; // output is a parameter to use in the log-posterior function to be differentiated
 }
 
 
 
 
 
 
 // input vector, outputs upper-triangular 3d array of corrs- double
 std::vector<Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor > >  fn_convert_Eigen_vec_of_corrs_to_3d_array_var_RM(
                                                                                                           Eigen::Matrix<stan::math::var, -1, -1  >  input_vec,
                                                                                                           int n_rows,
                                                                                                           int n_arrays) {

   std::vector<Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor > >   output_array = vec_of_mats_test_var_RM(n_rows, n_rows, n_arrays); // 1d vector to output

   int k = 0;
   for (int c = 0; c < n_arrays; ++c) {
     for (int i = 1; i < n_rows; ++i)  {
       for (int j = 0; j < i; ++j) { // equiv to 1 to K - 2 in R
         output_array[c](i,j) =  input_vec(i);
         k += 1;
       }
     }
   }

   return output_array; // output is a parameter to use in the log-posterior function to be differentiated
 }





 


 // outputs vector, input upper-triangular 3d array of corrs- double
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1 >     fn_convert_3d_array_of_corrs_to_Eigen_vec_RM(
                                                                     std::vector<Eigen::Matrix<double, -1, -1  > >  input_array,
                                                                     int n_rows,
                                                                     int n_arrays) {

   
    int dim = n_arrays * 0.5 * n_rows * (n_rows - 1);
    Eigen::Matrix<double, -1, 1>   output_vec(dim); // 1d vector to output
    
    std::vector<Eigen::Matrix<double, -1, -1, Eigen::RowMajor > >  input_array_RM =  vec_of_mats_test_RM(n_rows, n_rows, n_arrays)  ; // input_array;
    
    for (int c = 0; c < n_arrays; ++c) {
        input_array_RM[c] = input_array[c]; 
    }

   int k = 0;
   for (int c = 0; c < n_arrays; ++c) {
     for (int i = 1; i < n_rows; ++i)  {
       for (int j = 0; j < i; ++j) { // equiv to 1 to K - 2 in R
         output_vec(k) = input_array_RM[c](i,j);
         k += 1;
       }
     }
   }

   return output_vec; // output is a parameter to use in the log-posterior function to be differentiated
 }


 
 
 
 
 
 // outputs vector, input upper-triangular 3d array of corrs- var
 Eigen::Matrix<stan::math::var, -1, 1  >     fn_convert_3d_array_of_corrs_to_Eigen_vec_var_RM(
                                                                                             std::vector<Eigen::Matrix<stan::math::var, -1, -1  > >  input_array,
                                                                                             int n_rows,
                                                                                             int n_arrays) {

     int dim = n_arrays * 0.5 * n_rows * (n_rows - 1);
     Eigen::Matrix<stan::math::var, -1, 1  >    output_vec(dim); // 1d vector to output

     
     std::vector<Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor > >  input_array_RM =  vec_of_mats_test_var_RM(n_rows, n_rows, n_arrays)  ; // input_array;
     
     
     
     for (int c = 0; c < n_arrays; ++c) {
       input_array_RM[c] = input_array[c]; 
     }
     
     
   int k = 0;
   for (int c = 0; c < n_arrays; ++c) {
     for (int i = 1; i < n_rows; ++i)  {
       for (int j = 0; j < i; ++j) { // equiv to 1 to K - 2 in R
         output_vec(k) = input_array_RM[c](i,j);
         k += 1;
       }
     }
   }

   return output_vec; // output is a parameter to use in the log-posterior function to be differentiated
 }


 
 
 
 
 
 
 
 // convert std vec to eigen vec - var
 Eigen::Matrix<stan::math::var, -1, 1> std_vec_to_Eigen_vec_var(std::vector<stan::math::var> std_vec) {

   Eigen::Matrix<stan::math::var, -1, 1>  Eigen_vec(std_vec.size());

   for (int i = 0; i < std_vec.size(); ++i) {
     Eigen_vec(i) = std_vec[i];
   }

   return(Eigen_vec);
 }




 // convert std vec to eigen vec - double
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1> std_vec_to_Eigen_vec(std::vector<double> std_vec) {

   Eigen::Matrix<double, -1, 1>  Eigen_vec(std_vec.size());

   for (int i = 0; i < std_vec.size(); ++i) {
     Eigen_vec(i) = std_vec[i];
   }

   return(Eigen_vec);
 }

 // [[Rcpp::export]]
 std::vector<double> Eigen_vec_to_std_vec(Eigen::Matrix<double, -1, 1> Eigen_vec) {

   std::vector<double>  std_vec(Eigen_vec.rows());

   for (int i = 0; i < Eigen_vec.rows(); ++i) {
     std_vec[i] = Eigen_vec(i);
   }

   return(std_vec);
 }


 std::vector<stan::math::var> Eigen_vec_to_std_vec_var(Eigen::Matrix<stan::math::var, -1, 1> Eigen_vec) {

   std::vector<stan::math::var>  std_vec(Eigen_vec.rows());

   for (int i = 0; i < Eigen_vec.rows(); ++i) {
     std_vec[i] = Eigen_vec(i);
   }

   return(std_vec);
 }




 
 // [[Rcpp::export]]
 std::vector<std::vector<Eigen::Matrix<double, -1, -1 > > > vec_of_vec_of_mats_test(int n_rows,
                                                                                    int n_cols,
                                                                                    int n_mats_inner,
                                                                                    int n_mats_outer) {


   std::vector<Eigen::Matrix<double, -1, -1 > > my_vec_of_mats =  vec_of_mats_test(n_rows, n_cols, n_mats_inner);
   std::vector<std::vector<Eigen::Matrix<double, -1, -1 > > >  my_vec_of_vecs; 
   

   for (int c1 = 0; c1 < n_mats_outer; ++c1) {
       my_vec_of_vecs[c1]  = my_vec_of_mats;
   }


   return(my_vec_of_vecs);

 }














 std::vector<std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > > vec_of_vec_of_mats_test_var(int n_rows,
                                                                                    int n_cols,
                                                                                    int n_mats_inner,
                                                                                    int n_mats_outer) {


   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > my_vec_of_mats =  vec_of_mats_test_var(n_rows, n_cols, n_mats_inner);
   std::vector<std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > >  my_vec_of_vecs; 

   for (int c1 = 0; c1 < n_mats_outer; ++c1) {
     my_vec_of_vecs[c1]  = my_vec_of_mats;
   }


   return(my_vec_of_vecs);

 }
 
 
 
 
 
 
 // input vector, outputs upper-triangular 3d array of corrs- double
 std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >   fn_convert_std_vec_of_corrs_to_3d_array_var( 
     std::vector<stan::math::var>   input_vec, 
     int n_rows,
     int n_arrays) {
   
   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >   output_array = vec_of_mats_test_var(n_rows, n_rows, n_arrays); // 1d vector to output
   
   int k = 0;
   for (int c = 0; c < n_arrays; ++c) {
     for (int i = 1; i < n_rows; ++i)  {
       for (int j = 0; j < i; ++j) { // equiv to 1 to K - 2 in R
         output_array[c](i,j) =  input_vec[k];
         k = k + 1; 
       }
     }
   }
   
   return output_array; // output is a parameter to use in the log-posterior function to be differentiated 
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 // [[Rcpp::export]]
 std::vector<Eigen::Matrix<double, -1, -1, Eigen::RowMajor > >    fn_convert_unconstrained_to_corrs_double_RM(Eigen::Matrix<double, -1, -1  > Omega_unconstrained
 ) {


   int dim = Omega_unconstrained.rows();

   ///////////  (1) define lower-triangular matrix Z (tanh transform of Omega_unconstrained)
   Eigen::Matrix<double, -1, -1, Eigen::RowMajor > Omega_Z = Eigen::Matrix<double, -1, -1, Eigen::RowMajor >::Zero(dim,  dim);



   // // diagonal of zero's (i = j)
   // for (int i = 0; i < dim; ++i) {
   //   Omega_Z(i,i) = 0;
   // }

   // // upper triangle of zero's (j > i )
   // for (int j = 1; j < dim; ++j)  {
   //   for (int i = 0; i < j; ++i) { // equiv to 1 to K - 2 in R
   //     Omega_Z(i,j) = 0.0;
   //   }
   // }


   // lower triangle of tanh transforms (j < i)
   for (int i = 1; i < dim; ++i)  {
     for (int j = 0; j < i; ++j) { // equiv to 1 to K - 2 in R
       Omega_Z(i,j) = stan::math::tanh(Omega_unconstrained(i,j)) ; // (exp(2 * Omega_unconstrained(i,j)) - 1 ) /   (exp(2 * Omega_unconstrained(i,j)) + 1 );
     }
   }

   
   
   
    
   
   
   // convert to a vector
   std::vector<Eigen::Matrix<double, -1, -1  > > Omega_Z_array_CM = vec_of_mats_test(dim, dim, 1);
   Omega_Z_array_CM[0] = Omega_Z;

   Eigen::Matrix<double, -1, 1> Omega_Z_vec =  fn_convert_3d_array_of_corrs_to_Eigen_vec_RM(Omega_Z_array_CM,
                                                                                              dim,
                                                                                              1);

   ///////////// (2) then map Omega_Z -> LOWER - triangular cholesky factor corr's
   Eigen::Matrix<double, -1, -1  > L_Omega_lower = Eigen::Matrix<double, -1, -1, Eigen::RowMajor >::Zero(dim,  dim);


   int counter = 0;

   L_Omega_lower(0,0) = 1;  // 1 if i = j = 1

   double term_2 = 0.0;


   Eigen::Matrix<double, -1, -1, Eigen::RowMajor  > sqrt_term = Eigen::Matrix<double, -1, -1, Eigen::RowMajor >::Zero(dim,  dim);
   Eigen::Matrix<double, -1, -1, Eigen::RowMajor  > term_inv = Eigen::Matrix<double, -1, -1, Eigen::RowMajor >::Zero(dim,  dim);


   for (int i = 1; i < dim; ++i) {

     //  L_Omega_lower(i, 0) = Omega_Z_vec(counter);
     L_Omega_lower(i, 0) = Omega_Z(i, 0);
     counter = counter + 1;

     double temp_sum_square = L_Omega_lower(i, 0) * L_Omega_lower(i, 0);

     for (int j = 1; j < i + 1; ++j) {

       if (j == i) { continue; }


       //
       if (j != i) {

         term_2 += 0.5 * stan::math::log1m(temp_sum_square);

         L_Omega_lower(i, j) =  Omega_Z(i, j) * stan::math::sqrt(1.0 - temp_sum_square);

         sqrt_term(i, j) = stan::math::sqrt(1.0 - temp_sum_square);
         term_inv(i, j) = (1.0 /  sqrt_term(i, j)) * (1.0 /  sqrt_term(i, j));

         temp_sum_square += L_Omega_lower(i, j) * L_Omega_lower(i, j);


       }

     }
     L_Omega_lower(i, i) =  stan::math::sqrt(1.0 - temp_sum_square);

   }


   //////////// (3) calculate correlation matrix
   Eigen::Matrix<double, -1, -1, Eigen::RowMajor  > Omega = L_Omega_lower * L_Omega_lower.transpose();

   for (int i = 0; i < dim; ++i) {
     Omega(i,i) = 1.0;
   }

   //////////////////// calculate Jacobian adjustment
   // make vector of unconstrained params
   Eigen::Matrix<double, -1, 1  > Omega_y_vec =   Omega_Z_vec;
   Eigen::Matrix<double, -1, 1  > jac_vec =   Omega_Z_vec;

   for (int i = 0; i < Omega_Z_vec.rows(); ++i) {
     Omega_y_vec(i) = 0.5 * stan::math::log( (1.0 + Omega_Z_vec(i)) / (1.0 - Omega_Z_vec(i)) );  // undo tanh transform
     jac_vec(i) = stan::math::log( ( stan::math::exp( Omega_y_vec(i) ) +  stan::math::exp( - Omega_y_vec(i) ) ) / 2.0 ); // cosh(y)
   }

   double term_1 = -2.0 * jac_vec.sum();

   double log_det_jacobian = term_1 + term_2;


   //////// outputs
   std::vector<Eigen::Matrix<double, -1, -1, Eigen::RowMajor  > > out = vec_of_mats_test_RM(dim, dim, 6) ;

   out[0] = L_Omega_lower;
   out[1] = Omega;
   out[2] = Omega_Z;
   out[3](0,0) = log_det_jacobian;
   out[4] = sqrt_term;
   out[5] =  term_inv;


   return(out);

 }

 // 
 // 
 // 

 
 
 
 
 // 
 /////////////// for var corr's
 std::vector<Eigen::Matrix<stan::math::var, -1, -1 , Eigen::RowMajor  > >    fn_convert_unconstrained_to_corrs_var_RM(Eigen::Matrix<stan::math::var, -1, -1  > Omega_unconstrained
 ) {


   int dim = Omega_unconstrained.rows();

   ///////////  (1) define lower-triangular matrix Z (tanh transform of Omega_unconstrained)
   Eigen::Matrix<stan::math::var, -1, -1 , Eigen::RowMajor > Omega_Z =    Eigen::Matrix<stan::math::var, -1, -1 , Eigen::RowMajor >::Zero(dim, dim);

   // // diagonal of zero's (i = j)
   // for (int i = 0; i < dim; ++i) {
   //   Omega_Z(i,i) = 0;
   // }
   //
   // // upper triangle of zero's (j > i )
   // for (int j = 1; j < dim; ++j)  {
   //   for (int i = 0; i < j; ++i) {
   //     Omega_Z(i,j) = 0;
   //   }
   // }

   // lower triangle of tanh transforms (j < i)
   for (int i = 1; i < dim; ++i)  {
     for (int j = 0; j < i; ++j) {
       Omega_Z(i,j) = stan::math::tanh(Omega_unconstrained(i,j))  ; // (exp(2 * Omega_unconstrained(i,j)) - 1 ) /   (exp(2 * Omega_unconstrained(i,j)) + 1 );
     }
   }

   
   
   // convert to a vector
   std::vector<Eigen::Matrix<stan::math::var, -1, -1  > > Omega_Z_array_CM = vec_of_mats_test_var(dim, dim, 1);
   Omega_Z_array_CM[0] = Omega_Z;

   Eigen::Matrix<stan::math::var, -1, 1  > Omega_Z_vec = fn_convert_3d_array_of_corrs_to_Eigen_vec_var_RM(Omega_Z_array_CM,
                                                                                                          dim,
                                                                                                          1);

   ///////////// (2) then map Omega_Z -> LOWER - triangular cholesky factor corr's
   Eigen::Matrix<stan::math::var, -1, -1 , Eigen::RowMajor > L_Omega_lower = Eigen::Matrix< stan::math::var, -1, -1 , Eigen::RowMajor >::Zero(dim, dim);

   Eigen::Matrix<stan::math::var, -1, -1 , Eigen::RowMajor > sqrt_term =  Eigen::Matrix< stan::math::var, -1, -1 , Eigen::RowMajor >::Zero(dim, dim);
   Eigen::Matrix<stan::math::var, -1, -1 , Eigen::RowMajor > term_inv = Eigen::Matrix< stan::math::var, -1, -1 , Eigen::RowMajor >::Zero(dim, dim);

   L_Omega_lower(0,0) = 1.0;  // 1 if i = j = 1
   stan::math::var term_2 = 0.0;

   for (int i = 1; i < dim; ++i) {

     L_Omega_lower(i, 0) = Omega_Z(i, 0);

     stan::math::var temp_sum_square = L_Omega_lower(i, 0) * L_Omega_lower(i, 0);

     for (int j = 1; j < i + 1; ++j) {

       if (j == i) { continue; }


       if (j != i) {

         term_2 += 0.5 * stan::math::log1m(temp_sum_square);

         sqrt_term(i, j) = stan::math::sqrt( 1.0 - temp_sum_square);
         term_inv(i, j) = (1.0 /  sqrt_term(i, j)) * (1.0 /  sqrt_term(i, j));

         L_Omega_lower(i, j) =  Omega_Z(i, j) * stan::math::sqrt( 1.0 - temp_sum_square);

         temp_sum_square += L_Omega_lower(i, j) * L_Omega_lower(i, j);


       }

     }

     L_Omega_lower(i, i) =  stan::math::sqrt(1.0 - temp_sum_square);

   }


   //////////// (3) calculate correlation matrix
   Eigen::Matrix<stan::math::var, -1, -1 , Eigen::RowMajor  > Omega = L_Omega_lower * L_Omega_lower.transpose();

   for (int i = 0; i < dim; ++i) {
     Omega(i,i) = 1.0;
   }

   //////////////////// calculate Jacobian adjustment
   // make vector of unconstrained params
   Eigen::Matrix< stan::math::var, -1, 1  > Omega_y_vec(dim, dim) ; // =   Omega_Z_vec;
   Eigen::Matrix< stan::math::var, -1, 1  > jac_vec(dim, dim) ; //  =   Omega_Z_vec;

   for (int i = 0; i < Omega_Z_vec.rows(); ++i) {
     Omega_y_vec(i) = 0.5 * stan::math::log( (1.0 + Omega_Z_vec(i)) / (1.0 - Omega_Z_vec(i)) );  // undo tanh transform
     jac_vec(i) = stan::math::log( ( stan::math::exp( Omega_y_vec(i) ) +  stan::math::exp( - Omega_y_vec(i) ) ) / 2 ); // cosh(y)
   }

   stan::math::var term_1 =   -2.0 * jac_vec.sum();

   Eigen::Matrix< stan::math::var, -1, -1 , Eigen::RowMajor > jac_mtx = Eigen::Matrix< stan::math::var, -1, -1 , Eigen::RowMajor >::Zero(dim, dim);

   stan::math::var log_det_jacobian = term_1 + term_2;

   ////////// outputs

   std::vector<Eigen::Matrix<stan::math::var, -1, -1 , Eigen::RowMajor > > out = vec_of_mats_test_var_RM(dim, dim, 6) ;

   out[0] = L_Omega_lower;
   out[1] = Omega;
   out[2] = Omega_Z;
   out[3](0,0) = log_det_jacobian;
   out[4] = sqrt_term;
   out[5] =  term_inv;

   return(out);

 }


 // 
 
 
 
 
 
 
 // [[Rcpp::export]]
 double phi_sq_sum(Eigen::Matrix<double, -1, -1>  phi) {
   
   Eigen::Matrix<double, -1, 1> phi_sq(phi.rows(), 1);
   
   double M_inv_x_phi_sq_sum;
   Eigen::Matrix<double, -1, 1> M_inv_x_phi_sq;
   
   for (int k = 0; k < phi.rows(); ++k) {
     phi_sq(k,0) = phi(k,0) * phi(k,0);
   }
   
   M_inv_x_phi_sq =  phi_sq;
   
   M_inv_x_phi_sq_sum = M_inv_x_phi_sq.sum();
   
   return(M_inv_x_phi_sq_sum);
   
 }
 
 
 // [[Rcpp::export]]
 double phi_sq_x_M_inv_sum(Eigen::Matrix<double, -1, -1>  phi,
                           Eigen::Matrix<double, -1, -1>  M_inv) {
   
   
   double M_inv_x_phi_sq_sum;
   Eigen::Matrix<double, -1, -1> M_inv_x_phi_sq_sum_mat;
   
   M_inv_x_phi_sq_sum_mat = phi.transpose() * M_inv * phi;
   
   M_inv_x_phi_sq_sum = M_inv_x_phi_sq_sum_mat(0,0);
   
   return(M_inv_x_phi_sq_sum);
   
 }
 
 
 
 
 
 // for general Phi both overflow and underflow of concern
 stan::math::var Phi_approx_underflow_overflow(stan::math::var x)  {     
   
   if ((x >= -5) || (x <= 5)) { 
     return((stan::math::Phi_approx(x)));
   } else if (x < - 5)  { 
     return(exp(-0.5 * x * x - 4.8 + 2509 * ( (x-13)/((x-40)*(x-40)*(x-5)) )));
   } else { 
     return((0.5 * (1 + stan::math::sqrt(1 - stan::math::exp(-2*x*x/3.14159265359)))));
   }
   
 }
 
 // for log(Phi), UNDERFLOW is concern so use stable approx for x < -5
 stan::math::var log_Phi_approx(stan::math::var x)  {     
   
   if ((x > -5)) { 
     return(stan::math::log(stan::math::Phi_approx(x)));
   } else  { 
     return((-0.5 * x * x - 4.8 + 2509 * ( (x-13)/((x-40)*(x-40)*(x-5)) )));
   } 
   
 }
 
 // for log1m, OVERFLOW of Phi is concern so use stable approx for x > 5
 stan::math::var log_1m_Phi_approx(stan::math::var x)  {     
   
   
   if (x < 5) { 
     return(stan::math::log1m(stan::math::Phi_approx(x)));
   } else { 
     return(stan::math::log1m(0.5 * (1 + stan::math::sqrt(1 - stan::math::exp(-2*x*x/3.14159265359)))));
   }
   
   
 }
 
 
 
 
 
 
 
 stan::math::var    fn_log_1m_Phi_var(    stan::math::var x    ) {
   
   
   
   if (x < 5) { // low x not an issue for log(1 - Phi(x)) [goes to 0]
     stan::math::var y = stan::math::log1m(stan::math::Phi(x));
     return(y);
   } else { 
     stan::math::var y = - stan::math::log(x + sqrt(x*x + 2)) - 0.5 * stan::math::log(M_PI/2) - 0.5*x*x;
     return(y);
   }
   
 }
 
 
 stan::math::var    fn_log_Phi_var(    stan::math::var x    ) {
   
   
   
   if (x > -37) { // high x not an issue for log(Phi(x)) [ goes to 0]
     stan::math::var y = stan::math::log(stan::math::Phi(x));
     return(y);
   } else { 
     x = stan::math::fabs(x);
     stan::math::var y = - stan::math::log(x + sqrt(x*x + 2)) - 0.5 * stan::math::log(M_PI/2) - 0.5*x*x;
     return(y);
   }
   
 }
 
 stan::math::var    fn_log_Phi_diff_var(    stan::math::var x1, 
                                            stan::math::var x2) {
   
   
   
   if ((x1 < 5) || (x2 < 5)) { 
     stan::math::var y = stan::math::log(stan::math::Phi(x1) - stan::math::Phi(x2));
     return(y);
   } else { 
     stan::math::var y =  stan::math::log(-stan::math::exp(fn_log_1m_Phi_var(x2)) + stan::math::exp(fn_log_1m_Phi_var(x1)));
     return(y);
   }
   
 }
 
 
 // [[Rcpp::export]]
 double    fn_log_1m_Phi_double(   double x    ) {
   
   
   
   if (x < 5) { // low x not an issue for log(1 - Phi(x)) [goes to 0]
     // double y = stan::math::log1m(stan::math::Phi(x));
     double y = R::pnorm(x, 0, 1, false, true); 
     return(y);
   } else { 
     double y = - stan::math::log(x + sqrt(x*x + 2)) - 0.5 * stan::math::log(M_PI/2) - 0.5*x*x;
     return(y);
   }
   
 }
 
 Eigen::Matrix<double, -1, 1>     fn_log_1m_Phi_double_vec(   Eigen::Matrix<double, -1, 1>  x    ) {
   
   int N = x.rows();
   
   Eigen::Matrix<double, -1, 1> y   = stan::math::log1m(stan::math::Phi(x)); // apply standard Phi first
   
   for (int n = 0; n < N; ++n ) {
     if (x(n) > 5) { // low x not an issue for log(1 - Phi(x)) [goes to 0]
       double x_sq = x(n) * x(n);
       y(n) = - stan::math::log(x(n) + sqrt(x_sq + 2)) - 0.5 * stan::math::log(M_PI/2) - 0.5*x_sq;
     }
   }
   
   return(y);
   
 }
 
 // [[Rcpp::export]]
 double    fn_log_Phi_double(    double x    ) {
   
   
   
   if (x > -37) { // high x not an issue for log(Phi(x)) [ goes to 0]
     // double y = stan::math::log(stan::math::Phi(x));
     double y = R::pnorm(x, 0, 1, true, true); 
     return(y);
   } else { 
     x = stan::math::fabs(x);
     double y = - stan::math::log(x + sqrt(x*x + 2)) - 0.5 * stan::math::log(M_PI/2) - 0.5*x*x;
     return(y);
   }
   
 }
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1>     fn_log_Phi_double_vec(    Eigen::Matrix<double, -1, 1> x    ) {
   
   
   int N = x.rows();
   
   Eigen::Matrix<double, -1, 1> y   = stan::math::log(stan::math::Phi(x)); // apply standard Phi first
   
   for (int n = 0; n < N; ++n ) {
     if (x(n) < -37) { // high x not an issue for log(Phi(x)) [ goes to 0 ]
       x(n) = stan::math::fabs(x(n));
       double x_sq = x(n) * x(n);
       y(n) = - stan::math::log(x(n) + sqrt(x_sq + 2)) - 0.5 * stan::math::log(M_PI/2) - 0.5*x_sq;
     }
   }
   
   return(y);
   
 }
 
 
 
 
 
 Eigen::Matrix<double, -1, 1>     fn_first_element_neg_rest_pos_colvec(      Eigen::Matrix<double, -1, 1>  col_vec    ) {
   
   col_vec(0) = - col_vec(0);
   
   return(col_vec);
   
 }
 
 
 Eigen::Matrix<double, 1, -1>     fn_first_element_neg_rest_pos(      Eigen::Matrix<double, 1, -1>  row_vec    ) {
   
   row_vec(0) = - row_vec(0);
   
   return(row_vec);
   
 }
 
 
 Eigen::Matrix<float, 1, -1>     fn_first_element_neg_rest_pos_float(   
     Eigen::Matrix<float, 1, -1>  row_vec 
 ) {
   
   row_vec(0) = - row_vec(0);
   
   return(row_vec);
   
 }
 
 
 
 
 Eigen::Matrix<stan::math::var, 1, -1>     fn_first_element_neg_rest_pos_var(   
     Eigen::Matrix<stan::math::var, 1, -1>  row_vec 
 ) {
   
   row_vec(0) = - row_vec(0);
   
   return(row_vec);
   
 }
 
 
 
 
 
  
 
 
 
 
 std::unique_ptr<size_t[]> get_commutation_unequal_vec
  (unsigned const n, unsigned const m, bool const transpose){
   unsigned const nm = n * m, 
     nnm_p1 = n * nm + 1L, 
     nm_pm = nm + m;
   std::unique_ptr<size_t[]> out(new size_t[nm]);
   size_t * const o_begin = out.get();
   size_t idx = 0L;
   for(unsigned i = 0; i < n; ++i, idx += nm_pm){
     size_t idx1 = idx;
     for(unsigned j = 0; j < m; ++j, idx1 += nnm_p1)
       if(transpose)
         *(o_begin + idx1 / nm) = (idx1 % nm);
       else
         *(o_begin + idx1 % nm) = (idx1 / nm);
   }
   
   return out;
 }

// [[Rcpp::export(rng = false)]]
Rcpp::NumericVector commutation_dot
  (unsigned const n, unsigned const m, Rcpp::NumericVector x, 
   bool const transpose){
  size_t const nm = n * m;
  Rcpp::NumericVector out(nm);
  auto const indices = get_commutation_unequal_vec(n, m, transpose);
  
  for(size_t i = 0; i < nm; ++i)
    out[i] = x[*(indices.get() +i )];
  
  return out;
}

Rcpp::NumericMatrix get_commutation_unequal
  (unsigned const n, unsigned const m){
  
  unsigned const nm = n * m, 
    nnm_p1 = n * nm + 1L, 
    nm_pm = nm + m;
  Rcpp::NumericMatrix out(nm, nm);
  double * o = &out[0];
  for(unsigned i = 0; i < n; ++i, o += nm_pm){
    double *o1 = o;
    for(unsigned j = 0; j < m; ++j, o1 += nnm_p1)
      *o1 = 1.;
  }
  
  return out;
}

Rcpp::NumericMatrix get_commutation_equal(unsigned const m){
  unsigned const mm = m * m, 
    mmm = mm * m, 
    mmm_p1 = mmm + 1L, 
    mm_pm = mm + m;
  Rcpp::NumericMatrix out(mm, mm);
  double * const o = &out[0];
  unsigned inc_i(0L);
  for(unsigned i = 0; i < m; ++i, inc_i += m){
    double *o1 = o + inc_i + i * mm, 
      *o2 = o + i     + inc_i * mm;
    for(unsigned j = 0; j < i; ++j, o1 += mmm_p1, o2 += mm_pm){
      *o1 = 1.;
      *o2 = 1.;
    }
    *o1 += 1.;
  }
  return out;
}

// [[Rcpp::export(rng = false)]]
Eigen::Matrix<double, -1, -1  >  get_commutation(unsigned const n, unsigned const m) {
  
  if (n == m)  {
    
    Rcpp::NumericMatrix commutation_mtx_Nuemric_Matrix =  get_commutation_equal(n);
    
    double n_rows = commutation_mtx_Nuemric_Matrix.nrow(); 
    double n_cols = commutation_mtx_Nuemric_Matrix.ncol(); 
    
    Eigen::Matrix<double, -1, -1>  commutation_mtx_Eigen   =  Eigen::Matrix<double, -1, -1>::Zero(n_rows, n_cols); 
    
    
    for (int i = 0; i < n_rows; ++i) {
      for (int j = 0; j < n_cols; ++j) {
        commutation_mtx_Eigen(i, j) = commutation_mtx_Nuemric_Matrix(i, j) ; 
      }
    }
    
    return commutation_mtx_Eigen;
    
    
  } else { 
    
    Rcpp::NumericMatrix commutation_mtx_Nuemric_Matrix =  get_commutation_unequal(n, m);
    
    double n_rows = commutation_mtx_Nuemric_Matrix.nrow(); 
    double n_cols = commutation_mtx_Nuemric_Matrix.ncol(); 
    
    Eigen::Matrix<double, -1, -1>  commutation_mtx_Eigen   =  Eigen::Matrix<double, -1, -1>::Zero(n_rows, n_cols); 
    
    
    for (int i = 0; i < n_rows; ++i) {
      for (int j = 0; j < n_cols; ++j) {
        commutation_mtx_Eigen(i, j) = commutation_mtx_Nuemric_Matrix(i, j) ; 
      }
    }
    
    return commutation_mtx_Eigen;
    
    
  }
  
  
  
  
  
}







// [[Rcpp::export(rng = false)]]
Eigen::Matrix<double, -1, -1  > elimination_matrix(const int &n) {
  
  Eigen::Matrix<double, -1, -1> out   =  Eigen::Matrix<double, -1, -1>::Zero((n*(n+1))/2,  n*n); 
  
  for (int j = 0; j < n; ++j) {
    Eigen::Matrix<double, 1, -1> e_j   =  Eigen::Matrix<double, 1, -1>::Zero(n); 
    
    e_j(j) = 1.0;
    
    for (int i = j; i < n; ++i) {
      Eigen::Matrix<double, -1, 1> u   =  Eigen::Matrix<double, -1, 1>::Zero((n*(n+1))/2); 
      u(j*n+i-((j+1)*j)/2) = 1.0;
      Eigen::Matrix<double, 1, -1> e_i   =  Eigen::Matrix<double, 1, -1>::Zero(n); 
      e_i(i) = 1.0;
      
      out += Eigen::kroneckerProduct(u, Eigen::kroneckerProduct(e_j, e_i)); 
    }
  }
  
  return out;
}




// [[Rcpp::export(rng = false)]]
Eigen::Matrix<double, -1, -1  > duplication_matrix(const int &n) {
  
  //arma::mat out((n*(n+1))/2, n*n, arma::fill::zeros);
  Eigen::Matrix<double, -1, -1> out   =  Eigen::Matrix<double, -1, -1>::Zero((n*(n+1))/2,  n*n); 
  
  for (int j = 0; j < n; ++j) {
    for (int i = j; i < n; ++i) {
      // arma::vec u((n*(n+1))/2, arma::fill::zeros);
      Eigen::Matrix<double, -1, 1> u   =  Eigen::Matrix<double, -1, 1>::Zero((n*(n+1))/2);
      u(j*n+i-((j+1)*j)/2) = 1.0;
      
      //       arma::mat T(n,n, arma::fill::zeros);
      Eigen::Matrix<double, -1, -1> T   =  Eigen::Matrix<double, -1, -1>::Zero(n, n);
      T(i,j) = 1.0;
      T(j,i) = 1.0;
      
      Eigen::Map<Eigen::Matrix<double, -1, 1> > T_vec(T.data(), n*n);
      
      out += u * T_vec.transpose();
    }
  }
  
  return out.transpose(); 
  
}




 
 
 // [[Rcpp::export(rng = false)]]
 double notExp2_double( double x) { 
   
   double d = 25 ;
   double b = 1/d ; 

   return( stan::math::exp( d * stan::math::sin(x*b)  ) ) ; 
   
   
 }


// [[Rcpp::export(rng = false)]]
Eigen::Matrix<double, -1, 1 > notExp2_vec(  Eigen::Matrix<double, -1, 1 >  x) { 
  
  double d = 25 ;
  double b = 1/d ; 
  x.array() = stan::math::exp( d * stan::math::sin( (x.array() * b).matrix() ).array()  ) ;  
  
  
  return( x.matrix() ); 
  
}


 
 
 // [[Rcpp::export(rng = false)]]
double  notExp2_deriv_double(  double  x) { 
   
   double d = 25 ;
  double b = 1/d ; 
   x  = ( stan::math::exp( d * stan::math::sin( (x  * b)  ) )   * stan::math::cos(b * x  )   )  ;  
   
   
   return(  x  ); 
   
 }




// [[Rcpp::export(rng = false)]]
Eigen::Matrix<double, -1, 1 > notExp2_deriv_vec(  Eigen::Matrix<double, -1, 1 >  x) { 
  
  double d = 25 ;
  double b = 1/d ; 
  x.array() = ( stan::math::exp( d * stan::math::sin( (x.array() * b).matrix() ) ).array()  * stan::math::cos(b * x.array() ).array()  ).array() ;  
  
  
  return( x.matrix() ); 
  
}






 
 stan::math::var notExp2_var( stan::math::var x) { 
  
  double d = 25 ;
   double b = 1/d ; 
  
  return( stan::math::exp( d * stan::math::sin(x*b)  ) ) ; 
  
  
}


 
Eigen::Matrix<stan::math::var, -1, 1 > notExp2_vec_var(  Eigen::Matrix<stan::math::var, -1, 1 >  x) { 
  
  double d = 25 ;
  double b = 1/d ; 
  x.array() = stan::math::exp( d * stan::math::sin( (x.array() * b).matrix() ).array()  ) ;  
  
  
  return( x.matrix() ); 
  
}



 
Eigen::Matrix<stan::math::var, -1, 1 > notExp2_deriv_vec_var(  Eigen::Matrix<stan::math::var, -1, 1 >  x) { 
  
  double d = 25 ;
  double b = 1/d ; 
  x.array() = ( stan::math::exp( d * stan::math::sin( (x.array() * b).matrix() ) ).array()  * stan::math::cos(b * x.array() ).array()  ).array() ;  
  
  
  return( x.matrix() ); 
  
}












 
// [[Rcpp::export(rng = false)]]
double notLog2_double( double x) { 
  
  double d = 25;
  double b = 1/d ; 
  x = stan::math::log(x)/d;
  x = std::min(1.0, x);
  x = std::min(-1.0, x);
    
  return(stan::math::asin(x)/b); 
  
}


// [[Rcpp::export(rng = false)]]
Eigen::Matrix<double, -1, 1 > notLog2_vec(  Eigen::Matrix<double, -1, 1 >  x) { 
  
  double d = 25;
  double b = 1/d ; 
  x.array() = stan::math::log(x).array() / d;
  
  for (int i = 0; i < x.rows(); ++i) {
    x(i) = std::min(1.0, x(i));
    x(i) = std::min(-1.0, x(i));
  }
  
  return( (x.array().asin()/b).matrix() ); 
  
}


 
 
 
 
 
 
 
 
 
 
 
 
 
 Eigen::Matrix<stan::math::var, -1, 1 >                        lb_ub_lp (stan::math::var  y,
                                                                         stan::math::var lb,
                                                                         stan::math::var ub) {
   
   stan::math::var target = 0 ;
   
   // stan::math::var val   = (lb  + (ub  - lb) * stan::math::inv_logit(y)) ;
   stan::math::var val   =  lb +  (ub - lb) *  0.5 * (1 +  stan::math::tanh(y));
   
   // target += stan::math::log(ub - lb) + stan::math::log_inv_logit(y) + stan::math::log1m_inv_logit(y);
   target +=  stan::math::log(ub - lb) - log(2)  + stan::math::log1m(stan::math::square(stan::math::tanh(y)));
   
   Eigen::Matrix<stan::math::var, -1, 1 > out_mat  = Eigen::Matrix<stan::math::var, -1, 1 >::Zero(2);
   out_mat(0) = target;
   out_mat(1) = val;
   
   return(out_mat) ;
   
 }
 
 
 
 
 
 
 Eigen::Matrix<stan::math::var, -1, 1 >   lb_ub_lp_vec_y (Eigen::Matrix<stan::math::var, -1, 1 > y,
                                                          Eigen::Matrix<stan::math::var, -1, 1 > lb,
                                                          Eigen::Matrix<stan::math::var, -1, 1 > ub) {
   
   stan::math::var target = 0 ;
   
   
   //   stan::math::var val   =  lb +  (ub - lb) *  0.5 * (1 +  stan::math::tanh(y));
   Eigen::Matrix<stan::math::var, -1, 1 >  vec =   (lb.array() +  (ub.array()  - lb.array() ) *  0.5 * (1 +  stan::math::tanh(y).array() )).matrix();
   
   //  target += (stan::math::log( (ub.array() - lb.array()).matrix()).array() + stan::math::log_inv_logit(y).array() + stan::math::log1m_inv_logit(y).array()).matrix().sum() ;
   target +=  (stan::math::log((ub.array() - lb.array()).matrix()).array() - log(2)  +  stan::math::log1m(stan::math::square(stan::math::tanh(y))).array()).matrix().sum();
   
   Eigen::Matrix<stan::math::var, -1, 1 > out_mat  = Eigen::Matrix<stan::math::var, -1, 1 >::Zero(vec.rows() + 1);
   out_mat(0) = target;
   out_mat.segment(1, vec.rows()) = vec;
   
   return(out_mat);
   
 }
 
 
 //  
 
 
 
 
 
 
 
 
 
 
 
 
 // 
 Eigen::Matrix<stan::math::var, -1, -1 >    Spinkney_cholesky_corr_transform_opt( int n,
                                                                                  Eigen::Matrix<stan::math::var, -1, -1 >  lb,
                                                                                  Eigen::Matrix<stan::math::var, -1, -1 >  ub,
                                                                                  Eigen::Matrix<stan::math::var, -1, -1 >  Omega_theta_unconstrained_array,
                                                                                  Eigen::Matrix<int, -1, -1 >  known_values_indicator,
                                                                                  Eigen::Matrix<double, -1, -1 >  known_values) {


   stan::math::var target = 0 ;


   Eigen::Matrix<stan::math::var, -1, -1 > L = Eigen::Matrix<stan::math::var, -1, -1 >::Zero(n, n);
   Eigen::Matrix<stan::math::var, -1, 1 > first_col = Omega_theta_unconstrained_array.col(0).segment(1, n - 1);

   Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_vec_y_outs = lb_ub_lp_vec_y(first_col, lb.col(0), ub.col(0)) ;  // logit bounds
   target += lb_ub_lp_vec_y_outs.eval()(0);

   Eigen::Matrix<stan::math::var, -1, 1 >  z = lb_ub_lp_vec_y_outs.segment(1, n - 1);
   L.col(0).segment(1, n - 1) = z;

   for (int i = 2; i < n + 1; ++i) {
     if (known_values_indicator(i-1, 0) == 1) {
       L(i-1, 0) = stan::math::to_var(known_values(i-1, 0));
       Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_vec_y_out = lb_ub_lp(first_col(i-2), lb(i-1, 0), ub(i-1, 0)) ;  // logit bounds
       target += - lb_ub_lp_vec_y_out.eval()(0); // undo jac adjustment
     }
   }
   L(1, 1) = stan::math::sqrt(1 - stan::math::square(L(1, 0))) ;

   for (int i = 3; i < n + 1; ++i) {

     Eigen::Matrix<stan::math::var, 1, -1 >  row_vec_rep = stan::math::rep_row_vector(stan::math::sqrt(1 - L(i - 1, 0)* L(i - 1, 0)), i - 1) ;
     L.row(i - 1).segment(1, i - 1) = row_vec_rep;

     for (int j = 2; j < i; ++j) {

       stan::math::var   l_ij_old = L(i-1, j-1);
       stan::math::var   l_ij_old_x_l_jj = l_ij_old * L(j-1, j-1); // new
       stan::math::var b1 = stan::math::dot_product(L.row(j - 1).segment(0, j - 1), L.row(i - 1).segment(0, j - 1)) ;
       // stan::math::var b2 = L(j - 1, j - 1) * L(i - 1, j - 1) ; // old

       // stan::math::var  low = std::min(   std::max( b1 - b2, lb(i-1, j-1) / stan::math::abs(L(i-1, j-1)) ), b1 + b2 ); // old
       // stan::math::var   up = std::max(   std::min( b1 + b2, ub(i-1, j-1) / stan::math::abs(L(i-1, j-1)) ), b1 - b2 ); // old

       stan::math::var  low =   std::max( -l_ij_old_x_l_jj, (lb(i-1, j-1) - b1)    );   // new
       stan::math::var   up =   std::min( +l_ij_old_x_l_jj, (ub(i-1, j-1) - b1)    ); // new

       if (known_values_indicator(i-1, j-1) == 1) {
         // L(i-1, j-1) *= ( stan::math::to_var(known_values(i-1, j-1))  - b1) / b2; // old
         L(i-1, j-1)  = stan::math::to_var(known_values(i-1, j-1)) / L(j-1, j-1);  // new
       } else {
         Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_outs = lb_ub_lp(Omega_theta_unconstrained_array(i-1, j-1), low,  up) ;
         target += lb_ub_lp_outs.eval()(0); // old

         stan::math::var x = lb_ub_lp_outs.eval()(1);    // logit bounds
         target +=  - stan::math::log(L(j-1, j-1)) ;  //  Jacobian for transformation  z -> L_Omega

         //   L(i-1, j-1) *= (x - b1) / b2; // old
         L(i-1, j-1)  = x / L(j-1, j-1); //  low + (up - low) * x; // new
       }

       //    target += - stan::math::log(L(j-1, j-1)); // old

       stan::math::var   l_ij_new = L(i-1, j-1);
       L.row(i - 1).segment(j, i - j).array() *= stan::math::sqrt(  1 -  ( (l_ij_new / l_ij_old) * (l_ij_new / l_ij_old)  )  );

     }

   }
   L(0, 0) = 1;

   //////////// output
   Eigen::Matrix<stan::math::var, -1, -1 > out_mat = Eigen::Matrix<stan::math::var, -1, -1 >::Zero(1 + n , n);

   out_mat(0, 0) = target;
   out_mat.block(1, 0, n, n) = L;

   return(out_mat);

 }
 // 
 // 
 
 
 
 
 
 
 
 
 

 
 Eigen::Matrix<stan::math::var, -1, -1 >    Spinkney_LDL_bounds_opt( int K,
                                                                     Eigen::Matrix<stan::math::var, -1, -1 >  lb,
                                                                     Eigen::Matrix<stan::math::var, -1, -1 >  ub,
                                                                     Eigen::Matrix<stan::math::var, -1, -1 >  Omega_theta_unconstrained_array,
                                                                     Eigen::Matrix<int, -1, -1 >  known_values_indicator,
                                                                     Eigen::Matrix<double, -1, -1 >  known_values) {
   
   
   stan::math::var target = 0 ;
   
   Eigen::Matrix<stan::math::var, -1, 1 > first_col = Omega_theta_unconstrained_array.col(0).segment(1, K - 1);
   Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_vec_y_outs = lb_ub_lp_vec_y(first_col, lb.col(0), ub.col(0)) ;  // logit bounds
   target += lb_ub_lp_vec_y_outs.eval()(0);
   Eigen::Matrix<stan::math::var, -1, 1 >  z = lb_ub_lp_vec_y_outs.segment(1, K - 1);
   
   Eigen::Matrix<stan::math::var, -1, -1 > L = Eigen::Matrix<stan::math::var, -1, -1 >::Zero(K, K);
   
   for (int i = 0; i < K; ++i) {
     L(i, i) = 1;
   }
   
   Eigen::Matrix<stan::math::var, -1, 1 >  D = Eigen::Matrix<stan::math::var, -1, 1 >::Zero(K);
   
   D(0) = 1;
   L.col(0).segment(1, K - 1) = z;
   D(1) = 1 -  stan::math::square(L(1, 0)) ;
   
   for (int i = 2; i < K + 1; ++i) {
     if (known_values_indicator(i-1, 0) == 1) {
       L(i-1, 0) = stan::math::to_var(known_values(i-1, 0));
       Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_vec_y_out = lb_ub_lp(first_col(i-2), lb(i-1, 0), ub(i-1, 0)) ;  // logit bounds
       target += - lb_ub_lp_vec_y_out.eval()(0); // undo jac adjustment
     }
   }
   
   for (int i = 3; i < K + 1; ++i) {
     
     D(i-1) = 1 - stan::math::square(L(i-1, 0)) ;
     Eigen::Matrix<stan::math::var, 1, -1 >  row_vec_rep = stan::math::rep_row_vector(1 - stan::math::square(L(i-1, 0)), i - 2) ;
     L.row(i - 1).segment(1, i - 2) = row_vec_rep;
     stan::math::var   l_ij_old = L(i-1, 1);
     
     for (int j = 2; j < i; ++j) {
       
       stan::math::var b1 = stan::math::dot_product(L.row(j - 1).head(j - 1), (D.head(j - 1).transpose().array() *  L.row(i - 1).head(j - 1).array() ).matrix()  ) ;
       
       Eigen::Matrix<stan::math::var, -1, 1 > low_vec_to_max(2);
       Eigen::Matrix<stan::math::var, -1, 1 > up_vec_to_min(2);
       low_vec_to_max(0) = - stan::math::sqrt(l_ij_old) * D(j-1) ;
       low_vec_to_max(1) =   (lb(i-1, j-1) - b1) ;
       up_vec_to_min(0) =    stan::math::sqrt(l_ij_old) * D(j-1) ;
       up_vec_to_min(1) =    (ub(i-1, j-1) - b1)  ;
       
       stan::math::var  low =    stan::math::max( low_vec_to_max   );   // new
       stan::math::var  up  =    stan::math::min( up_vec_to_min    );   // new
       
       if (known_values_indicator(i-1, j-1) == 1) {
         L(i-1, j-1) =  stan::math::to_var(known_values(i-1, j-1)) /  D(j-1)  ; // new
       } else {
         Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_outs = lb_ub_lp(Omega_theta_unconstrained_array(i-1, j-1), low,  up) ;
         target += lb_ub_lp_outs.eval()(0);
         stan::math::var x = lb_ub_lp_outs.eval()(1);    // logit bounds
         L(i-1, j-1)  = x / D(j-1) ;
         target += -0.5 * stan::math::log(D(j-1)) ;
         // target += -  stan::math::log(D(j-1)) ;
       }
       
       l_ij_old *= 1 - (D(j-1) *  stan::math::square(L(i-1, j-1) )) / l_ij_old;
     }
     
     D(i-1) = l_ij_old;
   }
   //L(0, 0) = 1;
   
   //////////// output
   Eigen::Matrix<stan::math::var, -1, -1 > out_mat = Eigen::Matrix<stan::math::var, -1, -1 >::Zero(1 + K , K);
   
   out_mat(0, 0) = target;
   // out_mat.block(1, 0, n, n) = L;
   out_mat.block(1, 0, K, K) = stan::math::diag_post_multiply(L, stan::math::sqrt(stan::math::abs(D)));
   
   return(out_mat);
   
 }
 
 
 
 
 
 
 
 Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor >    Spinkney_LDL_bounds_opt_RM( int K,
                                                                     Eigen::Matrix<stan::math::var, -1, -1 >  lb,
                                                                     Eigen::Matrix<stan::math::var, -1, -1 >  ub,
                                                                     Eigen::Matrix<stan::math::var, -1, -1 >  Omega_theta_unconstrained_array,
                                                                     Eigen::Matrix<int, -1, -1 >  known_values_indicator,
                                                                     Eigen::Matrix<double, -1, -1 >  known_values) {


   stan::math::var target = 0.0;

   Eigen::Matrix<stan::math::var, -1, 1 > first_col = Omega_theta_unconstrained_array.col(0).segment(1, K - 1);
   Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_vec_y_outs = lb_ub_lp_vec_y(first_col, lb.col(0), ub.col(0)) ;  // logit bounds
   target += lb_ub_lp_vec_y_outs.eval()(0);
   Eigen::Matrix<stan::math::var, -1, 1 >  z = lb_ub_lp_vec_y_outs.segment(1, K - 1);

   Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor  > L = Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor  >::Zero(K, K);

   for (int i = 0; i < K; ++i) {
     L(i, i) = 1.0;
   }

   Eigen::Matrix<stan::math::var, -1, 1 >  D = Eigen::Matrix<stan::math::var, -1, 1 >::Zero(K);

   D(0) = 1.0;
   L.col(0).segment(1, K - 1) = z;
   D(1) = 1.0 -  stan::math::square(L(1, 0)) ;

   for (int i = 2; i < K + 1; ++i) {
     if (known_values_indicator(i-1, 0) == 1) {
       L(i-1, 0) = stan::math::to_var(known_values(i-1, 0));
       Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_vec_y_out = lb_ub_lp(first_col(i-2), lb(i-1, 0), ub(i-1, 0)) ;  // logit bounds
       target += - lb_ub_lp_vec_y_out.eval()(0); // undo jac adjustment
     }
   }

   for (int i = 3; i < K + 1; ++i) {

     D(i-1) = 1 - stan::math::square(L(i-1, 0)) ;
     Eigen::Matrix<stan::math::var, 1, -1 >  row_vec_rep = stan::math::rep_row_vector(1 - stan::math::square(L(i-1, 0)), i - 2) ;
     L.row(i - 1).segment(1, i - 2) = row_vec_rep;
     stan::math::var   l_ij_old = L(i-1, 1);

     for (int j = 2; j < i; ++j) {

       stan::math::var b1 = stan::math::dot_product(L.row(j - 1).head(j - 1), (D.head(j - 1).transpose().array() *  L.row(i - 1).head(j - 1).array() ).matrix()  ) ;

       Eigen::Matrix<stan::math::var, -1, 1 > low_vec_to_max(2);
       Eigen::Matrix<stan::math::var, -1, 1 > up_vec_to_min(2);
       low_vec_to_max(0) = - stan::math::sqrt(l_ij_old) * D(j-1) ;
       low_vec_to_max(1) =   (lb(i-1, j-1) - b1) ;
       up_vec_to_min(0) =    stan::math::sqrt(l_ij_old) * D(j-1) ;
       up_vec_to_min(1) =    (ub(i-1, j-1) - b1)  ;

       stan::math::var  low =    stan::math::max( low_vec_to_max   );   // new
       stan::math::var  up  =    stan::math::min( up_vec_to_min    );   // new

       if (known_values_indicator(i-1, j-1) == 1) {
         L(i-1, j-1) =  stan::math::to_var(known_values(i-1, j-1)) /  D(j-1)  ; // new
       } else {
         Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_outs = lb_ub_lp(Omega_theta_unconstrained_array(i-1, j-1), low,  up) ;
         target += lb_ub_lp_outs.eval()(0);
         stan::math::var x = lb_ub_lp_outs.eval()(1);    // logit bounds
         L(i-1, j-1)  = x / D(j-1) ;
         target += -0.5 * stan::math::log(D(j-1)) ;
         // target += -  stan::math::log(D(j-1)) ;
       }

       l_ij_old *= 1 - (D(j-1) *  stan::math::square(L(i-1, j-1) )) / l_ij_old;
     }
     D(i-1) = l_ij_old;
   }
   //L(0, 0) = 1;

   //////////// output
   Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor  > out_mat = Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor  >::Zero(1 + K , K);

   out_mat(0, 0) = target;
   // out_mat.block(1, 0, n, n) = L;
   out_mat.block(1, 0, K, K) = stan::math::diag_post_multiply(L, stan::math::sqrt(stan::math::abs(D)));

   return(out_mat);

 }



 // 
 // 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 // 
 // 
 // 
 // 
 // 
 // 
 // //  Rcpp::List
 // //   Eigen::Matrix<double, -1, 1 > 
 // 
 // 
 // // [[Rcpp::export]]
 // Eigen::Matrix<double, -1, 1 >        fn_log_posterior_and_gradient_latent_trait_MD_and_AD(  Eigen::Matrix<double, -1, 1  > theta,
 //                                                                                           Eigen::Matrix<int, -1, -1>	 y,
 //                                                                                           Rcpp::List other_args
 //                                                                                             
 //                                                                                             
 // ) {
 //   
 //   
 //   
 //   
 //   bool exclude_priors = other_args(0);
 //   int lkj_prior_method = other_args(1);
 //   bool grad_main = other_args(2);
 //   bool grad_nuisance = other_args(3);
 //   bool CI = other_args(4);
 //   bool rough_approx = other_args(5);
 //   bool homog_corr = other_args(6);
 //   bool lkj_cholesky= other_args(7);
 //   Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta = other_args(8);
 //   Eigen::Matrix<double, -1, -1> prior_coeffs_mean = other_args(9);
 //   Eigen::Matrix<double, -1, -1> prior_coeffs_sd = other_args(10);
 //   int n_class = other_args(11);
 //   int n_tests = other_args(12);
 //   
 //   
 //   bool Phi_exact_indicator_if_not_using_rough_approx = other_args(16);
 //   int lb_threshold_phi_approx = other_args(17);
 //   int ub_threshold_phi_approx = other_args(18);
 //   
 //   int n_chunks = other_args(26);
 //   
 //   int N = y.rows();
 //   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
 //   int n_bs_LT = n_class * n_tests;
 //   int n_coeffs = n_class * n_tests * 1;
 //   int n_us =  1 *  N * n_tests;
 //   
 //   int n_params = theta.rows() ; // n_corrs + n_coeffs + n_us + n_class;
 //   int n_params_main = n_params - n_us;
 //   
 //   bool corr_force_positive = other_args(29);
 //   
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a =  other_args(49);
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b =  other_args(50);
 //   
 //   bool corr_priors_LKJ_only = other_args(51);
 //   bool corr_param_Archakov = other_args(52);
 //   bool use_AD_for_chol_derivs = other_args(53);
 //   double constant_1 = other_args(54);
 //   double tol  = other_args(55);
 //   
 //   bool Archakov_corr_prior_beta =  other_args(56);
 //   bool Archakov_corr_prior_norm =  other_args(57);
 //   
 //   double corr_pos_offset =  other_args(63); 
 //   
 //   Eigen::Matrix<double, -1, -1> LT_b_priors_shape  =  other_args(90);  
 //   Eigen::Matrix<double, -1, -1> LT_b_priors_scale  =  other_args(91); 
 //   
 //   Eigen::Matrix<double, -1, -1> LT_known_bs_indicator  =  other_args(92); 
 //   Eigen::Matrix<double, -1, -1> LT_known_bs_values =  other_args(93);
 //   
 //   
 //   // corrs / b's
 //   Eigen::Matrix<double, -1, 1  >  bs_raw_vec_double = theta.segment(n_us, n_bs_LT) ;  
 //   Eigen::Matrix<stan::math::var, -1, 1  >  bs_raw_vec_var =  stan::math::to_var(bs_raw_vec_double) ; 
 //   Eigen::Matrix<stan::math::var, -1, -1 > bs_mat =    Eigen::Matrix<stan::math::var, -1, -1 >::Zero(n_class, n_tests);
 //   Eigen::Matrix<stan::math::var, -1, -1 > bs_raw_mat =  Eigen::Matrix<stan::math::var, -1, -1 >::Zero(n_class, n_tests);
 // 
 // 
 //   
 //   bs_raw_mat.row(0) =  bs_raw_vec_var.segment(0, n_tests).transpose();
 //   bs_raw_mat.row(1) =  bs_raw_vec_var.segment(n_tests, n_tests).transpose();
 //   
 //   bs_mat.row(0) = stan::math::exp( bs_raw_mat.row(0)) ; 
 //   bs_mat.row(1) = stan::math::exp( bs_raw_mat.row(1)) ; 
 // 
 //   stan::math::var known_bs_raw_sum = 0.0;
 // 
 //     
 //   Eigen::Matrix<stan::math::var, -1, 1 > bs_nd  =   bs_mat.row(0).transpose() ; //  bs_constrained_raw_vec_var.head(n_tests);
 //   Eigen::Matrix<stan::math::var, -1, 1 > bs_d   =   bs_mat.row(1).transpose() ; //  bs_constrained_raw_vec_var.segment(n_tests, n_tests);
 //   
 //   // coeffs
 //   Eigen::Matrix<stan::math::var, -1, -1  > LT_theta(n_class, n_tests);
 //   Eigen::Matrix<stan::math::var, -1, -1  > LT_a(n_class, n_tests);
 //   
 //   Eigen::Matrix<double, -1, 1  > coeffs_vec_double(n_coeffs);
 //   Eigen::Matrix<stan::math::var, -1, 1  > coeffs_vec_var(n_coeffs);
 //   
 //   coeffs_vec_double = theta.segment(n_us + n_corrs, n_coeffs); 
 //   coeffs_vec_var = stan::math::to_var(coeffs_vec_double); 
 //   
 //   {
 //     int i = 0 ; // n_us + n_corrs;
 //     for (int c = 0; c < n_class; ++c) {
 //       for (int t = 0; t < n_tests; ++t) {
 //         LT_a(c, t) = coeffs_vec_var(i);
 //         i = i + 1;
 //       }
 //     }
 //   }
 //   
 //   //// LT_theta as TRANSFORMED parameter (need Jacobian adj. if wish to put prior on theta!!!)
 //   for (int t = 0; t < n_tests; ++t) {
 //     LT_theta(1, t)   =    LT_a(1, t) /  stan::math::sqrt(1 + ( bs_d(t) * bs_d(t)));
 //     LT_theta(0, t)   =    LT_a(0, t) /  stan::math::sqrt(1 + ( bs_nd(t) * bs_nd(t)));
 //   }
 // 
 //   
 //   // prev
 //   double u_prev_diseased = theta(n_params - 1);
 //   
 //   
 //   ////////////////// u (double / manual diff)
 //   Eigen::Matrix<double, -1, 1 >   tanh_uu(n_us); ///////////////////////
 //   tanh_uu.array() =     ( stan::math::exp(theta.head(n_us)).array()    -   stan::math::exp( - theta.head(n_us) ).array()  )    /   
 //     ( stan::math::exp(theta.head(n_us)).array()    +   stan::math::exp( - theta.head(n_us) ).array()  )  ;
 //   double log_jac_u  =   +   (  0.5 *   (1 -  ( tanh_uu.array()  *  tanh_uu.array()  ) )   ).array().log().matrix().sum();
 //   
 //   //////////////// output vec
 //   Eigen::Matrix<double, -1, 1> out_mat    =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N);  ///////////////
 //   
 //   
 //   ////////////////////////////////////// AD part  -   for non-LKJ corr priors
 //   int n_choose_2 = n_tests * (n_tests - 1) * 0.5 ; 
 //   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  L_Omega_var_copy = vec_of_mats_test_var(n_tests, n_tests, n_class);
 //   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  Omega_var_copy  = vec_of_mats_test_var(n_tests, n_tests, n_class);
 // 
 // 
 //   Eigen::Matrix<stan::math::var, -1, -1 > identity_dim_T =     Eigen::Matrix<stan::math::var, -1, -1 > ::Zero(n_tests, n_tests) ; //  stan::math::diag_matrix(  stan::math::rep_vector(1, n_tests)  ) ; 
 //   
 //   
 //   Eigen::Matrix<double, -1, 1 >   bs_d_double(n_tests); 
 //   Eigen::Matrix<double, -1, 1 >   bs_nd_double(n_tests); 
 //   
 //   for (int i = 0; i < n_tests; ++i) {
 //     identity_dim_T(i, i) = 1;
 //     bs_d_double(i) = bs_d(i).val() ; 
 //     bs_nd_double(i) = bs_nd(i).val() ; 
 //   }
 //   
 // 
 //   Omega_var_copy[0] = identity_dim_T +  bs_nd * bs_nd.transpose();
 //   Omega_var_copy[1] = identity_dim_T +  bs_d * bs_d.transpose();
 //   
 //   stan::math::var target_AD = 0;
 // 
 //   
 //   for (int c = 0; c < n_class; ++c) {
 //     L_Omega_var_copy[c]   = stan::math::cholesky_decompose( Omega_var_copy[c]) ; 
 //   }
 //   
 //   
 //   //////////////// Jacobian L_Sigma -> b's
 //   
 //   std::vector< std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > > Jacobian_d_L_Sigma_wrt_b_3d_arrays_var = vec_of_vec_of_mats_test_var(n_tests, n_tests, n_tests, n_class);
 //   std::vector< std::vector<Eigen::Matrix<double, -1, -1 > > > Jacobian_d_L_Sigma_wrt_b_3d_arrays_double = vec_of_vec_of_mats_test(n_tests, n_tests, n_tests, n_class);
 //   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > Jacobian_d_L_Sigma_wrt_b_matrix_var = vec_of_mats_test_var(n_choose_2 + n_tests, n_tests, n_class);
 //   std::vector<Eigen::Matrix<double, -1, -1 > > Jacobian_d_L_Sigma_wrt_b_matrix = vec_of_mats_test(n_choose_2 + n_tests, n_tests, n_class);
 // 
 //   for (int c = 0; c < n_class; ++c) {
 // 
 //       //  # -----------  wrt last b first
 //         int t = n_tests;
 //         stan::math::var sum_sq_1 = 0.0;
 //         for (int j = 1; j < t; ++j) {
 //           Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](t-1, j-1) = ( L_Omega_var_copy[c](n_tests-1, j-1) / bs_mat(c, n_tests-1) ) ;//* bs_nd(n_tests-1) ;
 //           sum_sq_1 +=   bs_mat(c, j-1) * bs_mat(c, j-1) ;
 //         }
 //         stan::math::var big_denom_p1 =  1 + sum_sq_1;
 //         Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](t-1, n_tests-1) =   (1 / L_Omega_var_copy[c](n_tests-1, n_tests-1) ) * ( bs_mat(c, n_tests-1) / big_denom_p1 ) ;//* bs_nd(n_tests-1) ;
 // 
 //        //  # -----------  wrt 2nd-to-last b
 //        t = n_tests - 1;
 //        sum_sq_1 = 0;
 //        stan::math::var  sum_sq_2 = 0.0;
 //        for (int j = 1; j < t + 1; ++j) {
 //          Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](t-1, j-1) = ( L_Omega_var_copy[c](t-1, j-1) / bs_mat(c, t-1) );// * bs_nd(t-1) ;
 //          sum_sq_1 +=   bs_mat(c, j-1) * bs_mat(c, j-1) ;
 //          if (j < (t))   sum_sq_2 +=  bs_mat(c, j-1) * bs_mat(c, j-1) ;
 //        }
 //        big_denom_p1 =  1 + sum_sq_1;
 //        stan::math::var big_denom_p2 =  1 + sum_sq_2;
 //        stan::math::var  big_denom_part =  big_denom_p1 * big_denom_p2;
 //        Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](t-1, t-1) =   (1 / L_Omega_var_copy[c](t-1, t-1)) * ( bs_mat(c, t-1) / big_denom_p2 );// * bs_nd(t-1) ;
 // 
 //        for (int j = t+1; j < n_tests + 1; ++j) {
 //          Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](j-1, t-1) =   ( 1/L_Omega_var_copy[c](j-1, t-1) ) * (bs_mat(c, j-1) *  bs_mat(c, j-1)  ) * (   bs_mat(c, t-1)  / big_denom_part) * (1 - ( bs_mat(c, t-1) * bs_mat(c, t-1)  / big_denom_p1 ) );// * bs_nd(t-1)   ;
 //        }
 // 
 //        Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](t, t)   =  - ( 1/L_Omega_var_copy[c](t, t) ) * (bs_mat(c, t) * bs_mat(c, t)) * ( bs_mat(c, t-1)  / (big_denom_p1*big_denom_p1));//*  bs_nd(t-1) ;
 // 
 //        // # -----------  wrt rest of b's
 //          for (int t = 1; t < (n_tests - 2) + 1; ++t) {
 // 
 //            sum_sq_1  = 0;
 //            sum_sq_2  = 0;
 // 
 //          for (int j = 1; j < t + 1; ++j) {
 //            if (j < (t)) Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](t-1, j-1) = ( L_Omega_var_copy[c](t-1, j-1) /  bs_mat(c, t-1) ) ;//* ;// bs_nd(t-1) ;
 //            sum_sq_1 +=   bs_mat(c, j-1) *   bs_mat(c, j-1) ;
 //            if (j < (t))   sum_sq_2 +=    bs_mat(c, j-1) *   bs_mat(c, j-1) ;
 //          }
 //            big_denom_p1 = 1 + sum_sq_1;
 //            big_denom_p2 = 1 + sum_sq_2;
 //            big_denom_part =  big_denom_p1 * big_denom_p2;
 // 
 //          Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](t-1, t-1) =   (1 / L_Omega_var_copy[c](t-1, t-1) ) * (  bs_mat(c, t-1) / big_denom_p2 ) ;//*  bs_nd(t-1) ;
 // 
 //          for (int j = t + 1; j < n_tests + 1; ++j) {
 //            Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](j-1, t-1)  =   (1/L_Omega_var_copy[c](j-1, t-1)) * (  bs_mat(c, j-1) *   bs_mat(c, j-1) ) * (   bs_mat(c, t-1) / big_denom_part) * (1 - ( ( bs_mat(c, t-1) *  bs_mat(c, t-1) ) / big_denom_p1 ) ) ;//*  bs_nd(t-1) ;
 //          }
 // 
 //          for (int j = t + 1; j < n_tests ; ++j) {
 //            Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](j-1, j-1) =  - (1/L_Omega_var_copy[c](j-1, j-1)) * (  bs_mat(c, j-1) *   bs_mat(c, j-1) ) * ( bs_mat(c, t-1) / (big_denom_p1*big_denom_p1)) ;//*  bs_nd(t-1) ;
 //            big_denom_p1 = big_denom_p1 +   bs_mat(c, j-1) *   bs_mat(c, j-1) ;
 //            big_denom_p2 = big_denom_p2 + bs_mat(c, j-2) * bs_mat(c, j-2) ;
 //            big_denom_part =  big_denom_p1 * big_denom_p2 ;
 //            if (t < n_tests - 1) {
 //                for (int k = j + 1; k < n_tests + 1; ++k) {
 //                  Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](k-1, j-1) =   (-1 / L_Omega_var_copy[c](k-1, j-1)) * (  bs_mat(c, k-1) *   bs_mat(c, k-1) ) * (  bs_mat(c, j-1) *   bs_mat(c, j-1) ) * (  bs_mat(c, t-1) / big_denom_part ) * ( ( 1 / big_denom_p2 )  +  ( 1 / big_denom_p1 ) ) ;//*  bs_nd(t-1) ;
 //              }
 //            }
 //          }
 // 
 //          Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](n_tests-1, n_tests-1) =  - (1/L_Omega_var_copy[c](n_tests-1, n_tests-1)) * (bs_mat(c, n_tests-1) * bs_mat(c, n_tests-1)) * ( bs_mat(c, t-1) / (big_denom_p1*big_denom_p1)) ;//*  bs_nd(t-1) ;
 // 
 //        }
 // 
 // 
 // 
 //   }
 //   
 //   
 // 
 //   
 // 
 //   //  // ///////////////////// priors for corr
 //   for (int t = 0; t < n_tests; ++t) {
 //     target_AD += stan::math::weibull_lpdf(  bs_nd(t) ,   LT_b_priors_shape(0, t), LT_b_priors_scale(0, t)  );
 //     target_AD += stan::math::weibull_lpdf(  bs_d(t)  ,   LT_b_priors_shape(1, t), LT_b_priors_scale(1, t)  );
 //   }
 //   
 //   target_AD +=  (bs_raw_mat).sum()  - known_bs_raw_sum ; // Jacobian b -> raw_b
 //   
 // 
 //   
 //   /// priors and Jacobians for coeffs
 //   for (int c = 0; c < n_class; ++c) {
 //     for (int t = 0; t < n_tests; ++t) {
 //       target_AD += stan::math::normal_lpdf(LT_theta(c, t), prior_coeffs_mean(t, c), prior_coeffs_sd(t, c));
 //       target_AD +=  - 0.5 * stan::math::log(1 + stan::math::square(stan::math::abs(bs_mat(c, t) ))); // Jacobian for LT_theta -> LT_a
 //     }
 //   }
 // 
 //   //  /////////////////////// 
 //   stan::math::set_zero_all_adjoints();
 //   target_AD.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
 //   out_mat.segment(1 + n_us, n_bs_LT) = bs_raw_vec_var.adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
 //   stan::math::set_zero_all_adjoints();
 //   //////////////////////////////////////////////////////////// end of AD part
 //   
 // 
 // 
 // 
 //   //  /////////////////////// 
 //   stan::math::set_zero_all_adjoints();
 //   target_AD.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
 //   out_mat.segment(1 + n_us + n_corrs, n_coeffs)  = coeffs_vec_var.adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
 //   stan::math::set_zero_all_adjoints();
 //   //////////////////////////////////////////////////////////// end of AD part
 //     
 // 
 // 
 //   
 //   ///////////////// get cholesky factor's (lower-triangular) of corr matrices
 //   // convert to 3d var array
 //   std::vector<Eigen::Matrix<double, -1, -1 > > L_Omega_var = vec_of_mats_test(n_tests, n_tests, n_class);
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  Omega_var = L_Omega_var;
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  L_Omega_inv = L_Omega_var;
 //   
 //   for (int c = 0; c < n_class; ++c) {
 //     for (int t1 = 0; t1 < n_tests; ++t1) {
 //       for (int t2 = 0; t2 < n_tests; ++t2) {
 //         L_Omega_var[c](t1, t2) =   L_Omega_var_copy[c](t1, t2).val();
 //         Omega_var[c](t1, t2)   =   Omega_var_copy[c](t1, t2).val();
 //       }
 //     }
 //     
 //     L_Omega_inv[c] = L_Omega_var[c].inverse(); 
 //     
 //   }
 //   
 //   
 //   /////////////  prev stuff
 //   std::vector<double> 	 u_prev_var_vec(n_class, 0.0);
 //   std::vector<double> 	 prev_var_vec(n_class, 0.0);
 //   std::vector<double> 	 tanh_u_prev(n_class, 0.0);
 //   Eigen::Matrix<double, -1, -1>	 prev(1, n_class);
 //   
 //   u_prev_var_vec[1] = (u_prev_diseased);
 //   tanh_u_prev[1] = ( exp(2*u_prev_var_vec[1] ) - 1) / ( exp(2*u_prev_var_vec[1] ) + 1) ;
 //   u_prev_var_vec[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) )  ;
 //   tanh_u_prev[0] = (exp(2*u_prev_var_vec[0] ) - 1) / ( exp(2*u_prev_var_vec[0] ) + 1) ;
 //   
 //   prev_var_vec[1] = 0.5 * ( tanh_u_prev[1] + 1);
 //   prev_var_vec[0] =  0.5 * ( tanh_u_prev[0] + 1);
 //   prev(0,1) =  prev_var_vec[1];
 //   prev(0,0) =  prev_var_vec[0];
 //   
 // 
 //   double tanh_pu_deriv = ( 1 - tanh_u_prev[1] * tanh_u_prev[1]  );
 //   double deriv_p_wrt_pu_double = 0.5 *  tanh_pu_deriv;
 //   double tanh_pu_second_deriv  = -2 * tanh_u_prev[1]  * tanh_pu_deriv;
 //   double log_jac_p_deriv_wrt_pu  = ( 1 / deriv_p_wrt_pu_double) * 0.5 * tanh_pu_second_deriv; // for gradient of u's
 //   double  log_jac_p =    log( deriv_p_wrt_pu_double );
 //   
 //   
 //   ///////////////////////////////////////////////////////////////////////// prior densities
 //   double prior_densities = target_AD.val() ; // target_AD_coeffs.val() + target_AD_corrs.val();
 // 
 //   /////////////////////////////////////////////////////////////////////////////////////////////////////
 //   ///////// likelihood
 //   
 //   
 //   double s = 1/1.702;
 //   
 //   int chunk_counter = 0;
 //   int chunk_size  = std::round( N / n_chunks  / 2) * 2;  ; // N / n_chunks;
 //   
 //   
 //   double log_prob_out = 0.0;
 //   
 //   
 //   Eigen::Matrix<double, -1, -1 >  log_prev = prev;
 //   
 //   
 //   for (int c = 0; c < n_class; c++) {
 //     log_prev(0,c) =  log(prev(0,c));
 //     for (int t = 0; t < n_tests; t++) {
 //       if (CI == true)      L_Omega_var[c](t,t) = 1;
 //     }
 //   }
 //   
 //   
 //   Eigen::Matrix<double, -1, -1> u_array   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 //   
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  prob   = vec_of_mats_test(chunk_size, n_tests, n_class);
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  Z_std_norm =  prob;
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  Phi_Z =  prob;
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  Bound_Z =  prob;
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  Bound_U_Phi_Bound_Z =  prob;
 //   
 //   Eigen::Matrix<int, -1, -1> y_sign   =  Eigen::Matrix<int, -1, -1>::Zero(chunk_size, n_tests);
 //   Eigen::Matrix<double, -1, 1> prob_n  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
 //   Eigen::Matrix<double, -1, 1 >  log_lik_chunk   =   Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
 //   Eigen::Matrix<double, -1, 1 >  log_lik   =   Eigen::Matrix<double, -1, 1>::Zero(N);  //////////////////
 //   
 //   
 //   Eigen::Matrix<double, -1, -1> lp_array  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_class);
 //   std::vector<Eigen::Matrix<double, -1, -1 > > 	 inc_array = prob ;
 //   std::vector<Eigen::Matrix<double, -1, -1 > > 	 y1_array = prob ;
 //   
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  phi_Z  =  vec_of_mats_test(chunk_size, n_tests, n_class) ;
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  phi_Bound_Z  =  vec_of_mats_test(chunk_size, n_tests, n_class) ;
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  common_grad_term_1  =  vec_of_mats_test(chunk_size, n_tests, n_class) ;
 //   
 //   Eigen::Matrix<double, -1, -1> derivs_chain_container_vec_array  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 //   Eigen::Matrix<double, -1, -1> z_grad_term  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 //   Eigen::Matrix<double, -1, -1> prob_term  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 //   Eigen::Matrix<double, -1, 1> prod_container  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
 //   
 //   Eigen::Matrix<double, -1, -1> u_grad_array   =  Eigen::Matrix<double, -1, -1>::Zero(N, n_tests);    //////////////////
 // 
 //   
 //   
 //   Eigen::Matrix< double , -1, 1>  beta_grad_vec   =  Eigen::Matrix<double, -1, 1>::Zero(n_coeffs);
 //   Eigen::Matrix<double, -1, -1>   beta_grad_array  =  Eigen::Matrix<double, -1, -1>::Zero(n_class, n_tests);
 //   
 //   std::vector<Eigen::Matrix<double, -1, -1 > > U_Omega_grad_array =  vec_of_mats_test(n_tests, n_tests, n_class);
 //   Eigen::Matrix<double, -1, 1 > U_Omega_grad_vec(n_corrs);
 //   
 //   Eigen::Matrix<double, -1, 1>  deriv_L_t1 =     Eigen::Matrix<double, -1, 1>::Zero( n_tests);
 //   Eigen::Matrix<double, -1, 1>  deriv_L_t1_output_vec =     Eigen::Matrix<double, -1, 1>::Zero( n_tests);
 //   
 //   Eigen::Matrix<double, -1, -1 >   deriv_inc  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 //   Eigen::Matrix<double, -1, 1> deriv_comp_2  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
 //   
 //   Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(n_class);
 //   Eigen::Matrix<double, -1, 1>  prev_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(n_class);
 //   Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec_out =   Eigen::Matrix<double, -1, 1>::Zero(n_class - 1);
 //   
 //   Eigen::Matrix<double, -1, -1 >  y_m_ysign_x_u_array =   Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;  ;
 //   
 //   
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  grad_bound_z = vec_of_mats_test(chunk_size, n_tests*2, n_class) ; 
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  grad_Phi_bound_z = vec_of_mats_test(chunk_size, n_tests*2, n_class) ; 
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  deriv_Bound_Z_x_L = vec_of_mats_test(chunk_size, n_tests*2, n_class) ; 
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  grad_prob = vec_of_mats_test(chunk_size, n_tests*2, n_class) ; 
 //   std::vector<Eigen::Matrix<double, -1, -1 > >  grad_z_mat = vec_of_mats_test(chunk_size, n_tests*2, n_class) ;  
 //   
 //   Eigen::Matrix< double , -1, 1>  temp_L_Omega_x_grad_z_sum_1(chunk_size);
 //   
 //   
 //   Eigen::Matrix<double, -1, -1>  grad_pi_wrt_b_raw =  Eigen::Matrix<double, -1, -1>::Zero(n_class, n_tests) ; 
 //   
 //   
 //   int iiii = 0;
 //   int iiiiii = 0;
 //   int nn = 0;
 //   double sqrt_2_pi_recip =   1 / sqrt(2 * M_PI) ; //  0.3989422804;
 //   
 //   for (int nc = 0; nc < n_chunks; nc++) {
 //     
 //     prob = vec_of_mats_test(chunk_size, n_tests, n_class);
 //     Z_std_norm =  prob;
 //     Phi_Z =  prob;
 //     Bound_Z =  prob;
 //     Bound_U_Phi_Bound_Z =  prob;
 //     
 //     y_sign   =  Eigen::Matrix<int, -1, -1>::Zero(chunk_size, n_tests);
 //     prob_n  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
 //     log_lik_chunk   =   Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
 //     
 //     lp_array  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_class);
 //     inc_array = prob ;
 //     y1_array = prob ;
 //     
 //     phi_Z  =  vec_of_mats_test(chunk_size, n_tests, n_class) ;
 //     phi_Bound_Z = phi_Z;
 //     common_grad_term_1 = phi_Z;
 //     
 //     derivs_chain_container_vec_array  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 //     z_grad_term  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 //     prob_term  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 //     prod_container  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
 //     
 //     deriv_inc  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 //     deriv_comp_2  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
 //     
 //     y_m_ysign_x_u_array =   Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;  ;
 //     
 //     
 //     for (int nc_index = 0; nc_index < chunk_size; nc_index++ ) {
 //       
 //       for (int t = 0; t < n_tests; t++) {
 //         
 //         
 //         u_array(nc_index, t) =   0.5 * ( tanh_uu(iiii) + 1) ; // u_vec(iiii);
 //         iiii = iiii + 1;
 //         
 //         for (int c = 0; c < n_class; c++) {
 //           inc_array[c](nc_index, t) = 0;
 //         }
 //         
 //         
 //         if ( y(nn,t) == 1 ) {
 //           y_sign(nc_index, t) = +1;
 //         } else {
 //           y_sign(nc_index, t) = -1;
 //         }
 //         
 //         
 //         
 //       }
 //       
 //       nn += 1; // counter for individual
 //       
 //     }
 //     
 //     
 //     
 //     y_m_ysign_x_u_array.array()  =   ( (  (y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array()  - y_sign.array()  *  u_array.array()  ).array() ) ) ;
 //     
 //     
 //     
 //     for (int t = 0; t < n_tests; t++) {
 //       
 //       for (int c = 0; c < n_class; c++) {
 //         
 //         Bound_Z[c].col(t).array() =   ( ((  0 - ( LT_a(c, t).val() +    inc_array[c].col(t).array()    )  ) / L_Omega_var[c](t, t) )  ).array() ;
 //         
 //         if (rough_approx == true)  {
 //           Bound_U_Phi_Bound_Z[c].col(t).array() =  ( stan::math::inv_logit(  1.702 *  Bound_Z[c].col(t) ) ).array() ;
 //         }  else  {
 //           if (   ( Phi_exact_indicator_if_not_using_rough_approx  == false) ) {     // for numerical stability
 //             Bound_U_Phi_Bound_Z[c].col(t) =   (  stan::math::abs(Bound_Z[c].col(t).array()) > ub_threshold_phi_approx ).select(  ( stan::math::inv_logit(  1.702 *  Bound_Z[c].col(t) ) ) ,  stan::math::Phi_approx( Bound_Z[c].col(t) ) ) ;   
 //           } else {    // for numerical stability
 //             Bound_U_Phi_Bound_Z[c].col(t) =   (  stan::math::abs(Bound_Z[c].col(t).array()) > ub_threshold_phi_approx ).select(  ( stan::math::inv_logit(  1.702 *  Bound_Z[c].col(t) ) ) ,  stan::math::Phi( Bound_Z[c].col(t) ) ) ;   
 //             
 //           }
 //         }
 //         
 //         Phi_Z[c].col(t).array()    =     y.col(t).segment(chunk_size * chunk_counter, chunk_size).array() *    Bound_U_Phi_Bound_Z[c].col(t).array() +   (  y.col(t).segment(chunk_size * chunk_counter, chunk_size).array()  -   Bound_U_Phi_Bound_Z[c].col(t).array() ) * y_sign.col(t).array() * u_array.col(t).array() ;
 //         
 //         y1_array[c].col(t) =  ( (  y.col(t).segment(chunk_size * chunk_counter, chunk_size).array() == 1 ).array()  ).select( stan::math::log1m( Bound_U_Phi_Bound_Z[c].col(t)),   Bound_U_Phi_Bound_Z[c].col(t).array().log().matrix() ) ; 
 //         
 //         Bound_U_Phi_Bound_Z[c].col(t)  =   (  stan::math::abs(Bound_Z[c].col(t).array()) > ub_threshold_phi_approx ).array().select(  stan::math::inv_logit(1.702 *  Bound_Z[c].col(t))  ,    stan::math::Phi(Bound_Z[c].col(t)) ) ;   
 //         
 //         
 //         prob[c].col(t) =   y1_array[c].col(t).array().exp();
 //         
 //         if (rough_approx == true)  {
 //           Z_std_norm[c].col(t).array()  =     (  (  Phi_Z[c].col(t).array().log() ).array() -   stan::math::log1m(   Phi_Z[c].col(t) ).array()    )   * s ;  // logit(..) * s
 //         } else {
 //           // for numerical stability
 //           Z_std_norm[c].col(t).array() = Eigen::Select(    stan::math::fabs(Bound_Z[c].col(t).array()) > ub_threshold_phi_approx ,
 //                             (  (  Phi_Z[c].col(t).array().log() ).array() -    ( stan::math::log1m(   Phi_Z[c].col(t)).array()  ) ).array()     * s  ,
 //                             stan::math::inv_Phi( Phi_Z[c].col(t)  ).array() );
 //           
 //        //   Z_std_norm[c].col(t) =   (  stan::math::abs(Bound_Z[c].col(t).array()) > ub_threshold_phi_approx ).array().select(  ((  (  Phi_Z[c].col(t).array().log() ).array() -    ( stan::math::log1m(   Phi_Z[c].col(t)).array()  ) ).array()     * s ).matrix() ,   stan::math::inv_Phi(Phi_Z[c].col(t)) ) ; 
 //           
 //         }
 //         
 //         if (CI == false) {
 //           if (t < n_tests - 1) {
 //             inc_array[c].col(t + 1)    =   ( Z_std_norm[c].block(0, 0, chunk_size, t + 1)  *   ( L_Omega_var[c].row(t+1).head(t+1).transpose()  ) ) ;
 //           }
 //         }
 //         
 //       } // end of c loop
 //       
 //     } // end of t loop
 // 
 //     for (int c = 0; c < n_class; c++) {
 //       lp_array.col(c).array() = y1_array[c].rowwise().sum().array() +  log_prev(0,c) ;
 //     }
 //     
 //     log_lik_chunk.array()   =  lp_array.array().maxCoeff() +   (lp_array.array() - lp_array.array().maxCoeff() ).array().exp().rowwise().sum().array().log() ;  //  log_sum_exp(lp);
 //     log_lik.segment( chunk_size * chunk_counter, chunk_size).array() =  log_lik_chunk.array() ;
 //     
 //     prob_n =   log_lik_chunk.array().exp().matrix();
 //     
 //     log_prob_out += log_lik_chunk.sum();
 //     
 //     
 //     
 //     // /////////////////////////////////////////////////////////////////////////////////////// Manual gradients
 //     bool grad;
 //     if (grad_nuisance == true) grad = true;
 //     if (grad_main == true) grad = true;
 //     
 //     if (grad == true) {
 //       
 //       if (rough_approx == true)  {
 //         for (int c = 0; c < n_class; c++) {
 //           phi_Z[c].array()  =        Phi_Z[c].array() * (1 -        Phi_Z[c].array() ) * (1/s);
 //           phi_Bound_Z[c].array()      =  Bound_U_Phi_Bound_Z[c].array() * ( 1 - Bound_U_Phi_Bound_Z[c].array()  ) * (1/s);
 //         }
 //       } else {
 //         for (int c = 0; c < n_class; c++) {
 //           
 //           phi_Z[c] =   (  stan::math::abs(Bound_Z[c].array()) > ub_threshold_phi_approx ).array().select(  (  Phi_Z[c].array() * (1 -        Phi_Z[c].array() ) * (1/s)  ).matrix(),   sqrt_2_pi_recip *  ( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).exp().array().matrix()  ) ; 
 //           
 //           phi_Bound_Z[c] =   (  stan::math::abs(Bound_Z[c].array()) > ub_threshold_phi_approx ).array().select(  (  Bound_U_Phi_Bound_Z[c].array() * (1 -        Bound_U_Phi_Bound_Z[c].array() ) * (1/s)  ).matrix(),   sqrt_2_pi_recip *  ( - 0.5 * Bound_Z[c].array() *  Bound_Z[c].array() ).exp().array().matrix()  ) ; 
 //           
 //         }
 //       }
 //       
 //       
 //       for (int c = 0; c < n_class; c++) {
 //         for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
 //           int t = n_tests - (i + 1) ;
 //           common_grad_term_1[c].col(t) =   ( prev(0,c) / prob_n.array() ) * ( prob[c].block(0, 0, n_chunks, n_tests).rowwise().prod().array()  /  prob[c].block(0, t + 0, n_chunks, i + 1).rowwise().prod().array()  ).array();
 //         }
 //       }
 //       
 //     }
 //     
 //     //  ///////////////////////////////////////////////////////////////////////////////// Grad of nuisance parameters / u's (manual)
 //     if (grad_nuisance == true) {
 //       
 //       for (int c = 0; c < n_class; c++) {
 //         
 //         u_grad_array.col(n_tests - 1).array() = 0; // ----------   correct
 //         
 //         ///// then second-to-last term (test T - 1)
 //         int t = n_tests - 1;
 //         
 //         u_grad_array.col(n_tests - 2).segment( chunk_size * chunk_counter, chunk_size).array()  +=   common_grad_term_1[c].col(t).array()  * (y_sign.col(t).array()  * phi_Bound_Z[c].col(t).array() * (1 / L_Omega_var[c](t,t)  ) *  // lp(T)
 //           L_Omega_var[c](t,t - 1) * ( 1 /phi_Z[c].col(t-1).array() )  * prob[c].col(t-1).array()).array(); // lp(T)    // ----------   correct
 //         
 //         
 //           { ///// then third-to-last term (test T - 2)
 //             t = n_tests - 2;
 //             
 //             z_grad_term.col(0) = (1 / phi_Z[c].col(t-1).array())  * prob[c].col(t-1).array() ;
 //             prob_term.col(0) =     y_sign.col(t).array()  *    phi_Bound_Z[c].col(t).array() * (1 / L_Omega_var[c](t,t)  ) *     L_Omega_var[c](t, t - 1) *   z_grad_term.col(0).array() ; // lp(T-1) - part 2;
 //             z_grad_term.col(1).array()  = (1 /phi_Z[c].col(t).array() ) * phi_Bound_Z[c].col(t).array() * (1 / L_Omega_var[c](t,t))  * L_Omega_var[c](t,t-1) *   z_grad_term.col(0).array() *       y_m_ysign_x_u_array.col(t).array() ;
 //             
 //             prob_term.col(1)  =       y_sign.col(t + 1).array()   *   (   phi_Bound_Z[c].col(t+1).array()  *  (1 / L_Omega_var[c](t+1,t+1)  ) ) *
 //               (  z_grad_term.col(0).array() *  L_Omega_var[c](t + 1,t - 1)  -   z_grad_term.col(1).array()  * L_Omega_var[c](t+1,t)) ;
 //             
 //             u_grad_array.col(n_tests - 3).segment( chunk_size * chunk_counter, chunk_size).array()  +=  common_grad_term_1[c].col(t).array()   *  (  prob_term.col(1).array() * prob[c].col(t).array()  +      prob_term.col(0).array() *  prob[c].col(t+1).array()  );  // ----------   correct
 //           }
 //           
 //       }
 //       
 //       
 //       ///// then rest of terms
 //       for (int c = 0; c < n_class; c++) {
 //         
 //         // then rest of terms
 //         for (int i = 1; i < n_tests - 2; i++) { // i goes from 1 to 3
 //           
 //           for (int nc_index = 0; nc_index < chunk_size; nc_index++ ) {
 //             prod_container(nc_index) = 0;
 //             for (int t = 0; t < n_tests; t++) {
 //               prob_term(nc_index, t) = 0;
 //               z_grad_term(nc_index, t) = 0;
 //             }
 //           }
 //           
 //           int t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)
 //           
 //           z_grad_term.col(0) = (1 / phi_Z[c].col(t-1).array())  * prob[c].col(t-1).array() ;
 //           
 //           prob_term.col(0) =     y_sign.col(t).array()  *    phi_Bound_Z[c].col(t).array() * (1 / L_Omega_var[c](t,t)  ) *  // lp(T-1) - part 1
 //             L_Omega_var[c](t, t - 1) *   z_grad_term.col(0).array() ; // lp(T-1) - part 2;
 //             
 //             for (int ii = 0; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1 u_grad_z u_grad_term
 //               
 //               if (ii == 0)    prod_container  = (   (z_grad_term.block(0, 0, chunk_size, ii + 1) ) *  (fn_first_element_neg_rest_pos(L_Omega_var[c].row( t + (ii-1) + 1).segment(t - 1, ii + 1))).transpose()  )      ;
 //               z_grad_term.col(ii+1)  =  (1 /phi_Z[c].col( t+(ii-1)+1).array() ).array() * phi_Bound_Z[c].col(t+(ii-1)+1).array() * (1 / L_Omega_var[c](t+(ii-1)+1,t+(ii-1)+1))   *   y_m_ysign_x_u_array.col(t + ii).array() *  -   prod_container.array() ;
 //               prod_container  = (   (z_grad_term.block(0, 0, chunk_size, ii + 2) ) *  (fn_first_element_neg_rest_pos(L_Omega_var[c].row( t + (ii) + 1).segment(t - 1, ii + 2))).transpose()  )      ;
 //               prob_term.col(ii+1)  =    y_sign.col(t + ii + 1).array()  *   (    phi_Bound_Z[c].col(t+ii+1).array() *  (1 / L_Omega_var[c](t+ii+1,t+ii+1)  )) *     -    prod_container.array()  ;
 //               
 //             } // end of ii loop
 //             
 //             for (int ii = 0; ii < i + 2; ii++) {
 //               derivs_chain_container_vec_array.col(ii)  =  ( prob_term.col(ii).array()  * (    prob[c].block(0, t + 0, chunk_size, i + 2).rowwise().prod().array() /  prob[c].col(t + ii).array()  ).array() ).matrix() ;
 //             }
 //             u_grad_array.col(n_tests - (i+3)).segment( chunk_size * chunk_counter, chunk_size)  +=    ( common_grad_term_1[c].col(t).array()   *  derivs_chain_container_vec_array.block(0, 0, chunk_size, i + 2).rowwise().sum().array() ).matrix() ;
 //             
 //         }
 //         
 //       } // end of c loop
 //       
 //     }
 //     
 //     /////////////////////////////////////////////////////////////////////////// Grad of intercepts / coefficients (beta's)
 //     for (int c = 0; c < n_class; c++) {
 //       
 //       if (grad_main == true) {
 //         
 //         ///// last term first (test T)
 //         int t = n_tests - 1;
 //         
 //         beta_grad_array(c, t) +=     (common_grad_term_1[c].col(t).array()  *   ( - y_sign.col(t).array()   * phi_Bound_Z[c].col(t).array()  * ( - 1 / L_Omega_var[c](t,t)  ))).sum();
 //         
 //         ///// then second-to-last term (test T - 1)
 //         {
 //           t = n_tests - 2;
 //           prob_term.col(0) =       ( (- y_sign.col(t).array()   )  * phi_Bound_Z[c].col(t).array() * (- 1 / L_Omega_var[c](t,t)  ) ) ;
 //           z_grad_term.col(1)   =      (1 /phi_Z[c].col(t).array()  ) *  y_m_ysign_x_u_array.col(t).array() *   phi_Bound_Z[c].col(t).array()  * (- 1 / L_Omega_var[c](t,t))     ;
 //           prob_term.col(1)  =       ( - y_sign.col(t+1).array()    ) *  (   phi_Bound_Z[c].col(t+1).array()  *  (- 1 / L_Omega_var[c](t+1,t+1)  ) ) * (   L_Omega_var[c](t + 1,t) *      z_grad_term.col(1).array() ) ;
 //           
 //           beta_grad_array(c, t) +=  (common_grad_term_1[c].col(t).array()   * ( prob_term.col(1).array() * prob[c].col(t).array() +         prob_term.col(0).array() *  prob[c].col(t+1).array() ) ).sum() ;
 //         }
 //         
 //         // then rest of terms
 //         for (int i = 1; i < n_tests - 1; i++) { // i goes from 1 to 3
 //           
 //               t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)
 //               
 //               // component 1 (earliest test)
 //               for (int nc_index = 0; nc_index < chunk_size; ++nc_index ) {
 //                 z_grad_term(nc_index, 0) = 0;
 //               }
 //               prob_term.col(0)  =    ( ( - y_sign.col(t).array()  )  * phi_Bound_Z[c].col(t).array()  * (- 1 / L_Omega_var[c](t,t)  ) ) ;
 //               
 //               // component 2 (second-to-earliest test)
 //               z_grad_term.col(1)  =     (1 /phi_Z[c].col(t).array()  ) *  y_m_ysign_x_u_array.col(t).array() *    phi_Bound_Z[c].col(t).array()  * (- 1 / L_Omega_var[c](t,t))    ;
 //               prob_term.col(1) =        - y_sign.col(t + 1).array()   * (   phi_Bound_Z[c].col(t+1).array() *  (- 1 / L_Omega_var[c](t+1,t+1)  ) ) *    (   L_Omega_var[c](t + 1,t) *   z_grad_term.col(1).array() ) ;
 //               
 //               // rest of components
 //               for (int ii = 1; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1
 //                     if (ii == 1)  prod_container  = (    z_grad_term.block(0, 1, chunk_size, ii)  *   L_Omega_var[c].row( t + (ii - 1) + 1).segment(t + 0, ii + 0).transpose()  );
 //                     z_grad_term.col(ii+1)  =      (1 /phi_Z[c].col(t+(ii-1)+1).array() ).array() * y_m_ysign_x_u_array.col(t + ii).array() *
 //                     phi_Bound_Z[c].col(t+(ii-1)+1).array() * (- 1 / L_Omega_var[c](t+(ii-1)+1,t+(ii-1)+1))  *   prod_container.array();
 //                     prod_container  = (    z_grad_term.block(0, 1, chunk_size, ii + 1)  *   L_Omega_var[c].row( t + (ii) + 1).segment(t + 0, ii + 1).transpose()  );
 //                     prob_term.col(ii+1) =      (  - y_sign.col(t + ii + 1).array()  ).array() *   (    phi_Bound_Z[c].col(t+ii+1).array() *  (- 1 / L_Omega_var[c](t+ii+1,t+ii+1)  ) ).array()   *  prod_container.array();
 //               }
 //               
 //               ///// attempt at vectorising  // bookmark
 //               for (int ii = 0; ii < i + 2; ii++) {
 //                 derivs_chain_container_vec_array.col(ii)  =  ( prob_term.col(ii).array()  * (    prob[c].block(0, t + 0, chunk_size, i + 2).rowwise().prod().array() /  prob[c].col(t + ii).array()  ).array() ).matrix() ;
 //               }
 //               beta_grad_array(c, t) +=        ( common_grad_term_1[c].col(t).array()   *  derivs_chain_container_vec_array.block(0, 0, chunk_size, i + 2).rowwise().sum().array() ).sum();
 //           
 //         }
 //         
 //       }
 //       
 //     }
 //     ////////////////////////////////////////////////////////////////////////////////////////////////// Grad of L_Omega ('s)
 //     for (int c = 0; c < n_class; c++) {
 // 
 //         
 //         ///////////////////////// deriv of diagonal elements (not needed if using the "standard" or "Stan" Cholesky parameterisation of Omega)
 //         
 //         //////// w.r.t last diagonal first
 //         {
 //           int  t1 = n_tests - 1;
 //         
 //         
 //         
 //         double deriv_L_T_T_inv =  ( - 1 /  ( L_Omega_var[c](t1,t1)  * L_Omega_var[c](t1,t1) ) )   *   Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1, t1).val()  ;
 //         
 //         deriv_Bound_Z_x_L[c].col(0).array() = 0;
 //         for (int t = 0; t < t1; t++) {
 //           deriv_Bound_Z_x_L[c].col(0).array() +=   Z_std_norm[c].col(t).array() *  Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1, t).val();
 //         }
 // 
 //         double deriv_a = 0 ; //  stan::math::pow( (1 + (bs_mat(c, t1).val()*bs_mat(c, t1).val()) ), -0.5) * bs_mat(c, t1).val()  * LT_theta(c, t1)  ;
 //         deriv_Bound_Z_x_L[c].col(0).array()   = deriv_a -     deriv_Bound_Z_x_L[c].col(0).array();
 //           
 //         grad_bound_z[c].col(0).array() =   deriv_L_T_T_inv * (Bound_Z[c].col(t1).array() * L_Omega_var[c](t1,t1)  ) +  (1 / L_Omega_var[c](t1, t1)) *   deriv_Bound_Z_x_L[c].col(0).array()  ;         
 //         grad_Phi_bound_z[c].col(0)  =  ( phi_Bound_Z[c].col(t1).array() *  (  grad_bound_z[c].col(0).array() )  ) .matrix();   // correct  (standard form)
 //         grad_prob[c].col(0)   =  (   - y_sign.col(t1).array()  *   grad_Phi_bound_z[c].col(0).array() ).matrix() ;     // correct  (standard form)
 //         
 //         
 //         grad_pi_wrt_b_raw(c, t1)  +=   (   common_grad_term_1[c].col(t1).array()    *            grad_prob[c].col(0).array()    ).matrix().sum()   ; // correct  (standard form)
 //         
 // 
 //         }
 //         
 //         
 //         //////// then w.r.t the second-to-last diagonal
 //         {
 //           int  t1 = n_tests - 2;
 //           
 //           double deriv_L_T_T_inv =  ( - 1 /   ( L_Omega_var[c](t1,t1)  * L_Omega_var[c](t1,t1) ) )  * Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1, t1).val()  ;
 //           
 //           deriv_Bound_Z_x_L[c].col(0).array() = 0;
 //           for (int t = 0; t < t1; t++) {
 //             deriv_Bound_Z_x_L[c].col(0).array() += Z_std_norm[c].col(t).array() *  Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1, t).val();
 //           }
 // 
 //           double deriv_a = 0 ; //   stan::math::pow( (1 + (bs_mat(c, t1).val()*bs_mat(c, t1).val()) ), -0.5) * bs_mat(c, t1).val()   * LT_theta(c, t1)   ;
 //           deriv_Bound_Z_x_L[c].col(0).array()   = deriv_a -     deriv_Bound_Z_x_L[c].col(0).array();
 //           
 //           
 //           grad_bound_z[c].col(0).array() =  deriv_L_T_T_inv * (Bound_Z[c].col(t1).array() * L_Omega_var[c](t1,t1)  ) +  (1 / L_Omega_var[c](t1, t1)) *     deriv_Bound_Z_x_L[c].col(0).array()  ;   
 //           grad_Phi_bound_z[c].col(0)  =  ( phi_Bound_Z[c].col(t1).array() *  (  grad_bound_z[c].col(0).array() )  ) .matrix();   // correct  (standard form)
 //           grad_prob[c].col(0)   =  (   - y_sign.col(t1).array()  *   grad_Phi_bound_z[c].col(0).array() ).matrix() ;     // correct  (standard form)
 //           
 //           
 //           grad_z_mat[c].col(0).array()  =      (  ( (  y_m_ysign_x_u_array.col(t1).array()   / phi_Z[c].col(t1).array()  ).array()    * phi_Bound_Z[c].col(t1).array() *   grad_bound_z[c].col(0).array()  ).array() ).matrix()  ;  // correct  (standard form)
 //           
 //           deriv_L_T_T_inv =  ( - 1 /  ( L_Omega_var[c](t1+1,t1+1)  * L_Omega_var[c](t1+1,t1+1)  )  )  * Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1+1, t1+1).val()  ;
 //           deriv_Bound_Z_x_L[c].col(1).array()  =    L_Omega_var[c](t1+1,t1) *   grad_z_mat[c].col(0).array()     +   Z_std_norm[c].col(t1).array() *  Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1+1, t1).val();
 //           grad_bound_z[c].col(1).array() =  deriv_L_T_T_inv * (Bound_Z[c].col(t1+1).array() * L_Omega_var[c](t1+1,t1+1)  ) +  (1 / L_Omega_var[c](t1+1, t1+1)) * -   deriv_Bound_Z_x_L[c].col(1).array()  ; 
 //           
 //           grad_Phi_bound_z[c].col(1) =   ( phi_Bound_Z[c].col(t1 + 1).array() *  (    grad_bound_z[c].col(1).array()   ) ).matrix();   // correct  (standard form)
 //           grad_prob[c].col(1)   =   (  - y_sign.col(t1 + 1).array()  *     grad_Phi_bound_z[c].col(1).array()  ).array().matrix() ;    // correct   (standard form)
 //           
 //           grad_pi_wrt_b_raw(c, t1) +=   ( ( common_grad_term_1[c].col(t1).array() )    *
 //                                   ( prob[c].col(t1 + 1).array()  *      grad_prob[c].col(0).array()  +   prob[c].col(t1).array()  *         grad_prob[c].col(1).array()   ) ).sum() ;
 //         }
 //         
 //         
 //         //////// then w.r.t the third-to-last diagonal .... etc
 //         {
 //           
 //           //   int i = 4;
 //           for (int i = 3; i < n_tests + 1; i++) {
 //             
 //             int  t1 = n_tests - i;
 //             
 //             double deriv_L_T_T_inv =  ( - 1 /   ( L_Omega_var[c](t1,t1)  * L_Omega_var[c](t1,t1) ) )  * Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1, t1).val()  ;
 //             
 //             deriv_Bound_Z_x_L[c].col(0).array() = 0;
 //             for (int t = 0; t < t1; t++) {
 //               deriv_Bound_Z_x_L[c].col(0).array() += Z_std_norm[c].col(t).array() *  Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1, t).val();
 //             }
 // 
 //            double deriv_a = 0 ; //  stan::math::pow( (1 + (bs_mat(c, t1).val()*bs_mat(c, t1).val()) ), -0.5) * bs_mat(c, t1).val() *   LT_theta(c, t1)   ;
 //             deriv_Bound_Z_x_L[c].col(0).array()   = deriv_a -     deriv_Bound_Z_x_L[c].col(0).array();
 //             
 //             
 //             grad_bound_z[c].col(0).array() =  deriv_L_T_T_inv * (Bound_Z[c].col(t1).array() * L_Omega_var[c](t1,t1)  ) +  (1 / L_Omega_var[c](t1, t1)) *    deriv_Bound_Z_x_L[c].col(0).array()  ;   
 //             grad_Phi_bound_z[c].col(0)  =  ( phi_Bound_Z[c].col(t1).array() *  (  grad_bound_z[c].col(0).array() )  ) .matrix();   // correct  (standard form)
 //             grad_prob[c].col(0)   =  (   - y_sign.col(t1).array()  *   grad_Phi_bound_z[c].col(0).array() ).matrix() ;     // correct  (standard form)
 //             
 //             
 //             grad_z_mat[c].col(0).array()  =      (  ( (  y_m_ysign_x_u_array.col(t1).array()   / phi_Z[c].col(t1).array()  ).array()    * phi_Bound_Z[c].col(t1).array() *   grad_bound_z[c].col(0).array()  ).array() ).matrix()  ;  // correct  (standard form)
 //             
 //             deriv_L_T_T_inv =  ( - 1 /  ( L_Omega_var[c](t1+1,t1+1)  * L_Omega_var[c](t1+1,t1+1)  )  )  * Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1+1, t1+1).val()  ;
 //             deriv_Bound_Z_x_L[c].col(1).array()  =    L_Omega_var[c](t1+1,t1) *   grad_z_mat[c].col(0).array()     +   Z_std_norm[c].col(t1).array() *  Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1+1, t1).val();
 //             grad_bound_z[c].col(1).array() =  deriv_L_T_T_inv * (Bound_Z[c].col(t1+1).array() * L_Omega_var[c](t1+1,t1+1)  ) +  (1 / L_Omega_var[c](t1+1, t1+1)) * -  deriv_Bound_Z_x_L[c].col(1).array()  ; 
 //             
 //             grad_Phi_bound_z[c].col(1) =   ( phi_Bound_Z[c].col(t1 + 1).array() *  (    grad_bound_z[c].col(1).array()   ) ).matrix();   // correct  (standard form)
 //             grad_prob[c].col(1)  =   (  - y_sign.col(t1 + 1).array()  *     grad_Phi_bound_z[c].col(1).array()  ).array().matrix() ;    // correct   (standard form)
 //             
 //             
 //             for (int ii = 1; ii < i - 1; ii++) {
 //                 grad_z_mat[c].col(ii).array()  =    (  ( (  y_m_ysign_x_u_array.col(t1 + ii).array()   / phi_Z[c].col(t1 + ii).array()  ).array()    * phi_Bound_Z[c].col(t1 + ii).array() *   grad_bound_z[c].col(ii).array()  ).array() ).matrix() ;     // correct  (standard form)
 //                 
 //                 deriv_L_T_T_inv =  ( - 1 /  (  L_Omega_var[c](t1 + ii + 1,t1 + ii + 1)  * L_Omega_var[c](t1 + ii + 1,t1 + ii + 1) )  )  * Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1 + ii + 1, t1 + ii + 1).val()  ;
 //                 
 //                 deriv_Bound_Z_x_L[c].col(ii + 1).array()   =  0;
 //                 for (int jj = 0; jj < ii + 1; jj++) {
 //                   deriv_Bound_Z_x_L[c].col(ii + 1).array()  +=    L_Omega_var[c](t1 + ii + 1,t1 + jj)     *   grad_z_mat[c].col(jj).array()     +   Z_std_norm[c].col(t1 + jj).array()     *  Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1 + ii + 1, t1 + jj).val() ;// + 
 //                 }
 //                 grad_bound_z[c].col(ii + 1).array() =  deriv_L_T_T_inv * (Bound_Z[c].col(t1 + ii + 1).array() * L_Omega_var[c](t1 + ii + 1,t1 + ii + 1)  ) +  (1 / L_Omega_var[c](t1 + ii + 1, t1 + ii + 1)) * -   deriv_Bound_Z_x_L[c].col(ii + 1).array()  ; 
 //                 grad_Phi_bound_z[c].col(ii + 1).array()  =     phi_Bound_Z[c].col(t1 + ii + 1).array()  *   grad_bound_z[c].col(ii + 1).array() ;   // correct  (standard form)
 //                 grad_prob[c].col(ii + 1).array()  =   ( - y_sign.col(t1 + ii + 1).array()  ) *    grad_Phi_bound_z[c].col(ii + 1).array() ;  // correct  (standard form)
 //               
 //             }
 //             
 //             
 //             
 //             ///// attempt at vectorising  // bookmark
 //             for (int iii = 0; iii <  i; iii++) {
 //               derivs_chain_container_vec_array.col(iii)  =  (    grad_prob[c].col(iii).array()  * (    prob[c].block(0, t1 + 0, chunk_size, i).rowwise().prod().array() /  prob[c].col(t1 + iii).array()  ).array() ).matrix() ; // correct  (standard form)
 //             }
 //             
 //             grad_pi_wrt_b_raw(c, t1) +=        ( common_grad_term_1[c].col(t1).transpose()   *  derivs_chain_container_vec_array.block(0, 0, chunk_size, i).rowwise().sum() ).eval()(0, 0)  ; // correct  (standard form)
 //             
 //           }
 // 
 //         }
 //  
 //         prev_grad_vec(c)  +=  ( ( 1 / prob_n.array() ) * prob[c].rowwise().prod().array() ).matrix().sum() ;
 // 
 //       
 //     } // end of c loop
 //     
 //     
 //     
 //     chunk_counter += 1;
 //     
 //     
 //   }  // end of chunk loop
 //   
 //   
 //   
 //   //////////////////////// gradients for latent class membership probabilitie(s) (i.e. disease prevalence)
 //   if (grad_main == true) {
 //     for (int c = 0; c < n_class; c++) {
 //       prev_unconstrained_grad_vec(c)  =   prev_grad_vec(c)   * deriv_p_wrt_pu_double ;
 //     }
 //     prev_unconstrained_grad_vec(0) = prev_unconstrained_grad_vec(1) - prev_unconstrained_grad_vec(0) - 2 * tanh_u_prev[1];
 //     prev_unconstrained_grad_vec_out(0) = prev_unconstrained_grad_vec(0);
 //   }
 //   
 //   if (exclude_priors == false)     log_prob_out += prior_densities;
 // 
 //   double log_prob_out_wo_jacs = log_prob_out;
 //   
 //   log_prob_out +=  log_jac_u;
 //   log_prob_out +=  log_jac_p;
 //   
 //   auto log_prob = log_prob_out;
 //   
 // 
 //   int i = 0; // probs_all_range.prod() cancels out
 //   for (int c = 0; c < n_class; c++) {
 //     for (int t = 0; t < n_tests; t++) {
 //       //  if (exclude_priors == false)      beta_grad_array(c, t) +=  - ((LT_a(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) * (1/ prior_coeffs_sd(t,c) ) ;     // add normal prior density derivative to gradient
 //         beta_grad_vec(i) = beta_grad_array(c, t);
 //         i += 1;
 //     }
 //   }
 //   
 //   for (int n = 0; n < N; n++ ) {
 //     for (int t = 0; t < n_tests; t++) {
 //       out_mat(iiiiii + 1) = u_grad_array(n, t);
 //       iiiiii += 1;
 //     }
 //   }
 //   
 //   Eigen::Matrix<double, -1, 1 >  bs_grad_vec_nd =  (grad_pi_wrt_b_raw.row(0).transpose().array() * bs_nd_double.array()).matrix() ; //     ( deriv_log_pi_wrt_L_Omega[0].asDiagonal().diagonal().array() * bs_nd_double.array()  ).matrix()  ; //  Jacobian_d_L_Sigma_wrt_b_matrix[0].transpose() * deriv_log_pi_wrt_L_Omega_vec_nd;
 //   Eigen::Matrix<double, -1, 1 >  bs_grad_vec_d =   (grad_pi_wrt_b_raw.row(1).transpose().array() * bs_d_double.array()).matrix() ; //    ( deriv_log_pi_wrt_L_Omega[1].asDiagonal().diagonal().array() * bs_d_double.array()  ).matrix()  ; //   Jacobian_d_L_Sigma_wrt_b_matrix[1].transpose()  * deriv_log_pi_wrt_L_Omega_vec_d;
 //   
 //   Eigen::Matrix<double, -1, 1 >   bs_grad_vec(n_bs_LT);
 //   bs_grad_vec.head(n_tests)              = bs_grad_vec_nd ;
 //   bs_grad_vec.segment(n_tests, n_tests)  = bs_grad_vec_d;
 // 
 //   stan::math::recover_memory();
 //   
 //   ////////////////////////////  outputs
 //   out_mat(0) = log_prob;
 //   
 // 
 //   out_mat.segment(1 + n_us, n_bs_LT)  += bs_grad_vec ; 
 //   out_mat.segment(1 + n_us + n_corrs, n_coeffs) += beta_grad_vec;//.cast<float>();
 //   out_mat(n_params) = prev_unconstrained_grad_vec_out(0); // cast<float>()(0);
 //   out_mat.segment(1, n_us).array() =   (out_mat.segment(1, n_us).array() *   0.5 * (1 - tanh_uu.array() *  tanh_uu.array() )  - 2 * tanh_uu.array()) ;
 //   
 //   out_mat.segment(1 + n_params, N) = log_lik;
 //   
 //   
 //   int LT_cnt_2 = 0;
 //   for (int c = 0; c < n_class; ++c) {
 //     for (int t = 0; t < n_tests; ++t) {
 //       if (LT_known_bs_indicator(c, t) == 1) {
 //         out_mat(1 + n_us + LT_cnt_2) = 0;
 //       }
 //       LT_cnt_2 += 1;
 //     }
 //   }
 //   
 //   
 //    return(out_mat);
 //   
 //   
 //   
 //   
 // }
 // 
 // 
 // 
 // 
 // 
 // 
 // 
 
 
 // 
 // 
 // //
 //
 //
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1 >    fn_wo_list_log_posterior_and_gradient_Chol_Schur_MD_and_AD_1(   int n_cores,
                                                                                                  Eigen::Matrix<double, -1, 1  > theta_main,
                                                                                                  Eigen::Matrix<double, -1, 1  > theta_us,
                                                                                                  Eigen::Matrix<int, -1, -1>	 y,
                                                                                                  std::vector<Eigen::Matrix<double, -1, -1 > >  X,
                                                                                                  bool exclude_priors,
                                                                                                  bool CI,
                                                                                                  Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                                                  Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                                                  Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                                                  int n_class, // 10
                                                                                                  int n_tests,
                                                                                                  int ub_threshold_phi_approx,
                                                                                                  int n_chunks,
                                                                                                  bool corr_force_positive,
                                                                                                  std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                                                  std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                                                  bool corr_prior_beta ,
                                                                                                  bool corr_prior_norm ,
                                                                                                  std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                                                  std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr, // 20
                                                                                                  std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                                                  std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                                                  double prev_prior_a,
                                                                                                  double prev_prior_b,
                                                                                                  int Phi_type,
                                                                                                  int tanh_option


 ) {





   int N = y.rows();
   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
   int n_coeffs = n_class * n_tests * 1;
   int n_us =  1 *  N * n_tests;

   int n_params = theta_main.rows() + theta_us.rows() ; // n_corrs + n_coeffs + n_us + n_class;
   int n_params_main = n_params - n_us;



   // corrs
   Eigen::Matrix<double, -1, 1  >  Omega_raw_vec_double = theta_main.segment(0, n_corrs);

   Eigen::Matrix<stan::math::var, -1, 1  >  Omega_raw_vec_var =  stan::math::to_var(Omega_raw_vec_double) ;
   Eigen::Matrix<stan::math::var, -1, 1  >  Omega_constrained_raw_vec_var =  Eigen::Matrix<stan::math::var, -1, 1  >::Zero(n_corrs) ;

   Omega_constrained_raw_vec_var = ( (Omega_raw_vec_var)); // no transformation for Nump needed! done later on



   // coeffs
   Eigen::Matrix<double, -1, -1  > beta_double_array(n_class, n_tests);

   {
     int i = 0 + n_corrs;
     for (int c = 0; c < n_class; ++c) {
       for (int t = 0; t < n_tests; ++t) {
         beta_double_array(c, t) = theta_main(i);
         i = i + 1;
       }
     }
   }


   // prev
   double u_prev_diseased = theta_main(n_params_main - 1);



   Eigen::Matrix<double, -1, 1 >  target_AD_grad(n_corrs);


   int dim_choose_2 = n_tests * (n_tests - 1) * 0.5 ;

   stan::math::var target_AD = 0.0;
   double grad_prev_AD = 0;

   std::vector<Eigen::Matrix<double, -1, -1 > > L_Omega_double = vec_of_mats_test(n_tests, n_tests, n_class);
   std::vector<Eigen::Matrix<double, -1, -1 > > deriv_L_wrt_unc_full = vec_of_mats_test(dim_choose_2 + n_tests, dim_choose_2, n_class);


   {


     std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > Omega_unconstrained_var = fn_convert_std_vec_of_corrs_to_3d_array_var( Eigen_vec_to_std_vec_var(Omega_constrained_raw_vec_var),
                                                                                                                                  n_tests,
                                                                                                                                  n_class);


     std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > L_Omega_var_copy = vec_of_mats_test_var(n_tests, n_tests, n_class);
     std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  Omega_var_copy  = vec_of_mats_test_var(n_tests, n_tests, n_class);

     for (int c = 0; c < n_class; ++c) {
       Eigen::Matrix<stan::math::var, -1, -1 >  ub = stan::math::to_var(ub_corr[c]);
       Eigen::Matrix<stan::math::var, -1, -1 >  lb = stan::math::to_var(lb_corr[c]);

       Eigen::Matrix<stan::math::var, -1, -1  >  Chol_Schur_outs =  Spinkney_LDL_bounds_opt(n_tests, lb, ub, Omega_unconstrained_var[c], known_values_indicator[c], known_values[c]) ; //   Omega_unconstrained_var[c], n_tests, tol )  ;

       L_Omega_var_copy[c]   =  Chol_Schur_outs.block(1, 0, n_tests, n_tests);
       Omega_var_copy[c] =   L_Omega_var_copy[c] * L_Omega_var_copy[c].transpose() ;


       target_AD +=   Chol_Schur_outs(0, 0); // now can set prior directly on Omega
     }



     for (int c = 0; c < n_class; ++c) {
       if ( (corr_prior_beta == false)   &&  (corr_prior_norm == false) ) {
         target_AD +=  stan::math::lkj_corr_cholesky_lpdf(L_Omega_var_copy[c], lkj_cholesky_eta(c)) ;
       } else if ( (corr_prior_beta == true)   &&  (corr_prior_norm == false) ) {
         for (int i = 1; i < n_tests; i++) {
           for (int j = 0; j < i; j++) {
             target_AD +=  stan::math::beta_lpdf(  (Omega_var_copy[c](i, j) + 1)/2, prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
           }
         }
         //  Jacobian for  Omega -> L_Omega transformation for prior log-densities (since both LKJ and truncated normal prior densities are in terms of Omega, not L_Omega)
         Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
         for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * log(L_Omega_var_copy[c](i, i));
         target_AD  += + (n_tests * stan::math::log(2) + jacobian_diag_elements.sum());  //  L -> Omega
       } else if  ( (corr_prior_beta == false)   &&  (corr_prior_norm == true) ) {
         for (int i = 1; i < n_tests; i++) {
           for (int j = 0; j < i; j++) {
             target_AD +=  stan::math::normal_lpdf(  Omega_var_copy[c](i, j), prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
           }
         }
         Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
         for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * log(L_Omega_var_copy[c](i, i));
         target_AD  += + (n_tests * stan::math::log(2) + jacobian_diag_elements.sum());  //  L -> Omega
       }
     }


     ///////////////////////
     stan::math::set_zero_all_adjoints();
     target_AD.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
     target_AD_grad =  Omega_raw_vec_var.adj();    // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
     stan::math::set_zero_all_adjoints();
     //////////////////////////////////////////////////////////// end of AD part



     /////////////  prev stuff  ---- vars
     std::vector<stan::math::var> 	 u_prev_var_vec_var(n_class, 0.0);
     std::vector<stan::math::var> 	 prev_var_vec_var(n_class, 0.0);
     std::vector<stan::math::var> 	 tanh_u_prev_var(n_class, 0.0);
     Eigen::Matrix<stan::math::var, -1, -1>	 prev_var(1, n_class);

     u_prev_var_vec_var[1] =  stan::math::to_var(u_prev_diseased);
     tanh_u_prev_var[1] = ( exp(2*u_prev_var_vec_var[1] ) - 1) / ( exp(2*u_prev_var_vec_var[1] ) + 1) ;
     u_prev_var_vec_var[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1) ) )  ;
     tanh_u_prev_var[0] = (exp(2*u_prev_var_vec_var[0] ) - 1) / ( exp(2*u_prev_var_vec_var[0] ) + 1) ;

     prev_var_vec_var[1] = 0.5 * ( tanh_u_prev_var[1] + 1);
     prev_var_vec_var[0] =  0.5 * ( tanh_u_prev_var[0] + 1);
     prev_var(0,1) =  prev_var_vec_var[1];
     prev_var(0,0) =  prev_var_vec_var[0];

     stan::math::var tanh_pu_deriv_var = ( 1 - tanh_u_prev_var[1] * tanh_u_prev_var[1]  );
     stan::math::var deriv_p_wrt_pu_var = 0.5 *  tanh_pu_deriv_var;
     stan::math::var tanh_pu_second_deriv_var  = -2 * tanh_u_prev_var[1]  * tanh_pu_deriv_var;
     stan::math::var log_jac_p_deriv_wrt_pu_var  = ( 1 / deriv_p_wrt_pu_var) * 0.5 * tanh_pu_second_deriv_var; // for gradient of u's
     stan::math::var  log_jac_p_var =    log( deriv_p_wrt_pu_var );


     stan::math::var  target_AD_prev = beta_lpdf(  prev_var(0,1), prev_prior_a, prev_prior_b  ); // weakly informative prior - helps avoid boundaries with slight negative skew (for lower N)
     target_AD_prev += log_jac_p_var;

     target_AD  +=  target_AD_prev;

     ///////////////////////
     target_AD_prev.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
     grad_prev_AD  =  u_prev_var_vec_var[1].adj() - u_prev_var_vec_var[0].adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
     stan::math::set_zero_all_adjoints();
     //////////////////////////////////////////////////////////// end of AD part




     for (int c = 0; c < n_class; ++c) {
       int cnt_1 = 0;
       for (int k = 0; k < n_tests; k++) {
         for (int l = 0; l < k + 1; l++) {
           (  L_Omega_var_copy[c](k, l)).grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
           int cnt_2 = 0;
           for (int i = 1; i < n_tests; i++) {
             for (int j = 0; j < i; j++) {
               deriv_L_wrt_unc_full[c](cnt_1, cnt_2)  =   Omega_unconstrained_var[c](i, j).adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
               cnt_2 += 1;
             }
           }
           stan::math::set_zero_all_adjoints();
           cnt_1 += 1;
         }
       }
     }


     ///////////////// get cholesky factor's (lower-triangular) of corr matrices
     // convert to 3d var array

     for (int c = 0; c < n_class; ++c) {
       for (int t1 = 0; t1 < n_tests; ++t1) {
         for (int t2 = 0; t2 < n_tests; ++t2) {
           L_Omega_double[c](t1, t2) =   L_Omega_var_copy[c](t1, t2).val()  ;
         }
       }
     }

     stan::math::recover_memory();
   }


   /////////////  prev stuff
   std::vector<double> 	 u_prev_var_vec(n_class, 0.0);
   std::vector<double> 	 prev_var_vec(n_class, 0.0);
   std::vector<double> 	 tanh_u_prev(n_class, 0.0);
   Eigen::Matrix<double, -1, -1>	 prev(1, n_class);

   u_prev_var_vec[1] =  (double) u_prev_diseased ;
   tanh_u_prev[1] = ( exp(2*u_prev_var_vec[1] ) - 1) / ( exp(2*u_prev_var_vec[1] ) + 1) ;
   u_prev_var_vec[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) )  ;
   tanh_u_prev[0] = (exp(2*u_prev_var_vec[0] ) - 1) / ( exp(2*u_prev_var_vec[0] ) + 1) ;

   prev_var_vec[1] = 0.5 * ( tanh_u_prev[1] + 1);
   prev_var_vec[0] =  0.5 * ( tanh_u_prev[0] + 1);
   prev(0,1) =  prev_var_vec[1];
   prev(0,0) =  prev_var_vec[0];


   double tanh_pu_deriv = ( 1 - tanh_u_prev[1] * tanh_u_prev[1]  );
   double deriv_p_wrt_pu_double = 0.5 *  tanh_pu_deriv;
   double tanh_pu_second_deriv  = -2 * tanh_u_prev[1]  * tanh_pu_deriv;
   double log_jac_p_deriv_wrt_pu  = ( 1 / deriv_p_wrt_pu_double) * 0.5 * tanh_pu_second_deriv; // for gradient of u's
   double  log_jac_p =    log( deriv_p_wrt_pu_double );



   ///////////////////////////////////////////////////////////////////////// prior densities
   double prior_densities = 0.0;


   if (exclude_priors == false) {
     ///////////////////// priors for coeffs
     double prior_densities_coeffs = 0.0;
     for (int c = 0; c < n_class; c++) {
       for (int t = 0; t < n_tests; t++) {
         double num_1 = 0.9189385;
         prior_densities_coeffs  +=  - num_1 - log(prior_coeffs_sd(t,c)) - 0.5 * ( (beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) *   ( (beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) )  ;
       }
     }
     double prior_densities_corrs = target_AD.val();
     prior_densities = prior_densities_coeffs  +      prior_densities_corrs ;     // total prior densities and Jacobian adjustments
   }


   /////////////////////////////////////////////////////////////////////////////////////////////////////
   ///////// likelihood
   double s = 1/1.702;
   double sqrt_2_recip = 1 / stan::math::sqrt(2);

   int chunk_counter = 0;
   int chunk_size  = std::round( N / n_chunks  / 2) * 2;  ; // N / n_chunks;


   double log_prob_out = 0.0;


   Eigen::Matrix<double, -1, -1 >  log_prev = prev;

   for (int c = 0; c < n_class; c++) {
     log_prev(0,c) =  log(prev(0,c));
     for (int t = 0; t < n_tests; t++) {
       if (CI == true)      L_Omega_double[c](t,t) = 1;
     }
   }


   ///////////////////////////////////////////////
   Eigen::Matrix<double, -1, 1 >  log_lik   =   Eigen::Matrix<double, -1, 1>::Zero(N);   //////////////////////////////////////////////////
   Eigen::Matrix< double , -1, 1>  beta_grad_vec   =  Eigen::Matrix<double, -1, 1>::Zero(n_coeffs);  //
   Eigen::Matrix<double, -1, -1>   beta_grad_array  =  Eigen::Matrix<double, -1, -1>::Zero(n_class, n_tests); //
   std::vector<Eigen::Matrix<double, -1, -1 > > U_Omega_grad_array =  vec_of_mats_test(n_tests, n_tests, n_class); //
   Eigen::Matrix<double, -1, 1 > L_Omega_grad_vec(n_corrs + (n_class * n_tests)); //
   Eigen::Matrix<double, -1, 1 > U_Omega_grad_vec(n_corrs); //
   Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(n_class); //
   Eigen::Matrix<double, -1, 1>  prev_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(n_class); //
   Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec_out =   Eigen::Matrix<double, -1, 1>::Zero(n_class - 1); //
   // Eigen::Matrix<double, -1, -1, Eigen::RowMajor> u_grad_array_RM   =  Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(N, n_tests);  ////////////////////////////////////////////////
   Eigen::Matrix<double, -1, -1> u_grad_array_CM   =  Eigen::Matrix<double, -1, -1>::Zero(N, n_tests);  ////////////////////////////////////////////////
   ///////////////////////////////////////////////



   double log_prob = 0;

  //  theta_us.head(n_us) =    theta_usarray().tanh() ;
   double log_jac_u  =  0 ; //   (  0.5 *   (1 -  ( theta_usarray()   *  theta_usarray()   ) )   ).log().matrix().sum();


   if (tanh_option == 1) theta_us.array() =      theta_us.array().tanh() ;  // this works
   if (tanh_option == 2) theta_us.array() =      tanh_2_Eigen( theta_us ).array();
   if (tanh_option == 3) theta_us.array() =      fast_tanh_approx_1_Eigen( theta_us ).array();
   if (tanh_option == 4) theta_us.array() =      fast_tanh_approx_2_Eigen( theta_us ).array(); // seems to work  ?!?!
   if (tanh_option == 5) theta_us.array() =      fast_inv_logit_1_Eigen( theta_us.array() ).array();  // inv_logit
   if (tanh_option == 6) theta_us.array() =      stan::math::inv_logit( theta_us  ).array();  // inv_logit


   if   (tanh_option < 5)  log_jac_u  =    (  ( 0.5 *   (  1 -  ( theta_us.array()   *  theta_us.array()   ).array()  ).array()  ).log().array()   ).matrix().sum();
   else                    log_jac_u  =    (   (1 -  theta_us.array())*theta_us.array()  ).log().matrix().sum();




   // ////////////////////////////////////////////////////////////////////////////////////// output vec
   // Eigen::Matrix<double, -1, 1> out_mat    =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N);
   // //////////////////////////////////////////////////////////////////////////////////////


   {



     ///////////////////////////////////////////////
     std::vector<Eigen::Matrix<double, -1, -1 > >  prob   = vec_of_mats_test(chunk_size, n_tests, n_class); //////////////////////////////
     std::vector<Eigen::Matrix<double, -1, -1 > >  Z_std_norm =  vec_of_mats_test(chunk_size, n_tests, n_class); //////////////////////////////
     std::vector<Eigen::Matrix<double, -1, -1 > >  Bound_Z =  vec_of_mats_test(chunk_size, n_tests, n_class); //////////////////////////////
     ///////////////////////////////////////////////



     ///////////////////////////////////////////////
     Eigen::Matrix<int, -1, -1>  y_sign_chunk  =  Eigen::Matrix<int, -1, -1>::Zero(chunk_size, n_tests); /////
     Eigen::Matrix<double, -1, -1>  y_m_ysign_x_u_array =   Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;
     Eigen::Matrix<double, -1, -1> y1_or_phi_Bound_Z =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, -1> phi_Z_or_u_array = Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     ///////////////////////////////////////////////


     ///////////////////////////////////////////////
     Eigen::Matrix<double, -1, 1> prod_container_or_inc_array  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
     Eigen::Matrix<double, -1, 1> prob_n  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
     ///////////////////////////////////////////////


     ///////////////////////////////////////////////
     Eigen::Matrix<double, -1, -1>     common_grad_term_1   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, -1 >    prop_rowwise_prod_temp   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, -1 >    y_sign_chunk_times_phi_Bound_Z   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, -1 >    y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, -1> grad_prob =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, -1> z_grad_term = Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, 1> derivs_chain_container_vec  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
     Eigen::Matrix<double, -1, 1> prop_rowwise_prod_temp_all  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
     ///////////////////////////////////////////////




     //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
     int iiii = 0;
     int iiiiii = 0;
     double sqrt_2_pi_recip =   1 / sqrt(2 * M_PI) ; //  0.3989422804;


     for (int nc = 0; nc < n_chunks; nc++) {

       // fn_wo_list_log_posterior_and_gradient_Chol_Schur_MD_and_AD_1

       int chunk_counter = nc;

       phi_Z_or_u_array.array() = 0.5 * (  theta_us.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).reshaped(chunk_size, n_tests).array() + 1 ).array() ;


       y_sign_chunk.array() =     ( y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array() + (  y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array() - 1).array() ).array() ;
       y_m_ysign_x_u_array.array()  =   ( (  (   y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array()   - y_sign_chunk.array()    *  phi_Z_or_u_array.array()    ).array() ) ) ; //////// checked


       {

         Eigen::Matrix<double, -1, -1>    lp_array  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_class);//////
         Eigen::Matrix<double, -1, -1 >    Phi_Z_temp   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;
         Eigen::Matrix<double, -1, -1 >    Bound_U_Phi_Bound_Z_temp   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);

         for (int c = 0; c < n_class; c++) {

           prod_container_or_inc_array.array()  = 0; // needs to be reset to 0

           for (int t = 0; t < n_tests; t++) {

             Bound_Z[c].col(t).array() =   ( ((  - ( beta_double_array(c, t) +      prod_container_or_inc_array.array()   )  ) / L_Omega_double[c](t, t) )  )  ;


             if (Phi_type == 3) {
               Bound_U_Phi_Bound_Z_temp.col(t).array() =   stan::math::inv_logit(1.702 *  Bound_Z[c].col(t).array() )  ;
             } else if (Phi_type == -1) {
               Bound_U_Phi_Bound_Z_temp.col(t).array() =  0.5 *  ( -  sqrt_2_recip * Bound_Z[c].col(t).array() ).erfc().array()  ; // Phi
             } else if (Phi_type == 1) {
             //   exp_stuff_1[c].col(t).array()      =      ( -  (a*Bound_Z[c].col(t).array()*Bound_Z[c].col(t).array()*Bound_Z[c].col(t).array()  + b*Bound_Z[c].col(t).array()) ).exp() ; // .exp() ;
               Bound_U_Phi_Bound_Z_temp.col(t).array()  =     Phi_approx_1_Eigen(  Bound_Z[c].col(t) ) ;
             }




             Phi_Z_temp.col(t).array()    =  (   y.col(t).segment(chunk_size * chunk_counter, chunk_size).array()  *       Bound_U_Phi_Bound_Z_temp.col(t).array() +
                                             (  y.col(t).segment(chunk_size * chunk_counter, chunk_size).array()  -   Bound_U_Phi_Bound_Z_temp.col(t).array() ) * y_sign_chunk.col(t).array() * phi_Z_or_u_array.col(t).array()  ).array()   ;  //////// checked


             if (Phi_type == 3) {
               Z_std_norm[c].col(t).array() =    stan::math::logit(     Phi_Z_temp.col(t) ).array() / 1.702  ; //  Eigen::Select(     stan::math::abs(Bound_Z[c].col(t).array()) < ub_threshold_phi_approx ,
             } else if (Phi_type == -1) {
               Z_std_norm[c].col(t).array() =  qnorm_rcpp_vec(  Phi_Z_temp.col(t)).array()  ;
             } else if (Phi_type == 1) {
               Z_std_norm[c].col(t).array() =  qnorm_rcpp_vec(     Phi_Z_temp.col(t) ).array()  ;  // standard Phi
             //   exp_stuff_2[c].col(t).array()     =        ( -  (a*Z_std_norm[c].col(t).array()*Z_std_norm[c].col(t).array()*Z_std_norm[c].col(t).array()  + b*Z_std_norm[c].col(t).array()) ).exp() ;
             }


             if (t < n_tests - 1)       prod_container_or_inc_array.array()  =   ( Z_std_norm[c].block(0, 0, chunk_size, t + 1)  *   ( L_Omega_double[c].row(t+1).head(t+1).transpose()  ) ) ; //////// checked

           } // end of t loop


           y1_or_phi_Bound_Z.array() =   (  y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array() * ( 1 - Bound_U_Phi_Bound_Z_temp.array() ) +
                                         (  y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array() - 1  ).array()   * Bound_U_Phi_Bound_Z_temp.array() * y_sign_chunk.array() ).array().log() ;


           lp_array.col(c).array() =    y1_or_phi_Bound_Z.rowwise().sum().array() +  log_prev(0,c) ;

           prob[c] =   y1_or_phi_Bound_Z.array().exp();

         } // end of c loop

         log_lik.segment(chunk_size * chunk_counter, chunk_size).array()   = (  lp_array.array().maxCoeff() + (lp_array.array() - lp_array.array().maxCoeff() ).array().exp().rowwise().sum().array().log() )  ; // correct & stable
         prob_n =   log_lik.segment(chunk_size * chunk_counter, chunk_size).array().exp().matrix(); // correct & stable

       }


       //  #pragma omp critical

       {


         //  #pragma omp parallel for   num_threads(n_cores)    schedule(auto)
         for (int c = 0; c < n_class; c++) {

           for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
             int t = n_tests - (i+1) ;
             prop_rowwise_prod_temp.col(t).array()   =   prob[c].block(0, t + 0, chunk_size, i + 1).rowwise().prod().array() ;
           }

           prop_rowwise_prod_temp_all.array() = prob[c].block(0, 0, chunk_size, n_tests).rowwise().prod().array()  ;



           for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
             int t = n_tests - (i + 1) ;
             common_grad_term_1.col(t) =   (  ( prev(0,c) / prob_n.array() ) * ( prop_rowwise_prod_temp_all.array() /  prop_rowwise_prod_temp.col(t).array()  ).array() )  ;
           }
           if (Phi_type == 3) {
             phi_Z_or_u_array.array() =                 1.702 * (1 / stan::math::square( stan::math::exp(Z_std_norm[c] *  (1/(2*s)) ) + stan::math::exp( - Z_std_norm[c] *  (1/(2*s)) ) ).array()  )  ;
             y1_or_phi_Bound_Z.array() =                1.702 * (1 / stan::math::square( stan::math::exp(Bound_Z[c] *  (1/(2*s)) )    + stan::math::exp( - Bound_Z[c] *  (1/(2*s)) ) ).array()  ) ;
           } else if (Phi_type == -1) { // standard Phi
             phi_Z_or_u_array.array()  =       (  sqrt_2_pi_recip *  ( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).exp().array()  ) ;
             y1_or_phi_Bound_Z.array() =       sqrt_2_pi_recip *  ( - 0.5 * Bound_Z[c].array()    *  Bound_Z[c].array()    ).exp().array() ;
           } else if (Phi_type == 1) { // standard Phi
             phi_Z_or_u_array.array()  =       sqrt_2_pi_recip *  ( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).exp().array() ;
             y1_or_phi_Bound_Z.array() =       sqrt_2_pi_recip *  ( - 0.5 * Bound_Z[c].array()    *  Bound_Z[c].array()    ).exp().array() ;
           }


           y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.array() =   y_m_ysign_x_u_array.array() * ( 1 /  phi_Z_or_u_array.array() ).array()  * y1_or_phi_Bound_Z.array() ;
           y_sign_chunk_times_phi_Bound_Z.array() =  y_sign_chunk.array() * y1_or_phi_Bound_Z.array() ;


           ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grad of nuisance parameters / u's (manual)
           u_grad_array_CM.col(n_tests - 1).segment( chunk_size * chunk_counter, chunk_size).array() +=  0;

           ///// then second-to-last term (test T - 1)
           int t = n_tests - 1;


           u_grad_array_CM.col(n_tests - 2).segment( chunk_size * chunk_counter, chunk_size).array()  +=  (  common_grad_term_1.col(t).array()  * (y_sign_chunk_times_phi_Bound_Z.col(t).array()   * (1 / L_Omega_double[c](t,t)  ) *
                                                      L_Omega_double[c](t,t - 1) * ( 1 /phi_Z_or_u_array.col(t-1).array() )  * prob[c].col(t-1).array()) ).array();


             { ///// then third-to-last term (test T - 2)
               t = n_tests - 2;

               z_grad_term.col(0) = (1 / phi_Z_or_u_array.col(t-1).array())  * prob[c].col(t-1).array() ;
               grad_prob.col(0) =        y_sign_chunk_times_phi_Bound_Z.col(t).array() * (1 / L_Omega_double[c](t,t)  ) *     L_Omega_double[c](t, t - 1) *   z_grad_term.col(0).array() ; // lp(T-1) - part 2;
               z_grad_term.col(1).array()  =  (1 / L_Omega_double[c](t,t))  * L_Omega_double[c](t,t-1) *   z_grad_term.col(0).array() *       y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t).array() ;

               grad_prob.col(1)  =         (   y_sign_chunk_times_phi_Bound_Z.col(t+1).array()  *  (1 / L_Omega_double[c](t+1,t+1)  ) ) *  (  z_grad_term.col(0).array() *  L_Omega_double[c](t + 1,t - 1)  -   z_grad_term.col(1).array()  * L_Omega_double[c](t+1,t)) ;

               u_grad_array_CM.col(n_tests - 3).segment( chunk_size * chunk_counter, chunk_size).array()  +=  common_grad_term_1.col(t).array()   *  (  grad_prob.col(1).array() * prob[c].col(t).array()  +      grad_prob.col(0).array() *  prob[c].col(t+1).array()  );  // ----------   correct
             }



             // then rest of terms
             for (int i = 1; i < n_tests - 2; i++) { // i goes from 1 to 3


               grad_prob.array() = 0;
               z_grad_term.array() = 0;

               int t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)

               z_grad_term.col(0) = (1 / phi_Z_or_u_array.col(t-1).array())  * prob[c].col(t-1).array() ;

               grad_prob.col(0) =         y_sign_chunk_times_phi_Bound_Z.col(t).array() * (1 / L_Omega_double[c](t,t)  ) *   L_Omega_double[c](t, t - 1) *   z_grad_term.col(0).array() ; // lp(T-1) - part 2;

               for (int ii = 0; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1 u_grad_z u_grad_term
                 if (ii == 0)    prod_container_or_inc_array  = (   (z_grad_term.block(0, 0, chunk_size, ii + 1) ) *  (fn_first_element_neg_rest_pos(L_Omega_double[c].row( t + (ii-1) + 1).segment(t - 1, ii + 1))).transpose()  )      ;
                 //   z_grad_term.col(ii+1)  =  (1 /phi_Z_or_u_array.col( t+(ii-1)+1).array() ).array() * y1_or_phi_Bound_Z.col(t+(ii-1)+1).array() * (1 / L_Omega_double[c](t+(ii-1)+1,t+(ii-1)+1))   *   y_m_ysign_x_u_array.col(t + ii).array() *  -   prod_container_or_inc_array.array() ;
                 z_grad_term.col(ii+1)  =     (1 / L_Omega_double[c](t+(ii-1)+1,t+(ii-1)+1))   *   y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t + ii).array() *  -   prod_container_or_inc_array.array() ;
                 prod_container_or_inc_array  = (   (z_grad_term.block(0, 0, chunk_size, ii + 2) ) *  (fn_first_element_neg_rest_pos(L_Omega_double[c].row( t + (ii) + 1).segment(t - 1, ii + 2))).transpose()  )      ;
                 grad_prob.col(ii+1)  =       (    y_sign_chunk_times_phi_Bound_Z.col(t+ii+1).array() *  (1 / L_Omega_double[c](t+ii+1,t+ii+1)  )) *     -    prod_container_or_inc_array.array()  ;
               } // end of ii loop

               {
                 derivs_chain_container_vec.array() = 0;

                 for (int ii = 0; ii < i + 2; ii++) {
                   derivs_chain_container_vec.array()  +=  ( grad_prob.col(ii).array()    * (       prop_rowwise_prod_temp.col(t).array() /  prob[c].col(t + ii).array()  ).array() ).array()  ;
                 }
                 u_grad_array_CM.col(n_tests - (i+3)).segment( chunk_size * chunk_counter, chunk_size).array()    +=   (  ( (   common_grad_term_1.col(t).array()   *  derivs_chain_container_vec.array() ) ).array()  ).array() ;
               }

             }



             // /////////////////////////////////////////////////////////////////////////// Grad of intercepts / coefficients (beta's)
             // ///// last term first (test T)

             {

               int t = n_tests - 1;

               beta_grad_array(c, t) +=     (common_grad_term_1.col(t).array()  *   ( - y_sign_chunk_times_phi_Bound_Z.col(t).array()    * ( - 1 / L_Omega_double[c](t,t)  ))).sum();

               ///// then second-to-last term (test T - 1)
               {
                 t = n_tests - 2;
                 grad_prob.col(0) =       (   -  y_sign_chunk_times_phi_Bound_Z.col(t).array() * (- 1 / L_Omega_double[c](t,t)  ) ) ;
                 z_grad_term.col(1)   =      y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t).array()   * (- 1 / L_Omega_double[c](t,t))     ;
                 grad_prob.col(1)  =       ( - y_sign_chunk_times_phi_Bound_Z.col(t+1).array()    ) *  (     (- 1 / L_Omega_double[c](t+1,t+1)  ) ) * (   L_Omega_double[c](t + 1,t) *      z_grad_term.col(1).array() ) ;
                 beta_grad_array(c, t) +=  (common_grad_term_1.col(t).array()   * ( grad_prob.col(1).array() * prob[c].col(t).array() +         grad_prob.col(0).array() *  prob[c].col(t+1).array() ) ).sum() ;
               }

               // then rest of terms
               for (int i = 1; i < n_tests - 1; i++) { // i goes from 1 to 3

                 t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)

                 grad_prob.col(0)  =    ( ( - y_sign_chunk_times_phi_Bound_Z.col(t).array()  )     * (- 1 / L_Omega_double[c](t,t)  ) ) ;


                 // component 2 (second-to-earliest test)
                 z_grad_term.col(1)  =        y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t).array()    * (- 1 / L_Omega_double[c](t,t))    ;
                 grad_prob.col(1) =        - y_sign_chunk_times_phi_Bound_Z.col(t + 1).array()   * (    (- 1 / L_Omega_double[c](t+1,t+1)  ) ) *    (   L_Omega_double[c](t + 1,t) *   z_grad_term.col(1).array() ) ;

                 // rest of components
                 for (int ii = 1; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1
                   if (ii == 1)  prod_container_or_inc_array  = (    z_grad_term.block(0, 1, chunk_size, ii)  *   L_Omega_double[c].row( t + (ii - 1) + 1).segment(t + 0, ii + 0).transpose()  );
                   z_grad_term.col(ii+1)  =        y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t + ii).array()  * (- 1 / L_Omega_double[c](t+(ii-1)+1,t+(ii-1)+1))  *   prod_container_or_inc_array.array();
                   prod_container_or_inc_array  = (    z_grad_term.block(0, 1, chunk_size, ii + 1)  *   L_Omega_double[c].row( t + (ii) + 1).segment(t + 0, ii + 1).transpose()  );
                   //  prod_container_or_inc_array  = (  L_Omega_double[c].row( t + (ii) + 1).segment(t + 0, ii + 1) *   z_grad_term.block(0, 1, chunk_size, ii + 1).transpose()  ).transpose();
                   grad_prob.col(ii+1) =      (  - y_sign_chunk_times_phi_Bound_Z.col(t + ii + 1).array()  ).array() *   (    (- 1 / L_Omega_double[c](t+ii+1,t+ii+1)  ) )    *  prod_container_or_inc_array.array();

                 }

                 {

                   derivs_chain_container_vec.array() = 0;

                   ///// attempt at vectorising  // bookmark
                   for (int ii = 0; ii < i + 2; ii++) {
                     derivs_chain_container_vec.array() +=  ( grad_prob.col(ii).array()  * (      prop_rowwise_prod_temp.col(t).array() /  prob[c].col(t + ii).array()  ).array() ).array() ;
                   }
                   beta_grad_array(c, t) +=        ( common_grad_term_1.col(t).array()   *  derivs_chain_container_vec.array() ).sum();
                 }

               }

             }



             ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grad of L_Omega ('s)


             {


               {
                 ///////////////////////// deriv of diagonal elements (not needed if using the "standard" or "Stan" Cholesky parameterisation of Omega)

                 //////// w.r.t last diagonal first
                 {
                   int  t1 = n_tests - 1;

                   U_Omega_grad_array[c](t1, t1) +=   ( ( common_grad_term_1.col(t1).array()   *    -  y_sign_chunk_times_phi_Bound_Z.col(t1).array() ).array() *
                     (  Bound_Z[c].col(t1).array() * L_Omega_double[c](t1,t1) *  - ( 1 / ( L_Omega_double[c](t1,t1)  *  L_Omega_double[c](t1,t1) ) )    )   ).sum() ;
                 }


                 //////// then w.r.t the second-to-last diagonal
                 int  t1 = n_tests - 2;

                 double deriv_L_Omega_Tm1_Tm1_inv =    - stan::math::pow( L_Omega_double[c](t1, t1), -2) ;

                 //  grad_bound_z.array() =    (   ( Bound_Z[c].col(t1).array()  *  L_Omega_double[c](t1, t1) )  *  (   deriv_L_Omega_Tm1_Tm1_inv    )  )    ; //  check (standard form, but varies depending on gradient)
                 grad_prob.col(0).array()  =  (   - y_sign_chunk_times_phi_Bound_Z.col(t1).array()  *   (   (  (   ( Bound_Z[c].col(t1).array()  *  L_Omega_double[c](t1, t1) )  *  (   deriv_L_Omega_Tm1_Tm1_inv    )  )  .array() )  )  )  ;     // correct  (standard form)


                 z_grad_term.col(0).array()  =      (  ( (  y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t1).array()   ).array()     *  (   ( Bound_Z[c].col(t1).array()  *  L_Omega_double[c](t1, t1) )  *  (   deriv_L_Omega_Tm1_Tm1_inv    )  ).array()  ).array() )   ;  // correct

                 prod_container_or_inc_array.array()  =   (  L_Omega_double[c](t1 + 1, t1)    *   z_grad_term.col(0).array()   ) ; // sequence
                 // grad_bound_z.array() =   (   ( - 1 /  L_Omega_double[c](t1 + 1, t1 + 1) ) *  prod_container_or_inc_array.array()   )   ;  // correct  (standard form)
                 grad_prob.col(1).array()  =   (  - y_sign_chunk_times_phi_Bound_Z.col(t1 + 1).array()   *     (   (   (   ( - 1 /  L_Omega_double[c](t1 + 1, t1 + 1) ) *  prod_container_or_inc_array.array()   ) .array()   ) )  ).array()  ;    // correct   (standard form)

                 U_Omega_grad_array[c](t1, t1) +=   ( (   common_grad_term_1.col(t1).array() )     *    ( prob[c].col(t1 + 1).array()  *   grad_prob.col(0).array()  +   prob[c].col(t1).array()  *      grad_prob.col(1).array()   )  ).sum()   ;

               }



               // //////// then w.r.t the third-to-last diagonal .... etc
               {

                 for (int i = 3; i < n_tests + 1; i++) {

                   int  t1 = n_tests - i;

                   //////// 1st component
                   // 1st grad_Z term and 1st grad_prob term (simplest terms)
                   // grad_bound_z.array()  =   ( Bound_Z[c].col(t1).array()  *  ( - 1 / L_Omega_double[c](t1, t1)  ) ).array() ; //  check (standard form, but varies depending on gradient)
                   grad_prob.col(0).array()  =   ( - y_sign_chunk_times_phi_Bound_Z.col(t1).array() )  *  ( Bound_Z[c].col(t1).array()  *  ( - 1 / L_Omega_double[c](t1, t1)  ) ).array()  ; // correct  (standard form)

                   z_grad_term.col(0).array()  =    y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t1).array()   *  ( Bound_Z[c].col(t1).array()  *  ( - 1 / L_Omega_double[c](t1, t1)  ) ).array()   ;   // correct  (standard form)

                   // 2nd   grad_Z term and 2nd grad_prob  (more complicated than 1st term)
                   prod_container_or_inc_array.array() =    L_Omega_double[c](t1 + 1, t1)   * z_grad_term.col(0).array()  ; // correct  (standard form)
                   //   grad_bound_z.array()  =  (  ( - 1 / L_Omega_double[c](t1 + 1, t1 + 1) ) * prod_container_or_inc_array.array() )  ;  // correct  (standard form)
                   grad_prob.col(1).array()  =   ( - y_sign_chunk_times_phi_Bound_Z.col(t1 + 1).array()  )   *  (  ( - 1 / L_Omega_double[c](t1 + 1, t1 + 1) ) * prod_container_or_inc_array.array() ).array()  ; // correct  (standard form)


                   for (int ii = 1; ii < i - 1; ii++) {
                     z_grad_term.col(ii).array()  =    y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t1 + ii).array()     *   ( ( - 1 / L_Omega_double[c](t1 + ii + 1, t1 + ii + 1)  ) * prod_container_or_inc_array.array() ).array()  ;   // correct  (standard form)       // grad_z term
                     prod_container_or_inc_array.matrix() =   (  L_Omega_double[c].row(t1 + ii + 1).segment(t1, ii + 1) *   z_grad_term.block(0, 0, chunk_size, ii + 1).transpose() ).transpose().matrix(); // correct  (standard form)
                     // grad_bound_z.array()  =  ( ( - 1 / L_Omega_double[c](t1 + ii + 1, t1 + ii + 1)  ) * prod_container_or_inc_array.array() ) ; // correct  (standard form)
                     grad_prob.col(ii + 1).array()  =   ( - y_sign_chunk_times_phi_Bound_Z.col(t1 + ii + 1).array()  )   *   ( ( - 1 / L_Omega_double[c](t1 + ii + 1, t1 + ii + 1)  ) * prod_container_or_inc_array.array() ).array() ;  // correct  (standard form)     //    grad_prob term
                   }

                   {

                     derivs_chain_container_vec.array() = 0;

                     ///// attempt at vectorising  // bookmark
                     for (int iii = 0; iii <  i; iii++) {
                       derivs_chain_container_vec.array()  +=    grad_prob.col(iii).array()  * (       prop_rowwise_prod_temp.col(t1).array()    /  prob[c].col(t1 + iii).array()  ).array()  ;  // correct  (standard form)
                     }

                     U_Omega_grad_array[c](t1, t1)   +=       ( common_grad_term_1.col(t1).array()   * derivs_chain_container_vec.array() ).sum()  ; // correct  (standard form)
                   }

                 }



               }

             }




             {

               { ///////////////////// last row first
                 int t1_dash = 0;  // t1 = n_tests - 1

                 int t1 = n_tests - (t1_dash + 1); //  starts at n_tests - 1;  // if t1_dash = 0 -> t1 = T - 1
                 int t2 = n_tests - (t1_dash + 2); //  starts at n_tests - 2;

                 U_Omega_grad_array[c](t1,t2) +=      ( ( common_grad_term_1.col(t1).array()      * - y_sign_chunk_times_phi_Bound_Z.col(t1).array() ).array() *   (    (1 / L_Omega_double[c](t1,t1)  ) * (-  Z_std_norm[c].col(t2).array()  )   ).array() ).sum() ;

                 if (t1 > 1) { // starts at  L_{T, T-2}
                   {
                     t2 =   n_tests - (t1_dash + 3); // starts at n_tests - 3;
                     U_Omega_grad_array[c](t1,t2) +=     (  common_grad_term_1.col(t1).array()  *   (  - y_sign_chunk_times_phi_Bound_Z.col(t1).array()  ).array()  *   ( (  (1 / L_Omega_double[c](t1,t1) ) *  ( - Z_std_norm[c].col(t2).array() )  ).array() ) ).sum()  ;
                   }
                 }

                 if (t1 > 2) {// starts at  L_{T, T-3}
                   for (int t2_dash = 3; t2_dash < n_tests; t2_dash++ ) { // t2 < t1
                     t2 = n_tests - (t1_dash + t2_dash + 1); // starts at T - 4
                     if (t2 < n_tests - 1) {
                       U_Omega_grad_array[c](t1,t2)  +=   (common_grad_term_1.col(t1).array() *   (  - y_sign_chunk_times_phi_Bound_Z.col(t1).array() ).array() * ( (  ( 1 / L_Omega_double[c](t1,t1) ) * - Z_std_norm[c].col(t2).array()  ) ).array()).sum() ;
                     }
                   }
                 }
               }
             }




             {
               /////////////////// then rest of rows (second-to-last row, then third-to-last row, .... , then first row)
               for (int t1_dash = 1; t1_dash <  n_tests - 1;  t1_dash++) {
                 int  t1 = n_tests - (t1_dash + 1);

                 for (int t2_dash = t1_dash + 1; t2_dash <  n_tests;  t2_dash++) {
                   int t2 = n_tests - (t2_dash + 1); // starts at t1 - 1, then t1 - 2, up to 0


                   {


                     //prod_container_or_inc_array.array()  =  Z_std_norm[c].block(0, t2, chunk_size, t1 - t2) * deriv_L_t1.head(t1 - t2) ;
                     prod_container_or_inc_array.array()  =  Z_std_norm[c].col(t2) ; // block(0, t2, chunk_size, t1 - t2) * deriv_L_t1.head(t1 - t2) ;
                     grad_prob.col(0) =      (( -  y_sign_chunk_times_phi_Bound_Z.col(t1).array()   ).array() *   (      ( ( 1/L_Omega_double[c](t1,t1) ) *  -    prod_container_or_inc_array.array() ) ).array())  ;


                     z_grad_term.col(0).array()  =               ( (  y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t1).array()    ).array()   ).array()  *
                       ( (   ( ( 1 / L_Omega_double[c](t1,t1) ) *   -    prod_container_or_inc_array.array()     ).array()  )   ).array()  ;

                     if (t1_dash > 0) {
                       for (int t1_dash_dash = 1; t1_dash_dash <  t1_dash + 1;  t1_dash_dash++) {
                         if (t1_dash_dash > 1) {
                           z_grad_term.col(t1_dash_dash - 1)   =           (  (  y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t1 + t1_dash_dash - 1).array()    ).array()   *
                             ( 1/L_Omega_double[c](t1+t1_dash_dash - 1,t1+t1_dash_dash - 1) ) ).array()  *  ( - prod_container_or_inc_array.array() )    ;
                         }
                         prod_container_or_inc_array.array()  =            (   z_grad_term.block(0, 0, chunk_size, t1_dash_dash) *   L_Omega_double[c].row(t1 + t1_dash_dash).segment(t1, t1_dash_dash).transpose()   ) ;
                         grad_prob.col(t1_dash_dash)  =            (  ( ( -  y_sign_chunk_times_phi_Bound_Z.col(t1 + t1_dash_dash).array()     ).array() ) *
                           ( 1 / L_Omega_double[c](t1+t1_dash_dash,t1+t1_dash_dash) )  *    (  -    prod_container_or_inc_array).array()  ) ;
                       }
                     }

                     {

                       derivs_chain_container_vec.array() = 0;

                       ///// attempt at vectorising  // bookmark
                       for (int ii = 0; ii <  t1_dash + 1; ii++) {
                         derivs_chain_container_vec.array() += ( grad_prob.col(ii).array()  * ( prop_rowwise_prod_temp.col(t1).array()     /  prob[c].col(t1 + ii).array()  ).array() ).array() ; // correct i think
                       }
                       U_Omega_grad_array[c](t1, t2)   +=       ( common_grad_term_1.col(t1).array()   * derivs_chain_container_vec.array() ).sum()  ; // correct  (standard form)

                     }



                   }
                 }
               }

             }


             prev_grad_vec(c)  +=  ( ( 1 / prob_n.array() ) * prob[c].rowwise().prod().array() ).matrix().sum()  ;




         } // end of c loop

       }



     }  // end of chunk loop





     //////////////////////// gradients for latent class membership probabilitie(s) (i.e. disease prevalence)
     for (int c = 0; c < n_class; c++) {
       prev_unconstrained_grad_vec(c)  =   prev_grad_vec(c)   * deriv_p_wrt_pu_double ;
     }
     prev_unconstrained_grad_vec(0) = prev_unconstrained_grad_vec(1) - prev_unconstrained_grad_vec(0) - 2 * tanh_u_prev[1];
     prev_unconstrained_grad_vec_out(0) = prev_unconstrained_grad_vec(0);


     log_prob_out += log_lik.sum();

     if (exclude_priors == false)  log_prob_out += prior_densities;

     log_prob_out +=  log_jac_u;

     log_prob = (double) log_prob_out;

     int i = 0; // probs_all_range.prod() cancels out
     for (int c = 0; c < n_class; c++) {
       for (int t = 0; t < n_tests; t++) {
         if (exclude_priors == false) {
           beta_grad_array(c, t) +=  - ((beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) * (1/ prior_coeffs_sd(t,c) ) ;     // add normal prior density derivative to gradient
         }
         beta_grad_vec(i) = beta_grad_array(c, t);
         i += 1;
       }
     }




     {
       int i = 0;
       for (int c = 0; c < n_class; c++ ) {
         for (int t1 = 0; t1 < n_tests; t1++ ) {
           for (int t2 = 0; t2 < t1 + 1; t2++ ) {
             L_Omega_grad_vec(i) = U_Omega_grad_array[c](t1,t2);
             i += 1;
           }
         }
       }
     }



     Eigen::Matrix<double, -1, 1>  grad_wrt_L_Omega_nd =   L_Omega_grad_vec.segment(0, dim_choose_2 + n_tests);
     Eigen::Matrix<double, -1, 1>  grad_wrt_L_Omega_d =   L_Omega_grad_vec.segment(dim_choose_2 + n_tests, dim_choose_2 + n_tests);

     U_Omega_grad_vec.segment(0, dim_choose_2) =  ( grad_wrt_L_Omega_nd.transpose()  *  deriv_L_wrt_unc_full[0].cast<double>() ).transpose() ;
     U_Omega_grad_vec.segment(dim_choose_2, dim_choose_2) =   ( grad_wrt_L_Omega_d.transpose()  *  deriv_L_wrt_unc_full[1].cast<double>() ).transpose()  ;





   }

   ////////////////////////////////////////////////////////////////////////////////////// output vec
   Eigen::Matrix<double, -1, 1> out_mat    =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N);
   //////////////////////////////////////////////////////////////////////////////////////


   {


     // out_mat.segment(1, n_us).array() =    u_grad_array_RM.reshaped<RowMajor>()      ;

     for (int nc = 0; nc < n_chunks; nc++) {

       int chunk_counter = nc;
       out_mat.segment(1, n_us).segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)  =    u_grad_array_CM.block(chunk_size * chunk_counter, 0, chunk_size, n_tests).reshaped()     ;

     }

   }





   ////////////////////////////  outputs
   out_mat(0) = log_prob;

   out_mat.segment(1 + n_us, n_corrs) = target_AD_grad.cast<double>();
   out_mat.segment(1 + n_us, n_corrs) += U_Omega_grad_vec  ;
   out_mat.segment(1 + n_us + n_corrs, n_coeffs) = beta_grad_vec ;
   out_mat(n_params) = grad_prev_AD +  prev_unconstrained_grad_vec_out(0);

   // out_mat.segment(1, n_us).array() =     out_mat.segment(1, n_us).array() *  ( 0.5 * (1 - theta_us.head(n_us).array() * theta_us.head(n_us).array()  )  ) - 2 * theta_us.head(n_us).array()   ;

   if   (tanh_option < 5)  out_mat.segment(1, n_us).array() =     ( out_mat.segment(1, n_us).array() *  ( 0.5 * (1 - theta_us.head(n_us).array() * theta_us.head(n_us).array()  )  )   ).array()    - 2 * theta_us.head(n_us).array()   ;
   else                    out_mat.segment(1, n_us).array() =     (  out_mat.segment(1, n_us).array() *  (  (   (1 -  theta_us.array())*theta_us.array()  ) ) ).array()     - 1 ;  // inverse logit
   //
   out_mat.segment( 1 + n_params, N) = log_lik ;

   return(out_mat);

 }



 //
 //

 
 
 
 
 
 
 
 
 
 // [[Rcpp::export]]
 float fastlog2 (float x)
 {
   union { float f; uint32_t i; } vx = { x };
   union { uint32_t i; float f; } mx = { (vx.i & 0x007FFFFF) | (0x7e << 23) };
   float y = vx.i;
   y *= 1.0 / (1 << 23);
   
   return  y - 124.22544637f - 1.498030302f * mx.f - 1.72587999f / (0.3520887068f + mx.f);
 }
 
 
 
 
 
 // [[Rcpp::export]]
 double fast_log_1_float (double x)
 {
   return 0.69314718f * fastlog2(x);
 }
 
 
 
 
 
 
 
 // [[Rcpp::export]]
 Eigen::Array<double, -1, 1>    fast_log_1_Eigen(   Eigen::Array<double, -1, 1 >  x  )   { 
   
   
   for (int i = 0; i <  x.rows(); i++) {
     x(i) = fast_log_1_float(x(i)) ; 
   }
   
   return  x;
   
 }
 
 // [[Rcpp::export]]
 Eigen::Array<double, 1, -1>    fast_log_1_Eigen_rowvec(   Eigen::Array<double, 1, -1 >  x  )   { 
   
   
   for (int i = 0; i <  x.cols(); i++) {
     x(i) = fast_log_1_float(x(i)) ; 
   }
   
   return  x;
   
 }
 
 
 
 // [[Rcpp::export]]
 Eigen::Array<double, -1, -1>    fast_log_1_Eigen_mat(   Eigen::Array<double, -1, -1 >  x  )   { 
   
   for (int j = 0; j <  x.cols(); j++) {
     for (int i = 0; i <  x.rows(); i++) {
       x(i, j) = fast_log_1_float(x(i, j)) ; 
   }
   }
   
   return  x;
   
 }
 
 // // [[Rcpp:
 
 

 Eigen::Array<double, -1, -1>    fast_log_1_Eigen_mat_RM(   Eigen::Array<double, -1, -1  >  x  )   {

   for (int i = 0; i <  x.rows(); i++) {
      for (int j = 0; j <  x.cols(); j++) {
       x(i, j) = fast_log_1_float(x(i, j)) ;
     }
   }

   return  x;

 }

 // 
 // 
 
 
 
 
 
 
 // [[Rcpp::export]]
 double    fast_arcsinh_approx_1_double( double  x  )   { 
   
   return  fast_log_1_float(x + sqrt(1.0 + (x*x))) ; 
   
 }
 
 
 
 
 // [[Rcpp::export]]
 Eigen::Array<double, -1, 1>    fast_arcsinh_approx_1_Eigen(   Eigen::Array<double, -1, 1 >  x  )   { 
   
   
   for (int i = 0; i <  x.rows(); i++) {
     
     double x_i = x(i) ; 
     x(i) = fast_log_1_float(x_i + sqrt(1.0 + (x_i*x_i))) ; 
     
   }
   
   return  x;
   
 }
 
 
 // [[Rcpp::export]]
 double     arcsinh_approx_1_double( double  x  )   { 
   
   return  log(x + sqrt(1.0 + (x*x))) ; 
   
 }
 
 
 
 
 // [[Rcpp::export]]
 Eigen::Array<double, -1, 1>     arcsinh_approx_1_Eigen(   Eigen::Array<double, -1, 1 >  x  )   { 
   
   
   for (int i = 0; i <  x.rows(); i++) {
     
     double x_i = x(i) ; 
     x(i) = log(x_i + sqrt(1.0 + (x_i*x_i))) ; 
     
   }
   
   return  x;
   
 }
 
 
 
 
 
 // [[Rcpp::export]]
 double    sinh_approx_1_double(  double  x  )   { 
   
   
   double exp_x_i = exp(x); 
   double exp_2x_i = exp_x_i*exp_x_i;
   
   return  (exp_2x_i - 1.0)/(2.0*exp_x_i) ; 
   
 }
 
 
 
 // [[Rcpp::export]]
 Eigen::Array<double, -1, 1>    sinh_approx_1_Eigen(   Eigen::Array<double, -1, 1 >  x  )   { 
   
   
   for (int i = 0; i <  x.rows(); i++) {
     
     double exp_x_i = exp( x(i) ); 
     double exp_2x_i = exp_x_i*exp_x_i;
     
     x(i) =  (exp_2x_i - 1.0)/(2.0*exp_x_i) ; 
     
   }
   
   return  x;
   
 }
 
 
 
 
 // [[Rcpp::export]]
 double    fast_sinh_approx_1_double(  double  x  )   { 
   
   
   double exp_x_i = fast_exp_1_double(x); 
   double exp_2x_i = exp_x_i*exp_x_i;
   
   return  (exp_2x_i - 1.0)/(2.0*exp_x_i) ; 
   
 }
 
 
 
 // [[Rcpp::export]]
 Eigen::Array<double, -1, 1>    fast_sinh_approx_1_Eigen(   Eigen::Array<double, -1, 1 >  x  )   { 
   
   
   for (int i = 0; i <  x.rows(); i++) {
     
     double exp_x_i = fast_exp_1_double( x(i) ); 
     double exp_2x_i = exp_x_i*exp_x_i;
     
     x(i) =  (exp_2x_i - 1.0)/(2.0*exp_x_i) ; 
     
   }
   
   return  x;
   
 }
 
 
 
 
 
 
 
 
 // [[Rcpp::export]]
 Eigen::Array<double, -1, 1>    inv_Phi_approx_1_Eigen(   Eigen::Array<double, -1, 1 >  p  )   { 
   
   for (int i = 0; i <  p.rows(); i++) {
     p(i) =  5.494 * sinh_approx_1_double(arcsinh_approx_1_double(-0.3418*log(1.0/p(i)-1.0))/3.0) ; 
   }
   
   return  p;
   
 }
 
 
 // // [[Rcpp::export]]
 // Eigen::Array<double, 1, -1>    inv_Phi_approx_1_Eigen_rowvec(   Eigen::Array<double, 1, -1 >  p  )   {
 // 
 //   for (int i = 0; i <  p.cols(); i++) {
 //     p(i) =  5.494 * sinh_approx_1_double(arcsinh_approx_1_double(-0.3418*log(1/p(i)-1))/3) ;
 //   }
 // 
 //   return  p;
 // 
 // }
 // 
 
 
 
 // [[Rcpp::export]]
 Eigen::Array<double, -1, 1>    fast_inv_Phi_approx_1_Eigen(   Eigen::Array<double, -1, 1 >  p  )   { 
   
   for (int i = 0; i <  p.rows(); i++) {
     p(i) =  5.494 * fast_sinh_approx_1_double(fast_arcsinh_approx_1_double(-0.3418*fast_log_1_float(1.0/p(i)-1.0))/3.0) ; 
   }
   
   return  p;
   
 }
 
 // [[Rcpp::export]]
 Eigen::Array<double, 1, -1>    fast_inv_Phi_approx_1_Eigen_rowvec(   Eigen::Array<double, 1, -1 >  p  )   {

   for (int i = 0; i <  p.cols(); i++) {
     p(i) =  5.494 * fast_sinh_approx_1_double(fast_arcsinh_approx_1_double(-0.3418*fast_log_1_float(1.0/p(i)-1.0))/3.0) ;
   }

   return  p;

 }

 // 
 
 
 
 
 // [[Rcpp::export]]
 double  qnorm_w_fastlog_rcpp(double p) {
   
   double r;
   double val;
   double q = p - 0.5;
   
   if (abs(q) <= .425) {
     r = .180625 - q * q;
     val = q * (((((((r * 2509.0809287301226727 +
       33430.575583588128105) * r + 67265.770927008700853) * r +
       45921.953931549871457) * r + 13731.693765509461125) * r +
       1971.5909503065514427) * r + 133.14166789178437745) * r +
       3.387132872796366608) / (((((((r * 5226.495278852854561 +
       28729.085735721942674) * r + 39307.89580009271061) * r +
       21213.794301586595867) * r + 5394.1960214247511077) * r +
       687.1870074920579083) * r + 42.313330701600911252) * r + 1.0);
   } else { /* closer than 0.075 from {0,1} boundary */
     if (q > 0) r = 1.0 - p;
     else r = p;
     
     r = sqrt(-fast_log_1_float(r));
     
     if (r <= 5.) { /* <==> min(p,1-p) >= exp(-25) ~= 1.3888e-11 */
       r += -1.6;
       val = (((((((r * 0.00077454501427834140764 +
                         .0227238449892691845833) * r + .24178072517745061177) *
       r + 1.27045825245236838258) * r +
       3.64784832476320460504) * r + 5.7694972214606914055) * r + 4.6303378461565452959) * r +
       1.42343711074968357734) / (((((((r *
       0.00000000105075007164441684324 + 0.0005475938084995344946) *
       r + .0151986665636164571966) * r +
           .14810397642748007459) * r + .68976733498510000455) *
       r + 1.6763848301838038494) * r +
       2.05319162663775882187) * r + 1.);
     } else { /* very close to  0 or 1 */
       r += -5.;
       val = (((((((r * 0.000000201033439929228813265 +
         0.0000271155556874348757815) * r +
          .0012426609473880784386) * r + .026532189526576123093) *
         r + .29656057182850489123) * r +
         1.7848265399172913358) * r + 5.4637849111641143699) *
         r + 6.6579046435011037772) / (((((((r *
         0.00000000000000204426310338993978564 + 0.00000014215117583164458887)*
         r + 0.000018463183175100546818) * r +
         0.0007868691311456132591) * r + .0148753612908506148525)
                                           * r + .13692988092273580531) * r +
                                                 .59983220655588793769) * r + 1.);
     }
     
     if (q < 0.0) val = -val;
   }
   return val;
   
 }
 
 
 
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1>  qnorm_w_fastlog_rcpp_vec( Eigen::Matrix<double, -1, 1>  p) {
   
   int N = p.rows() ; 
   
   for (int n = 0; n < N; n++) {
     p(n) = qnorm_w_fastlog_rcpp(p(n));
   }
   
   return p;
 }
 
 
 // 
 // [[Rcpp::export]]
 Eigen::Matrix<double, 1, -1>  qnorm_w_fastlog_rcpp_rowvec( Eigen::Matrix<double, 1, -1>  p) {

   int N = p.cols() ;

   for (int n = 0; n < N; n++) {
     p(n) = qnorm_w_fastlog_rcpp(p(n));
   }

   return p;
 }

 // 
 
 
 
 
 // // [[Rcpp::export]]
 // Eigen::Matrix<double, -1, 1>    Phi_approx_Eidos_2021_et_al(   Eigen::Array<double, -1, 1 >  z  )   { 
 //   
 //   
 //   
 //   for (int i = 0; i <  z.rows(); i++) {
 //     
 //     double z_i = z(i);
 //     
 //     //double z_2 = z_i*z_i;
 //     double z_3 = z_i*z_i*z_i;
 //     double z_5 = z_3*z_i*z_i;
 //     // long double z_6 = z_3*z_3;
 //     double z_7 =   z_5*z_i*z_i;
 //     // long double z_8 = z_i*z_7;
 //     double z_9 = z_7*z_i*z_i;
 //     
 //     // fast_exp_1_double
 //     
 //     z(i) =   1 / (1 + exp(  -(   1.595852*z_i - 0.07248014*z_3 + 7.396148*0.000001*z_5 + 1.0832*0.0001*z_7 - 4.834311*0.000001*z_9 ) )  ); 
 //     
 //     //  z(i) =  (double)  1 / (1 + exp(  -(  1.5957764*z_i + 0.0726161*z_i*z_i*z_i + 0.00003318*z_i*z_i*z_i*z_i*z_i*z_i  ) )  ); 
 //     
 //   }
 //   
 //   return  z.matrix() ; 
 //   
 // }
 // 
 // 
 // 
 // 
 // 
 // // [[Rcpp::export]]
 // Eigen::Matrix<double, -1, 1>    fast_Phi_approx_Lipoth_2022_et_al(   Eigen::Array<double, -1, 1 >  z  )   { 
 //   
 //   
 //   double c_1 = 0.00141349455;
 //   double c_2 = 3.143479998875;
 //   double c_3 = 3.12017824876;
 //   double c_4 = 13.4751284391;
 //   double c_5 = 0.80551656318;
 //   
 //   for (int i = 0; i <  z.rows(); i++) {
 //     
 //     double z_i = z(i);
 //     double stuff_1 = fast_log_1_float(1 + exp((-z_i/c_5) + c_3 ) ) ; 
 //     z(i) = std::pow(1 + c_1*std::pow(stuff_1, c_2), -c_4);
 //     
 //   }
 //   
 //   return  z.matrix() ; 
 //   
 // }
 // 
 
 
 
 
 // [[Rcpp::export]]
 Eigen::Array<double, -1, 1>    logit_1_Eigen(   Eigen::Array<double, -1, 1 >  x  )   { 
   
   int N =  x.rows();
   
   for (int i = 0; i < N; i++) {
     x(i) = log( x(i) / ( 1.0 - x(i)) ) ; 
   }
   
   return x;
   
 }
 
 
 // [[Rcpp::export]]
 Eigen::Array<double, 1, -1>    logit_1_Eigen_rowvec(   Eigen::Array<double, 1, -1 >  x  )   {

   int N =  x.cols();

   for (int i = 0; i < N; i++) {
     x(i) = log( x(i) / ( 1.0 - x(i)) ) ;
   }

   return x;

 }

 
 // [[Rcpp::export]]
 Eigen::Array<double, -1, 1>    fast_logit_1_Eigen(   Eigen::Array<double, -1, 1 >  x  )   { 
   
   int N =  x.rows();  
   
   for (int i = 0; i < N; i++) {
     x(i) = fast_log_1_float( x(i) / ( 1.0 - x(i)) )   ;
   }
   
   return x;
   
 }
 
 
 
 // [[Rcpp::export]]
 Eigen::Array<double, 1, -1>    fast_logit_1_Eigen_rowvec(   Eigen::Array<double, 1, -1 >  x  )   {

   int N =  x.cols();

   for (int i = 0; i < N; i++) {
     x(i) = fast_log_1_float( x(i) / ( 1.0 - x(i)) )   ;
   }

   return x;

 }

 // 
 
 
 
 
 
 
 // Eigen::Array<double, -1, 1>   fast_Phi_approx_1_or_inv_logit_1_Eigen(  Eigen::Array<double, -1, 1>  z  ) {
 // 
 // 
 //   for (int i = 0; i < z.rows(); i++) {
 //     double z_i = z(i);
 //     if ( abs(x_i) < 5.0) {
 //       x(i) =      (3 *  0.07056*x_i*x_i   + 1.5976  )    *  CDF_x_i  * (1 -  CDF_x_i)    ;
 //     } else {
 //       x(i) =      1.702   *  CDF_x_i  * (1 -  CDF_x_i)
 //     }
 //   }
 // 
 //   return z;
 // 
 // }
 // 
 // Eigen::Array<double, -1, 1>   PDF_for_fast_Phi_approx_1_or_inv_logit_1_Eigen( Eigen::Array<double, -1, 1>   x,
 //                                                                               Eigen::Array<double, -1, 1>   CDF_x
 // ) {
 // 
 // 
 //   for (int i = 0; i < x.rows(); i++) {
 //         double x_i = x(i);
 //         double CDF_x_i = CDF_x(i) ;
 //         if ( abs(x_i) < 5.0) {
 //                x(i) =      (3 *  0.07056*x_i*x_i   + 1.5976  )    *  CDF_x_i  * (1 -  CDF_x_i)    ;
 //         } else {
 //                x(i) =      1.702   *  CDF_x_i  * (1 -  CDF_x_i)
 //         }
 //   }
 // 
 //   return  x;
 // 
 // }
 
 
 
 // [[Rcpp::export]]
 Eigen::Array<double, -1, 1>  abs_fn_1_Rcpp(  Eigen::Array<double, -1, 1>  x) {
   
   for (int i = 0; i < x.rows(); i++) {
     if ( std::abs(x(i)) < 5.0 )   x(i) =  1.0;
     else                          x(i) =  0.0;
   }
   
   return x;
   
 }
 
 
 
 // [[Rcpp::export]]
 Eigen::Array<double, -1, 1>  abs_fn_2_Rcpp(  Eigen::Array<double, -1, 1>  x) {
   
   for (int i = 0; i < x.rows(); i++) {
     if ( stan::math::abs(x(i)) < 5.0 )   x(i) =  1.0;
     else                          x(i) =  0.0;
   }
   
   return x;
   
 }
 
 // [[Rcpp::export]]
 Eigen::Array<double, -1, 1>  abs_fn_3_Rcpp(  Eigen::Array<double, -1, 1>  x) {
   
   for (int i = 0; i < x.rows(); i++) {
     if ( stan::math::fabs(x(i)) < 5.0 )   x(i) =  1.0;
     else                          x(i) =  0.0;
   }
   
   return x;
   
 }
 
 
 // [[Rcpp::export]]
 Eigen::Array<double, -1, 1>  abs_fn_4_Rcpp(  Eigen::Array<double, -1, 1>  x) {
   
   int N = x.rows();
   
   x  = Eigen::Select(x.abs() < 5.0, 
           Eigen::Array<double, -1, 1>::Ones(N), 
           Eigen::Array<double, -1, 1>::Zero(N));
   
   return x;
   
 }
 
 
 
 
 
 
 
 
 
 
 
//  
//  




 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1 >    fn_wo_list_log_posterior_and_gradient_Chol_Schur_MD_and_AD_3(  int n_cores,
                                                                                                       Eigen::Matrix<double, -1, 1  > theta_main,
                                                                                                       Eigen::Matrix<double, -1, 1  > theta_us,
                                                                                                     Eigen::Matrix<int, -1, -1>	 y,
                                                                                                     std::vector<Eigen::Matrix<double, -1, -1 > >  X,
                                                                                                     bool exclude_priors,
                                                                                                     bool CI,
                                                                                                     Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                                                     Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                                                     Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                                                     int n_class, // 10
                                                                                                     int n_tests,
                                                                                                     int ub_threshold_phi_approx,
                                                                                                     int n_chunks,
                                                                                                     bool corr_force_positive,
                                                                                                     std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                                                     std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                                                     bool corr_prior_beta ,
                                                                                                     bool corr_prior_norm ,
                                                                                                     std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                                                     std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr, // 20
                                                                                                     std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                                                     std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                                                     double prev_prior_a,
                                                                                                     double prev_prior_b,
                                                                                                     int Phi_type,
                                                                                                     int tanh_option,
                                                                                                     bool approx_exp_and_log_for_log_lik,
                                                                                                     bool approx_exp_and_log_for_grad


 ) {



   int N = y.rows();
   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
   int n_coeffs = n_class * n_tests * 1;
   int n_us =  1 *  N * n_tests;

   int n_params = theta_us.rows() +  theta_main.rows()   ; // n_corrs + n_coeffs + n_us + n_class;
   int n_params_main = n_params - n_us;

   // corrs
   Eigen::Matrix<double, -1, 1  >  Omega_raw_vec_double = theta_main.head(n_corrs); // .cast<double>();

   Eigen::Matrix<stan::math::var, -1, 1  >  Omega_raw_vec_var =  stan::math::to_var(Omega_raw_vec_double) ;
   Eigen::Matrix<stan::math::var, -1, 1  >  Omega_constrained_raw_vec_var =  Eigen::Matrix<stan::math::var, -1, 1  >::Zero(n_corrs) ;
   Omega_constrained_raw_vec_var = Omega_raw_vec_var ; // no transformation for Nump needed! done later on


   // coeffs
   Eigen::Matrix<double, -1, -1> beta_double_array(n_class, n_tests);

   {
     int i = n_corrs;
     for (int c = 0; c < n_class; ++c) {
       for (int t = 0; t < n_tests; ++t) {
         beta_double_array(c, t) = theta_main(i);
         i += 1;
       }
     }
   }


   // prev
   double u_prev_diseased = theta_main(n_params_main - 1);



   Eigen::Matrix<double, -1, 1 >  target_AD_grad(n_corrs);
   stan::math::var target_AD = 0.0;
   double grad_prev_AD = 0.0;

   int dim_choose_2 = n_tests * (n_tests - 1) * 0.5 ;
   // std::vector<Eigen::Matrix<double, -1, -1, Eigen::RowMajor > > deriv_L_wrt_unc_full = vec_of_mats_test_RM(dim_choose_2 + n_tests, dim_choose_2, n_class);
   // std::vector<Eigen::Matrix<double, -1, -1, Eigen::RowMajor > > L_Omega_double = vec_of_mats_test_RM(n_tests, n_tests, n_class);
   // std::vector<Eigen::Matrix<double, -1, -1, Eigen::RowMajor > > L_Omega_recip_double = L_Omega_double ; 
   std::vector<Eigen::Matrix<double, -1, -1 > > deriv_L_wrt_unc_full = vec_of_mats_test(dim_choose_2 + n_tests, dim_choose_2, n_class);
   std::vector<Eigen::Matrix<double, -1, -1 > > L_Omega_double = vec_of_mats_test(n_tests, n_tests, n_class);
   std::vector<Eigen::Matrix<double, -1, -1 > > L_Omega_recip_double = L_Omega_double ; 


   // {
   // 
   //          // std::vector<Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor  > > Omega_unconstrained_var = fn_convert_Eigen_vec_of_corrs_to_3d_array_var_RM(Omega_constrained_raw_vec_var, n_tests, n_class);
   //          //   std::vector<Eigen::Matrix<stan::math::var, -1, -1  > > Omega_unconstrained_var = fn_convert_Eigen_vec_of_corrs_to_3d_array_var(Omega_constrained_raw_vec_var, n_tests, n_class);
   //   
   //   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > Omega_unconstrained_var = fn_convert_std_vec_of_corrs_to_3d_array_var( Eigen_vec_to_std_vec_var(Omega_constrained_raw_vec_var),
   //                                                                                                                                n_tests,
   //                                                                                                                                n_class);
   // 
   //           // std::vector<Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor  > >  L_Omega_var  = vec_of_mats_test_var_RM(n_tests, n_tests, n_class);
   //           // std::vector<Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor  > >  Omega_var    = vec_of_mats_test_var_RM(n_tests, n_tests, n_class);
   //           std::vector<Eigen::Matrix<stan::math::var, -1, -1  > >  L_Omega_var  = vec_of_mats_test_var(n_tests, n_tests, n_class);
   //           std::vector<Eigen::Matrix<stan::math::var, -1, -1  > >  Omega_var    = vec_of_mats_test_var(n_tests, n_tests, n_class);
   // 
   //           for (int c = 0; c < n_class; ++c) {
   //             // Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor  >  ub = stan::math::to_var(ub_corr[c]);
   //             // Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor  >  lb = stan::math::to_var(lb_corr[c]);
   //             Eigen::Matrix<stan::math::var, -1, -1  >  ub = stan::math::to_var(ub_corr[c]);
   //             Eigen::Matrix<stan::math::var, -1, -1  >  lb = stan::math::to_var(lb_corr[c]);
   // 
   //             //  Eigen::Matrix<stan::math::var, -1, -1, Eigen::RowMajor   >  Chol_Schur_outs =  Spinkney_LDL_bounds_opt_RM(n_tests, lb, ub, Omega_unconstrained_var[c], known_values_indicator[c], known_values[c]) ; 
   //             Eigen::Matrix<stan::math::var, -1, -1  >  Chol_Schur_outs =  Spinkney_LDL_bounds_opt(n_tests, lb, ub, Omega_unconstrained_var[c], known_values_indicator[c], known_values[c]) ; 
   //             
   //             // L_Omega_var[c]   =  Chol_Schur_outs.middleRows(1, n_tests) ; // block(1, 0, n_tests, n_tests);
   //             L_Omega_var[c]   =  Chol_Schur_outs.block(1, 0, n_tests, n_tests);
   //             Omega_var[c] =   L_Omega_var[c] * L_Omega_var[c].transpose() ;
   // 
   // 
   //             target_AD +=   Chol_Schur_outs(0, 0); // now can set prior directly on Omega
   //           }
   // 
   // 
   // 
   //           for (int c = 0; c < n_class; ++c) {
   //                 if ( (corr_prior_beta == false)   &&  (corr_prior_norm == false) ) {
   //                   target_AD +=  stan::math::lkj_corr_cholesky_lpdf(L_Omega_var[c], lkj_cholesky_eta(c)) ;
   //                 } else if ( (corr_prior_beta == true)   &&  (corr_prior_norm == false) ) {
   //                     for (int i = 1; i < n_tests; i++) {
   //                       for (int j = 0; j < i; j++) {
   //                       target_AD +=  stan::math::beta_lpdf(  (Omega_var[c](i, j) + 1.0)/1.0, prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
   //                     }
   //                   }
   //                   //  Jacobian for  Omega -> L_Omega transformation for prior log-densities (since both LKJ and truncated normal prior densities are in terms of Omega, not L_Omega)
   //                   Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
   //                   for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * stan::math::log(L_Omega_var[c](i, i));
   //                   target_AD  += + (n_tests * stan::math::log(1.0) + jacobian_diag_elements.sum());  //  L -> Omega
   //                 } else if  ( (corr_prior_beta == false)   &&  (corr_prior_norm == true) ) {
   //                     for (int i = 1; i < n_tests; i++) {
   //                       for (int j = 0; j < i; j++) {
   //                       target_AD +=  stan::math::normal_lpdf(  Omega_var[c](i, j), prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
   //                     }
   //                   }
   //                   Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
   //                   for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * stan::math::log(L_Omega_var[c](i, i));
   //                   target_AD  += + (n_tests * stan::math::log(1.0) + jacobian_diag_elements.sum());  //  L -> Omega
   //                 }
   //           }
   // 
   // 
   //           ///////////////////////
   //           stan::math::set_zero_all_adjoints();
   //           target_AD.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
   //           target_AD_grad =  Omega_raw_vec_var.adj();    // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
   //           stan::math::set_zero_all_adjoints();
   //           //////////////////////////////////////////////////////////// end of AD part
   // 
   // 
   // 
   //           /////////////  prev stuff  ---- vars
   //           std::vector<stan::math::var> 	 u_prev_var_vec_var(n_class, 0.0);
   //           std::vector<stan::math::var> 	 prev_var_vec_var(n_class, 0.0);
   //           std::vector<stan::math::var> 	 tanh_u_prev_var(n_class, 0.0);
   //           Eigen::Matrix<stan::math::var, -1, -1>	 prev_var(1, n_class);
   // 
   //           u_prev_var_vec_var[1] =  stan::math::to_var(u_prev_diseased);
   //           tanh_u_prev_var[1] = ( exp(2.0*u_prev_var_vec_var[1] ) - 1.0) / ( exp(2*u_prev_var_vec_var[1] ) + 1.0) ;
   //           u_prev_var_vec_var[0] =   0.5 *  stan::math::log( (1.0 + ( (1.0 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1.0) ) / (1.0 - ( (1.0 - 0.5 * ( tanh_u_prev_var[1] + 1.0))*2.0 - 1.0) ) )  ;
   //           tanh_u_prev_var[0] = (exp(2*u_prev_var_vec_var[0] ) - 1.0) / ( exp(2*u_prev_var_vec_var[0] ) + 1.0) ;
   // 
   //           prev_var_vec_var[1] =  0.5 * ( tanh_u_prev_var[1] + 1.0);
   //           prev_var_vec_var[0] =  0.5 * ( tanh_u_prev_var[0] + 1.0);
   //           prev_var(0,1) =  prev_var_vec_var[1];
   //           prev_var(0,0) =  prev_var_vec_var[0];
   // 
   //           stan::math::var tanh_pu_deriv_var = ( 1.0 - tanh_u_prev_var[1] * tanh_u_prev_var[1]  );
   //           stan::math::var deriv_p_wrt_pu_var = 0.5 *  tanh_pu_deriv_var;
   //           stan::math::var tanh_pu_second_deriv_var  = -2.0 * tanh_u_prev_var[1]  * tanh_pu_deriv_var;
   //           stan::math::var log_jac_p_deriv_wrt_pu_var  = ( 1.0 / deriv_p_wrt_pu_var) * 0.5 * tanh_pu_second_deriv_var; // for gradient of u's
   //           stan::math::var  log_jac_p_var =    stan::math::log( deriv_p_wrt_pu_var );
   // 
   // 
   //           stan::math::var  target_AD_prev = beta_lpdf(  prev_var(0,1), prev_prior_a, prev_prior_b  ); // weakly informative prior - helps avoid boundaries with slight negative skew (for lower N)
   //           target_AD_prev += log_jac_p_var;
   // 
   //           target_AD  +=  target_AD_prev;
   // 
   //           ///////////////////////
   //           target_AD_prev.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
   //           grad_prev_AD  =  u_prev_var_vec_var[1].adj() - u_prev_var_vec_var[0].adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
   //           stan::math::set_zero_all_adjoints();
   //           //////////////////////////////////////////////////////////// end of AD part
   // 
   //           for (int c = 0; c < n_class; ++c) {
   //             int cnt_1 = 0;
   //             for (int k = 0; k < n_tests; k++) {
   //               for (int l = 0; l < k + 1; l++) {
   //                 (  L_Omega_var[c](k, l)).grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
   //                 int cnt_2 = 0;
   //                 for (int i = 1; i < n_tests; i++) {
   //                   for (int j = 0; j < i; j++) {
   //                     deriv_L_wrt_unc_full[c](cnt_1, cnt_2)  =   Omega_unconstrained_var[c](i, j).adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
   //                     cnt_2 += 1;
   //                   }
   //                 }
   //                 stan::math::set_zero_all_adjoints();
   //                 cnt_1 += 1;
   //               }
   //             }
   //           }
   // 
   //           for (int c = 0; c < n_class; ++c) {
   //             for (int t1 = 0; t1 < n_tests; ++t1) {
   //               for (int t2 = 0; t2 < n_tests; ++t2) {
   //                 L_Omega_double[c](t1, t2) =   L_Omega_var[c](t1, t2).val()  ;
   //                 L_Omega_recip_double[c](t1, t2) =   1.0 / L_Omega_double[c](t1, t2) ;
   //               }
   //             }
   //           //    L_Omega_recip_double[c].array() = 1.0 / L_Omega_double[c].array() ;
   //           }
   // 
   // 
   //           stan::math::recover_memory();
   // 
   // 
   // }   //// end of AD bloock
   // 

   
   {
     
     
     std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > Omega_unconstrained_var = fn_convert_std_vec_of_corrs_to_3d_array_var( Eigen_vec_to_std_vec_var(Omega_constrained_raw_vec_var),
                                                                                                                                  n_tests,
                                                                                                                                  n_class);
     
     
     std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > L_Omega_var = vec_of_mats_test_var(n_tests, n_tests, n_class);
     std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  Omega_var   = vec_of_mats_test_var(n_tests, n_tests, n_class);
     
     for (int c = 0; c < n_class; ++c) {
       Eigen::Matrix<stan::math::var, -1, -1 >  ub = stan::math::to_var(ub_corr[c]);
       Eigen::Matrix<stan::math::var, -1, -1 >  lb = stan::math::to_var(lb_corr[c]);
       
       Eigen::Matrix<stan::math::var, -1, -1  >  Chol_Schur_outs =  Spinkney_LDL_bounds_opt(n_tests, lb, ub, Omega_unconstrained_var[c], known_values_indicator[c], known_values[c]) ; //   Omega_unconstrained_var[c], n_tests, tol )  ;
       
       L_Omega_var[c]   =  Chol_Schur_outs.block(1, 0, n_tests, n_tests);
       Omega_var[c] =   L_Omega_var[c] * L_Omega_var[c].transpose() ;
       
       
       target_AD +=   Chol_Schur_outs(0, 0); // now can set prior directly on Omega
     }
     
     
     
     for (int c = 0; c < n_class; ++c) {
       if ( (corr_prior_beta == false)   &&  (corr_prior_norm == false) ) {
         target_AD +=  stan::math::lkj_corr_cholesky_lpdf(L_Omega_var[c], lkj_cholesky_eta(c)) ;
       } else if ( (corr_prior_beta == true)   &&  (corr_prior_norm == false) ) {
         for (int i = 1; i < n_tests; i++) {
           for (int j = 0; j < i; j++) {
             target_AD +=  stan::math::beta_lpdf(  (Omega_var[c](i, j) + 1)/2, prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
           }
         }
         //  Jacobian for  Omega -> L_Omega transformation for prior log-densities (since both LKJ and truncated normal prior densities are in terms of Omega, not L_Omega)
         Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
         for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * log(L_Omega_var[c](i, i));
         target_AD  += + (n_tests * stan::math::log(2) + jacobian_diag_elements.sum());  //  L -> Omega
       } else if  ( (corr_prior_beta == false)   &&  (corr_prior_norm == true) ) {
         for (int i = 1; i < n_tests; i++) {
           for (int j = 0; j < i; j++) {
             target_AD +=  stan::math::normal_lpdf(  Omega_var[c](i, j), prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
           }
         }
         Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
         for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * log(L_Omega_var[c](i, i));
         target_AD  += + (n_tests * stan::math::log(2) + jacobian_diag_elements.sum());  //  L -> Omega
       }
     }
     
     
     ///////////////////////
     stan::math::set_zero_all_adjoints();
     target_AD.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
     target_AD_grad =  Omega_raw_vec_var.adj();    // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
     stan::math::set_zero_all_adjoints();
     //////////////////////////////////////////////////////////// end of AD part
     
     
     
     /////////////  prev stuff  ---- vars
     std::vector<stan::math::var> 	 u_prev_var_vec_var(n_class, 0.0);
     std::vector<stan::math::var> 	 prev_var_vec_var(n_class, 0.0);
     std::vector<stan::math::var> 	 tanh_u_prev_var(n_class, 0.0);
     Eigen::Matrix<stan::math::var, -1, -1>	 prev_var(1, n_class);
     
     u_prev_var_vec_var[1] =  stan::math::to_var(u_prev_diseased);
     tanh_u_prev_var[1] = ( exp(2*u_prev_var_vec_var[1] ) - 1) / ( exp(2*u_prev_var_vec_var[1] ) + 1) ;
     u_prev_var_vec_var[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1) ) )  ;
     tanh_u_prev_var[0] = (exp(2*u_prev_var_vec_var[0] ) - 1) / ( exp(2*u_prev_var_vec_var[0] ) + 1) ;
     
     prev_var_vec_var[1] = 0.5 * ( tanh_u_prev_var[1] + 1);
     prev_var_vec_var[0] =  0.5 * ( tanh_u_prev_var[0] + 1);
     prev_var(0,1) =  prev_var_vec_var[1];
     prev_var(0,0) =  prev_var_vec_var[0];
     
     stan::math::var tanh_pu_deriv_var = ( 1 - tanh_u_prev_var[1] * tanh_u_prev_var[1]  );
     stan::math::var deriv_p_wrt_pu_var = 0.5 *  tanh_pu_deriv_var;
     stan::math::var tanh_pu_second_deriv_var  = -2 * tanh_u_prev_var[1]  * tanh_pu_deriv_var;
     stan::math::var log_jac_p_deriv_wrt_pu_var  = ( 1 / deriv_p_wrt_pu_var) * 0.5 * tanh_pu_second_deriv_var; // for gradient of u's
     stan::math::var  log_jac_p_var =    log( deriv_p_wrt_pu_var );
     
     
     stan::math::var  target_AD_prev = beta_lpdf(  prev_var(0,1), prev_prior_a, prev_prior_b  ); // weakly informative prior - helps avoid boundaries with slight negative skew (for lower N)
     target_AD_prev += log_jac_p_var;
     
     target_AD  +=  target_AD_prev;
     
     ///////////////////////
     target_AD_prev.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
     grad_prev_AD  =  u_prev_var_vec_var[1].adj() - u_prev_var_vec_var[0].adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
     stan::math::set_zero_all_adjoints();
     //////////////////////////////////////////////////////////// end of AD part
     
     
     
     
     for (int c = 0; c < n_class; ++c) {
       int cnt_1 = 0;
       for (int k = 0; k < n_tests; k++) {
         for (int l = 0; l < k + 1; l++) {
           (  L_Omega_var[c](k, l)).grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
           int cnt_2 = 0;
           for (int i = 1; i < n_tests; i++) {
             for (int j = 0; j < i; j++) {
               deriv_L_wrt_unc_full[c](cnt_1, cnt_2)  =   Omega_unconstrained_var[c](i, j).adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
               cnt_2 += 1;
             }
           }
           stan::math::set_zero_all_adjoints();
           cnt_1 += 1;
         }
       }
     }
     
     
     ///////////////// get cholesky factor's (lower-triangular) of corr matrices
     // convert to 3d var array
     
     for (int c = 0; c < n_class; ++c) {
       for (int t1 = 0; t1 < n_tests; ++t1) {
         for (int t2 = 0; t2 < n_tests; ++t2) {
           L_Omega_double[c](t1, t2) =   L_Omega_var[c](t1, t2).val()  ;
           L_Omega_recip_double[c](t1, t2) =   1.0 / L_Omega_double[c](t1, t2) ;
         }
       }
     }
     
     stan::math::recover_memory();
   }
   



   /////////////  prev stuff
   std::vector<double> 	 u_prev_var_vec(n_class, 0.0);
   std::vector<double> 	 prev_var_vec(n_class, 0.0);
   std::vector<double> 	 tanh_u_prev(n_class, 0.0);
   Eigen::Matrix<double, -1, -1>	 prev(1, n_class);

   u_prev_var_vec[1] =  (double) u_prev_diseased ;
   tanh_u_prev[1] = ( exp(2.0*u_prev_var_vec[1] ) - 1.0) / ( exp(2.0*u_prev_var_vec[1] ) + 1.0) ;
   u_prev_var_vec[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2.0 - 1.0) ) / (1.0 - ( (1.0 - 0.5 * ( tanh_u_prev[1] + 1.0))*2.0 - 1.0) ) )  ;
   tanh_u_prev[0] = (exp(2.0*u_prev_var_vec[0] ) - 1.0) / ( exp(2.0*u_prev_var_vec[0] ) + 1.0) ;

   prev_var_vec[1] =  0.5 * ( tanh_u_prev[1] + 1.0);
   prev_var_vec[0] =  0.5 * ( tanh_u_prev[0] + 1.0);
   prev(0,1) =  prev_var_vec[1];
   prev(0,0) =  prev_var_vec[0];


   double tanh_pu_deriv = ( 1.0 - tanh_u_prev[1] * tanh_u_prev[1]  );
   double deriv_p_wrt_pu_double = 0.5 *  tanh_pu_deriv;
   double tanh_pu_second_deriv  = -2.0 * tanh_u_prev[1]  * tanh_pu_deriv;
   double log_jac_p_deriv_wrt_pu  = ( 1.0 / deriv_p_wrt_pu_double) * 0.5 * tanh_pu_second_deriv; // for gradient of u's
   double  log_jac_p =    log( deriv_p_wrt_pu_double );



   ///////////////////////////////////////////////////////////////////////// prior densities
   double prior_densities = 0.0;


   if (exclude_priors == false) {
     ///////////////////// priors for coeffs
     double prior_densities_coeffs = 0.0;
     for (int c = 0; c < n_class; c++) {
       for (int t = 0; t < n_tests; t++) {
            prior_densities_coeffs  += stan::math::normal_lpdf(beta_double_array(c, t), prior_coeffs_mean(c, t), prior_coeffs_sd(c, t));
          //  prior_densities_coeffs  +=  - 0.9189385 - log(prior_coeffs_sd(c, t)) - 0.5 * ( (beta_double_array(c,t) - prior_coeffs_mean(c, t)) / prior_coeffs_sd(c, t) ) *   ( (beta_double_array(c,t) - prior_coeffs_mean(c, t)) / prior_coeffs_sd(c, t) )  ;
       }
     }
     double prior_densities_corrs = target_AD.val();
     prior_densities = prior_densities_coeffs  +      prior_densities_corrs ;     // total prior densities and Jacobian adjustments
   }


   /////////////////////////////////////////////////////////////////////////////////////////////////////
   ///////// likelihood
   int chunk_counter = 0;
   int chunk_size  = std::round( N / n_chunks  / 2) * 2;  ; // N / n_chunks;


   double log_prob_out = 0.0;


   Eigen::Matrix<double, -1, -1 >  log_prev = prev;

   for (int c = 0; c < n_class; c++) {
     log_prev(0,c) =  log(prev(0,c));
     for (int t = 0; t < n_tests; t++) {
       if (CI == true)      L_Omega_double[c](t,t) = 1.0;
     }
   }



   if (tanh_option == 1) theta_us.array() =      theta_us.array().tanh() ;  // this works
   if (tanh_option == 2) theta_us.array() =      tanh_2_Eigen( theta_us ).array();
   if (tanh_option == 3) theta_us.array() =      fast_tanh_approx_1_Eigen( theta_us ).array();
   if (tanh_option == 4) theta_us.array() =      fast_tanh_approx_2_Eigen( theta_us ).array(); // seems to work  ?!?!
   if (tanh_option == 5) theta_us.array() =      fast_inv_logit_1_Eigen( theta_us.array() ).array();  // inv_logit
   if (tanh_option == 6) theta_us.array() =      stan::math::inv_logit( theta_us  ).array();  // inv_logit


   double log_jac_u  =  0.0;
   if    (approx_exp_and_log_for_log_lik == true)    {  // most stable
     
     // for (int u_i = 0; u_i < n_us; u_i++) {
     //   theta_us(u_i) =     ( 2.0 / (1.0 + fast_exp_1_double(-2.0 *  theta_us(u_i) )  )  ) - 1.0  ; 
     //   double val =    0.5 *   (  1.0 -  ( theta_us(u_i)  *  theta_us(u_i)   ) ) ;  
     //  log_jac_u += fast_log_1_float(val) ;
     // }
       
        if   (tanh_option < 5)  log_jac_u  =    (  fast_log_1_Eigen( 0.5 *   (  1.0 -  ( theta_us.array()   *  theta_us.array()   ).array()  ).array()  ).array()   ).matrix().sum();  // log
        else                    log_jac_u  =    fast_log_1_Eigen(   (1.0 -  theta_us.array())*theta_us.array()  ).matrix().sum();
   } else {
     // for (int u_i = 0; u_i < n_us; u_i++) {
     //   theta_us(u_i) =     ( 2.0 / (1.0 + std::exp(-2.0 *  theta_us(u_i) )  )  ) - 1.0  ; 
     //   double val =    0.5 *   (  1.0 -  ( theta_us(u_i)  *  theta_us(u_i)   ) ) ;  
     //   log_jac_u += std::log(val) ;
     // }
     
       if   (tanh_option < 5)  log_jac_u  =    (  fast_log_0_Eigen( 0.5 *   (  1.0 -  ( theta_us.array()   *  theta_us.array()   ).array()  ).array()  ).array()   ).matrix().sum();  // log
       else                    log_jac_u  =    fast_log_0_Eigen(   (1.0 -  theta_us.array())*theta_us.array()  ).matrix().sum();
   }



   ///////////////////////////////////////////////
   Eigen::Matrix<double , -1, 1>   beta_grad_vec   =  Eigen::Matrix<double, -1, 1>::Zero(n_coeffs);  //
   Eigen::Matrix<double, -1, -1>   beta_grad_array  =  Eigen::Matrix<double, -1, -1>::Zero(2, n_tests); //
   std::vector<Eigen::Matrix<double, -1, -1 > > U_Omega_grad_array =  vec_of_mats_test(n_tests, n_tests, 2); //
   Eigen::Matrix<double, -1, 1 > L_Omega_grad_vec(n_corrs + (2 * n_tests)); //
   Eigen::Matrix<double, -1, 1 > U_Omega_grad_vec(n_corrs); //
   Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(2); //
   Eigen::Matrix<double, -1, 1>  prev_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(2); //
   Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec_out =   Eigen::Matrix<double, -1, 1>::Zero(2 - 1); //
   // ///////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////////////////////////// output vec
   Eigen::Matrix<double, -1, 1> out_mat    =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N);  ///////////////////////////////////////////////
   ///////////////////////////////////////////////////////////////////////////////////////////////////

   double log_prob = 0.0;


   {


     //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
     double sqrt_2_pi_recip =   1.0 / sqrt(2.0 * M_PI) ; //  0.3989422804;
     double minus_sqrt_2_recip =  - 1.0 / stan::math::sqrt(2.0);
     double sqrt_2_recip = 1.0 / stan::math::sqrt(2.0);
     double a = 0.07056;
     double b = 1.5976;
     double a_times_3 = 3.0 * 0.07056;
     double s = 1.0/1.702;


     ///////////////////////////////////////////////
     std::vector<Eigen::Matrix<double, -1, -1 > >  Z_std_norm =  vec_of_mats_test(chunk_size, n_tests, 2); //////////////////////////////
     std::vector<Eigen::Matrix<double, -1, -1 > >  Bound_Z =  Z_std_norm ; // vec_of_mats_test(chunk_size, n_tests, 2); //////////////////////////////
     std::vector<Eigen::Matrix<double, -1, -1 > >  Bound_U_Phi_Bound_Z =  Z_std_norm ;  //  vec_of_mats_test(chunk_size, n_tests, 2); //////////////////////////////
     std::vector<Eigen::Matrix<double, -1, -1 > >  Phi_Z =  Z_std_norm ;  //  vec_of_mats_test(chunk_size, n_tests, 2); //////////////////////////////
     std::vector<Eigen::Matrix<double, -1, -1 > >  y1_or_phi_Bound_Z =  Z_std_norm ;  //  vec_of_mats_test(chunk_size, n_tests, 2); //////////////////////////////
     std::vector<Eigen::Matrix<double, -1, -1 > >  prob =  Z_std_norm ;  //  vec_of_mats_test(chunk_size, n_tests, 2); //////////////////////////////
     ///////////////////////////////////////////////);
     Eigen::Matrix<double, -1, -1> y_chunk = Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, -1> u_array =  y_chunk ; // Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     ///////////////////////////////////////////////
     Eigen::Matrix<double, -1, 1> prod_container_or_inc_array  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
     Eigen::Matrix<double, -1, 1>      prob_n  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
     ///////////////////////////////////////////////
     Eigen::Matrix<double, -1, -1>     common_grad_term_1   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, -1 >    L_Omega_diag_recip_array   = common_grad_term_1 ; //  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, -1 >    y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip   =  common_grad_term_1 ; //   Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, -1 >    y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip   =   common_grad_term_1 ; //  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, -1 >    prop_rowwise_prod_temp   =   common_grad_term_1 ; //  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, -1>     grad_prob =    common_grad_term_1 ; //  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, -1>     z_grad_term =  common_grad_term_1 ; //  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     Eigen::Matrix<double, -1, -1>     u_grad_array_CM_chunk   =   common_grad_term_1 ; //  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);    ////////
     Eigen::Matrix<double, -1, -1>     phi_Z_recip  =   common_grad_term_1 ; //  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     ///////////////////////////////////////////////
     Eigen::Matrix<double, -1, 1>      derivs_chain_container_vec  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
     Eigen::Matrix<double, -1, 1>      prop_rowwise_prod_temp_all  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
     ////////////////////////////////////////////////


     {

       // /////////////////////////////////////////////////////////////////////////////////////////////////////
       Eigen::Matrix<double, -1, -1>    lp_array  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, 2);///////
       ////////////////////////////////////////////////////////////////////////////////////////////////////////


     for (int nc = 0; nc < n_chunks; nc++) {

         u_grad_array_CM_chunk.array() = 0.0;

              int chunk_counter = nc;

              y_chunk = y.middleRows(chunk_size * chunk_counter , chunk_size).cast<double>() ;


               if   (tanh_option < 5)   u_array.array() = 0.5 * (  theta_us.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).reshaped(chunk_size, n_tests).array() + 1.0 ).array() ;
               else                     u_array.array() =          theta_us.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).reshaped(chunk_size, n_tests).array()   ;


                 for (int c = 0; c < n_class; c++) {

                                   prod_container_or_inc_array.array()  = 0.0; // needs to be reset to 0

                                   for (int t = 0; t < n_tests; t++) {

                                                        Bound_Z[c].col(t).array() =    L_Omega_recip_double[c](t, t) * (  - ( beta_double_array(c, t) +      prod_container_or_inc_array.array()   )  ) ; // / L_Omega_double[c](t, t)     ;
                                                     
                                                       //  Bound_U_Phi_Bound_Z[c].col(t).array()  =  fast_Phi_approx_1_Eigen( Bound_Z[c].col(t).array() ).array()  ; ; ///////////// using function is slower! likely due to overhead
                                                              for (int n_index = 0; n_index < chunk_size; n_index++) {
                                                                double x_i =  Bound_Z[c](n_index, t);
                                                                double val = 0.07056*x_i*x_i*x_i + 1.5976*x_i ;
                                                                Bound_U_Phi_Bound_Z[c](n_index, t) =  (1.0/(1.0 +   fast_exp_1_double(-val) )) ;
                                                                  if ( std::abs(x_i) > 5.0   ) {
                                                                    Bound_U_Phi_Bound_Z[c](n_index, t) =    stan::math::inv_logit( 1.702 * x_i  );  //  stan::math::inv_logit( 1.702 * Bound_Z[c].col(t)  )
                                                                  }
                                                              }
                                                       
                                                        Phi_Z[c].col(t).array()    =      (   y_chunk.col(t).array()  *  Bound_U_Phi_Bound_Z[c].col(t).array() +
                                                                                          (   y_chunk.col(t).array()  -  Bound_U_Phi_Bound_Z[c].col(t).array() ) *   ( y_chunk.col(t).array() + (  y_chunk.col(t).array() - 1.0).array() ).array() * u_array.col(t).array()  ).array()   ;  
                                                    
                                                          if (Phi_type == 5)  {
                                                                //  Z_std_norm[c].col(t).array() =  fast_inv_Phi_approx_1_Eigen( Phi_Z[c].col(t)).array()  ; /////////////// using function is slower! likely due to overhead
                                                                 for (int n_index = 0; n_index < chunk_size; n_index++) {
                                                                   double p_i =  Phi_Z[c](n_index, t);
                                                                   Z_std_norm[c](n_index, t) =   5.494 * fast_sinh_approx_1_double(fast_arcsinh_approx_1_double(-0.3418*fast_log_1_float(1.0/p_i-1.0))/3.0) ;
                                                                 }
                                                          }  else   {
                                                                 //  Z_std_norm[c].col(t).array() =  qnorm_w_fastlog_rcpp_vec( Phi_Z[c].col(t)).array()  ; // qnorm_rcpp_vec  //////////////// using function is slower! likely due to overhead
                                                                 for (int n_index = 0; n_index < chunk_size; n_index++) {
                                                                   double p_i =  Phi_Z[c](n_index, t);
                                                                   Z_std_norm[c](n_index, t) =       qnorm_w_fastlog_rcpp(p_i);
                                                                 }
                                                          }
                                                          for (int n_index = 0; n_index < chunk_size; n_index++) {
                                                             if ( std::abs(Bound_Z[c](n_index, t)) > 5.0   ) {
                                                              Z_std_norm[c](n_index, t) =    s  *  stan::math::logit(Phi_Z[c](n_index, t));  //   s *  fast_logit_1_Eigen(    Phi_Z[c].col(t) ).array()
                                                            }
                                                          }

                                                      if (t < n_tests - 1)       prod_container_or_inc_array.array()  =   ( Z_std_norm[c].topLeftCorner(chunk_size, t + 1)  *   ( L_Omega_double[c].row(t+1).head(t+1).transpose()  ) ) ; //////// checked

                                   } // end of t loop


                                   prob[c].array() =  y_chunk.array() * ( 1.0 -    Bound_U_Phi_Bound_Z[c].array() ) +
                                                      ( y_chunk.array() - 1.0  ).array()   *    Bound_U_Phi_Bound_Z[c].array() *   ( y_chunk.array() +  (  y_chunk.array() - 1.0).array() ).array() ;
                                     
                                 if (approx_exp_and_log_for_log_lik == true) {
                                   //y1_or_phi_Bound_Z[c].array() =  fast_log_1_Eigen_mat(     y_chunk.array() * ( 1.0 -    Bound_U_Phi_Bound_Z[c].array() ) +  /////////////// using function is slower! likely due to overhead
                                   //                                                       (  y_chunk.array() - 1.0  ).array()   *    Bound_U_Phi_Bound_Z[c].array() *   ( y_chunk.array() +  (  y_chunk.array() - 1.0).array() ).array() ).array() ;
                                   for (int t = 0; t < n_tests; t++) {
                                     for (int n_index = 0; n_index < chunk_size; n_index++) {
                                       double val =      prob[c](n_index, t) ; //   y_chunk(n_index, t) * (1.0 -   Bound_U_Phi_Bound_Z[c](n_index, t)) +  (  y_chunk(n_index, t)  - 1.0  )  *    Bound_U_Phi_Bound_Z[c](n_index, t)  *   ( y_chunk(n_index, t) +  (  y_chunk(n_index, t)  - 1.0)  ) ;
                                      // prob[c](n_index, t) = val;
                                       y1_or_phi_Bound_Z[c](n_index, t) = fast_log_1_float(val) ;
                                     }
                                   }
                                 } else {
                                   //y1_or_phi_Bound_Z[c].array() =  fast_log_0_Eigen_mat(   y_chunk.array() * ( 1.0 -    Bound_U_Phi_Bound_Z[c].array() ) +  ///////////////// using function is slower! likely due to overhead 
                                   //                                                    (  y_chunk.array() - 1.0  ).array()   *    Bound_U_Phi_Bound_Z[c].array() *   ( y_chunk.array() +  (  y_chunk.array() - 1.0).array() ).array() ).array() ;
                                   for (int t = 0; t < n_tests; t++) {
                                     for (int n_index = 0; n_index < chunk_size; n_index++) {
                                       double val =      prob[c](n_index, t) ; //    y_chunk(n_index, t) * (1.0 -   Bound_U_Phi_Bound_Z[c](n_index, t)) +  (  y_chunk(n_index, t)  - 1.0  )  *    Bound_U_Phi_Bound_Z[c](n_index, t)  *   ( y_chunk(n_index, t) +  (  y_chunk(n_index, t)  - 1.0)  ) ;
                                     //  prob[c](n_index, t) = val;
                                       y1_or_phi_Bound_Z[c](n_index, t) = std::log(val) ;
                                     }
                                   }
                                 }

                                lp_array.col(c).array() =     y1_or_phi_Bound_Z[c].rowwise().sum().array() +  log_prev(0,c) ;

                        } // end of c loop

                         // log_lik
                      if   (approx_exp_and_log_for_log_lik == false)    {
                        out_mat.segment(n_params + 1, N).segment(chunk_size * chunk_counter, chunk_size).array()   = (  lp_array.array().maxCoeff() +  fast_log_0_Eigen(   fast_exp_0_Eigen_mat(  (lp_array.array() - lp_array.array().maxCoeff() ).array()).matrix().rowwise().sum().array()   )  )  ;
                        prob_n  =  fast_exp_0_Eigen(out_mat.segment(n_params + 1, N).segment(chunk_size * chunk_counter, chunk_size).array()) ;
                      } else {   // still use exacct exp and log for this part as cost is negligable and seems to not improve efficiency anyway (worse ESS/grad)
                        out_mat.segment(n_params + 1, N).segment(chunk_size * chunk_counter, chunk_size).array()   = (  lp_array.array().maxCoeff() +  fast_log_1_Eigen(   fast_exp_1_Eigen_mat(  (lp_array.array() - lp_array.array().maxCoeff() ).array()).matrix().rowwise().sum().array())  )  ;
                        prob_n  =  fast_exp_1_Eigen(out_mat.segment(n_params + 1, N).segment(chunk_size * chunk_counter, chunk_size).array()) ;
                      }


    for (int c = 0; c < n_class; c++) {



          //  if (approx_exp_and_log_for_grad == true)     prob[c].array() = fast_exp_1_Eigen_mat(   y1_or_phi_Bound_Z[c].array() ).array() ;  //////////// using function is slower! likely due to overhead
          //  if (approx_exp_and_log_for_grad == false)    prob[c].array() = fast_exp_0_Eigen_mat(   y1_or_phi_Bound_Z[c].array() ).array() ;  ///////////// using function is slower! likely due to overhead
            // if (approx_exp_and_log_for_grad == true)   {
            //         for (int t = 0; t < n_tests; t++) {
            //           for (int n_index = 0; n_index < chunk_size; n_index++) {
            //             prob[c](n_index, t) = fast_exp_1_double(y1_or_phi_Bound_Z[c](n_index, t)) ;
            //           }
            //         }
            // } else {
            //         for (int t = 0; t < n_tests; t++) {
            //           for (int n_index = 0; n_index < chunk_size; n_index++) {
            //             prob[c](n_index, t) = std::exp(y1_or_phi_Bound_Z[c](n_index, t)) ;
            //           }
            //         }
            // }
                      



                 for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
                   int t = n_tests - (i+1) ;
                   prop_rowwise_prod_temp.col(t).array()   =   prob[c].block(0, t + 0, chunk_size, i + 1).rowwise().prod().array() ;
                 }

                  prop_rowwise_prod_temp_all.array() =  prob[c].rowwise().prod().array()  ;

                 for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
                   int t = n_tests - (i + 1) ;
                   common_grad_term_1.col(t) =   (  ( prev(0,c) / prob_n.array() ) * (    prop_rowwise_prod_temp_all.array() /  prop_rowwise_prod_temp.col(t).array()  ).array() )  ;
                 }
                 for (int t = 0; t < n_tests; t++) {
                   L_Omega_diag_recip_array.col(t).array() =  L_Omega_recip_double[c](t, t) ;
                 }

                         y1_or_phi_Bound_Z[c].array() =                (  (    (  3.0*a*Bound_Z[c].array()*Bound_Z[c].array()   + b  ).array()  ).array() )  *  Bound_U_Phi_Bound_Z[c].array() * (1.0 -  Bound_U_Phi_Bound_Z[c].array() )   ;
                       //  if (approx_exp_and_log_for_grad == true)      y1_or_phi_Bound_Z[c].array() =                   sqrt_2_pi_recip *  fast_exp_1_Eigen_mat( - 0.5 * Bound_Z[c].array()    *  Bound_Z[c].array()    ).array()  ;
                       //  if (approx_exp_and_log_for_grad == false)     y1_or_phi_Bound_Z[c].array() =                   sqrt_2_pi_recip *  fast_exp_0_Eigen_mat( - 0.5 * Bound_Z[c].array()    *  Bound_Z[c].array()    ).array()  ;
                              for (int t = 0; t < n_tests; t++) {
                                  for (int n_index = 0; n_index < chunk_size; n_index++) {
                                    if ( std::abs(Bound_Z[c](n_index, t)) > 5.0   ) {
                                      double Phi_x_i =  Bound_U_Phi_Bound_Z[c](n_index, t);
                                      double Phi_x_1m_Phi  =    (  Phi_x_i * (1.0 - Phi_x_i)  ) ;
                                      y1_or_phi_Bound_Z[c](n_index, t) =  1.702 * Phi_x_1m_Phi;
                                    }
                                  }
                              }
                     

            y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.array()  =                  ( y_chunk.array()  + (  y_chunk.array() - 1.0).array() ).array() *    y1_or_phi_Bound_Z[c].array()  *   L_Omega_diag_recip_array.array() ;


                       //   y_m_ysign_x_u_array.array()  =   ( (  (   y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array()   -  ( y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array() + (  y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array() - 1).array() ).array()
                       //  * u_array.array()    ).array() ) ) ; //////// checked

                       
                          if (Phi_type == 5)  {
                              phi_Z_recip.array()  =    1.0 / (    (   (3.0 * a*Z_std_norm[c].array()*Z_std_norm[c].array()   + b  ).array()  ).array() *  Phi_Z[c].array() * (1.0 -  Phi_Z[c].array() )  ).array()  ;  // Phi_type == 2
                          } else   {
                              if (approx_exp_and_log_for_grad == true)  { 
                                        // phi_Z_recip.array()  =      1.0 / (  sqrt_2_pi_recip *  fast_exp_1_Eigen_mat( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).array()  ) ;
                                      for (int t = 0; t < n_tests; t++) {
                                        for (int n_index = 0; n_index < chunk_size; n_index++) {
                                              double Z_val = Z_std_norm[c](n_index, t) ; //  * Z_std_norm[c](n_index, t);
                                              double Z_sq = Z_val * Z_val;
                                              double val =  sqrt_2_pi_recip * fast_exp_1_double( -0.5  * Z_sq  ) ; 
                                              phi_Z_recip(n_index, t) = 1.0 / val ; 
                                        }
                                      }
                              } else { 
                                       // phi_Z_recip.array()  =      1.0 / (  sqrt_2_pi_recip *  fast_exp_0_Eigen_mat( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).array()  ) ;
                                      for (int t = 0; t < n_tests; t++) {
                                       for (int n_index = 0; n_index < chunk_size; n_index++) {
                                             double Z_val = Z_std_norm[c](n_index, t) ; //  * Z_std_norm[c](n_index, t);
                                             double Z_sq = Z_val * Z_val;
                                             double val =  sqrt_2_pi_recip * std::exp( -0.5  * Z_sq  ) ; 
                                             phi_Z_recip(n_index, t) = 1.0 / val ; 
                                       }
                                      }
                              }
                          }
                                for (int t = 0; t < n_tests; t++) {
                                        for (int n_index = 0; n_index < chunk_size; n_index++) {
                                          if ( std::abs(Bound_Z[c](n_index, t)) > 5.0   ) {
                                            double Phi_x_i =  Phi_Z[c](n_index, t);
                                            double Phi_x_1m_Phi_x_recip =  1.0 / (  Phi_x_i * (1.0 - Phi_x_i)  ) ;
                                            Phi_x_1m_Phi_x_recip =  1.0 / (  Phi_x_i * (1.0 - Phi_x_i)  ) ;
                                            phi_Z_recip(n_index, t) =      s * Phi_x_1m_Phi_x_recip;
                                          }
                                        }
                                }
                       


             y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.array()  =    ( (  (   y_chunk.array()   -  ( y_chunk.array()  + (  y_chunk.array()  - 1.0).array() ).array()    * u_array.array()    ).array() ) ).array() *
                                                                                                        phi_Z_recip.array()  *   y1_or_phi_Bound_Z[c].array()   *    L_Omega_diag_recip_array.array() ;




           ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grad of nuisance parameters / u's (manual)
           {

                 ///// then second-to-last term (test T - 1)
                 int t = n_tests - 1;

                 u_grad_array_CM_chunk.col(n_tests - 2).array()  +=  (  common_grad_term_1.col(t).array()  * (y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t).array()  *  L_Omega_double[c](t,t - 1) * ( phi_Z_recip.col(t-1).array() )  *  prob[c].col(t-1).array()) ).array()  ;

                   { ///// then third-to-last term (test T - 2)
                     t = n_tests - 2;

                     z_grad_term.col(0) = ( phi_Z_recip.col(t-1).array())  *  prob[c].col(t-1).array() ;
                     grad_prob.col(0) =        y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t).array()   *     L_Omega_double[c](t, t - 1) *   z_grad_term.col(0).array() ; // lp(T-1) - part 2;
                     z_grad_term.col(1).array()  =      L_Omega_double[c](t,t-1) *   z_grad_term.col(0).array() *       y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t).array() ;
                     grad_prob.col(1)  =         (   y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t+1).array()   ) *  (  z_grad_term.col(0).array() *  L_Omega_double[c](t + 1,t - 1)  -   z_grad_term.col(1).array()  * L_Omega_double[c](t+1,t)) ;

                    u_grad_array_CM_chunk.col(n_tests - 3).array()  +=  ( common_grad_term_1.col(t).array()   *  (  grad_prob.col(1).array() *  prob[c].col(t).array()  +      grad_prob.col(0).array() *   prob[c].col(t+1).array()  )  )   ;
                   }

                   // then rest of terms
                   for (int i = 1; i < n_tests - 2; i++) { // i goes from 1 to 3

                             grad_prob.array()   = 0.0;
                             z_grad_term.array() = 0.0;

                             int t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)

                             z_grad_term.col(0) = (  phi_Z_recip.col(t-1).array())  *  prob[c].col(t-1).array() ;
                             grad_prob.col(0) =         y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t).array()   *   L_Omega_double[c](t, t - 1) *   z_grad_term.col(0).array() ; // lp(T-1) - part 2;

                             for (int ii = 0; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1 u_grad_z u_grad_term
                            //   if (ii == 0)    prod_container_or_inc_array  = (   (z_grad_term.block(0, 0, chunk_size, ii + 1) ) *  (fn_first_element_neg_rest_pos_colvec(L_Omega_double[c].col( t + (ii-1) + 1).segment(t - 1, ii + 1)))  )      ;
                               if (ii == 0)    prod_container_or_inc_array  = (   (z_grad_term.topLeftCorner(chunk_size, ii + 1) ) *  (fn_first_element_neg_rest_pos(L_Omega_double[c].row( t + (ii-1) + 1).segment(t - 1, ii + 1))).transpose()  )      ;
                               z_grad_term.col(ii+1)  =           y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t + ii).array() *  -   prod_container_or_inc_array.array() ;
                             //  prod_container_or_inc_array  = (   (z_grad_term.block(0, 0, chunk_size, ii + 2) ) *  (fn_first_element_neg_rest_pos_colvec(L_Omega_double[c].col( t + (ii) + 1).segment(t - 1, ii + 2)))   )      ;
                               prod_container_or_inc_array  = (   (z_grad_term.topLeftCorner(chunk_size, ii + 2) ) *  (fn_first_element_neg_rest_pos(L_Omega_double[c].row( t + (ii) + 1).segment(t - 1, ii + 2))).transpose()  )      ;
                               grad_prob.col(ii+1)  =       (    y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t+ii+1).array()  ) *     -    prod_container_or_inc_array.array()  ;
                             } // end of ii loop

                             {
                               derivs_chain_container_vec.array() = 0.0;

                               for (int ii = 0; ii < i + 2; ii++) {
                                 derivs_chain_container_vec.array()  +=  ( grad_prob.col(ii).array()    * (       prop_rowwise_prod_temp.col(t).array() /   prob[c].col(t + ii).array()  ).array() ).array()  ;
                               }
                             u_grad_array_CM_chunk.col(n_tests - (i+3)).array()    +=   (  ( (   common_grad_term_1.col(t).array()   *  derivs_chain_container_vec.array() ) ).array()  ).array() ;
                             }

                   }


                    out_mat.segment(1, n_us).segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)  =  u_grad_array_CM_chunk.reshaped() ; //   u_grad_array_CM.block(chunk_size * chunk_counter, 0, chunk_size, n_tests).reshaped() ; // .cast<float>()     ;         }

             }

             // /////////////////////////////////////////////////////////////////////////// Grad of intercepts / coefficients (beta's)
             // ///// last term first (test T)

             {

               int t = n_tests - 1;

               beta_grad_array(c, t) +=     (common_grad_term_1.col(t).array()  *   (  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t).array()    )).sum();

               ///// then second-to-last term (test T - 1)
               {
                 t = n_tests - 2;
                 grad_prob.col(0) =       (     y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t).array()   ) ;
                 z_grad_term.col(0)   =     - y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t).array()         ;
                 grad_prob.col(1)  =       (  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t+1).array()    )   * (   L_Omega_double[c](t + 1,t) *      z_grad_term.col(0).array() ) ;
                 beta_grad_array(c, t) +=  (common_grad_term_1.col(t).array()   * ( grad_prob.col(1).array() *  prob[c].col(t).array() +         grad_prob.col(0).array() *   prob[c].col(t+1).array() ) ).sum() ;
               }

               // then rest of terms
               for (int i = 1; i < n_tests - 1; i++) { // i goes from 1 to 3

                 t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)

                 grad_prob.col(0)  =     y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t).array()   ;

                 // component 2 (second-to-earliest test)
                 z_grad_term.col(0)  =        -y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t).array()       ;
                 grad_prob.col(1) =        y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t + 1).array()    *    (   L_Omega_double[c](t + 1,t) *   z_grad_term.col(0).array() ) ;

                 // rest of components
                 for (int ii = 1; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1
                           // if (ii == 1)  prod_container_or_inc_array  = (    z_grad_term.block(0, 1, chunk_size, ii)  *   L_Omega_double[c].col( t + (ii - 1) + 1).segment(t + 0, ii + 0)  );
                           //  if (ii == 1)  prod_container_or_inc_array  = (    z_grad_term.block(0, 1, chunk_size, ii)  *   L_Omega_double[c].row( t + (ii - 1) + 1).segment(t + 0, ii + 0).transpose()  );
                            if (ii == 1)  prod_container_or_inc_array  = (    z_grad_term.topLeftCorner(chunk_size, ii)  *   L_Omega_double[c].row( t + (ii - 1) + 1).segment(t + 0, ii + 0).transpose()  );
                           z_grad_term.col(ii)  =        -y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t + ii).array()    *   prod_container_or_inc_array.array();
                        //    prod_container_or_inc_array  = (    z_grad_term.block(0, 1, chunk_size, ii + 1)  *   L_Omega_double[c].col( t + (ii) + 1).segment(t + 0, ii + 1)   );
                            prod_container_or_inc_array  = (    z_grad_term.topLeftCorner(chunk_size, ii + 1)  *   L_Omega_double[c].row( t + (ii) + 1).segment(t + 0, ii + 1).transpose()  );
                         //  prod_container_or_inc_array  = (    z_grad_term.block(0, 1, chunk_size, ii + 1)  *   L_Omega_double[c].row( t + (ii) + 1).segment(t + 0, ii + 1).transpose()  );
                         grad_prob.col(ii + 1) =      (   y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t + ii + 1).array()  ).array()     *  prod_container_or_inc_array.array();
                 }

                 {
                   derivs_chain_container_vec.array() = 0.0;

                   ///// attempt at vectorising  // bookmark
                   for (int ii = 0; ii < i + 2; ii++) {
                     derivs_chain_container_vec.array() +=  ( grad_prob.col(ii).array()  * (      prop_rowwise_prod_temp.col(t).array() /   prob[c].col(t + ii).array()  ).array() ).array() ;
                   }
                   beta_grad_array(c, t) +=        ( common_grad_term_1.col(t).array()   *  derivs_chain_container_vec.array() ).sum();
                 }

               }

             }



             ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grad of L_Omega ('s)
             {
               {
                 ///////////////////////// deriv of diagonal elements (not needed if using the "standard" or "Stan" Cholesky parameterisation of Omega)

                 //////// w.r.t last diagonal first
                 {
                   int  t1 = n_tests - 1;

                   U_Omega_grad_array[c](t1, t1) +=   ( common_grad_term_1.col(t1).array()   *   y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array()  *   Bound_Z[c].col(t1).array()       ).sum() ;
                 }


                 //////// then w.r.t the second-to-last diagonal
                 int  t1 = n_tests - 2;
                 grad_prob.col(0).array()  =         y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array() *     Bound_Z[c].col(t1).array()     ;     // correct  (standard form)
                 z_grad_term.col(0).array()  =      (   - y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t1).array()  )    *  Bound_Z[c].col(t1).array()    ;  // correct

                 prod_container_or_inc_array.array()  =   (  L_Omega_double[c](t1 + 1, t1)    *   z_grad_term.col(0).array()   ) ; // sequence
                 grad_prob.col(1).array()  =   y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1 + 1).array()   *          prod_container_or_inc_array.array()      ;    // correct   (standard form)

                 U_Omega_grad_array[c](t1, t1) +=   ( (   common_grad_term_1.col(t1).array() )     *    (  prob[c].col(t1 + 1).array()  *   grad_prob.col(0).array()  +    prob[c].col(t1).array()  *      grad_prob.col(1).array()   )  ).sum()   ;

               }

               // //////// then w.r.t the third-to-last diagonal .... etc
               {

                 for (int i = 3; i < n_tests + 1; i++) {

                   int  t1 = n_tests - i;

                   //////// 1st component
                   // 1st grad_Z term and 1st grad_prob term (simplest terms)
                   grad_prob.col(0).array()  =   (  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array() )  *  ( Bound_Z[c].col(t1).array()   ).array()  ; // correct  (standard form)
                   z_grad_term.col(0).array()  =    ( -y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t1).array()  )  *  Bound_Z[c].col(t1).array()       ;   // correct  (standard form)

                   // 2nd   grad_Z term and 2nd grad_prob  (more complicated than 1st term)
                   prod_container_or_inc_array.array() =    L_Omega_double[c](t1 + 1, t1)   * z_grad_term.col(0).array()  ; // correct  (standard form)
                   grad_prob.col(1).array()  =   (  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1 + 1).array()  )   *  (    prod_container_or_inc_array.array() ).array()  ; // correct  (standard form)


                   for (int ii = 1; ii < i - 1; ii++) {
                     z_grad_term.col(ii).array()  =     (- y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t1 + ii).array()  )    *   prod_container_or_inc_array.array()   ;   // correct  (standard form)       // grad_z term
                     ////////// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    //  prod_container_or_inc_array.matrix() =   (  L_Omega_double[c].row(t1 + ii + 1).segment(t1, ii + 1) *   z_grad_term.block(0, 0, chunk_size, ii + 1).transpose() ).transpose().matrix(); ////////// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                     prod_container_or_inc_array.matrix() =   (  L_Omega_double[c].row(t1 + ii + 1).segment(t1, ii + 1) *   z_grad_term.topLeftCorner(chunk_size, ii + 1).transpose() ).transpose().matrix(); // correct  (standard form)
                     ////////// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                     grad_prob.col(ii + 1).array()  =    y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1 + ii + 1).array()    *    prod_container_or_inc_array.array()  ;  // correct  (standard form)     //    grad_prob term
                   }

                   {

                     derivs_chain_container_vec.array() = 0.0;

                     ///// attempt at vectorising  // bookmark
                     for (int iii = 0; iii <  i; iii++) {
                       derivs_chain_container_vec.array()  +=    grad_prob.col(iii).array()  * (       prop_rowwise_prod_temp.col(t1).array()    /   prob[c].col(t1 + iii).array()  ).array()  ;  // correct  (standard form)
                     }

                     U_Omega_grad_array[c](t1, t1)   +=       ( common_grad_term_1.col(t1).array()   * derivs_chain_container_vec.array() ).sum()  ; // correct  (standard form)
                   }

                 }



               }

             }






             {

               z_grad_term.array() = 0 ;
               grad_prob.array() = 0;


               { ///////////////////// last row first
                 int t1_dash = 0;  // t1 = n_tests - 1

                 int t1 = n_tests - (t1_dash + 1); //  starts at n_tests - 1;  // if t1_dash = 0 -> t1 = T - 1
                 int t2 = n_tests - (t1_dash + 2); //  starts at n_tests - 2;

                 U_Omega_grad_array[c](t1, t2) +=        (  common_grad_term_1.col(t1).array()      *  (  - y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array()   )     *  ( -  Z_std_norm[c].col(t2).array()  )  ).sum() ;

                 if (t1 > 1) { // starts at  L_{T, T-2}
                   {
                     t2 =   n_tests - (t1_dash + 3); // starts at n_tests - 3;
                     U_Omega_grad_array[c](t1, t2) +=     (  common_grad_term_1.col(t1).array()  *   (  - y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array()    )   *     (  - Z_std_norm[c].col(t2).array()   ) ).sum()  ;
                   }
                 }

                 if (t1 > 2) {// starts at  L_{T, T-3}
                   for (int t2_dash = 3; t2_dash < n_tests; t2_dash++ ) { // t2 < t1
                     t2 = n_tests - (t1_dash + t2_dash + 1); // starts at T - 4
                     if (t2 < n_tests - 1) {
                       U_Omega_grad_array[c](t1, t2)  +=   (  common_grad_term_1.col(t1).array() *   (  - y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array()    )  *   (      - Z_std_norm[c].col(t2).array()  )  ).sum() ;
                     }
                   }
                 }
               }
             }




             {
               /////////////////// then rest of rows (second-to-last row, then third-to-last row, .... , then first row)
               for (int t1_dash = 1; t1_dash <  n_tests - 1;  t1_dash++) {
                 int  t1 = n_tests - (t1_dash + 1);

                 for (int t2_dash = t1_dash + 1; t2_dash <  n_tests;  t2_dash++) {
                   int t2 = n_tests - (t2_dash + 1); // starts at t1 - 1, then t1 - 2, up to 0


                   {


                     //prod_container_or_inc_array.array()  =  Z_std_norm[c].block(0, t2, chunk_size, t1 - t2) * deriv_L_t1.head(t1 - t2) ;
                     prod_container_or_inc_array.array()  =  Z_std_norm[c].col(t2) ; // block(0, t2, chunk_size, t1 - t2) * deriv_L_t1.head(t1 - t2) ;
                     grad_prob.col(0) =       y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array()   *           prod_container_or_inc_array.array()   ;
                     z_grad_term.col(0).array()  =                 y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t1).array()     *   (   -    prod_container_or_inc_array.array()     )      ;

                     if (t1_dash > 0) {
                       for (int t1_dash_dash = 1; t1_dash_dash <  t1_dash + 1;  t1_dash_dash++) {
                         if (t1_dash_dash > 1) {
                           z_grad_term.col(t1_dash_dash - 1)   =           y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t1 + t1_dash_dash - 1).array()   *  ( - prod_container_or_inc_array.array() )    ;
                         }
                       //   prod_container_or_inc_array.array()  =            (   z_grad_term.block(0, 0, chunk_size, t1_dash_dash) *   L_Omega_double[c].col(t1 + t1_dash_dash).segment(t1, t1_dash_dash)    ) ;
                         prod_container_or_inc_array.array()  =            (   z_grad_term.topLeftCorner(chunk_size, t1_dash_dash) *   L_Omega_double[c].row(t1 + t1_dash_dash).segment(t1, t1_dash_dash).transpose()   ) ;
                         // prod_container_or_inc_array.array()  =            (   z_grad_term.block(0, 0, chunk_size, t1_dash_dash) *   L_Omega_double[c].row(t1 + t1_dash_dash).segment(t1, t1_dash_dash).transpose()   ) ;
                         grad_prob.col(t1_dash_dash)  =             y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1 + t1_dash_dash).array()    *      prod_container_or_inc_array.array()  ;
                       }
                     }

                     {

                       derivs_chain_container_vec.array() = 0.0;

                       ///// attempt at vectorising  // bookmark
                       for (int ii = 0; ii <  t1_dash + 1; ii++) {
                         derivs_chain_container_vec.array() += ( grad_prob.col(ii).array()  * ( prop_rowwise_prod_temp.col(t1).array()     /   prob[c].col(t1 + ii).array()  ).array() ).array() ; // correct i think
                       }
                       U_Omega_grad_array[c](t1, t2)   +=       ( common_grad_term_1.col(t1).array()   * derivs_chain_container_vec.array() ).sum()  ; // correct  (standard form)

                     }



                   }
                 }
               }

             }


             prev_grad_vec(c)  +=  ( ( 1.0 / prob_n.array() ) *  prob[c].rowwise().prod().array() ).matrix().sum()  ;




         }

     //  }



     }

     }





     //////////////////////// gradients for latent class membership probabilitie(s) (i.e. disease prevalence)
     for (int c = 0; c < n_class; c++) {
       prev_unconstrained_grad_vec(c)  =   prev_grad_vec(c)   * deriv_p_wrt_pu_double ;
     }
     prev_unconstrained_grad_vec(0) = prev_unconstrained_grad_vec(1) - prev_unconstrained_grad_vec(0) - 2 * tanh_u_prev[1];
     prev_unconstrained_grad_vec_out(0) = prev_unconstrained_grad_vec(0);


      // log_prob_out += log_lik.sum();
       log_prob_out += out_mat.segment(1 + n_params, N).sum();

     if (exclude_priors == false)  log_prob_out += prior_densities;

     log_prob_out +=  log_jac_u;

     log_prob = (double) log_prob_out;

     int i = 0; // probs_all_range.prod() cancels out
     for (int c = 0; c < n_class; c++) {
       for (int t = 0; t < n_tests; t++) {
         if (exclude_priors == false) {
           beta_grad_array(c, t) +=  - ((beta_double_array(c,t) - prior_coeffs_mean(c, t)) / prior_coeffs_sd(c, t) ) * (1.0/ prior_coeffs_sd(c, t) ) ;     // add normal prior density derivative to gradient
         }
         beta_grad_vec(i) = beta_grad_array(c, t);
         i += 1;
       }
     }




     {
       int i = 0;
       for (int c = 0; c < n_class; c++ ) {
         for (int t1 = 0; t1 < n_tests  ; t1++ ) {
          for (int t2 = 0; t2 <  t1 + 1; t2++ ) {
             L_Omega_grad_vec(i) = U_Omega_grad_array[c](t1,t2);
             i += 1;
           }
         }
       }
     }



     Eigen::Matrix<double, -1, 1>  grad_wrt_L_Omega_nd =   L_Omega_grad_vec.segment(0, dim_choose_2 + n_tests);
     Eigen::Matrix<double, -1, 1>  grad_wrt_L_Omega_d =   L_Omega_grad_vec.segment(dim_choose_2 + n_tests, dim_choose_2 + n_tests);

     U_Omega_grad_vec.segment(0, dim_choose_2) =  ( grad_wrt_L_Omega_nd.transpose()  *  deriv_L_wrt_unc_full[0].cast<double>() ).transpose() ;
     U_Omega_grad_vec.segment(dim_choose_2, dim_choose_2) =   ( grad_wrt_L_Omega_d.transpose()  *  deriv_L_wrt_unc_full[1].cast<double>() ).transpose()  ;





   }




   {

   ////////////////////////////  outputs // add log grad and sign stuff';///////////////
   out_mat(0) =  log_prob;
   out_mat.segment(1 + n_us, n_corrs) = target_AD_grad ;          // .cast<float>();
   out_mat.segment(1 + n_us, n_corrs) += U_Omega_grad_vec ;        //.cast<float>()  ;
   out_mat.segment(1 + n_us + n_corrs, n_coeffs) = beta_grad_vec ; //.cast<float>() ;
   out_mat(n_params) = ((grad_prev_AD +  prev_unconstrained_grad_vec_out(0)));

   if   (tanh_option < 5)  out_mat.segment(1, n_us).array() =     (  out_mat.segment(1, n_us).array() *  ( 0.5 * (1.0 - theta_us.array() * theta_us.array()  )  )   ).array()    - 2.0 * theta_us.array()   ;
   else                    out_mat.segment(1, n_us).array() =     (  out_mat.segment(1, n_us).array() *  (  (    (1.0 -  theta_us.array())*theta_us.array()  ) ) ).array()       - 1.0  ;  // inverse logit


   }

   return(out_mat);


 }



//  
//  
//  
// 
// //  
// //  
//
//  //
//  //
//  //
//  //
//
//
//  // [[Rcpp::export]]
//  Eigen::Matrix<double, -1, 1 >    fn_wo_list_log_posterior_and_gradient_Chol_Schur_MD_and_AD_4(  int n_cores,
//                                                                                                  Eigen::Matrix<double, -1, 1  > theta_main,
//                                                                                                  Eigen::Matrix<double, -1, 1  > theta_us,
//                                                                                                  Eigen::Matrix<int, -1, -1>	 y,
//                                                                                                  std::vector<Eigen::Matrix<double, -1, -1 > >  X,
//                                                                                                  bool exclude_priors,
//                                                                                                  bool CI,
//                                                                                                  Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
//                                                                                                  Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
//                                                                                                  Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
//                                                                                                  int n_class, // 10
//                                                                                                  int n_tests,
//                                                                                                  int ub_threshold_phi_approx,
//                                                                                                  int n_chunks,
//                                                                                                  bool corr_force_positive,
//                                                                                                  std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
//                                                                                                  std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
//                                                                                                  bool corr_prior_beta ,
//                                                                                                  bool corr_prior_norm ,
//                                                                                                  std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
//                                                                                                  std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr, // 20
//                                                                                                  std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
//                                                                                                  std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
//                                                                                                  double prev_prior_a,
//                                                                                                  double prev_prior_b,
//                                                                                                  int Phi_type,
//                                                                                                  int tanh_option,
//                                                                                                  bool approx_exp_and_log_for_log_lik,
//                                                                                                  bool approx_exp_and_log_for_grad
//
//
//  ) {
//
//
//
//    int N = y.cols();
//    int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
//    int n_coeffs = n_class * n_tests * 1;
//    int n_us =  1 *  N * n_tests;
//
//    int n_params = theta_us.rows() +  theta_main.rows()   ; // n_corrs + n_coeffs + n_us + n_class;
//    int n_params_main = n_params - n_us;
//
//
//
//
//    // corrs
//    Eigen::Matrix<double, -1, 1  >  Omega_raw_vec_double = theta_main.segment(0, n_corrs); // .cast<double>();
//
//    Eigen::Matrix<stan::math::var, -1, 1  >  Omega_raw_vec_var =  stan::math::to_var(Omega_raw_vec_double) ;
//    Eigen::Matrix<stan::math::var, -1, 1  >  Omega_constrained_raw_vec_var =  Eigen::Matrix<stan::math::var, -1, 1  >::Zero(n_corrs) ;
//
//    Omega_constrained_raw_vec_var = ( (Omega_raw_vec_var)); // no transformation for Nump needed! done later on
//
//
//
//    // coeffs
//    Eigen::Matrix<double, -1, -1  > beta_double_array(n_class, n_tests);
//
//    {
//      int i = 0 + n_corrs;
//      for (int c = 0; c < n_class; ++c) {
//        for (int t = 0; t < n_tests; ++t) {
//          beta_double_array(c, t) = theta_main(i);
//          i = i + 1;
//        }
//      }
//    }
//
//
//    // prev
//    double u_prev_diseased = theta_main(n_params_main - 1);
//
//
//
//    Eigen::Matrix<double, -1, 1 >  target_AD_grad(n_corrs);
//
//
//    int dim_choose_2 = n_tests * (n_tests - 1) * 0.5 ;
//
//    stan::math::var target_AD = 0.0;
//    double grad_prev_AD = 0;
//
//    std::vector<Eigen::Matrix<double, -1, -1 > > L_Omega_double = vec_of_mats_test(n_tests, n_tests, n_class);
//    std::vector<Eigen::Matrix<double, -1, -1 > > deriv_L_wrt_unc_full = vec_of_mats_test(dim_choose_2 + n_tests, dim_choose_2, n_class);
//
//
//    {
//
//
//      std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > Omega_unconstrained_var = fn_convert_std_vec_of_corrs_to_3d_array_var( eigen_vec_to_std_vec_var(Omega_constrained_raw_vec_var),
//                                                                                                                                   n_tests,
//                                                                                                                                   n_class);
//
//
//      std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > L_Omega_var_copy = vec_of_mats_test_var(n_tests, n_tests, n_class);
//      std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  Omega_var_copy  = vec_of_mats_test_var(n_tests, n_tests, n_class);
//
//      for (int c = 0; c < n_class; ++c) {
//        Eigen::Matrix<stan::math::var, -1, -1 >  ub = stan::math::to_var(ub_corr[c]);
//        Eigen::Matrix<stan::math::var, -1, -1 >  lb = stan::math::to_var(lb_corr[c]);
//
//        Eigen::Matrix<stan::math::var, -1, -1  >  Chol_Schur_outs =  Spinkney_LDL_bounds_opt(n_tests, lb, ub, Omega_unconstrained_var[c], known_values_indicator[c], known_values[c]) ; //   Omega_unconstrained_var[c], n_tests, tol )  ;
//
//        L_Omega_var_copy[c]   =  Chol_Schur_outs.block(1, 0, n_tests, n_tests);
//        Omega_var_copy[c] =   L_Omega_var_copy[c] * L_Omega_var_copy[c].transpose() ;
//
//
//        target_AD +=   Chol_Schur_outs(0, 0); // now can set prior directly on Omega
//      }
//
//
//
//      for (int c = 0; c < n_class; ++c) {
//        if ( (corr_prior_beta == false)   &&  (corr_prior_norm == false) ) {
//          target_AD +=  stan::math::lkj_corr_cholesky_lpdf(L_Omega_var_copy[c], lkj_cholesky_eta(c)) ;
//        } else if ( (corr_prior_beta == true)   &&  (corr_prior_norm == false) ) {
//          for (int i = 1; i < n_tests; i++) {
//            for (int j = 0; j < i; j++) {
//              target_AD +=  stan::math::beta_lpdf(  (Omega_var_copy[c](i, j) + 1)/2, prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
//            }
//          }
//          //  Jacobian for  Omega -> L_Omega transformation for prior log-densities (since both LKJ and truncated normal prior densities are in terms of Omega, not L_Omega)
//          Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
//          for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * log(L_Omega_var_copy[c](i, i));
//          target_AD  += + (n_tests * stan::math::log(2) + jacobian_diag_elements.sum());  //  L -> Omega
//        } else if  ( (corr_prior_beta == false)   &&  (corr_prior_norm == true) ) {
//          for (int i = 1; i < n_tests; i++) {
//            for (int j = 0; j < i; j++) {
//              target_AD +=  stan::math::normal_lpdf(  Omega_var_copy[c](i, j), prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
//            }
//          }
//          Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
//          for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * log(L_Omega_var_copy[c](i, i));
//          target_AD  += + (n_tests * stan::math::log(2) + jacobian_diag_elements.sum());  //  L -> Omega
//        }
//      }
//
//
//      ///////////////////////
//      stan::math::set_zero_all_adjoints();
//      target_AD.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
//      target_AD_grad =  Omega_raw_vec_var.adj();    // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
//      stan::math::set_zero_all_adjoints();
//      //////////////////////////////////////////////////////////// end of AD part
//
//
//
//      /////////////  prev stuff  ---- vars
//      std::vector<stan::math::var> 	 u_prev_var_vec_var(n_class, 0.0);
//      std::vector<stan::math::var> 	 prev_var_vec_var(n_class, 0.0);
//      std::vector<stan::math::var> 	 tanh_u_prev_var(n_class, 0.0);
//      Eigen::Matrix<stan::math::var, -1, -1>	 prev_var(1, n_class);
//
//      u_prev_var_vec_var[1] =  stan::math::to_var(u_prev_diseased);
//      tanh_u_prev_var[1] = ( exp(2*u_prev_var_vec_var[1] ) - 1) / ( exp(2*u_prev_var_vec_var[1] ) + 1) ;
//      u_prev_var_vec_var[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1) ) )  ;
//      tanh_u_prev_var[0] = (exp(2*u_prev_var_vec_var[0] ) - 1) / ( exp(2*u_prev_var_vec_var[0] ) + 1) ;
//
//      prev_var_vec_var[1] = 0.5 * ( tanh_u_prev_var[1] + 1);
//      prev_var_vec_var[0] =  0.5 * ( tanh_u_prev_var[0] + 1);
//      prev_var(0,1) =  prev_var_vec_var[1];
//      prev_var(0,0) =  prev_var_vec_var[0];
//
//      stan::math::var tanh_pu_deriv_var = ( 1 - tanh_u_prev_var[1] * tanh_u_prev_var[1]  );
//      stan::math::var deriv_p_wrt_pu_var = 0.5 *  tanh_pu_deriv_var;
//      stan::math::var tanh_pu_second_deriv_var  = -2 * tanh_u_prev_var[1]  * tanh_pu_deriv_var;
//      stan::math::var log_jac_p_deriv_wrt_pu_var  = ( 1 / deriv_p_wrt_pu_var) * 0.5 * tanh_pu_second_deriv_var; // for gradient of u's
//      stan::math::var  log_jac_p_var =    log( deriv_p_wrt_pu_var );
//
//
//      stan::math::var  target_AD_prev = beta_lpdf(  prev_var(0,1), prev_prior_a, prev_prior_b  ); // weakly informative prior - helps avoid boundaries with slight negative skew (for lower N)
//      target_AD_prev += log_jac_p_var;
//
//      target_AD  +=  target_AD_prev;
//
//      ///////////////////////
//      target_AD_prev.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
//      grad_prev_AD  =  u_prev_var_vec_var[1].adj() - u_prev_var_vec_var[0].adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
//      stan::math::set_zero_all_adjoints();
//      //////////////////////////////////////////////////////////// end of AD part
//
//
//
//
//      for (int c = 0; c < n_class; ++c) {
//        int cnt_1 = 0;
//        for (int k = 0; k < n_tests; k++) {
//          for (int l = 0; l < k + 1; l++) {
//            (  L_Omega_var_copy[c](k, l)).grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
//            int cnt_2 = 0;
//            for (int i = 1; i < n_tests; i++) {
//              for (int j = 0; j < i; j++) {
//                deriv_L_wrt_unc_full[c](cnt_1, cnt_2)  =   Omega_unconstrained_var[c](i, j).adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
//                cnt_2 += 1;
//              }
//            }
//            stan::math::set_zero_all_adjoints();
//            cnt_1 += 1;
//          }
//        }
//      }
//
//
//      ///////////////// get cholesky factor's (lower-triangular) of corr matrices
//      // convert to 3d var array
//
//      for (int c = 0; c < n_class; ++c) {
//        for (int t1 = 0; t1 < n_tests; ++t1) {
//          for (int t2 = 0; t2 < n_tests; ++t2) {
//            L_Omega_double[c](t1, t2) =   L_Omega_var_copy[c](t1, t2).val()  ;
//          }
//        }
//      }
//
//      stan::math::recover_memory();
//    }
//
//
//    /////////////  prev stuff
//    std::vector<double> 	 u_prev_var_vec(n_class, 0.0);
//    std::vector<double> 	 prev_var_vec(n_class, 0.0);
//    std::vector<double> 	 tanh_u_prev(n_class, 0.0);
//    Eigen::Matrix<double, -1, -1>	 prev(1, n_class);
//
//    u_prev_var_vec[1] =  (double) u_prev_diseased ;
//    tanh_u_prev[1] = ( exp(2*u_prev_var_vec[1] ) - 1) / ( exp(2*u_prev_var_vec[1] ) + 1) ;
//    u_prev_var_vec[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) )  ;
//    tanh_u_prev[0] = (exp(2*u_prev_var_vec[0] ) - 1) / ( exp(2*u_prev_var_vec[0] ) + 1) ;
//
//    prev_var_vec[1] = 0.5 * ( tanh_u_prev[1] + 1);
//    prev_var_vec[0] =  0.5 * ( tanh_u_prev[0] + 1);
//    prev(0,1) =  prev_var_vec[1];
//    prev(0,0) =  prev_var_vec[0];
//
//
//    double tanh_pu_deriv = ( 1 - tanh_u_prev[1] * tanh_u_prev[1]  );
//    double deriv_p_wrt_pu_double = 0.5 *  tanh_pu_deriv;
//    double tanh_pu_second_deriv  = -2 * tanh_u_prev[1]  * tanh_pu_deriv;
//    double log_jac_p_deriv_wrt_pu  = ( 1 / deriv_p_wrt_pu_double) * 0.5 * tanh_pu_second_deriv; // for gradient of u's
//    double  log_jac_p =    log( deriv_p_wrt_pu_double );
//
//
//
//    ///////////////////////////////////////////////////////////////////////// prior densities
//    double prior_densities = 0.0;
//
//
//    if (exclude_priors == false) {
//      ///////////////////// priors for coeffs
//      double prior_densities_coeffs = 0.0;
//      for (int c = 0; c < n_class; c++) {
//        for (int t = 0; t < n_tests; t++) {
//          double num_1 = 0.9189385;
//          prior_densities_coeffs  +=  - num_1 - log(prior_coeffs_sd(t,c)) - 0.5 * ( (beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) *   ( (beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) )  ;
//        }
//      }
//      double prior_densities_corrs = target_AD.val();
//      prior_densities = prior_densities_coeffs  +      prior_densities_corrs ;     // total prior densities and Jacobian adjustments
//    }
//
//
//    /////////////////////////////////////////////////////////////////////////////////////////////////////
//    ///////// likelihood
//    double s = 1/1.702;
//
//    int chunk_counter = 0;
//    int chunk_size  = std::round( N / n_chunks  / 2) * 2;  ; // N / n_chunks;
//
//
//    double log_prob_out = 0.0;
//
//
//    Eigen::Matrix<double, -1, -1 >  log_prev = prev;
//
//    for (int c = 0; c < n_class; c++) {
//      log_prev(0,c) =  log(prev(0,c));
//      for (int t = 0; t < n_tests; t++) {
//        if (CI == true)      L_Omega_double[c](t,t) = 1;
//      }
//    }
//
//    if (tanh_option == 1) theta_us.array() =      theta_us.array().tanh() ;  // this works
//    if (tanh_option == 2) theta_us.array() =      tanh_2_Eigen( theta_us ).array();
//    if (tanh_option == 3) theta_us.array() =      fast_tanh_approx_1_Eigen( theta_us ).array();
//    if (tanh_option == 4) theta_us.array() =      fast_tanh_approx_2_Eigen( theta_us ).array(); // seems to work  ?!?!
//    if (tanh_option == 5) theta_us.array() =      fast_inv_logit_1_eigen( theta_us.array() ).array();  // inv_logit
//    if (tanh_option == 6) theta_us.array() =      stan::math::inv_logit( theta_us  ).array();  // inv_logit
//
//
//    double log_jac_u  =  0 ;
//    if  ( (Phi_type == 3) ||     (approx_exp_and_log_for_log_lik == true)  ) {  // most stable
//      if   (tanh_option < 5)  log_jac_u  =    (  fast_log_0_Eigen( 0.5 *   (  1 -  ( theta_us.array()   *  theta_us.array()   ).array()  ).array()  ).array()   ).matrix().sum();  // log
//      else                    log_jac_u  =    fast_log_0_Eigen(   (1 -  theta_us.array())*theta_us.array()  ).matrix().sum();
//    } else {
//      if   (tanh_option < 5)  log_jac_u  =    (  fast_log_1_Eigen( 0.5 *   (  1 -  ( theta_us.array()   *  theta_us.array()   ).array()  ).array()  ).array()   ).matrix().sum();  // log
//      else                    log_jac_u  =    fast_log_1_Eigen(   (1 -  theta_us.array())*theta_us.array()  ).matrix().sum();
//    }
//
//
//
//    ///////////////////////////////////////////////////////////////////////////////////////// output vec
//    Eigen::Matrix<double, 1, -1> out_mat    =  Eigen::Matrix<double, 1, -1>::Zero(n_params + 1 + N);  ////////////////////////////////////////////////
//    ///////////////////////////////////////////////////////////////////////////////////////////////////
//    Eigen::Matrix<double, 1, -1 >  log_lik   =   Eigen::Matrix<double, 1, -1>::Zero(N);   //////////////////////////////////////////////////
//    Eigen::Matrix<double , -1, 1>   beta_grad_vec   =  Eigen::Matrix<double, -1, 1>::Zero(n_coeffs);  //
//    Eigen::Matrix<double, -1, -1>   beta_grad_array  =  Eigen::Matrix<double, -1, -1>::Zero(2, n_tests); //
//    std::vector<Eigen::Matrix<double, -1, -1 > > U_Omega_grad_array =  vec_of_mats_test(n_tests, n_tests, 2); //
//    Eigen::Matrix<double, -1, 1 > L_Omega_grad_vec(n_corrs + (2 * n_tests)); //
//    Eigen::Matrix<double, -1, 1 > U_Omega_grad_vec(n_corrs); //
//    Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(2); //
//    Eigen::Matrix<double, -1, 1>  prev_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(2); //
//    Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec_out =   Eigen::Matrix<double, -1, 1>::Zero(2 - 1); //
//   // Eigen::Matrix<double, -1, -1> u_grad_array_CM   =  Eigen::Matrix<double, -1, -1>::Zero(N, n_tests);  ////////////////////////////////////////////////
//    // ///////////////////////////////////////////////
//    // ///////////////////////////////////////////////////////////////////////////////////////// output vec
//    // Eigen::Matrix<double, -1, 1> out_mat    =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N);  ///////////////////////////////////////////////
//    // ///////////////////////////////////////////////////////////////////////////////////////////////////
//
//    double log_prob = 0;
//
//
//    {
//
//
//      //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//      int iiii = 0;
//      int iiiiii = 0;
//
//      double sqrt_2_pi_recip =   1 / sqrt(2 * M_PI) ; //  0.3989422804;
//      double minus_sqrt_2_recip =  - 1 / stan::math::sqrt(2);
//      double sqrt_2_recip = 1 / stan::math::sqrt(2);
//      double a = 0.07056;
//      double b = 1.5976;
//
//
//      ///////////////////////////////////////////////
//      std::vector<Eigen::Matrix<double, -1, -1, Eigen::RowMajor > >  prob   = vec_of_mats_test_RM(n_tests, chunk_size, 2); //////////////////////////////
//      std::vector<Eigen::Matrix<double, -1, -1, Eigen::RowMajor > >  Z_std_norm =  vec_of_mats_test_RM(n_tests, chunk_size, 2); //////////////////////////////
//      std::vector<Eigen::Matrix<double, -1, -1, Eigen::RowMajor > >  Bound_Z =  vec_of_mats_test_RM(n_tests, chunk_size, 2); //////////////////////////////
//      std::vector<Eigen::Matrix<double, -1, -1, Eigen::RowMajor > >  Bound_U_Phi_Bound_Z =  vec_of_mats_test_RM(n_tests, chunk_size, 2); //////////////////////////////
//      std::vector<Eigen::Matrix<double, -1, -1, Eigen::RowMajor > >  Phi_Z =  vec_of_mats_test_RM(n_tests, chunk_size, 2); //////////////////////////////
//      ///////////////////////////////////////////////
//      Eigen::Matrix<double, -1, -1, Eigen::RowMajor> y1_or_phi_Bound_Z =  Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(n_tests, chunk_size);
//      Eigen::Matrix<double, -1, -1, Eigen::RowMajor> u_array = Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(n_tests, chunk_size);
//      ///////////////////////////////////////////////
//
//
//      {
//
//        Eigen::Matrix<double, -1, -1, Eigen::RowMajor>  inc_array  =  Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(2, chunk_size);
//
//        // fn_wo_list_log_posterior_and_gradient_Chol_Schur_MD_and_AD_3
//
//        for (int nc = 0; nc < n_chunks; nc++) {
//
//          int chunk_counter = nc;
//
//          if   (tanh_option < 5)   u_array.array() = 0.5 * (  theta_us.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).reshaped(n_tests, chunk_size).array() + 1 ).array() ;
//          else                     u_array.array() =   theta_us.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).reshaped(n_tests, chunk_size).array()   ;
//
//         for (int c = 0; c < n_class; c++) { //  VECTOR / ARRAY index
//
//            for (int t = 0; t < n_tests; t++) { // COLUMN index (loop through this AFTER c or BEFORE c????)
//               // rowwise
//
//                    Bound_Z[c].row(t).array() =   ( ((  - ( beta_double_array(c, t) +      inc_array.row(c).array()   )  ) / L_Omega_double[c](t, t) )  )  ;
//
//                    if (Phi_type == 4) {
//                      Bound_U_Phi_Bound_Z[c].row(t).array() = fast_inv_logit_1_eigen_rowvec( 1.702 * Bound_Z[c].row(t).array() ).array() ;
//                    } if (Phi_type == 3) {  // most stable but less acccurate
//                      Bound_U_Phi_Bound_Z[c].row(t).array() = stan::math::inv_logit( 1.702 * Bound_Z[c].row(t)  ).array() ;  // inv_logit_1_eigen
//                    } else if (Phi_type == 2) { // DEFAULT setting /  FIRST attempt
//                      Bound_U_Phi_Bound_Z[c].row(t).array()  =  fast_Phi_approx_1_eigen_rowvec( Bound_Z[c].row(t).array() ).array()  ;
//                    } else if (Phi_type == 1) {  // using EXACT inv_Phi (or close approx using approx exp/log)
//                      Bound_U_Phi_Bound_Z[c].row(t).array()  =  fast_Phi_approx_1_eigen_rowvec( Bound_Z[c].row(t).array() ).array()  ;
//                      // Phi_approx_1_eigen
//                      // fast_Phi_approx_1_eigen
//                    } else if (Phi_type == 0) {    // standard Phi
//                      Bound_U_Phi_Bound_Z[c].row(t).array() =    0.5 *  ( -  sqrt_2_recip * Bound_Z[c].row(t).array() ).erfc().array()  ; // Phi
//                    } else if (Phi_type == -1) {  // standard Phi
//                      Bound_U_Phi_Bound_Z[c].row(t).array() =    0.5 *  ( -  sqrt_2_recip * Bound_Z[c].row(t).array() ).erfc().array()  ; // Phi
//                    }
//                     // .block( 0, chunk_size * chunk_counter , n_tests , chunk_size   )
//
//                    Phi_Z[c].row(t).array()    =       (   y.row(t).segment(chunk_size * chunk_counter, chunk_size).array()  *          Bound_U_Phi_Bound_Z[c].row(t).array() +
//                                                        (  y.row(t).segment(chunk_size * chunk_counter, chunk_size).array()  -          Bound_U_Phi_Bound_Z[c].row(t).array() ) *   ( y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() +
//                                                        (  y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() - 1).array() ).row(t).array() * u_array.row(t).array()  ).array()   ;  //////// checked
//
//
//                    if (Phi_type == 4) {
//                      Z_std_norm[c].row(t).array() =   fast_logit_1_eigen_rowvec(    Phi_Z[c].row(t) ).array() / 1.702  ;
//                    } if (Phi_type == 3) {  // most stable but less accurate
//                      Z_std_norm[c].row(t).array() =    stan::math::logit(    Phi_Z[c].row(t) ).array() / 1.702  ; //  Eigen::Select(     stan::math::abs(Bound_Z[c].row(t).array()) < ub_threshold_phi_approx ,
//                    } else if (Phi_type == 2) { // using inv_Phi_approx
//                      Z_std_norm[c].row(t).array() =  fast_inv_Phi_approx_1_Eigen_rowvec( Phi_Z[c].row(t)).array()  ;
//                      // inv_Phi_approx
//                    } else if (Phi_type == 1) { // using EXACT inv_Phi (or close approx using approx exp/log)
//                      Z_std_norm[c].row(t).array() =  qnorm_w_fastlog_rcpp_rowvec( Phi_Z[c].row(t)).array()  ;
//                      // inv_Phi
//                      // qnorm_rcpp_vec
//                      // qnorm_w_fastlog_rcpp_vec
//                    } else if (Phi_type == 0) {  // standard Phi
//                      Z_std_norm[c].row(t).array() =  qnorm_w_fastlog_rcpp_rowvec(    Phi_Z[c].row(t) ).array()  ;
//                      // qnorm_w_fastlog_rcpp_vec
//                      // qnorm_rcpp_vec
//                    } else if (Phi_type == -1) {  // standard Phi
//                      Z_std_norm[c].row(t).array() =  qnorm_rcpp_rowvec(    Phi_Z[c].row(t) ).array()  ;   // EXACT inv_Phi
//                    }
//
//                    if (t < n_tests - 1)       inc_array.row(c).array()  =   (   L_Omega_double[c].row(t+1).head(t+1)   *   Z_std_norm[c].block(0, 0, t + 1, chunk_size)   ).array() ; //////// checked
//
//
//              } // end of c loop
//
//            } // end of t loop
//
//        } // end of chunks loop
//
//      }
//
//
//      {
//
//              Eigen::Matrix<double, -1, -1, Eigen::RowMajor>    lp_array  =  Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(2, chunk_size);
//
//              for (int nc = 0; nc < n_chunks; nc++) {
//
//                int chunk_counter = nc;
//
//                    for (int c = 0; c < n_class; c++) {
//
//                        if   (Phi_type == 3)    {
//                                y1_or_phi_Bound_Z.array() =  fast_log_0_Eigen_mat_RM(  y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() * ( 1 -    Bound_U_Phi_Bound_Z[c].array() ) +
//                                                                                    (  y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() - 1  ).array()   *    Bound_U_Phi_Bound_Z[c].array() *  ( y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() +
//                                                                                    (  y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() - 1).array() ).array() ).array() ; // .log() ;
//                                 prob[c].array() = fast_exp_0_Eigen_mat_RM(  y1_or_phi_Bound_Z.array() ).array() ; //    //   prob[c].array() =  y1_or_phi_Bound_Z.array().exp().array() ;
//                        } else {
//                                if (approx_exp_and_log_for_log_lik == true) {
//                                  y1_or_phi_Bound_Z.array() =  fast_log_1_Eigen_mat_RM(  y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() * ( 1 -    Bound_U_Phi_Bound_Z[c].array() ) +
//                                                                                      (  y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() - 1  ).array()   *    Bound_U_Phi_Bound_Z[c].array() *  ( y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() +
//                                                                                      (  y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() - 1).array() ).array() ).array() ; // .log() ;
//                                } else {
//                                  y1_or_phi_Bound_Z.array() =  fast_log_0_Eigen_mat_RM(  y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() * ( 1 -    Bound_U_Phi_Bound_Z[c].array() ) +
//                                                                                      (  y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() - 1  ).array()   *    Bound_U_Phi_Bound_Z[c].array() *  ( y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() +
//                                                                                      (  y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() - 1).array() ).array() ).array() ; // .log() ;
//                                }
//                                if (approx_exp_and_log_for_grad == true)    prob[c].array() = fast_exp_1_Eigen_mat_RM(  y1_or_phi_Bound_Z.array() ).array() ;
//                                if (approx_exp_and_log_for_grad == false)   prob[c].array() = fast_exp_0_Eigen_mat_RM(  y1_or_phi_Bound_Z.array() ).array() ;
//                        }
//
//                        lp_array.row(c).array() =    y1_or_phi_Bound_Z.colwise().sum().array() +  log_prev(0,c) ; // checcked
//
//
//                      } // end of c loop
//
//                    if  ( (Phi_type == 3) || (approx_exp_and_log_for_log_lik == false) )  {
//                      log_lik.segment(chunk_size * chunk_counter, chunk_size).array()   = (  lp_array.array().maxCoeff() +  fast_log_0_Eigen_rowvec(   fast_exp_0_Eigen_mat_RM(  (lp_array.array() - lp_array.array().maxCoeff() ).array()).matrix().colwise().sum().array())  )  ; // checcked  // log  exp  // .cast<float>()  ; // correct & stable
//                    } else {   // still use exacct exp and log for this part as cost is negligable and seems to not improve efficiency anyway (worse ESS/grad)
//                      log_lik.segment(chunk_size * chunk_counter, chunk_size).array()   = (  lp_array.array().maxCoeff() +  fast_log_0_Eigen_rowvec(   fast_exp_0_Eigen_mat_RM(  (lp_array.array() - lp_array.array().maxCoeff() ).array()).matrix().colwise().sum().array())  )  ;  // checcked  // log  exp  // .cast<float>()  ; // correct & stable
//                    }
//
//                } // end of chunks loop
//
//          }
//
//
//
//
//
//        Eigen::Matrix<double, 1, -1>      prob_n  =  Eigen::Matrix<double, 1, -1>::Zero(N);  //////////////////////////////////
//
//        if  ( (Phi_type == 3) || (approx_exp_and_log_for_log_lik == false) )  {
//            prob_n  =  fast_exp_0_Eigen_rowvec(log_lik.array()) ; // .segment(chunk_size * chunk_counter, chunk_size).array()) ; // .exp() ;  //   fast_exp_1_Eigen( log_lik.segment(chunk_size * chunk_counter, chunk_size).array() ).matrix() ; //
//        } else {   // still use exacct exp and log for this part as cost is negligable and seems to not improve efficiency anyway (worse ESS/grad)
//            prob_n  =  fast_exp_0_Eigen_rowvec(log_lik.array()) ; // .segment(chunk_size * chunk_counter, chunk_size).array()) ; // .exp() ;  //   fast_exp_1_Eigen( log_lik.segment(chunk_size * chunk_counter, chunk_size).array() ).matrix() ; //
//        }
//
//        for (int c = 0; c < n_class; c++) {
//            prev_grad_vec(c)  +=  ( ( 1 / prob_n.segment(chunk_size * chunk_counter, chunk_size).array() ) * prob[c].colwise().prod().array() ).matrix().sum()  ;   // prev grad first // checked
//        }
//
//
//
//        {
//
//
//
//      for (int c = 0; c < n_class; c++) {
//
//        ///////////////////////////////////////////////
//        Eigen::Matrix<double, -1, -1, Eigen::RowMajor>     grad_prob =  Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(n_tests, chunk_size);
//        Eigen::Matrix<double, -1, -1, Eigen::RowMajor>     z_grad_term = Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(n_tests, chunk_size);
//        ///////////////////////////////////////////////
//        Eigen::Matrix<double, -1, -1, Eigen::RowMajor>     phi_Z_recip  = Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(n_tests, chunk_size);
//        Eigen::Matrix<double, -1, -1, Eigen::RowMajor>     common_grad_term_1   =  Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(n_tests, chunk_size);
//        Eigen::Matrix<double, -1, -1 , Eigen::RowMajor>    L_Omega_diag_recip_array   =  Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(n_tests, chunk_size);
//        Eigen::Matrix<double, -1, -1 , Eigen::RowMajor>    y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip   =  Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(n_tests, chunk_size);
//        Eigen::Matrix<double, -1, -1 , Eigen::RowMajor>    y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip   =  Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(n_tests, chunk_size);
//        Eigen::Matrix<double, -1, -1 , Eigen::RowMajor>    prop_rowwise_prod_temp   =  Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(n_tests, chunk_size);
//        //   Eigen::Matrix<double, -1, -1 >    prop_rowwise_prod_temp_div_prob   =  Eigen::Matrix<double, -1, -1>::Zero(n_tests, chunk_size,);  // not tdone yet (will make ~ 3-4% faster)
//        // ///////////////////////////////////////////////
//        Eigen::Matrix<double, 1, -1>      derivs_chain_container_vec   =  Eigen::Matrix<double, 1, -1>::Zero(chunk_size);
//        Eigen::Matrix<double, 1, -1>      prop_rowwise_prod_temp_all   =  Eigen::Matrix<double, 1, -1>::Zero(chunk_size);
//        Eigen::Matrix<double, 1, -1>      prod_container_or_inc_array  =  Eigen::Matrix<double, 1, -1>::Zero(chunk_size);
//        // ///////////////////////////////////////////////
//
//
//        for (int nc = 0; nc < n_chunks; nc++) {
//
//
//          int chunk_counter = nc;
//
//
//          {
//
//              for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
//                int t = n_tests - (i+1) ;
//                prop_rowwise_prod_temp.row(t).array()   =   prob[c].block(0, t + 0, i + 1, chunk_size).colwise().prod().array() ;
//              }
//
//              prop_rowwise_prod_temp_all.array() = prob[c].block(0, 0, n_tests, chunk_size).colwise().prod().array()  ;
//
//              for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
//                int t = n_tests - (i + 1) ;
//                common_grad_term_1.row(t) =   (  ( prev(0,c) / prob_n.segment(chunk_size * chunk_counter, chunk_size).array().array() ) * (    prop_rowwise_prod_temp_all.array() /  prop_rowwise_prod_temp.row(t).array()  ).array() )  ;
//              }
//
//
//              // for (int i = 1; i < n_tests - 2; i++) { // i goes from 1 to 3
//              //   int t = n_tests - (i+2) ;
//              //   //  prop_rowwise_prod_temp_div_prob.row(t).array()   = 0;
//              //   for (int ii = 0; ii < i + 2; ii++) {
//              //     prop_rowwise_prod_temp_div_prob.row(t).array()  =   (    prop_rowwise_prod_temp.row(t).array() /  prob[c].row(t + ii).array()  ).array()    ;
//              //   }
//              // }
//
//              for (int t = 0; t < n_tests; t++) {
//                L_Omega_diag_recip_array.row(t).array() = (1 / L_Omega_double[c](t,t)  ) ;
//              }
//
//              if (  (Phi_type == 3) ||  (Phi_type == 4)  ) {
//                y1_or_phi_Bound_Z.array() =                 1.702 *  Bound_U_Phi_Bound_Z[c].array() * (1 -  Bound_U_Phi_Bound_Z[c].array() )   ;
//              } else if (Phi_type == 2) {  // using inv_Phi_approx
//                y1_or_phi_Bound_Z.array() =                (  (    (  3*a*Bound_Z[c].array()*Bound_Z[c].array()   + b  ).array()  ).array() )  *  Bound_U_Phi_Bound_Z[c].array() * (1 -  Bound_U_Phi_Bound_Z[c].array() )   ;
//              } else if (Phi_type == 1) {  // using EXACT inv_Phi (or close approx using approx exp/log)
//                y1_or_phi_Bound_Z.array() =                (  (    (  3*a*Bound_Z[c].array()*Bound_Z[c].array()   + b  ).array()  ).array() )  *  Bound_U_Phi_Bound_Z[c].array() * (1 -  Bound_U_Phi_Bound_Z[c].array() )   ;
//              } else if (Phi_type == 0) {
//                if (approx_exp_and_log_for_grad == true)     y1_or_phi_Bound_Z.array() =                   sqrt_2_pi_recip *  fast_exp_1_Eigen_mat_RM( - 0.5 * Bound_Z[c].array()    *  Bound_Z[c].array()    ).array()  ;
//                if (approx_exp_and_log_for_grad == false)    y1_or_phi_Bound_Z.array() =                   sqrt_2_pi_recip *  fast_exp_0_Eigen_mat_RM( - 0.5 * Bound_Z[c].array()    *  Bound_Z[c].array()    ).array()  ;
//              }
//
//              y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.array()  =                         ( y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() + (  y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() - 1).array() ).array() *
//                                                                                                        y1_or_phi_Bound_Z.array()  *  L_Omega_diag_recip_array.array() ;
//
//              //   y_m_ysign_x_u_array.array()  =   ( (  (   y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array()   -  ( y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() + (  y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() - 1).array() ).array()
//              //  * u_array.array()    ).array() ) ) ; //////// checked
//
//              if (  (Phi_type == 3) ||  (Phi_type == 4)  ) {
//                phi_Z_recip.array()  =    1 / (  1.702 *  Phi_Z[c].array() * (1 -  Phi_Z[c].array() )  )  ;
//              } else if (Phi_type == 2) {  // using inv_Phi_approx
//                phi_Z_recip.array()  =    1 / (    (   (3 * a*Z_std_norm[c].array()*Z_std_norm[c].array()   + b  ).array()  ).array() *  Phi_Z[c].array() * (1 -  Phi_Z[c].array() )  ).array()  ;
//              } else if (Phi_type == 1) {  // using EXACT inv_Phi (or close approx using approx exp/log)
//                if (approx_exp_and_log_for_grad == true)      phi_Z_recip.array()  =      1 / (  sqrt_2_pi_recip *  fast_exp_1_Eigen_mat_RM( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).array()  ) ;
//                if (approx_exp_and_log_for_grad == false)     phi_Z_recip.array()  =      1 / (  sqrt_2_pi_recip *  fast_exp_0_Eigen_mat_RM( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).array()  ) ;
//              } else if (Phi_type == 0) {
//                if (approx_exp_and_log_for_grad == true)      phi_Z_recip.array()  =     1 / (  sqrt_2_pi_recip *  fast_exp_1_Eigen_mat_RM( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).array()  ) ;
//                if (approx_exp_and_log_for_grad == false)     phi_Z_recip.array()  =     1 / (  sqrt_2_pi_recip *  fast_exp_0_Eigen_mat_RM( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).array()  ) ;
//              }
//
//              y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.array()  =    ( (  (   y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array()   -  ( y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() + (  y.block( 0, chunk_size * chunk_counter , n_tests , chunk_size   ).array() - 1).array() ).array()
//                                                                                                                  * u_array.array()    ).array() ) ).array() *
//                                                                                                                    phi_Z_recip.array()  *
//                                                                                                                    y1_or_phi_Bound_Z.array()   *  L_Omega_diag_recip_array.array() ;
//
//              ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grad of nuisance parameters / u's (manual)
//              {
//                 //  u_grad_array_CM.row(n_tests - 1).segment( chunk_size * chunk_counter, chunk_size).array() +=  0;
//
//                       // out_mat.segment(1, n_us).segment(chunk_size * (n_tests - 1) * 1 , chunk_size).array()  +=  0 ; //    u_grad_array_CM.row(n_tests - 1).segment( chunk_size * chunk_counter, chunk_size).array() ; //  u_grad_array_CM.block(chunk_size * chunk_counter, 0, n_tests, chunk_size,).reshaped().cast<float>()     ;
//
//                  ///// then second-to-last term (test T - 1)
//                  int t = n_tests - 1;
//
//
//                 // u_grad_array_CM.row(n_tests - 2).segment( chunk_size * chunk_counter, chunk_size).array()  +=  (  common_grad_term_1.row(t).array()  * (y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t).array()     *
//                  //  L_Omega_double[c](t,t - 1) * ( phi_Z_recip.row(t-1).array() )  * prob[c].row(t-1).array()) ).array()  ;
//
//                   out_mat.segment(1, n_us).segment(chunk_size *  (n_tests - 2)  * 1 , chunk_size).array()  +=  (  common_grad_term_1.row(t).array()  * (y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t).array()     *
//                                                                                                                           L_Omega_double[c](t,t - 1) * ( phi_Z_recip.row(t-1).array() )  * prob[c].row(t-1).array()) ).array()  ;
//
//
//                    { ///// then third-to-last term (test T - 2)
//                      t = n_tests - 2;
//
//                      z_grad_term.row(0) = ( phi_Z_recip.row(t-1).array())  * prob[c].row(t-1).array() ;
//                      grad_prob.row(0) =        y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t).array()   *     L_Omega_double[c](t, t - 1) *   z_grad_term.row(0).array() ; // lp(T-1) - part 2;
//                      z_grad_term.row(1).array()  =      L_Omega_double[c](t,t-1) *   z_grad_term.row(0).array() *       y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.row(t).array() ;
//                      grad_prob.row(1)  =         (   y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t+1).array()   ) *  (  z_grad_term.row(0).array() *  L_Omega_double[c](t + 1,t - 1)  -   z_grad_term.row(1).array()  * L_Omega_double[c](t+1,t)) ;
//
//                      //u_grad_array_CM.row(n_tests - 3).segment( chunk_size * chunk_counter, chunk_size).array()  +=  ( common_grad_term_1.row(t).array()   *  (  grad_prob.row(1).array() * prob[c].row(t).array()  +      grad_prob.row(0).array() *  prob[c].row(t+1).array()  )  )   ;
//                      out_mat.segment(1, n_us).segment(chunk_size *  (n_tests - 3)  * 1 , chunk_size).array()  +=  ( common_grad_term_1.row(t).array()   *  (  grad_prob.row(1).array() * prob[c].row(t).array()  +      grad_prob.row(0).array() *  prob[c].row(t+1).array()  )  )   ;
//                    }
//
//
//
//                    // then rest of terms
//                    for (int i = 1; i < n_tests - 2; i++) { // i goes from 1 to 3
//
//                      grad_prob.array() = 0;
//                      z_grad_term.array() = 0;
//
//                      int t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)
//
//                      z_grad_term.row(0) = (  phi_Z_recip.row(t-1).array())  * prob[c].row(t-1).array() ;
//                      grad_prob.row(0) =         y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t).array()   *   L_Omega_double[c](t, t - 1) *   z_grad_term.row(0).array() ; // lp(T-1) - part 2;
//
//                      for (int ii = 0; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1 u_grad_z u_grad_term  //  fn_first_element_neg_rest_pos
//                        if (ii == 0)    prod_container_or_inc_array  = (  (fn_first_element_neg_rest_pos_colvec(L_Omega_double[c].col( t + (ii-1) + 1).segment(t - 1, ii + 1))).transpose()  *   z_grad_term.block(0, 0, ii + 1, chunk_size)   )      ;
//                        z_grad_term.row(ii+1)  =           y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.row(t + ii).array() *  -   prod_container_or_inc_array.array() ;
//                        prod_container_or_inc_array  = (   (fn_first_element_neg_rest_pos_colvec(L_Omega_double[c].col( t + (ii) + 1).segment(t - 1, ii + 2))).transpose()  *  z_grad_term.block(0, 0, ii + 2, chunk_size) )         ;
//                        grad_prob.row(ii+1)  =       (    y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t+ii+1).array()  ) *     -    prod_container_or_inc_array.array()  ;
//                      } // end of ii loop
//
//                      {
//                        derivs_chain_container_vec.array() = 0;
//
//                        for (int ii = 0; ii < i + 2; ii++) {
//                        derivs_chain_container_vec.array()  +=  ( grad_prob.row(ii).array()    * (       prop_rowwise_prod_temp.row(t).array() /  prob[c].row(t + ii).array()  ).array() ).array()  ;
//                      //    derivs_chain_container_vec.array()  +=  ( grad_prob.row(ii).array()    * (      prop_rowwise_prod_temp_div_prob.row(t).array()  ).array() ).array()  ;
//
//                        }
//                        //u_grad_array_CM.row(n_tests - (i+3)).segment( chunk_size * chunk_counter, chunk_size).array()    +=   (  ( (   common_grad_term_1.row(t).array()   *  derivs_chain_container_vec.array() ) ).array()  ).array() ;
//                          out_mat.segment(1, n_us).segment(chunk_size * ( n_tests - (i+3) ) * 1 , chunk_size).array()  += (  ( (   common_grad_term_1.row(t).array()   *  derivs_chain_container_vec.array() ) ).array()  ).array() ;
//
//                      }
//
//                    }
//
//                }
//
//              ///// all grads below  this line were commented out b4
//
//                // /////////////////////////////////////////////////////////////////////////// Grad of intercepts / coefficients (beta's)
//                // ///// last term first (test T)
//
//                {
//
//                  int t = n_tests - 1;
//
//                  beta_grad_array(c, t) +=     (common_grad_term_1.row(t).array()  *   (  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t).array()    )).sum();
//
//                  ///// then second-to-last term (test T - 1)
//                  {
//                    t = n_tests - 2;
//                    grad_prob.row(0) =       (     y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t).array()   ) ;
//                    z_grad_term.row(1)   =     - y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.row(t).array()         ;
//                    grad_prob.row(1)  =       (  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t+1).array()    )   * (   L_Omega_double[c](t + 1,t) *      z_grad_term.row(1).array() ) ;
//                    beta_grad_array(c, t) +=  (common_grad_term_1.row(t).array()   * ( grad_prob.row(1).array() * prob[c].row(t).array() +         grad_prob.row(0).array() *  prob[c].row(t+1).array() ) ).sum() ;
//                  }
//
//                  // then rest of terms
//                  for (int i = 1; i < n_tests - 1; i++) { // i goes from 1 to 3
//
//                    t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)
//
//                    grad_prob.row(0)  =     y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t).array()   ;
//
//                    // component 2 (second-to-earliest test)
//                    z_grad_term.row(1)  =        -y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.row(t).array()       ;
//                    grad_prob.row(1) =        y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t + 1).array()    *    (   L_Omega_double[c](t + 1,t) *   z_grad_term.row(1).array() ) ;
//
//                    // rest of components
//                    for (int ii = 1; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1
//                      if (ii == 1)  prod_container_or_inc_array  = (   L_Omega_double[c].col( t + (ii - 1) + 1).segment(t + 0, ii + 0).transpose()    *    z_grad_term.block(1, 0, ii, chunk_size)   );
//                      z_grad_term.row(ii+1)  =        -y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.row(t + ii).array()    *   prod_container_or_inc_array.array();
//                      prod_container_or_inc_array  = (     L_Omega_double[c].col( t + (ii) + 1).segment(t + 0, ii + 1).transpose()  *  z_grad_term.block(1, 0, ii + 1, chunk_size)     );
//                      grad_prob.row(ii+1) =      (   y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t + ii + 1).array()  ).array()     *  prod_container_or_inc_array.array();
//                    }
//
//                    {
//
//                      derivs_chain_container_vec.array() = 0;
//
//                      ///// attempt at vectorising  // bookmark
//                      for (int ii = 0; ii < i + 2; ii++) {
//                        derivs_chain_container_vec.array() +=  ( grad_prob.row(ii).array()  * (      prop_rowwise_prod_temp.row(t).array() /  prob[c].row(t + ii).array()  ).array() ).array() ;
//                     //   derivs_chain_container_vec.array()  +=  ( grad_prob.row(ii).array()    * (      prop_rowwise_prod_temp_div_prob.row(t).array()  ).array() ).array()  ;
//                      }
//                      beta_grad_array(c, t) +=        ( common_grad_term_1.row(t).array()   *  derivs_chain_container_vec.array() ).sum();
//                    }
//
//                  }
//
//                }
//
//
//
//                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grad of L_Omega ('s)
//                {
//                  {
//                    ///////////////////////// deriv of diagonal elements (not needed if using the "standard" or "Stan" Cholesky parameterisation of Omega)
//
//                    //////// w.r.t last diagonal first
//                    {
//                      int  t1 = n_tests - 1;
//
//                      U_Omega_grad_array[c](t1, t1) +=   ( common_grad_term_1.row(t1).array()   *   y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t1).array()  *   Bound_Z[c].row(t1).array()       ).sum() ;
//                    }
//
//
//                    //////// then w.r.t the second-to-last diagonal
//                    int  t1 = n_tests - 2;
//                    grad_prob.row(0).array()  =         y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t1).array() *     Bound_Z[c].row(t1).array()     ;     // correct  (standard form)
//                    z_grad_term.row(0).array()  =      (   - y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.row(t1).array()  )    *  Bound_Z[c].row(t1).array()    ;  // correct
//
//                    prod_container_or_inc_array.array()  =   (  L_Omega_double[c](t1 + 1, t1)    *   z_grad_term.row(0).array()   ) ; // sequence
//                    grad_prob.row(1).array()  =   y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t1 + 1).array()   *          prod_container_or_inc_array.array()      ;    // correct   (standard form)
//
//                    U_Omega_grad_array[c](t1, t1) +=   ( (   common_grad_term_1.row(t1).array() )     *    ( prob[c].row(t1 + 1).array()  *   grad_prob.row(0).array()  +   prob[c].row(t1).array()  *      grad_prob.row(1).array()   )  ).sum()   ;
//
//                  }
//
//                  // //////// then w.r.t the third-to-last diagonal .... etc
//                  {
//
//                    for (int i = 3; i < n_tests + 1; i++) {
//
//                      int  t1 = n_tests - i;
//
//                      //////// 1st component
//                      // 1st grad_Z term and 1st grad_prob term (simplest terms)
//                      grad_prob.row(0).array()  =   (  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t1).array() )  *  ( Bound_Z[c].row(t1).array()   ).array()  ; // correct  (standard form)
//                      z_grad_term.row(0).array()  =    ( -y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.row(t1).array()  )  *  Bound_Z[c].row(t1).array()       ;   // correct  (standard form)
//
//                      // 2nd   grad_Z term and 2nd grad_prob  (more complicated than 1st term)
//                      prod_container_or_inc_array.array() =    L_Omega_double[c](t1 + 1, t1)   * z_grad_term.row(0).array()  ; // correct  (standard form)
//                      grad_prob.row(1).array()  =   (  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t1 + 1).array()  )   *  (    prod_container_or_inc_array.array() ).array()  ; // correct  (standard form)
//
//
//                      for (int ii = 1; ii < i - 1; ii++) {
//                        z_grad_term.row(ii).array()  =     (- y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.row(t1 + ii).array()  )    *   prod_container_or_inc_array.array()   ;   // correct  (standard form)       // grad_z term
//                        prod_container_or_inc_array =   (     L_Omega_double[c].col(t1 + ii + 1).segment(t1, ii + 1).transpose() *  z_grad_term.block(0, 0, ii + 1, chunk_size)  ) ; // correct  (standard form)
//                        grad_prob.row(ii + 1).array()  =    y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t1 + ii + 1).array()    *    prod_container_or_inc_array.array()  ;  // correct  (standard form)     //    grad_prob term
//                      }
//
//                      {
//
//                        derivs_chain_container_vec.array() = 0;
//
//                        ///// attempt at vectorising  // bookmark
//                        for (int iii = 0; iii <  i; iii++) {
//                          derivs_chain_container_vec.array()  +=    grad_prob.row(iii).array()  * (       prop_rowwise_prod_temp.row(t1).array()    /  prob[c].row(t1 + iii).array()  ).array()  ;  // correct  (standard form)
//                       //   derivs_chain_container_vec.array()  +=  ( grad_prob.row(iii).array()    * (      prop_rowwise_prod_temp_div_prob.row(t1).array()  ).array() ).array()  ;
//                        }
//
//                        U_Omega_grad_array[c](t1, t1)   +=       ( common_grad_term_1.row(t1).array()   * derivs_chain_container_vec.array() ).sum()  ; // correct  (standard form)
//                      }
//
//                    }
//
//
//
//                  }
//
//                }
//
//
//
//
//
// //
//                {
//
//                      z_grad_term.array() = 0 ;
//                      grad_prob.array() = 0;
//
//
//                      { ///////////////////// last row first
//                        int t1_dash = 0;  // t1 = n_tests - 1
//
//                        int t1 = n_tests - (t1_dash + 1); //  starts at n_tests - 1;  // if t1_dash = 0 -> t1 = T - 1
//                        int t2 = n_tests - (t1_dash + 2); //  starts at n_tests - 2;
//
//                        U_Omega_grad_array[c](t1,t2) +=        (  common_grad_term_1.row(t1).array()      *  (  - y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t1).array()   )     *  ( -  Z_std_norm[c].row(t2).array()  )  ).sum() ;
//
//                        if (t1 > 1) { // starts at  L_{T, T-2}
//                          {
//                            t2 =   n_tests - (t1_dash + 3); // starts at n_tests - 3;
//                            U_Omega_grad_array[c](t1,t2) +=     (  common_grad_term_1.row(t1).array()  *   (  - y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t1).array()    )   *     (  - Z_std_norm[c].row(t2).array()   ) ).sum()  ;
//                          }
//                        }
//
//                        if (t1 > 2) {// starts at  L_{T, T-3}
//                          for (int t2_dash = 3; t2_dash < n_tests; t2_dash++ ) { // t2 < t1
//                            t2 = n_tests - (t1_dash + t2_dash + 1); // starts at T - 4
//                            if (t2 < n_tests - 1) {
//                              U_Omega_grad_array[c](t1,t2)  +=   (  common_grad_term_1.row(t1).array() *   (  - y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t1).array()    )  *   (      - Z_std_norm[c].row(t2).array()  )  ).sum() ;
//                            }
//                          }
//                        }
//                      }
//
//                }
//
//
//
//
//                {
//                  /////////////////// then rest of rows (second-to-last row, then third-to-last row, .... , then first row)
//                  for (int t1_dash = 1; t1_dash <  n_tests - 1;  t1_dash++) {
//                    int  t1 = n_tests - (t1_dash + 1);
//
//                    for (int t2_dash = t1_dash + 1; t2_dash <  n_tests;  t2_dash++) {
//                      int t2 = n_tests - (t2_dash + 1); // starts at t1 - 1, then t1 - 2, up to 0
//
//
//                      {
//
//
//                        //prod_container_or_inc_array.array()  =  Z_std_norm[c].block(0, t2, chunk_size, t1 - t2) * deriv_L_t1.head(t1 - t2) ;
//                        prod_container_or_inc_array.array()  =  Z_std_norm[c].row(t2) ; // block(0, t2, chunk_size, t1 - t2) * deriv_L_t1.head(t1 - t2) ;
//                        grad_prob.row(0) =       y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t1).array()   *           prod_container_or_inc_array.array()   ;
//                        z_grad_term.row(0).array()  =                 y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.row(t1).array()     *   (   -    prod_container_or_inc_array.array()     )      ;
//
//                        if (t1_dash > 0) {
//                          for (int t1_dash_dash = 1; t1_dash_dash <  t1_dash + 1;  t1_dash_dash++) {
//                            if (t1_dash_dash > 1) {
//                              z_grad_term.row(t1_dash_dash - 1)   =           y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.row(t1 + t1_dash_dash - 1).array()   *  ( - prod_container_or_inc_array.array() )    ;
//                            }
//                            prod_container_or_inc_array.array()  =            (     L_Omega_double[c].col(t1 + t1_dash_dash).segment(t1, t1_dash_dash).transpose()  * z_grad_term.block(0, 0, t1_dash_dash, chunk_size)    ).array() ;
//                            grad_prob.row(t1_dash_dash)  =             y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.row(t1 + t1_dash_dash).array()    *      prod_container_or_inc_array.array()  ;
//                          }
//                        }
//
//                        {
//
//                          derivs_chain_container_vec.array() = 0;
//
//                          ///// attempt at vectorising  // bookmark
//                          for (int ii = 0; ii <  t1_dash + 1; ii++) {
//                           derivs_chain_container_vec.array() += ( grad_prob.row(ii).array()  * ( prop_rowwise_prod_temp.row(t1).array()     /  prob[c].row(t1 + ii).array()  ).array() ).array() ; // correct i think
//                           // derivs_chain_container_vec.array()  +=  ( grad_prob.row(ii).array()    * (      prop_rowwise_prod_temp_div_prob.row(t1).array()  ).array() ).array()  ;
//                          }
//                          U_Omega_grad_array[c](t1, t2)   +=       ( common_grad_term_1.row(t1).array()   * derivs_chain_container_vec.array() ).sum()  ; // correct  (standard form)
//
//                        }
//
//
//
//                      }
//                    }
//                  }
//
//                }
//
//
//
//
//
//
//
//            }
//
//          }  // end of chunk loop
//
//
//
//        }   // end of second big  c loop
//
//      }
//
//
//
//        //////////////////////// gradients for latent class membership probabilitie(s) (i.e. disease prevalence)
//        for (int c = 0; c < n_class; c++) {
//          prev_unconstrained_grad_vec(c)  =   prev_grad_vec(c)   * deriv_p_wrt_pu_double ;
//        }
//        prev_unconstrained_grad_vec(0) = prev_unconstrained_grad_vec(1) - prev_unconstrained_grad_vec(0) - 2 * tanh_u_prev[1];
//        prev_unconstrained_grad_vec_out(0) = prev_unconstrained_grad_vec(0);
//
//
//        log_prob_out += log_lik.sum();
//
//        if (exclude_priors == false)  log_prob_out += prior_densities;
//
//        log_prob_out +=  log_jac_u;
//
//        log_prob = (double) log_prob_out;
//
//        int i = 0; // probs_all_range.prod() cancels out
//        for (int c = 0; c < n_class; c++) {
//          for (int t = 0; t < n_tests; t++) {
//            if (exclude_priors == false) {
//              beta_grad_array(c, t) +=  - ((beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) * (1/ prior_coeffs_sd(t,c) ) ;     // add normal prior density derivative to gradient
//            }
//            beta_grad_vec(i) = beta_grad_array(c, t);
//            i += 1;
//          }
//        }
//
//
//
//
//        {
//          int i = 0;
//          for (int c = 0; c < n_class; c++ ) {
//            for (int t1 = 0; t1 < n_tests; t1++ ) {
//              for (int t2 = 0; t2 < t1 + 1; t2++ ) {
//                L_Omega_grad_vec(i) = U_Omega_grad_array[c](t1,t2);
//                i += 1;
//              }
//            }
//          }
//        }
//
//
//
//        Eigen::Matrix<double, -1, 1>  grad_wrt_L_Omega_nd =   L_Omega_grad_vec.segment(0, dim_choose_2 + n_tests);
//        Eigen::Matrix<double, -1, 1>  grad_wrt_L_Omega_d =   L_Omega_grad_vec.segment(dim_choose_2 + n_tests, dim_choose_2 + n_tests);
//
//        U_Omega_grad_vec.segment(0, dim_choose_2) =  ( grad_wrt_L_Omega_nd.transpose()  *  deriv_L_wrt_unc_full[0].cast<double>() ).transpose() ;
//        U_Omega_grad_vec.segment(dim_choose_2, dim_choose_2) =   ( grad_wrt_L_Omega_d.transpose()  *  deriv_L_wrt_unc_full[1].cast<double>() ).transpose()  ;
//
//
//
//
//
//      }
//
//
//
//   // for (int nc = 0; nc < n_chunks; nc++) {
//   //   int chunk_counter = nc;
//   //   out_mat.segment(1, n_us).segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)  =    u_grad_array_CM.block(chunk_size * chunk_counter, 0, n_tests, chunk_size,).reshaped() ; // .cast<float>()     ;         }
//   // }
//
//
//    {
//
//      ////////////////////////////  outputs // add log grad and sign stuff';///////////////
//      out_mat(0) =  log_prob;
//      out_mat.segment(1 + n_us, n_corrs) = target_AD_grad.transpose() ;          // .cast<float>();
//      out_mat.segment(1 + n_us, n_corrs) += U_Omega_grad_vec.transpose() ;        //.cast<float>()  ;
//      out_mat.segment(1 + n_us + n_corrs, n_coeffs) = beta_grad_vec.transpose() ; //.cast<float>() ;
//      out_mat(n_params) = ((grad_prev_AD +  prev_unconstrained_grad_vec_out(0)));
//
//   //   if   (tanh_option < 5)  out_mat.segment(1, n_us).array() =     ( (  out_mat.segment(1, n_us).transpose().array() *  ( 0.5 * (1 - theta_us.array() * theta_us.array()  )  )   ).array()    - 2 * theta_us.array()  ).transpose()  ;
//     // else                    out_mat.segment(1, n_us).array() =     ( (  out_mat.segment(1, n_us).transpose().array() *  (  (   (1 -  theta_us.array())*theta_us.array()  ) ) ).array()      -  1  ).transpose()  ;  // inverse logit
//
//      // for (int nc = 0; nc < n_chunks; nc++) {
//      //
//      //      int chunk_counter = nc;
//      //
//      //      if   (tanh_option < 5)  out_mat.segment(1, n_us).array() =     (  out_mat.segment(1, n_us).array() *  ( 0.5 * (1 -  theta_us.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).array() * theta_us.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).head(n_us).array()  )  )   ).array()    - 2 * theta_us.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).head(n_us).array()   ;
//      //      else                    out_mat.segment(1, n_us).array() =     (  out_mat.segment(1, n_us).array() *  (  (   (1 -  theta_us.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).array())*theta_us.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).array()  ) ) ).array()     - 1 ;  // inverse logit
//      // }
//
//      out_mat.segment( 1 + n_params, N) = log_lik ; // .cast<double>() ; //
//
//    }
//
//    return(out_mat);
//
//
//  }
//
//
//
//
//  //
//  //
//  //
 //






//
//
//
// // [[Rcpp::export]]
//  Eigen::Matrix<double, -1, 1>     fn_wo_list_log_posterior_and_gradient_Chol_Schur_AD_float( int n_cores,
//                                                                                              Eigen::Matrix<double, -1, 1  > theta,
//                                                                                              Eigen::Matrix<int, -1, -1>	 y,
//                                                                                              std::vector<Eigen::Matrix<double, -1, -1 > >  X,
//                                                                                              bool exclude_priors,
//                                                                                              bool CI,
//                                                                                              Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
//                                                                                              Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
//                                                                                              Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
//                                                                                              int n_class,
//                                                                                              int n_tests,
//                                                                                              int ub_threshold_phi_approx,
//                                                                                              int n_chunks,
//                                                                                              bool corr_force_positive,
//                                                                                              std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
//                                                                                              std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
//                                                                                              bool corr_prior_beta ,
//                                                                                              bool corr_prior_norm ,
//                                                                                              std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
//                                                                                              std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
//                                                                                              std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
//                                                                                              std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
//                                                                                              double prev_prior_a,
//                                                                                              double prev_prior_b,
//                                                                                              int Phi_type,
//                                                                                              int tanh_option
//
//  ) {
//
//
//
//    int N = y.rows();
//    int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
//    int n_coeffs = n_class * n_tests * 1;
//    int n_us =  1 *  N * n_tests;
//
//    int n_params = theta.rows() ; // n_corrs + n_coeffs + n_us + n_class;
//    int n_params_main = n_params - n_us;
//
//
//
//    stan::math::var target = 0.0;
//
//    Eigen::Matrix<stan::math::var, -1, 1  >  theta_var = stan::math::to_var(theta);
//    std::vector<stan::math::var> theta_var_std = eigen_vec_to_std_vec_var(theta_var);
//
//    // u's
//    Eigen::Matrix<stan::math::var, -1, 1>  u_unconstrained_vec_var = theta_var.head(n_us);
//
//    // corrs
//    Eigen::Matrix<stan::math::var, -1, 1> theta_corrs_var = theta_var.segment(n_us, n_corrs);
//    std::vector<stan::math::var>  Omega_unconstrained_vec_var(n_corrs, 0.0);
//    Omega_unconstrained_vec_var = eigen_vec_to_std_vec_var(theta_corrs_var);
//
//    // coeffs
//    Eigen::Matrix<stan::math::var, -1, -1 >  beta_all_tests_class_var = mat_out_test_var(n_class, n_tests);
//
//    {
//      int i = n_us + n_corrs;
//      for (int c = 0; c < n_class; ++c) {
//        for (int t = 0; t < n_tests; ++t) {
//          beta_all_tests_class_var(c,t) = theta_var(i);
//          i = i + 1;
//        }
//      }
//    }
//
//    // prev
//    stan::math::var u_prev_diseased_var = theta_var(n_params-1);
//
//
//    ////////////////// u (double / manual diff)
//    // constrained u
//    std::vector<stan::math::var>  u_vec_var = eigen_vec_to_std_vec_var(u_unconstrained_vec_var);
//    stan::math::var log_jac_u = 0.0;
//
//    for (int i = 0; i < n_us; ++i) {
//
//      stan::math::var exp_uu = stan::math::exp(u_unconstrained_vec_var[i]);
//      stan::math::var  exp_m_uu = stan::math::exp(- u_unconstrained_vec_var[i]);
//
//      stan::math::var   tanh_uu  =  ((exp_uu - exp_m_uu) / (exp_uu + exp_m_uu));
//
//      u_vec_var[i] = 0.5 * ( tanh_uu  + 1);
//
//      stan::math::var tanh_uu_deriv  = (1 - tanh_uu  *  tanh_uu  );
//      stan::math::var tanh_uu_second_deriv  = -2 * tanh_uu  * tanh_uu_deriv;
//
//      stan::math::var  deriv_u_wrt_uu_double  = 0.5 *  tanh_uu_deriv;
//
//      log_jac_u +=   +  stan::math::log(  deriv_u_wrt_uu_double  );
//
//    }
//
//
//
//    ///////////////// get cholesky factor's (lower-triangular) of corr matrices
//    ////// first need to convert Omega_unconstrained to var
//    // then convert to 3d var array
//    std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > Omega_unconstrained_var = fn_convert_std_vec_of_corrs_to_3d_array_var(Omega_unconstrained_vec_var,
//                                                                                                                                n_tests,
//                                                                                                                                n_class);
//
//
//    std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > L_Omega_var = vec_of_mats_test_var(n_tests, n_tests, n_class);
//    std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  Omega_var  = vec_of_mats_test_var(n_tests, n_tests, n_class);
//
//
//    for (int c = 0; c < n_class; ++c) {
//
//      Eigen::Matrix<stan::math::var, -1, -1 >  ub = stan::math::to_var(ub_corr[c]);
//      Eigen::Matrix<stan::math::var, -1, -1 >  lb = stan::math::to_var(lb_corr[c]);
//
//      // if (Spinkney_param == 1) {
//      //   Eigen::Matrix<stan::math::var, -1, -1  >  Chol_Schur_outs =  Spinkney_cholesky_corr_transform_opt(n_tests, lb, ub, Omega_unconstrained_var[c], known_values_indicator[c], known_values[c]) ;
//      //   L_Omega_var[c]   =  Chol_Schur_outs.block(1, 0, n_tests, n_tests);  // stan::math::cholesky_decompose( Omega_var[c]) ;
//      //   target +=   Chol_Schur_outs(0, 0); // now can set prior directly on Omega
//      // }
//      // if (Spinkney_param == 2)  {
//        Eigen::Matrix<stan::math::var, -1, -1  >  Chol_Schur_outs =  Spinkney_LDL_bounds_opt(n_tests, lb, ub, Omega_unconstrained_var[c], known_values_indicator[c], known_values[c]) ;
//        L_Omega_var[c]   =  Chol_Schur_outs.block(1, 0, n_tests, n_tests);  // stan::math::cholesky_decompose( Omega_var[c]) ;
//        target +=   Chol_Schur_outs(0, 0); // now can set prior directly on Omega
//      // }
//
//      Omega_var[c] =   L_Omega_var[c] * L_Omega_var[c].transpose() ;
//
//    }
//
//
//
//
//    // make prev var variable
//    std::vector<stan::math::var> 	 u_prev_var_vec(n_class, 0.0);
//    std::vector<stan::math::var> 	 prev_var_vec(n_class, 0.0);
//    std::vector<stan::math::var> 	 tanh_u_prev(n_class, 0.0);
//    Eigen::Matrix<stan::math::var, -1, -1>	 prev(1, n_class);
//
//    u_prev_var_vec[1] = u_prev_diseased_var; //  stan::math::to_var(u_prev_diseased);
//
//    stan::math::var exp_2_x_u_prev = stan::math::exp(2*u_prev_var_vec[1] ) ;
//
//    tanh_u_prev[1] = ( exp_2_x_u_prev - 1 ) / ( exp_2_x_u_prev + 1 ) ;
//
//    u_prev_var_vec[0] =   0.5 * stan::math::log( (1 + ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) )  ;
//
//    tanh_u_prev[0] = (stan::math::exp(2*u_prev_var_vec[0] ) - 1) / (stan::math::exp(2*u_prev_var_vec[0] ) + 1) ;
//
//    prev_var_vec[1] = 0.5 * ( tanh_u_prev[1] + 1);
//    prev_var_vec[0] =  0.5 * ( tanh_u_prev[0] + 1);
//    prev(0,1) =  prev_var_vec[1];
//    prev(0,0) =  prev_var_vec[0];
//
//    target += stan::math::beta_lpdf(  prev(0,1),  prev_prior_a, prev_prior_b  );
//
//    //u_prev_var_vec[1] =   0.5 * stan::math::log( (1 + (prev_var_vec[1]*2 - 1) ) / (1 - (prev_var_vec[1]*2 - 1) ) )  ;
//
//    stan::math::var tanh_pu_deriv = ( 1 - tanh_u_prev[1] * tanh_u_prev[1]  );
//    stan::math::var tanh_pu_second_deriv  = -2 * tanh_u_prev[1]  * tanh_pu_deriv;
//
//    stan::math::var deriv_p_wrt_pu_double = 0.5 *  tanh_pu_deriv;
//
//    stan::math::var log_jac_p_deriv_wrt_pu  = ( 1 / deriv_p_wrt_pu_double) * 0.5 * tanh_pu_second_deriv; // for gradient of u's
//    stan::math::var log_jac_p =    stan::math::log( deriv_p_wrt_pu_double );
//
//
//
//    ///////////////////////////////////////////////////////////////////////// prior densities
//    ///////////////////// priors for coeffs
//    for (int c = 0; c < n_class; c++) {
//      for (int t = 0; t < n_tests; t++) {
//        target +=      - 0.9189385  - stan::math::log(prior_coeffs_sd(t,c)) - 0.5 * ( (beta_all_tests_class_var(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) *
//          ( (beta_all_tests_class_var(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) )  ;
//      }
//    }
//
//
//
//    target +=  stan::math::lkj_corr_cholesky_lpdf(L_Omega_var[0], lkj_cholesky_eta(0)) ;
//    target +=  stan::math::lkj_corr_cholesky_lpdf(L_Omega_var[1], lkj_cholesky_eta(1)) ;
//
//
//
//    /////////////////////////////////////////////////////////////////////////////////////////////////////
//    ///////// likelihood
//    //  stan::math::var log_prob_out = 0.0;
//
//
//    Eigen::Matrix<stan::math::var, -1, -1>	 y1(n_tests, n_class);
//    Eigen::Matrix<stan::math::var, -1, -1>	 Z_std_norm_var(n_tests, n_class);
//    Eigen::Matrix<stan::math::var, -1, -1>	 inc(n_class, 1); // col vec (initialised at 0)
//    Eigen::Matrix<stan::math::var, -1, 1>	 lp(n_class); // colvec
//    Eigen::Matrix<stan::math::var, -1, -1>	 u_array(N, n_tests);
//
//    int i = 0;
//    for (int n = 0; n < N; n++ ) {
//      for (int t = 0; t < n_tests; t++) {
//        u_array(n, t) = u_vec_var[i];
//        i = i + 1;
//      }
//    }
//
//
//    //  if (prior_only == false) {
//    for (int n = 0; n < N; n++ ) {
//
//
//      for (int c = 0; c < n_class; c++) {
//        inc(c, 0) = 0;
//      }
//
//
//      for (int t = 0; t < n_tests; t++) {
//
//        int index = y(n,t);
//
//        for (int c = 0; c < n_class; c++) {
//
//
//          if (CI == true) {
//            L_Omega_var[c](t,t) = 1;
//            inc(c, 0)  = 0;
//          }
//
//          stan::math::var bound_bin = 0.0;
//          stan::math::var stuff = 0.0;
//
//          stuff = ( ((  0 - ( beta_all_tests_class_var(c,t) + inc(c, 0)   )  ) / L_Omega_var[c](t,t) )  );
//
//          if (Phi_type == 3) { // mixed type (stable and accurate but slower)
//            if  (stan::math::abs(stuff) < 5)   {
//              bound_bin = stan::math::Phi( stuff );
//            } else  {
//              bound_bin = stan::math::inv_logit( 1.702 *  stuff );
//            }
//          } else if (Phi_type == 2) { // rough_approx (very stable but less accurate + efficient)
//            bound_bin = stan::math::inv_logit( 1.702 * stuff );
//          } else if (Phi_type == -1) {  // standard Phi (less stable but most accurate + efficient)
//            bound_bin = stan::math::Phi( 1.702 * stuff );
//          }
//
//
//
//          stan::math::var Phi_Z_var  = 0.0;
//
//          if (index == 1) {
//            y1(t,c) = stan::math::log1m(bound_bin);
//            Phi_Z_var  = bound_bin + (1 - bound_bin) * u_array(n, t);
//          } else { // y == 0
//            y1(t,c) = stan::math::log(bound_bin);
//            Phi_Z_var  =  bound_bin * u_array(n, t);
//          }
//
//
//          if (Phi_type == 3) {  // mixed type (stable and accurate but slower)
//              if  (stan::math::abs(stuff) < 5)   Z_std_norm_var(t, c) =  stan::math::inv_Phi(Phi_Z_var) ;
//              else    Z_std_norm_var(t, c) =  stan::math::logit(Phi_Z_var) / 1.702 ;
//          } else if (Phi_type == 2) {  // rough_approx (very stable but less accurate + efficient)
//              Z_std_norm_var(t, c) =  stan::math::logit(Phi_Z_var) / 1.702 ;
//          } else if (Phi_type == -1) {  // standard Phi (less stable but most accurate + efficient)
//              Z_std_norm_var(t, c) =  stan::math::inv_Phi(Phi_Z_var) ;
//          }
//
//
//          if (CI == false) {
//            if (t < n_tests - 1) {
//              inc(c,0)  = (L_Omega_var[c].row(t+1).head(t+1) * Z_std_norm_var.col(c).head(t+1)).eval()(0,0);
//            }
//          }
//
//
//
//
//        } // end of c loop
//
//      } // end of t loop
//
//
//      for (int c = 0; c < n_class; c++) {
//        lp(c) = y1.colwise().sum().eval()(0,c) +  log(prev(0,c)) ;
//      }
//
//      stan::math::var log_posterior = stan::math::log_sum_exp(lp);
//
//      target += log_posterior;
//
//    } // end of n loop
//    // }
//
//
//    // if (prior_only == false)   target +=  log_jac_u;
//    // if (prior_only == false)   target +=  log_jac_p;
//
//    target +=  log_jac_u;
//    target +=  log_jac_p;
//
//    // corr_force_positive
//    auto log_prob = target.val();
//
//    //////////////////// calculate gradients
//
//    ///// gradients
//    std::vector<stan::math::var> theta_grad;
//
//    for (int i = 0; i < n_params; i++) {
//      theta_grad.push_back(theta_var_std[i]);    // Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
//    }
//
//    // for (int i = 0; i < 15; i++) {
//    //   theta_grad.push_back( L_Omega_inc_diag_constrained_vec_var(i) );    // Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
//    // }
//
//    std::vector<double> gradient_std_vec;
//
//    target.grad(theta_grad, gradient_std_vec);
//    stan::math::recover_memory();
//
//    Eigen::Matrix<double, -1, 1>  gradient_vec(n_params);
//    //  Eigen::Matrix<double, -1, 1>  gradient_vec(15);
//
//    gradient_vec = std_vec_to_eigen_vec(gradient_std_vec);
//
//    //////////////// output
//    Eigen::Matrix<double, -1, 1> out_mat  =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N) ;  // mat of zero's
//
//    out_mat.segment(1, n_params) = gradient_vec.col(0);
//    // out_mat.segment(1 + n_us, 15) = gradient_vec.col(0);
//    out_mat(0) = log_prob;
//
//
//    return(out_mat);
//
//
//
//
//  }
//
//
//
//
//
//
//
//
//
//
//
//
//


//
//
//
//
//
//
// // [[Rcpp::export]]
//  Eigen::Matrix<double, -1, 1 >    fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float(  Eigen::Matrix<double, -1, 1  > theta,
//                                                                                           Eigen::Matrix<int, -1, -1>	 y,
//                                                                                           Rcpp::List other_args
//
//
//  ) {
//
//
//
//
//   bool exclude_priors = other_args(0); //////////
//   // int lkj_prior_method = other_args(1);
//  //  bool grad_main = other_args(2);
//   // bool grad_nuisance = other_args(3);
//    bool CI = other_args(4); //////////
//  //  bool rough_approx = other_args(5);
//  //  bool homog_corr = other_args(6);
//  //  bool lkj_cholesky= other_args(7);
//    Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta = other_args(8); //////////
//     Eigen::Matrix<double, -1, -1> prior_coeffs_mean = other_args(9); //////////
//    Eigen::Matrix<double, -1, -1> prior_coeffs_sd = other_args(10); //////////
//     int n_class = other_args(11); //////////
//    int n_tests = other_args(12); //////////
//
//
//    //bool Phi_exact_indicator_if_not_using_rough_approx = other_args(16);
//   // int lb_threshold_phi_approx = other_args(17);
//    int ub_threshold_phi_approx = other_args(18); //////////
//
//    int n_chunks = other_args(26); //////////
//
//    int N = y.rows();
//    int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
//    int n_coeffs = n_class * n_tests * 1;
//    int n_us =  1 *  N * n_tests;
//
//    int n_params = theta.rows() ; // n_corrs + n_coeffs + n_us + n_class;
//    int n_params_main = n_params - n_us;
//
//    bool corr_force_positive = other_args(29); ///////////
//
//    std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a =  other_args(49); //////////
//    std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b =  other_args(50); //////////
//
//
//     bool corr_prior_beta =  other_args(56); //////////
//    bool corr_prior_norm =  other_args(57); //////////
//
//    std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr =   other_args(64); //////////
//    std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr =   other_args(65); //////////
//
//
//    std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator =  other_args(72); //////////
//     std::vector<Eigen::Matrix<double, -1, -1 > >   known_values  =  other_args(73); //////////
//
//    double prev_prior_a = other_args(80); //////////
//     double prev_prior_b = other_args(81); //////////
//
//  // Eigen::Matrix<int, -1, -1>  y_sign = other_args(100);
//
//    bool CDA =  other_args(105); //////////
//    Eigen::Matrix<double, -1, -1>  CDA_r =  other_args(106);   //////////
//    Eigen::Matrix<double, -1, -1>  CDA_b =  other_args(107);  //////////
//
//
//    // corrs
//    Eigen::Matrix<double, -1, 1  >  Omega_raw_vec_double = theta.segment(n_us, n_corrs);
//
//    Eigen::Matrix<stan::math::var, -1, 1  >  Omega_raw_vec_var =  stan::math::to_var(Omega_raw_vec_double) ;
//    Eigen::Matrix<stan::math::var, -1, 1  >  Omega_constrained_raw_vec_var =  Eigen::Matrix<stan::math::var, -1, 1  >::Zero(n_corrs) ;
//
//    Omega_constrained_raw_vec_var = ( (Omega_raw_vec_var)); // no transformation for Nump needed! done later on
//
//
//
//    // coeffs
//    Eigen::Matrix<double, -1, -1  > beta_double_array(n_class, n_tests);
//
//    {
//      int i = n_us + n_corrs;
//      for (int c = 0; c < n_class; ++c) {
//        for (int t = 0; t < n_tests; ++t) {
//          beta_double_array(c, t) = theta(i);
//          i = i + 1;
//        }
//      }
//    }
//
//
//    // prev
//    double u_prev_diseased = (double) theta(n_params - 1);
//
//    ////////////////// u (double / manual diff)
//    Eigen::Matrix<double, -1, 1 > tanh_uu =    theta.head(n_us).array().tanh() ;   ///////////////////////
//  //  Eigen::Matrix<double, -1, -1 > tanh_uu_mat =  ( Eigen::Map<Eigen::Matrix<double, -1, -1>>( tanh_uu.data(), N, n_tests) ) ; ///////////////////////
//
//      double log_jac_u  =   +   (  0.5 *   (1 -  ( tanh_uu.array()   *  tanh_uu.array()   ) )   ).log().matrix().sum();
//
//
//    std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > Omega_unconstrained_var = fn_convert_std_vec_of_corrs_to_3d_array_var( eigen_vec_to_std_vec_var(Omega_constrained_raw_vec_var),
//                                                                                                                                 n_tests,
//                                                                                                                                 n_class);
//
//
//    for (int t = 0; t < n_tests; ++t) {
//         for (int c = 0; c < n_class; ++c) {
//                 if (CDA == false) {
//                     CDA_b(c, t) = 0;
//                     CDA_r(c, t) = 1;
//                 }
//
//                 beta_double_array(c, t) +=  CDA_b(c, t);
//         }
//    }
//
//    int dim_choose_2 = n_tests * (n_tests - 1) * 0.5 ;
//
//    stan::math::var target_AD = 0.0;
//
//    std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > L_Omega_var_copy = vec_of_mats_test_var(n_tests, n_tests, n_class);
//    std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  Omega_var_copy  = vec_of_mats_test_var(n_tests, n_tests, n_class);
//
//    for (int c = 0; c < n_class; ++c) {
//        Eigen::Matrix<stan::math::var, -1, -1 >  ub = stan::math::to_var(ub_corr[c]);
//        Eigen::Matrix<stan::math::var, -1, -1 >  lb = stan::math::to_var(lb_corr[c]);
//
//        Eigen::Matrix<stan::math::var, -1, -1  >  Chol_Schur_outs =  Spinkney_LDL_bounds_opt(n_tests, lb, ub, Omega_unconstrained_var[c], known_values_indicator[c], known_values[c]) ; //   Omega_unconstrained_var[c], n_tests, tol )  ;
//
//        L_Omega_var_copy[c]   =  Chol_Schur_outs.block(1, 0, n_tests, n_tests);
//        Omega_var_copy[c] =   L_Omega_var_copy[c] * L_Omega_var_copy[c].transpose() ;
//
//        if (CDA == true) {
//            Omega_var_copy[c] = stan::math::diag_matrix( stan::math::sqrt( stan::math::to_var(CDA_r).row(c) ) ) *   Omega_var_copy[c] *   stan::math::diag_matrix( stan::math::sqrt( stan::math::to_var(CDA_r).row(c) ) ) ;
//            L_Omega_var_copy[c]   = stan::math::cholesky_decompose(     Omega_var_copy[c]   );
//        }
//
//        target_AD +=   Chol_Schur_outs(0, 0); // now can set prior directly on Omega
//    }
//
//
//
//    for (int c = 0; c < n_class; ++c) {
//      if ( (corr_prior_beta == false)   &&  (corr_prior_norm == false) ) {
//        target_AD +=  stan::math::lkj_corr_cholesky_lpdf(L_Omega_var_copy[c], lkj_cholesky_eta(c)) ;
//      } else if ( (corr_prior_beta == true)   &&  (corr_prior_norm == false) ) {
//        for (int i = 1; i < n_tests; i++) {
//          for (int j = 0; j < i; j++) {
//            target_AD +=  stan::math::beta_lpdf(  (Omega_var_copy[c](i, j) + 1)/2, prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
//          }
//        }
//        //  Jacobian for  Omega -> L_Omega transformation for prior log-densities (since both LKJ and truncated normal prior densities are in terms of Omega, not L_Omega)
//        Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
//        for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * log(L_Omega_var_copy[c](i, i));
//        target_AD  += + (n_tests * stan::math::log(2) + jacobian_diag_elements.sum());  //  L -> Omega
//      } else if  ( (corr_prior_beta == false)   &&  (corr_prior_norm == true) ) {
//        for (int i = 1; i < n_tests; i++) {
//          for (int j = 0; j < i; j++) {
//            target_AD +=  stan::math::normal_lpdf(  Omega_var_copy[c](i, j), prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
//          }
//        }
//        Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
//        for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * log(L_Omega_var_copy[c](i, i));
//        target_AD  += + (n_tests * stan::math::log(2) + jacobian_diag_elements.sum());  //  L -> Omega
//      }
//    }
//
//
//
//    /////////////  prev stuff  ---- vars
//    std::vector<stan::math::var> 	 u_prev_var_vec_var(n_class, 0.0);
//    std::vector<stan::math::var> 	 prev_var_vec_var(n_class, 0.0);
//    std::vector<stan::math::var> 	 tanh_u_prev_var(n_class, 0.0);
//    Eigen::Matrix<stan::math::var, -1, -1>	 prev_var(1, n_class);
//
//    u_prev_var_vec_var[1] =  stan::math::to_var(u_prev_diseased);
//    tanh_u_prev_var[1] = ( exp(2*u_prev_var_vec_var[1] ) - 1) / ( exp(2*u_prev_var_vec_var[1] ) + 1) ;
//    u_prev_var_vec_var[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1) ) )  ;
//    tanh_u_prev_var[0] = (exp(2*u_prev_var_vec_var[0] ) - 1) / ( exp(2*u_prev_var_vec_var[0] ) + 1) ;
//
//    prev_var_vec_var[1] = 0.5 * ( tanh_u_prev_var[1] + 1);
//    prev_var_vec_var[0] =  0.5 * ( tanh_u_prev_var[0] + 1);
//    prev_var(0,1) =  prev_var_vec_var[1];
//    prev_var(0,0) =  prev_var_vec_var[0];
//
//
//
//    target_AD += beta_lpdf(  prev_var(0,1), prev_prior_a, prev_prior_b  ); // weakly informative prior - helps avoid boundaries with slight negative skew (for lower N)
//
//    Eigen::Matrix<double, -1, 1 >  target_AD_grad(n_corrs);
//
//    ///////////////////////
//    stan::math::set_zero_all_adjoints();
//    target_AD.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
//    target_AD_grad =  Omega_raw_vec_var.adj();    // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
//    stan::math::set_zero_all_adjoints();
//    //////////////////////////////////////////////////////////// end of AD part
//
//
//
//    std::vector<Eigen::Matrix<double, -1, -1 > > deriv_L_wrt_unc_full = vec_of_mats_test(dim_choose_2 + n_tests, dim_choose_2, n_class);
//
//    for (int c = 0; c < n_class; ++c) {
//      int cnt_1 = 0;
//      for (int k = 0; k < n_tests; k++) {
//        for (int l = 0; l < k + 1; l++) {
//          (  L_Omega_var_copy[c](k, l)).grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
//          int cnt_2 = 0;
//          for (int i = 1; i < n_tests; i++) {
//            for (int j = 0; j < i; j++) {
//              deriv_L_wrt_unc_full[c](cnt_1, cnt_2)  =   Omega_unconstrained_var[c](i, j).adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
//              cnt_2 += 1;
//            }
//          }
//          stan::math::set_zero_all_adjoints();
//          cnt_1 += 1;
//        }
//      }
//    }
//
//    ///////////////// get cholesky factor's (lower-triangular) of corr matrices
//    // convert to 3d var array
//    std::vector<Eigen::Matrix<double, -1, -1 > > L_Omega_double = vec_of_mats_test(n_tests, n_tests, n_class);
//
//    for (int c = 0; c < n_class; ++c) {
//      for (int t1 = 0; t1 < n_tests; ++t1) {
//        for (int t2 = 0; t2 < n_tests; ++t2) {
//          L_Omega_double[c](t1, t2) =   L_Omega_var_copy[c](t1, t2).val()  ;
//        }
//      }
//    }
//
//
//    /////////////  prev stuff
//    std::vector<double> 	 u_prev_var_vec(n_class, 0.0);
//    std::vector<double> 	 prev_var_vec(n_class, 0.0);
//    std::vector<double> 	 tanh_u_prev(n_class, 0.0);
//    Eigen::Matrix<double, -1, -1>	 prev(1, n_class);
//
//    u_prev_var_vec[1] =  (double) u_prev_diseased ;
//    tanh_u_prev[1] = ( exp(2*u_prev_var_vec[1] ) - 1) / ( exp(2*u_prev_var_vec[1] ) + 1) ;
//    u_prev_var_vec[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) )  ;
//    tanh_u_prev[0] = (exp(2*u_prev_var_vec[0] ) - 1) / ( exp(2*u_prev_var_vec[0] ) + 1) ;
//
//    prev_var_vec[1] = 0.5 * ( tanh_u_prev[1] + 1);
//    prev_var_vec[0] =  0.5 * ( tanh_u_prev[0] + 1);
//    prev(0,1) =  prev_var_vec[1];
//    prev(0,0) =  prev_var_vec[0];
//
//
//    double tanh_pu_deriv = ( 1 - tanh_u_prev[1] * tanh_u_prev[1]  );
//    double deriv_p_wrt_pu_double = 0.5 *  tanh_pu_deriv;
//    double tanh_pu_second_deriv  = -2 * tanh_u_prev[1]  * tanh_pu_deriv;
//    double log_jac_p_deriv_wrt_pu  = ( 1 / deriv_p_wrt_pu_double) * 0.5 * tanh_pu_second_deriv; // for gradient of u's
//    double  log_jac_p =    log( deriv_p_wrt_pu_double );
//
//
//
//    ///////////////////////////////////////////////////////////////////////// prior densities
//    double prior_densities = 0.0;
//
//
//    if (exclude_priors == false) {
//      ///////////////////// priors for coeffs
//      double prior_densities_coeffs = 0.0;
//      for (int c = 0; c < n_class; c++) {
//        for (int t = 0; t < n_tests; t++) {
//          double num_1 = 0.9189385;
//          prior_densities_coeffs  +=  - num_1 - log(prior_coeffs_sd(t,c)) - 0.5 * ( (beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) *   ( (beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) )  ;
//        }
//      }
//      double prior_densities_corrs = target_AD.val();
//      prior_densities = prior_densities_coeffs  +      prior_densities_corrs ;     // total prior densities and Jacobian adjustments
//    }
//
//
//    /////////////////////////////////////////////////////////////////////////////////////////////////////
//    ///////// likelihood
//    double s = 1/1.702;
//    double sqrt_2_recip = 1 / stan::math::sqrt(2);
//
//    int chunk_counter = 0;
//    int chunk_size  = std::round( N / n_chunks  / 2) * 2;  ; // N / n_chunks;
//
//
//    double log_prob_out = 0.0;
//
//
//    Eigen::Matrix<double, -1, -1 >  log_prev = prev;
//
//    for (int c = 0; c < n_class; c++) {
//      log_prev(0,c) =  log(prev(0,c));
//      for (int t = 0; t < n_tests; t++) {
//        if (CI == true)      L_Omega_double[c](t,t) = 1;
//      }
//    }
//
//
//
//    ////////////////////////////////////////////////////////////////////////
//    Eigen::Matrix<double, -1, 1> out_mat    =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N);     //////////////// output vec    //////////////////////////////////////////////////  definitely fine as float
//           out_mat.segment(1 + n_us, n_corrs) = target_AD_grad.cast<double>();
//    Eigen::Matrix<double, -1, -1> u_grad_array   =  Eigen::Matrix<double, -1, -1>::Zero(N, n_tests);    //////////////////////////////////////////////////  definitely fine as float
//    Eigen::Matrix<double, -1, 1 >  log_lik   =   Eigen::Matrix<double, -1, 1>::Zero(N);   ////////////////////////////////////////////////// definitely fine as float
//    ////////////////////////////////////////////////////////////////////////
//
//
//    ///////////////////////////////////////////////
//    Eigen::Matrix< double , -1, 1>  beta_grad_vec   =  Eigen::Matrix<double, -1, 1>::Zero(n_coeffs);  //
//    Eigen::Matrix<double, -1, -1>   beta_grad_array  =  Eigen::Matrix<double, -1, -1>::Zero(n_class, n_tests); //
//    std::vector<Eigen::Matrix<double, -1, -1 > > U_Omega_grad_array =  vec_of_mats_test(n_tests, n_tests, n_class); //
//    Eigen::Matrix<double, -1, 1 > L_Omega_grad_vec(n_corrs + (n_class * n_tests)); //
//    Eigen::Matrix<double, -1, 1 > U_Omega_grad_vec(n_corrs); //
//    Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(n_class); //
//    Eigen::Matrix<double, -1, 1>  prev_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(n_class); //
//    Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec_out =   Eigen::Matrix<double, -1, 1>::Zero(n_class - 1); //
//    ///////////////////////////////////////////////
//
//    Eigen::Matrix<double, -1, -1>   lp_array  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_class);//////
//    Eigen::Matrix<int, -1, -1>  y_sign_chunk  =  Eigen::Matrix<int, -1, -1>::Zero(chunk_size, n_tests); /////
//
//
//    ///////////////////////////////////////////////
//    std::vector<Eigen::Matrix<double, -1, -1 > >  prob   = vec_of_mats_test(chunk_size, n_tests, n_class); //////////////////////////////
//    std::vector<Eigen::Matrix<double, -1, -1 > >  Z_std_norm =  vec_of_mats_test(chunk_size, n_tests, n_class); //////////////////////////////
//    std::vector<Eigen::Matrix<double, -1, -1 > >  Bound_Z =  vec_of_mats_test(chunk_size, n_tests, n_class); //////////////////////////////
//    ///////////////////////////////////////////////
//
//
//
//    ///////////////////////////////////////////////
//   // Eigen::Matrix<double, -1, -1>  Bound_Z =   Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;
//    Eigen::Matrix<double, -1, -1>  y_m_ysign_x_u_array =   Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;
//    Eigen::Matrix<double, -1, -1> y1_or_phi_Bound_Z =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
//    Eigen::Matrix<double, -1, -1> phi_Z_or_u_array = Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
//    Eigen::Matrix<double, -1, -1> common_grad_term_1   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
//    Eigen::Matrix<double, -1, -1> grad_prob =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
//    Eigen::Matrix<double, -1, -1> z_grad_term = Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
//    Eigen::Matrix<double, -1, -1 >    Phi_Z_temp   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;
//    Eigen::Matrix<double, -1, -1 >    Bound_U_Phi_Bound_Z_temp   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
//    Eigen::Matrix<double, -1, -1 >    prop_rowwise_prod_temp   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
//  //  Eigen::Matrix<double, -1, -1 > tanh_uu_chunk =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size,  n_tests);
//    Eigen::Array<double, -1, -1 >    Array_of_ones   = Eigen::Array<int, -1, -1>::Ones(chunk_size, n_tests);
//    Eigen::Matrix<double, -1, -1 >    y_m_ysign_x_u_array_times_phi_Z   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
//    Eigen::Matrix<double, -1, -1 >    y_sign_chunk_times_phi_Bound_Z   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
//    ///////////////////////////////////////////////
//
//
//
//    ///////////////////////////////////////////////
//    Eigen::Matrix<double, -1, 1> prop_rowwise_prod_temp_all  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
//    Eigen::Matrix<double, -1, 1> derivs_chain_container_vec  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
//    Eigen::Matrix<double, -1, 1> prod_container_or_inc_array  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
//    Eigen::Matrix<double, -1, 1> prob_n  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
//    Eigen::Matrix<double, -1, 1> grad_bound_z = Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
//    Eigen::Matrix<double, -1, 1> grad_Phi_bound_z = Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
//    ///////////////////////////////////////////////
//
//
//
//    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//    int iiii = 0;
//    int iiiiii = 0;
//    double sqrt_2_pi_recip =   1 / sqrt(2 * M_PI) ; //  0.3989422804;
//
//
//
//
//    for (int nc = 0; nc < n_chunks; nc++) {
//
//              //
//
//
//              for (int nc_index = 0; nc_index < chunk_size; nc_index++ ) {
//                        for (int t = 0; t < n_tests; t++) {
//                          phi_Z_or_u_array(nc_index, t) =   0.5 * ( tanh_uu(iiii) + 1) ;
//                          iiii = iiii + 1;
//                        }
//              }
//
//
//
//                 y_sign_chunk.array() =     Eigen::Select(  y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array()  == 1, Array_of_ones, - Array_of_ones) ;
//
//                 y_m_ysign_x_u_array.array()  =   ( (  (   y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array()   - y_sign_chunk.array()    *  phi_Z_or_u_array.array()    ).array() ) ) ; //////// checked
//
//
//
//              for (int c = 0; c < n_class; c++) {
//
//                           prod_container_or_inc_array.array()  = 0;
//                           Phi_Z_temp.array()    =   0;
//                           Bound_U_Phi_Bound_Z_temp.array()    =   0;
//                           y1_or_phi_Bound_Z.array()    =   0;
//
//                        for (int t = 0; t < n_tests; t++) {
//
//                                    Bound_Z[c].col(t).array() =   ( ((  - ( beta_double_array(c, t) +      prod_container_or_inc_array.array()   )  ) / L_Omega_double[c](t, t) )  )  ;
//
//                                    Bound_U_Phi_Bound_Z_temp.col(t).array() =  Eigen::Select(  Bound_Z[c].col(t).array().abs() < ub_threshold_phi_approx  ,
//                                                                 0.5 *  ( -  sqrt_2_recip * Bound_Z[c].col(t).array() ).erfc().array()   ,
//                                                                 ( stan::math::inv_logit(  1.702 *  Bound_Z[c].col(t) )  ).array()          )  ; //////// checked
//
//
//                                    Phi_Z_temp.col(t).array()    =     y.col(t).segment(chunk_size * chunk_counter, chunk_size).array()  *       Bound_U_Phi_Bound_Z_temp.col(t).array() +
//                                                                     (  y.col(t).segment(chunk_size * chunk_counter, chunk_size).array()  -   Bound_U_Phi_Bound_Z_temp.col(t).array() ) * y_sign_chunk.col(t).array() * phi_Z_or_u_array.col(t).array()  ;  //////// checked
//
//                                    y1_or_phi_Bound_Z.col(t).array() =  Eigen::Select(  y.col(t).segment(chunk_size * chunk_counter, chunk_size).array()   == 1,
//                                                          stan::math::log1m(     Bound_U_Phi_Bound_Z_temp.col(t)   ).array()  ,
//                                                          Bound_U_Phi_Bound_Z_temp.col(t).array().log()     ) ; //////// checked
//
//
//                                    Z_std_norm[c].col(t).array() =    Eigen::Select(   Bound_Z[c].col(t).array().abs() < ub_threshold_phi_approx ,
//                                                      (  qnorm_rcpp_vec(  Phi_Z_temp.col(t)    )    ).array()    ,
//                                                      (  stan::math::logit(    Phi_Z_temp.col(t)   )   * s ).array()      ) ; //////// checked
//
//
//
//                                    if (t < n_tests - 1)       prod_container_or_inc_array.array()  =   ( Z_std_norm[c].block(0, 0, chunk_size, t + 1)  *   ( L_Omega_double[c].row(t+1).head(t+1).transpose()  ) ) ; //////// checked
//
//                           } // end of t loop
//
//                        lp_array.col(c).array() =    y1_or_phi_Bound_Z.rowwise().sum().array() +  log_prev(0,c) ;
//
//
//                        prob[c]  =      y1_or_phi_Bound_Z.array().exp() ; //////// checked
//
//              } // end of c loop
//
//
//              log_lik.segment(chunk_size * chunk_counter, chunk_size).array()   = (  lp_array.array().maxCoeff() + (lp_array.array() - lp_array.array().maxCoeff() ).array().exp().rowwise().sum().array().log() )  ;  //////// checked  //  log_sum_exp(lp);
//              prob_n =   log_lik.segment(chunk_size * chunk_counter, chunk_size).array().exp().matrix();  //////// checked
//
//        for (int c = 0; c < n_class; c++) {
//
//                // for (int i = 0; i < n_tests - 1; i++) { // i goes from 1 to 3
//                //   int t = n_tests - (i+2) ;
//                //   prop_rowwise_prod_temp.col(t).array()   =   prob[c].block(0, t + 0, chunk_size, i + 2).rowwise().prod().array() ;
//                // }
//
//                for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
//                  int t = n_tests - (i+1) ;
//                  prop_rowwise_prod_temp.col(t).array()   =   prob[c].block(0, t + 0, chunk_size, i + 1).rowwise().prod().array() ;
//                }
//
//                prop_rowwise_prod_temp_all.array() = prob[c].block(0, 0, chunk_size, n_tests).rowwise().prod().array()  ;
//
//
//                for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
//                  int t = n_tests - (i + 1) ;
//                //   common_grad_term_1.col(t) =   (  ( prev(0,c) / prob_n.array() ) * ( prop_rowwise_prod_temp_all /  prob[c].block(0, t + 0, chunk_size, i + 1).rowwise().prod().array()  ).array() )  ;
//                  common_grad_term_1.col(t) =   (  ( prev(0,c) / prob_n.array() ) * ( prop_rowwise_prod_temp_all.array() /  prop_rowwise_prod_temp.col(t).array()  ).array() )  ;
//                }
//
//
//                // for numerical stability
//                phi_Z_or_u_array.array() =    Eigen::Select(   Bound_Z[c].array().abs() < ub_threshold_phi_approx ,
//                                       sqrt_2_pi_recip *  ( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).exp().array()   ,
//                                       1.702 * (1 / stan::math::square( stan::math::exp(Z_std_norm[c] * (1/(2*s)) ) + stan::math::exp( - Z_std_norm[c] *  (1/(2*s)) ) ).array()  ) ).array() ;
//
//                // for numerical stability
//                y1_or_phi_Bound_Z.array() =    Eigen::Select(   Bound_Z[c].array().abs() < ub_threshold_phi_approx ,
//                                        sqrt_2_pi_recip *  ( - 0.5 * Bound_Z[c].array() *  Bound_Z[c].array() ).exp().array()   ,
//                                        1.702 * (1 / stan::math::square( stan::math::exp(Bound_Z[c] *  (1/(2*s)) ) + stan::math::exp( - Bound_Z[c] *  (1/(2*s)) ) ).array()  ) ).array()  ;
//
//
//                y_m_ysign_x_u_array_times_phi_Z.array() = y_m_ysign_x_u_array.array() * ( 1 /  phi_Z_or_u_array.array() );
//                y_sign_chunk_times_phi_Bound_Z.array() =  y_sign_chunk.array() * y1_or_phi_Bound_Z.array() ;
//
//             ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grad of nuisance parameters / u's (manual)
//              u_grad_array.col(n_tests - 1).segment( chunk_size * chunk_counter, chunk_size).array() = 0 ;//+  (  0.5 * (1 - tanh_uu_chunk.col(n_tests - 1).array() * tanh_uu_chunk.col(n_tests - 1).array()  )  - 2 * tanh_uu_chunk.col(n_tests - 1).array() )  ; //  tanh_uu_chunk.array()  ; // ----------   correct
//
//              ///// then second-to-last term (test T - 1)
//              int t = n_tests - 1;
//
//              u_grad_array.col(n_tests - 2).segment( chunk_size * chunk_counter, chunk_size).array()  +=  (   common_grad_term_1.col(t).array()    *
//                                                                                                            (  y_sign_chunk_times_phi_Bound_Z.col(t).array()   * (1 / L_Omega_double[c](t,t)  ) *  // lp(T)
//                                                                                                              L_Omega_double[c](t, t - 1) * ( 1 / phi_Z_or_u_array.col(t-1).array()  )   * prob[c].col(t-1).array()  ).array() ) ;//  +
//                                                                                                            //  (  0.5 * (1 - tanh_uu_chunk.col(n_tests - 2).array() * tanh_uu_chunk.col(n_tests - 2).array()  )  - 2 * tanh_uu_chunk.col(n_tests - 2).array() );
//
//
//
//
//                  //
//                  // { ///// then third-to-last term (test T - 2)
//                  //     t = n_tests - 2;
//                  //
//                  //     prod_container_or_inc_array.array() = 0;
//                  //     grad_prob.array() = 0;
//                  //     z_grad_term.array() = 0;
//                  //
//                  //     z_grad_term.col(0).array() =  (1 / phi_Z_or_u_array.col(t-1).array())   * prob[c].col(t-1).array()   ;
//                  //     grad_prob.col(0).array() =   (  y_sign_chunk.col(t).array()   *    y1_or_phi_Bound_Z.col(t).array() )   * ( (1 /  L_Omega_double[c](t,t)  ) *      L_Omega_double[c](t, t - 1) *    z_grad_term.col(0).array()    ) ;
//                  //     z_grad_term.col(1).array()  =  ( (1 / phi_Z_or_u_array.col(t).array()  ) * y1_or_phi_Bound_Z.col(t).array() )  * ( (1 /  L_Omega_double[c](t,t)) ) *
//                  //       ( L_Omega_double[c](t,t-1)   *    z_grad_term.col(0).array() ) *       y_m_ysign_x_u_array.col(t).array()   ;
//                  //
//                  //     prod_container_or_inc_array.array()  =  (  z_grad_term.col(0).array()  *   L_Omega_double[c](t + 1,t - 1)  -   z_grad_term.col(1).array()   *  L_Omega_double[c](t+1,t)).array() ;
//                  //
//                  //     grad_prob.col(1).array()  =       y_sign_chunk.col(t + 1).array()    *   (   y1_or_phi_Bound_Z.col(t+1).array()    *  (1 /  L_Omega_double[c](t+1,t+1)  ) ).array() *   prod_container_or_inc_array.array()  ;
//                  //
//                  //     u_grad_array.col(n_tests - 3).segment( chunk_size * chunk_counter, chunk_size).array()  +=  (    common_grad_term_1.col(t).array()   *
//                  //       (  grad_prob.col(1).array()  * prob[c].col(t).array()  +      grad_prob.col(0).array()   *  prob[c].col(t+1).array()  ) ) ;//+
//                  //     // (  0.5 * (1 - tanh_uu_chunk.col(n_tests - 3).array() * tanh_uu_chunk.col(n_tests - 3).array()  )  - 2 * tanh_uu_chunk.col(n_tests - 3).array() ) ;
//                  // }
//                  //
//                  //
//
//
//                { ///// then third-to-last term (test T - 2)
//                  t = n_tests - 2;
//
//                  prod_container_or_inc_array.array() = 0;
//                  grad_prob.array() = 0;
//                  z_grad_term.array() = 0;
//
//                  z_grad_term.col(0).array() =  (1 / phi_Z_or_u_array.col(t-1).array())   * prob[c].col(t-1).array()   ;
//
//                  grad_prob.col(0).array() =   (  y_sign_chunk_times_phi_Bound_Z.col(t).array()   )   * ( (1 /  L_Omega_double[c](t,t)  ) *      L_Omega_double[c](t, t - 1) *    z_grad_term.col(0).array()    ) ;
//
//                  z_grad_term.col(1).array()  =  (  y1_or_phi_Bound_Z.col(t).array() )  * ( (1 /  L_Omega_double[c](t,t)) ) *
//                                                      ( L_Omega_double[c](t,t-1)   *    z_grad_term.col(0).array() ) *       y_m_ysign_x_u_array_times_phi_Z.col(t).array()   ;
//
//                  prod_container_or_inc_array.array()  =  (  z_grad_term.col(0).array()  *   L_Omega_double[c](t + 1,t - 1)  -   z_grad_term.col(1).array()   *  L_Omega_double[c](t+1,t)).array() ;
//
//                  grad_prob.col(1).array()  =        (   y_sign_chunk_times_phi_Bound_Z.col(t+1).array()    *  (1 /  L_Omega_double[c](t+1,t+1)  ) ).array() *   prod_container_or_inc_array.array()  ;
//
//                  u_grad_array.col(n_tests - 3).segment( chunk_size * chunk_counter, chunk_size).array()  +=  (    common_grad_term_1.col(t).array()   *
//                                                                                                                (  grad_prob.col(1).array()  * prob[c].col(t).array()  +      grad_prob.col(0).array()   *  prob[c].col(t+1).array()  ) ) ;//+
//                                                                                                               // (  0.5 * (1 - tanh_uu_chunk.col(n_tests - 3).array() * tanh_uu_chunk.col(n_tests - 3).array()  )  - 2 * tanh_uu_chunk.col(n_tests - 3).array() ) ;
//                }
//
//                // // then rest of terms
//                for (int i = 1; i < n_tests - 2; i++) { // i goes from 1 to 3
//
//                  grad_prob.array() = 0;
//                  z_grad_term.array() = 0;
//
//
//                    int t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)
//
//                    z_grad_term.col(0) = (1 / phi_Z_or_u_array.col(t-1).array() )  * prob[c].col(t-1).array() ;
//                    grad_prob.col(0) =         y_sign_chunk_times_phi_Bound_Z.col(t).array()  * (1 /   L_Omega_double[c](t,t)  ) *     L_Omega_double[c](t, t - 1) *   z_grad_term.col(0).array()   ;
//
//                   // prod_container_or_inc_array.array()   =  0;
//                   prod_container_or_inc_array.array()   = (   (z_grad_term.block(0, 0, chunk_size, 0 + 1) ) *  (fn_first_element_neg_rest_pos(  L_Omega_double[c].row( t + (0-1) + 1).segment(t - 1, 0 + 1))).transpose()   ).array()      ;
//                   // prod_container_or_inc_array    = ( fn_first_element_neg_rest_pos(  L_Omega_double[c].row( t + (0-1) + 1).segment(t - 1, 0 + 1)).transpose() *  (z_grad_term.block(0, 0, chunk_size, 0 + 1).transpose()  ) ).transpose() ;
//
//                      for (int ii = 0; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1 u_grad_z u_grad_term
//                          z_grad_term.col(ii+1)  =   ( (1 /phi_Z_or_u_array.col( t+(ii-1)+1).array()   ).array() * y1_or_phi_Bound_Z.col(t+(ii-1)+1).array()   * (1 /   L_Omega_double[c](t+(ii-1)+1,t+(ii-1)+1))   *   y_m_ysign_x_u_array.col(t + ii).array()  *  -   prod_container_or_inc_array.array() )  ;
//                        prod_container_or_inc_array  = (   (z_grad_term.block(0, 0, chunk_size, ii + 2) ) *  (fn_first_element_neg_rest_pos(  L_Omega_double[c].row( t + (ii) + 1).segment(t - 1, ii + 2))).transpose()   )      ;
//                     //   prod_container_or_inc_array  =  ( (fn_first_element_neg_rest_pos(  L_Omega_double[c].row( t + (ii) + 1).segment(t - 1, ii + 2))) *     z_grad_term.block(0, 0, chunk_size, ii + 2).transpose() ).transpose() ; // *  (fn_first_element_neg_rest_pos(  L_Omega_double[c].row( t + (ii) + 1).segment(t - 1, ii + 2))).transpose()   )      ;
//
//                          grad_prob.col(ii+1)  =    y_sign_chunk_times_phi_Bound_Z.col(t + ii + 1).array()   *   (    (1 /   L_Omega_double[c](t+ii+1,t+ii+1)  ) ) *     -    prod_container_or_inc_array.array()  ;
//                      } // end of ii loop
//
//                      derivs_chain_container_vec.array() = 0;
//
//                      for (int ii = 0; ii < i + 2; ii++) {
//                       derivs_chain_container_vec.array()  +=  ( grad_prob.col(ii).array()    * (       prop_rowwise_prod_temp.col(t).array() /  prob[c].col(t + ii).array()  ).array() ).array()  ;
//                      }
//                        u_grad_array.col(n_tests - (i+3)).segment( chunk_size * chunk_counter, chunk_size).array()  +=   ( (   common_grad_term_1.col(t).array()   *  derivs_chain_container_vec.array() ) ).array() ;
//
//                }
//
//        // }
//
//   // for (int c = 0; c < n_class; c++) {
//      // /////////////////////////////////////////////////////////////////////////// Grad of intercepts / coefficients (beta's)
//          // ///// last term first (test T)
//
//                grad_bound_z.array() = 0 ;
//                grad_Phi_bound_z.array() = 0;
//                z_grad_term.array() = 0 ;
//                grad_prob.array() = 0;
//
//
//
//
//      ///// last term first (test T)
//
//     {
//      int t = n_tests - 1;
//
//      beta_grad_array(c, t) +=     (common_grad_term_1.col(t).array()  *   ( - y_sign_chunk.col(t).array()   * y1_or_phi_Bound_Z.col(t).array()  * ( - 1 / L_Omega_double[c](t,t)  ))).sum();
//
//      ///// then second-to-last term (test T - 1)
//      {
//        t = n_tests - 2;
//        grad_prob.col(0) =       (   -  y_sign_chunk_times_phi_Bound_Z.col(t).array() * (- 1 / L_Omega_double[c](t,t)  ) ) ;
//
//        z_grad_term.col(1)   =      y_m_ysign_x_u_array_times_phi_Z.col(t).array() *   y1_or_phi_Bound_Z.col(t).array()  * (- 1 / L_Omega_double[c](t,t))     ;
//
//        grad_prob.col(1)  =       ( - y_sign_chunk_times_phi_Bound_Z.col(t+1).array()    ) *  (     (- 1 / L_Omega_double[c](t+1,t+1)  ) ) * (   L_Omega_double[c](t + 1,t) *      z_grad_term.col(1).array() ) ;
//
//        beta_grad_array(c, t) +=  (common_grad_term_1.col(t).array()   * ( grad_prob.col(1).array() * prob[c].col(t).array() +         grad_prob.col(0).array() *  prob[c].col(t+1).array() ) ).sum() ;
//      }
//
//      // then rest of terms
//      for (int i = 1; i < n_tests - 1; i++) { // i goes from 1 to 3
//
//        t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)
//
//        grad_prob.col(0)  =    ( ( - y_sign_chunk_times_phi_Bound_Z.col(t).array()  )     * (- 1 / L_Omega_double[c](t,t)  ) ) ;
//
//
//        // component 2 (second-to-earliest test)
//        z_grad_term.col(1)  =        y_m_ysign_x_u_array_times_phi_Z.col(t).array() *    y1_or_phi_Bound_Z.col(t).array()  * (- 1 / L_Omega_double[c](t,t))    ;
//        grad_prob.col(1) =        - y_sign_chunk_times_phi_Bound_Z.col(t + 1).array()   * (    (- 1 / L_Omega_double[c](t+1,t+1)  ) ) *    (   L_Omega_double[c](t + 1,t) *   z_grad_term.col(1).array() ) ;
//
//        // rest of components
//        for (int ii = 1; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1
//
//              if (ii == 1)  prod_container_or_inc_array  = (    z_grad_term.block(0, 1, chunk_size, ii)  *   L_Omega_double[c].row( t + (ii - 1) + 1).segment(t + 0, ii + 0).transpose()  );
//             // if (ii == 1)  prod_container_or_inc_array  =  ( L_Omega_double[c].row( t + (ii - 1) + 1).segment(t + 0, ii + 0) * z_grad_term.block(0, 1, chunk_size, ii) .transpose() ).transpose() ;
//
//              z_grad_term.col(ii+1)  =        y_m_ysign_x_u_array_times_phi_Z.col(t + ii).array() *
//                                                y1_or_phi_Bound_Z.col(t+(ii-1)+1).array() * (- 1 / L_Omega_double[c](t+(ii-1)+1,t+(ii-1)+1))  *   prod_container_or_inc_array.array();
//
//             prod_container_or_inc_array  = (    z_grad_term.block(0, 1, chunk_size, ii + 1)  *   L_Omega_double[c].row( t + (ii) + 1).segment(t + 0, ii + 1).transpose()  );
//            //  prod_container_or_inc_array  = (  L_Omega_double[c].row( t + (ii) + 1).segment(t + 0, ii + 1) *   z_grad_term.block(0, 1, chunk_size, ii + 1).transpose()  ).transpose();
//
//              grad_prob.col(ii+1) =      (  - y_sign_chunk_times_phi_Bound_Z.col(t + ii + 1).array()  ).array() *   (    (- 1 / L_Omega_double[c](t+ii+1,t+ii+1)  ) )    *  prod_container_or_inc_array.array();
//
//        }
//
//
//                         derivs_chain_container_vec.array() = 0;
//
//                         ///// attempt at vectorising  // bookmark
//                         for (int ii = 0; ii < i + 2; ii++) {
//                            derivs_chain_container_vec.array() +=  ( grad_prob.col(ii).array()  * (      prop_rowwise_prod_temp.col(t).array() /  prob[c].col(t + ii).array()  ).array() ).array() ;
//                         }
//                         beta_grad_array(c, t) +=        ( common_grad_term_1.col(t).array()   *  derivs_chain_container_vec.array() ).sum();
//      }
//
//                }
//
//
//
//      ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grad of L_Omega ('s)
//    //   for (int c = 0; c < n_class; c++) {
//
//        grad_bound_z.array() = 0 ;
//        grad_Phi_bound_z.array() = 0;
//        z_grad_term.array() = 0 ;
//        grad_prob.array() = 0;
//
//
//
//
//          {
//          ///////////////////////// deriv of diagonal elements (not needed if using the "standard" or "Stan" Cholesky parameterisation of Omega)
//
//          //////// w.r.t last diagonal first
//          {
//            int  t1 = n_tests - 1;
//
//            U_Omega_grad_array[c](t1, t1) +=   ( ( common_grad_term_1.col(t1).array()   *    -  y_sign_chunk_times_phi_Bound_Z.col(t1).array() ).array() *
//                                                      (  Bound_Z[c].col(t1).array() * L_Omega_double[c](t1,t1) *  - ( 1 / ( L_Omega_double[c](t1,t1)  *  L_Omega_double[c](t1,t1) ) )    )   ).sum() ;
//          }
//
//
//          //////// then w.r.t the second-to-last diagonal
//            int  t1 = n_tests - 2;
//
//            double deriv_L_Omega_Tm1_Tm1_inv =    - stan::math::pow( L_Omega_double[c](t1, t1), -2) ;
//
//            grad_bound_z.array() =   ( Bound_Z[c].col(t1).array()  *  L_Omega_double[c](t1, t1) )  *  (   deriv_L_Omega_Tm1_Tm1_inv    )   ; //  check (standard form, but varies depending on gradient)
//            grad_Phi_bound_z.array() =  ( y1_or_phi_Bound_Z.col(t1).array()  *  ( grad_bound_z.array() )  ) ;   // correct  (standard form)
//            grad_prob.col(0).array()  =  (   - y_sign_chunk.col(t1).array()  *  grad_Phi_bound_z.array() )  ;     // correct  (standard form)
//
//
//            z_grad_term.col(0).array()  =      (  ( (  y_m_ysign_x_u_array_times_phi_Z.col(t1).array()   ).array()    * y1_or_phi_Bound_Z.col(t1).array()  *  grad_bound_z.array()  ).array() )   ;  // correct
//
//            prod_container_or_inc_array.array()  =   (  L_Omega_double[c](t1 + 1, t1)    *   z_grad_term.col(0).array()   ) ; // sequence
//            grad_bound_z.array() =   (   ( - 1 /  L_Omega_double[c](t1 + 1, t1 + 1) ) *  prod_container_or_inc_array.array()   )   ;  // correct  (standard form)
//            grad_Phi_bound_z.array() =   ( y1_or_phi_Bound_Z.col(t1 + 1).array()  *  (   grad_bound_z.array()   ) ) ;   // correct  (standard form)
//            grad_prob.col(1).array()  =   (  - y_sign_chunk.col(t1 + 1).array()   *    grad_Phi_bound_z.array()  ).array()  ;    // correct   (standard form)
//
//            U_Omega_grad_array[c](t1, t1) +=   ( (   common_grad_term_1.col(t1).array() )     *    ( prob[c].col(t1 + 1).array()  *   grad_prob.col(0).array()  +   prob[c].col(t1).array()  *      grad_prob.col(1).array()   )  ).sum()   ;
//
//        }
//
//
//
//          // //////// then w.r.t the third-to-last diagonal .... etc
//        {
//
//          for (int i = 3; i < n_tests + 1; i++) {
//
//            int  t1 = n_tests - i;
//
//            //////// 1st component
//            // 1st grad_Z term and 1st grad_prob term (simplest terms)
//            grad_bound_z.array()  =   ( Bound_Z[c].col(t1).array()  *  ( - 1 / L_Omega_double[c](t1, t1)  ) ).matrix() ; //  check (standard form, but varies depending on gradient)
//            grad_Phi_bound_z.array()  =     y1_or_phi_Bound_Z.col(t1).array() *  grad_bound_z.array() ; // correct  (standard form)
//            grad_prob.col(0).array()  =   ( - y_sign_chunk.col(t1).array() ) *    grad_Phi_bound_z.array() ; // correct  (standard form)
//
//            z_grad_term.col(0).array()  =    y_m_ysign_x_u_array_times_phi_Z.col(t1).array()   *   grad_Phi_bound_z.array()  ;   // correct  (standard form)
//
//            // 2nd   grad_Z term and 2nd grad_prob  (more complicated than 1st term)
//            prod_container_or_inc_array.array() =    L_Omega_double[c](t1 + 1, t1)   * z_grad_term.col(0).array()  ; // correct  (standard form)
//            grad_bound_z.array()  = ( - 1 / L_Omega_double[c](t1 + 1, t1 + 1) ) * prod_container_or_inc_array.array() ;  // correct  (standard form)
//            grad_Phi_bound_z.array()  =     y1_or_phi_Bound_Z.col(t1 + 1).array()  *  grad_bound_z.array() ;    // correct  (standard form)
//            grad_prob.col(1).array()  =   ( - y_sign_chunk.col(t1 + 1).array()  ) *    grad_Phi_bound_z.array() ; // correct  (standard form)
//
//
//            for (int ii = 1; ii < i - 1; ii++) {
//              // grad_z term
//              z_grad_term.col(ii).array()  =    y_m_ysign_x_u_array_times_phi_Z.col(t1 + ii).array()    *   grad_Phi_bound_z.array()  ;   // correct  (standard form)
//              //    grad_prob term
//             prod_container_or_inc_array.matrix() =   (  L_Omega_double[c].row(t1 + ii + 1).segment(t1, ii + 1) *   z_grad_term.block(0, 0, chunk_size, ii + 1).transpose() ).transpose().matrix(); // correct  (standard form)
//             // prod_container_or_inc_array.matrix() =   (  z_grad_term.block(0, 0, chunk_size, ii + 1) *  L_Omega_double[c].row(t1 + ii + 1).segment(t1, ii + 1).transpose() ).matrix() ;  // correct  (standard form)
//
//              grad_bound_z.array()  = ( - 1 / L_Omega_double[c](t1 + ii + 1, t1 + ii + 1)  ) * prod_container_or_inc_array.array(); // correct  (standard form)
//              grad_Phi_bound_z.array()  =     y1_or_phi_Bound_Z.col(t1 + ii + 1).array()  *  grad_bound_z.array() ;   // correct  (standard form)
//              grad_prob.col(ii + 1).array()  =   ( - y_sign_chunk.col(t1 + ii + 1).array()  ) *   grad_Phi_bound_z.array() ;  // correct  (standard form)
//            }
//
//            derivs_chain_container_vec.array() = 0;
//
//            ///// attempt at vectorising  // bookmark
//            for (int iii = 0; iii <  i; iii++) {
//                derivs_chain_container_vec.array()  +=    grad_prob.col(iii).array()  * (       prop_rowwise_prod_temp.col(t1).array()    /  prob[c].col(t1 + iii).array()  ).array()  ;  // correct  (standard form)
//            }
//
//             U_Omega_grad_array[c](t1, t1)   +=       ( common_grad_term_1.col(t1).array()   * derivs_chain_container_vec.array() ).sum()  ; // correct  (standard form)
//
//          }
//
//
//
//        }
//
//
//
//
//
//          {
//
//          grad_bound_z.array() = 0 ;
//          grad_Phi_bound_z.array() = 0;
//          z_grad_term.array() = 0 ;
//          grad_prob.array() = 0;
//
//
//
//                { ///////////////////// last row first
//                  int t1_dash = 0;  // t1 = n_tests - 1
//
//                  int t1 = n_tests - (t1_dash + 1); //  starts at n_tests - 1;  // if t1_dash = 0 -> t1 = T - 1
//                  int t2 = n_tests - (t1_dash + 2); //  starts at n_tests - 2;
//
//                  U_Omega_grad_array[c](t1,t2) +=      ( ( common_grad_term_1.col(t1).array()      * - y_sign_chunk_times_phi_Bound_Z.col(t1).array() ).array() *
//                                                             (    (1 / L_Omega_double[c](t1,t1)  ) * (-  Z_std_norm[c].col(t2).array()  )   ).array() ).sum() ;
//
//
//                  if (t1 > 1) { // starts at  L_{T, T-2}
//
//                    {
//
//                      t2 =   n_tests - (t1_dash + 3); // starts at n_tests - 3;
//
//                      U_Omega_grad_array[c](t1,t2) +=     (  common_grad_term_1.col(t1).array()  *   (  - y_sign_chunk_times_phi_Bound_Z.col(t1).array()  ).array()  *
//                                                          ( (  (1 / L_Omega_double[c](t1,t1) ) *  ( - Z_std_norm[c].col(t2).array() )  ).array() ) ).sum()  ;
//
//
//                    }
//
//                  }
//
//                  if (t1 > 2) {// starts at  L_{T, T-3}
//
//                    for (int t2_dash = 3; t2_dash < n_tests; t2_dash++ ) { // t2 < t1
//
//                      t2 = n_tests - (t1_dash + t2_dash + 1); // starts at T - 4
//
//                      if (t2 < n_tests - 1) {
//
//                        U_Omega_grad_array[c](t1,t2)  +=   (common_grad_term_1.col(t1).array() *   (  - y_sign_chunk_times_phi_Bound_Z.col(t1).array() ).array() *
//                                                           ( (  ( 1 / L_Omega_double[c](t1,t1) ) * - Z_std_norm[c].col(t2).array()  ) ).array()).sum() ;
//
//                      }
//
//                    }
//
//                  }
//
//                }
//
//          }
//
//
//
//
//        {
//            Eigen::Matrix<double, -1, 1>  deriv_L_t1 =     Eigen::Matrix<double, -1, 1>::Zero(n_tests);
//
//        /////////////////// then rest of rows (second-to-last row, then third-to-last row, .... , then first row)
//
//        grad_bound_z.array() = 0 ;
//        grad_Phi_bound_z.array() = 0;
//        z_grad_term.array() = 0 ;
//        grad_prob.array() = 0;
//
//
//
//
//        for (int t1_dash = 1; t1_dash <  n_tests - 1;  t1_dash++) {
//          int  t1 = n_tests - (t1_dash + 1);
//
//              for (int t2_dash = t1_dash + 1; t2_dash <  n_tests;  t2_dash++) {
//                int t2 = n_tests - (t2_dash + 1); // starts at t1 - 1, then t1 - 2, up to 0
//
//                grad_prob.array() = 0;
//                z_grad_term.array() = 0;
//
//                  {
//                    deriv_L_t1(0) = 1;
//
//                    for (int t2_dash_dash = 1; t2_dash_dash < t1 - t2; t2_dash_dash++ ) {
//                      deriv_L_t1(t2_dash_dash) = 0;
//                    }
//
//
//                    prod_container_or_inc_array.array()  =  Z_std_norm[c].block(0, t2, chunk_size, t1 - t2) * deriv_L_t1.head(t1 - t2) ;
//                    grad_prob.col(0) =      (( -  y_sign_chunk_times_phi_Bound_Z.col(t1).array()   ).array() *   (      ( ( 1/L_Omega_double[c](t1,t1) ) *  -    prod_container_or_inc_array.array() ) ).array())  ;
//
//
//                    z_grad_term.col(0).array()  =               ( (  y_m_ysign_x_u_array_times_phi_Z.col(t1).array()    ).array()   *   y1_or_phi_Bound_Z.col(t1).array()  ).array()  *
//                                                                    ( (   ( ( 1 / L_Omega_double[c](t1,t1) ) *   -    prod_container_or_inc_array.array()     ).array()  )   ).array()  ;
//
//                    if (t1_dash > 0) {
//                      for (int t1_dash_dash = 1; t1_dash_dash <  t1_dash + 1;  t1_dash_dash++) {
//                              if (t1_dash_dash > 1) {
//                                z_grad_term.col(t1_dash_dash - 1)   =           (  (  y_m_ysign_x_u_array_times_phi_Z.col(t1 + t1_dash_dash - 1).array()    ).array()   *
//                                                                                y1_or_phi_Bound_Z.col(t1+t1_dash_dash - 1).array()   *  ( 1/L_Omega_double[c](t1+t1_dash_dash - 1,t1+t1_dash_dash - 1) ) ).array()  *  ( - prod_container_or_inc_array.array() )    ;
//                              }
//                              prod_container_or_inc_array.array()  =            (   z_grad_term.block(0, 0, chunk_size, t1_dash_dash) *   L_Omega_double[c].row(t1 + t1_dash_dash).segment(t1, t1_dash_dash).transpose()   ) ;
//                              grad_prob.col(t1_dash_dash)  =            (  ( ( -  y_sign_chunk_times_phi_Bound_Z.col(t1 + t1_dash_dash).array()     ).array() ) *
//                                                                          ( 1 / L_Omega_double[c](t1+t1_dash_dash,t1+t1_dash_dash) )  *    (  -    prod_container_or_inc_array).array()  ) ;
//                      }
//                    }
//
//                    derivs_chain_container_vec.array() = 0;
//
//                    ///// attempt at vectorising  // bookmark
//                    for (int ii = 0; ii <  t1_dash + 1; ii++) {
//                        derivs_chain_container_vec.array() += ( grad_prob.col(ii).array()  * ( prop_rowwise_prod_temp.col(t1).array()     /  prob[c].col(t1 + ii).array()  ).array() ).array() ; // correct i think
//                    }
//                    U_Omega_grad_array[c](t1, t2)   +=       ( common_grad_term_1.col(t1).array()   * derivs_chain_container_vec.array() ).sum()  ; // correct  (standard form)
//
//
//
//                  }
//              }
//        }
//
//      }
//
//
//           prev_grad_vec(c)  +=  ( ( 1 / prob_n.array() ) * prob[c].rowwise().prod().array() ).matrix().sum()  ;
//
//
//
//
//      } // end of c loop
//
//
//      chunk_counter += 1;
//
//
//    }  // end of chunk loop
//
//
//    //////////////////////// gradients for latent class membership probabilitie(s) (i.e. disease prevalence)
//      for (int c = 0; c < n_class; c++) {
//        prev_unconstrained_grad_vec(c)  =   prev_grad_vec(c)   * deriv_p_wrt_pu_double ;
//      }
//      prev_unconstrained_grad_vec(0) = prev_unconstrained_grad_vec(1) - prev_unconstrained_grad_vec(0) - 2 * tanh_u_prev[1];
//      prev_unconstrained_grad_vec_out(0) = prev_unconstrained_grad_vec(0);
//
//
//    log_prob_out += log_lik.sum();
//
//    if (exclude_priors == false)  log_prob_out += prior_densities;
//
//    log_prob_out +=  log_jac_u;
//
//    double log_prob = (double) log_prob_out;
//
//    int i = 0; // probs_all_range.prod() cancels out
//    for (int c = 0; c < n_class; c++) {
//      for (int t = 0; t < n_tests; t++) {
//        if (exclude_priors == false) {
//          beta_grad_array(c, t) +=  - ((beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) * (1/ prior_coeffs_sd(t,c) ) ;     // add normal prior density derivative to gradient
//        }
//        beta_grad_vec(i) = beta_grad_array(c, t);
//        i += 1;
//      }
//    }
//
// //
//    iiiiii = 0;
//    for (int n = 0; n < N; n++ ) {
//      for (int t = 0; t < n_tests; t++) {
//        out_mat(iiiiii + 1) = u_grad_array(n, t);
//        iiiiii += 1;
//      }
//    }
//
//
//    // iiiiii = 0;
//    // for (int t = 0; t < n_tests; t++) {
//    //   for (int n = 0; n < N; n++ ) {
//    //     out_mat(iiiiii + 1) = u_grad_array(n, t);
//    //     iiiiii += 1;
//    //   }
//    // }
//
//    //
//    // for (int t = 0; t < n_tests; t++) {
//    //   if (t == 0) out_mat.segment(0, N)   = u_grad_array.col(t) ; //    phi_Z_or_u_array.col(t) =   ( 0.5 * ( tanh_uu.array() + 1 ) ).array().matrix().segment(chunk_size * chunk_counter * t, chunk_size);
//    //   else        out_mat.segment( (N*t) - 1, N)   = u_grad_array.col(t) ;
//    //   // for (int nc_index = 0; nc_index < chunk_size; nc_index++ ) {
//    //   //     phi_Z_or_u_array(nc_index, t) =   0.5 * ( tanh_uu(iiii) + 1) ;
//    //   //     iiii = iiii + 1;
//    //   //   }
//    // }
//
//
//   //  Eigen::Matrix<float, -1, -1> matrix(3,2);
//   //  matrix << 1,2,3,4,5,6;
//   //  A.transposeInPlace(); // or ordered row-by-row
//
//      // Eigen::Matrix<float, -1, 1>  vector(Eigen::Map<Eigen::Matrix<float, -1, 1>>(u_grad_array.data(), u_grad_array.cols() * u_grad_array.rows()));
//
//     //   out_mat.segment(1, n_us) =   Eigen::Map<Eigen::Matrix<float, -1, 1>>(u_grad_array.data(), u_grad_array.cols() * u_grad_array.rows());
//
//
//    {
//      i = 0;
//      for (int c = 0; c < n_class; c++ ) {
//        for (int t1 = 0; t1 < n_tests; t1++ ) {
//          for (int t2 = 0; t2 < t1 + 1; t2++ ) {
//            L_Omega_grad_vec(i) = U_Omega_grad_array[c](t1,t2);
//            i += 1;
//          }
//        }
//      }
//    }
//
//
//
//    Eigen::Matrix<double, -1, 1>  grad_wrt_L_Omega_nd =   L_Omega_grad_vec.segment(0, dim_choose_2 + n_tests);
//    Eigen::Matrix<double, -1, 1>  grad_wrt_L_Omega_d =   L_Omega_grad_vec.segment(dim_choose_2 + n_tests, dim_choose_2 + n_tests);
//
//    U_Omega_grad_vec.segment(0, dim_choose_2) =  ( grad_wrt_L_Omega_nd.transpose()  *  deriv_L_wrt_unc_full[0].cast<double>() ).transpose() ;
//    U_Omega_grad_vec.segment(dim_choose_2, dim_choose_2) =   ( grad_wrt_L_Omega_d.transpose()  *  deriv_L_wrt_unc_full[1].cast<double>() ).transpose()  ;
//
//    ////////////////////////////  outputs
//
//
//
//    out_mat(0) = log_prob;
//
//
//    out_mat.segment(1 + n_us, n_corrs) += U_Omega_grad_vec  ;
//
//    out_mat.segment(1 + n_us + n_corrs, n_coeffs) = beta_grad_vec ;
//    out_mat(n_params) += prev_unconstrained_grad_vec_out(0); ;
//    out_mat.segment(1, n_us).array() =   (out_mat.segment(1, n_us).array() )   *   ( 0.5 * (1 - tanh_uu.array() * tanh_uu.array()  )  ) - 2 * tanh_uu.array()   ;
//  //  out_mat.segment(1, n_us).array() =   (out_mat.segment(1, n_us).array() *   0.5 * (1 -     ( Eigen::Map<Eigen::Matrix<float, -1, 1>>(tanh_uu.data(), tanh_uu.cols() * tanh_uu.rows()) ).array() *     ( Eigen::Map<Eigen::Matrix<float, -1, 1>>(tanh_uu.data(), tanh_uu.cols() * tanh_uu.rows()) ).array().array()  )  - 2 *     ( Eigen::Map<Eigen::Matrix<float, -1, 1>>(tanh_uu.data(), tanh_uu.cols() * tanh_uu.rows()) ).array().array()) ;
//
//    out_mat.segment( 1 + n_params, N) = log_lik ;
//
//  //
//  stan::math::recover_memory();
//
//    return(out_mat);
//
//
//    //
//    // // // //
//    //   Rcpp::List out_list(20);
//    //
//    //   out_list(0) = out_mat;
//    //
//    //  // out_list(1) = u_array;
//    //   out_list(2) = prob;
//    //   out_list(3) = Z_std_norm;
//    // //  out_list(4) = Phi_Z;
//    //   out_list(5) = Bound_Z;
//    // //  out_list(6) = Bound_U_Phi_Bound_Z;
//    //   out_list(7) = y_sign;
//    //   out_list(8) = prob_n;
//    //   out_list(9) = lp_array;
//    //  // out_list(10) = inc_array;
//    //  // out_list(11) = y1_array;
//    //  // out_list(12) = phi_Z;
//    // //  out_list(13) = phi_Bound_Z;
//    //   out_list(14) = common_grad_term_1;
//    //   out_list(15) = y_m_ysign_x_u_array;
//    //   out_list(16) = U_Omega_grad_array;
//    //
//    //   return(out_list);
//    // //
//    //
//  }
//
//
//


















 //
 //
 //
 // // [[Rcpp::export]]
 // Eigen::Matrix<double, -1, 1 >    fn_wo_list_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float_2(  int n_cores,
 //                                                                                                      Eigen::Matrix<double, -1, 1  > theta,
 //                                                                                                      Eigen::Matrix<int, -1, -1>	 y,
 //                                                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  X,
 //                                                                                                      bool exclude_priors,
 //                                                                                                      bool CI,
 //                                                                                                      Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
 //                                                                                                      Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
 //                                                                                                      Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
 //                                                                                                      int n_class, // 10
 //                                                                                                      int n_tests,
 //                                                                                                      int ub_threshold_phi_approx,
 //                                                                                                      int n_chunks,
 //                                                                                                      bool corr_force_positive,
 //                                                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
 //                                                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
 //                                                                                                      bool corr_prior_beta ,
 //                                                                                                      bool corr_prior_norm ,
 //                                                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
 //                                                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr, // 20
 //                                                                                                      std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
 //                                                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
 //                                                                                                      double prev_prior_a,
 //                                                                                                      double prev_prior_b,
 //                                                                                                      int Phi_type
 //
 //
 // ) {
 //
 //
 //
 //
 //   // Eigen::Matrix<double, -1, 1  > theta = ( log_theta.array().exp() * signs_theta.array() ).matrix().cast<double>() ;
 //
 //
 //   int N = y.rows();
 //   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
 //   int n_coeffs = n_class * n_tests * 1;
 //   int n_us =  1 *  N * n_tests;
 //
 //   int n_params = theta.rows() ; // n_corrs + n_coeffs + n_us + n_class;
 //   int n_params_main = n_params - n_us;
 //
 //
 //
 //
 //   // corrs
 //   Eigen::Matrix<double, -1, 1  >  Omega_raw_vec_double = theta.segment(n_us, n_corrs).cast<double>();
 //
 //   Eigen::Matrix<stan::math::var, -1, 1  >  Omega_raw_vec_var =  stan::math::to_var(Omega_raw_vec_double) ;
 //   Eigen::Matrix<stan::math::var, -1, 1  >  Omega_constrained_raw_vec_var =  Eigen::Matrix<stan::math::var, -1, 1  >::Zero(n_corrs) ;
 //
 //   Omega_constrained_raw_vec_var = ( (Omega_raw_vec_var)); // no transformation for Nump needed! done later on
 //
 //
 //
 //   // coeffs
 //   Eigen::Matrix<double, -1, -1  > beta_double_array(n_class, n_tests);
 //
 //   {
 //     int i = n_us + n_corrs;
 //     for (int c = 0; c < n_class; ++c) {
 //       for (int t = 0; t < n_tests; ++t) {
 //         beta_double_array(c, t) = theta(i);
 //         i = i + 1;
 //       }
 //     }
 //   }
 //
 //
 //   // prev
 //   double u_prev_diseased = theta(n_params - 1);
 //
 //
 //
 //   Eigen::Matrix<double, -1, 1 >  target_AD_grad(n_corrs);
 //
 //
 //   int dim_choose_2 = n_tests * (n_tests - 1) * 0.5 ;
 //
 //   stan::math::var target_AD = 0.0;
 //   double grad_prev_AD = 0;
 //
 //   std::vector<Eigen::Matrix<double, -1, -1 > > L_Omega_double = vec_of_mats_test(n_tests, n_tests, n_class);
 //   std::vector<Eigen::Matrix<double, -1, -1 > > deriv_L_wrt_unc_full = vec_of_mats_test(dim_choose_2 + n_tests, dim_choose_2, n_class);
 //
 //
 //   {
 //
 //
 //     std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > Omega_unconstrained_var = fn_convert_std_vec_of_corrs_to_3d_array_var( eigen_vec_to_std_vec_var(Omega_constrained_raw_vec_var),
 //                                                                                                                                  n_tests,
 //                                                                                                                                  n_class);
 //
 //
 //     std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > L_Omega_var_copy = vec_of_mats_test_var(n_tests, n_tests, n_class);
 //     std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  Omega_var_copy  = vec_of_mats_test_var(n_tests, n_tests, n_class);
 //
 //     for (int c = 0; c < n_class; ++c) {
 //       Eigen::Matrix<stan::math::var, -1, -1 >  ub = stan::math::to_var(ub_corr[c]);
 //       Eigen::Matrix<stan::math::var, -1, -1 >  lb = stan::math::to_var(lb_corr[c]);
 //
 //       Eigen::Matrix<stan::math::var, -1, -1  >  Chol_Schur_outs =  Spinkney_LDL_bounds_opt(n_tests, lb, ub, Omega_unconstrained_var[c], known_values_indicator[c], known_values[c]) ; //   Omega_unconstrained_var[c], n_tests, tol )  ;
 //
 //       L_Omega_var_copy[c]   =  Chol_Schur_outs.block(1, 0, n_tests, n_tests);
 //       Omega_var_copy[c] =   L_Omega_var_copy[c] * L_Omega_var_copy[c].transpose() ;
 //
 //
 //       target_AD +=   Chol_Schur_outs(0, 0); // now can set prior directly on Omega
 //     }
 //
 //
 //
 //     for (int c = 0; c < n_class; ++c) {
 //       if ( (corr_prior_beta == false)   &&  (corr_prior_norm == false) ) {
 //         target_AD +=  stan::math::lkj_corr_cholesky_lpdf(L_Omega_var_copy[c], lkj_cholesky_eta(c)) ;
 //       } else if ( (corr_prior_beta == true)   &&  (corr_prior_norm == false) ) {
 //         for (int i = 1; i < n_tests; i++) {
 //           for (int j = 0; j < i; j++) {
 //             target_AD +=  stan::math::beta_lpdf(  (Omega_var_copy[c](i, j) + 1)/2, prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
 //           }
 //         }
 //         //  Jacobian for  Omega -> L_Omega transformation for prior log-densities (since both LKJ and truncated normal prior densities are in terms of Omega, not L_Omega)
 //         Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
 //         for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * log(L_Omega_var_copy[c](i, i));
 //         target_AD  += + (n_tests * stan::math::log(2) + jacobian_diag_elements.sum());  //  L -> Omega
 //       } else if  ( (corr_prior_beta == false)   &&  (corr_prior_norm == true) ) {
 //         for (int i = 1; i < n_tests; i++) {
 //           for (int j = 0; j < i; j++) {
 //             target_AD +=  stan::math::normal_lpdf(  Omega_var_copy[c](i, j), prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
 //           }
 //         }
 //         Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
 //         for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * log(L_Omega_var_copy[c](i, i));
 //         target_AD  += + (n_tests * stan::math::log(2) + jacobian_diag_elements.sum());  //  L -> Omega
 //       }
 //     }
 //
 //
 //     ///////////////////////
 //     stan::math::set_zero_all_adjoints();
 //     target_AD.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
 //     target_AD_grad =  Omega_raw_vec_var.adj();    // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
 //     stan::math::set_zero_all_adjoints();
 //     //////////////////////////////////////////////////////////// end of AD part
 //
 //
 //
 //     /////////////  prev stuff  ---- vars
 //     std::vector<stan::math::var> 	 u_prev_var_vec_var(n_class, 0.0);
 //     std::vector<stan::math::var> 	 prev_var_vec_var(n_class, 0.0);
 //     std::vector<stan::math::var> 	 tanh_u_prev_var(n_class, 0.0);
 //     Eigen::Matrix<stan::math::var, -1, -1>	 prev_var(1, n_class);
 //
 //     u_prev_var_vec_var[1] =  stan::math::to_var(u_prev_diseased);
 //     tanh_u_prev_var[1] = ( exp(2*u_prev_var_vec_var[1] ) - 1) / ( exp(2*u_prev_var_vec_var[1] ) + 1) ;
 //     u_prev_var_vec_var[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1) ) )  ;
 //     tanh_u_prev_var[0] = (exp(2*u_prev_var_vec_var[0] ) - 1) / ( exp(2*u_prev_var_vec_var[0] ) + 1) ;
 //
 //     prev_var_vec_var[1] = 0.5 * ( tanh_u_prev_var[1] + 1);
 //     prev_var_vec_var[0] =  0.5 * ( tanh_u_prev_var[0] + 1);
 //     prev_var(0,1) =  prev_var_vec_var[1];
 //     prev_var(0,0) =  prev_var_vec_var[0];
 //
 //     stan::math::var tanh_pu_deriv_var = ( 1 - tanh_u_prev_var[1] * tanh_u_prev_var[1]  );
 //     stan::math::var deriv_p_wrt_pu_var = 0.5 *  tanh_pu_deriv_var;
 //     stan::math::var tanh_pu_second_deriv_var  = -2 * tanh_u_prev_var[1]  * tanh_pu_deriv_var;
 //     stan::math::var log_jac_p_deriv_wrt_pu_var  = ( 1 / deriv_p_wrt_pu_var) * 0.5 * tanh_pu_second_deriv_var; // for gradient of u's
 //     stan::math::var  log_jac_p_var =    log( deriv_p_wrt_pu_var );
 //
 //
 //     stan::math::var  target_AD_prev = beta_lpdf(  prev_var(0,1), prev_prior_a, prev_prior_b  ); // weakly informative prior - helps avoid boundaries with slight negative skew (for lower N)
 //     target_AD_prev += log_jac_p_var;
 //
 //     target_AD  +=  target_AD_prev;
 //
 //     ///////////////////////
 //     target_AD_prev.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
 //     grad_prev_AD  =  u_prev_var_vec_var[1].adj() - u_prev_var_vec_var[0].adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
 //     stan::math::set_zero_all_adjoints();
 //     //////////////////////////////////////////////////////////// end of AD part
 //
 //
 //
 //
 //     for (int c = 0; c < n_class; ++c) {
 //       int cnt_1 = 0;
 //       for (int k = 0; k < n_tests; k++) {
 //         for (int l = 0; l < k + 1; l++) {
 //           (  L_Omega_var_copy[c](k, l)).grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
 //           int cnt_2 = 0;
 //           for (int i = 1; i < n_tests; i++) {
 //             for (int j = 0; j < i; j++) {
 //               deriv_L_wrt_unc_full[c](cnt_1, cnt_2)  =   Omega_unconstrained_var[c](i, j).adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
 //               cnt_2 += 1;
 //             }
 //           }
 //           stan::math::set_zero_all_adjoints();
 //           cnt_1 += 1;
 //         }
 //       }
 //     }
 //
 //
 //     ///////////////// get cholesky factor's (lower-triangular) of corr matrices
 //     // convert to 3d var array
 //
 //     for (int c = 0; c < n_class; ++c) {
 //       for (int t1 = 0; t1 < n_tests; ++t1) {
 //         for (int t2 = 0; t2 < n_tests; ++t2) {
 //           L_Omega_double[c](t1, t2) =   L_Omega_var_copy[c](t1, t2).val()  ;
 //         }
 //       }
 //     }
 //
 //     stan::math::recover_memory();
 //   }
 //
 //
 //   /////////////  prev stuff
 //   std::vector<double> 	 u_prev_var_vec(n_class, 0.0);
 //   std::vector<double> 	 prev_var_vec(n_class, 0.0);
 //   std::vector<double> 	 tanh_u_prev(n_class, 0.0);
 //   Eigen::Matrix<double, -1, -1>	 prev(1, n_class);
 //
 //   u_prev_var_vec[1] =  (double) u_prev_diseased ;
 //   tanh_u_prev[1] = ( exp(2*u_prev_var_vec[1] ) - 1) / ( exp(2*u_prev_var_vec[1] ) + 1) ;
 //   u_prev_var_vec[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) )  ;
 //   tanh_u_prev[0] = (exp(2*u_prev_var_vec[0] ) - 1) / ( exp(2*u_prev_var_vec[0] ) + 1) ;
 //
 //   prev_var_vec[1] = 0.5 * ( tanh_u_prev[1] + 1);
 //   prev_var_vec[0] =  0.5 * ( tanh_u_prev[0] + 1);
 //   prev(0,1) =  prev_var_vec[1];
 //   prev(0,0) =  prev_var_vec[0];
 //
 //
 //   double tanh_pu_deriv = ( 1 - tanh_u_prev[1] * tanh_u_prev[1]  );
 //   double deriv_p_wrt_pu_double = 0.5 *  tanh_pu_deriv;
 //   double tanh_pu_second_deriv  = -2 * tanh_u_prev[1]  * tanh_pu_deriv;
 //   double log_jac_p_deriv_wrt_pu  = ( 1 / deriv_p_wrt_pu_double) * 0.5 * tanh_pu_second_deriv; // for gradient of u's
 //   double  log_jac_p =    log( deriv_p_wrt_pu_double );
 //
 //
 //
 //   ///////////////////////////////////////////////////////////////////////// prior densities
 //   double prior_densities = 0.0;
 //
 //
 //   if (exclude_priors == false) {
 //     ///////////////////// priors for coeffs
 //     double prior_densities_coeffs = 0.0;
 //     for (int c = 0; c < n_class; c++) {
 //       for (int t = 0; t < n_tests; t++) {
 //         double num_1 = 0.9189385;
 //         prior_densities_coeffs  +=  - num_1 - log(prior_coeffs_sd(t,c)) - 0.5 * ( (beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) *   ( (beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) )  ;
 //       }
 //     }
 //     double prior_densities_corrs = target_AD.val();
 //     prior_densities = prior_densities_coeffs  +      prior_densities_corrs ;     // total prior densities and Jacobian adjustments
 //   }
 //
 //
 //   /////////////////////////////////////////////////////////////////////////////////////////////////////
 //   ///////// likelihood
 //   double s = 1/1.702;
 //   double sqrt_2_recip = 1 / stan::math::sqrt(2);
 //
 //   int chunk_counter = 0;
 //   int chunk_size  = std::round( N / n_chunks  / 2) * 2;  ; // N / n_chunks;
 //
 //
 //   double log_prob_out = 0.0;
 //
 //
 //   Eigen::Matrix<double, -1, -1 >  log_prev = prev;
 //
 //   for (int c = 0; c < n_class; c++) {
 //     log_prev(0,c) =  log(prev(0,c));
 //     for (int t = 0; t < n_tests; t++) {
 //       if (CI == true)      L_Omega_double[c](t,t) = 1;
 //     }
 //   }
 //
 //
 //   ///////////////////////////////////////////////
 //   Eigen::Matrix<float, -1, 1 >  log_lik   =   Eigen::Matrix<float, -1, 1>::Zero(N);   //////////////////////////////////////////////////
 //   Eigen::Matrix< double , -1, 1>  beta_grad_vec   =  Eigen::Matrix<double, -1, 1>::Zero(n_coeffs);  //
 //   Eigen::Matrix<double, -1, -1>   beta_grad_array  =  Eigen::Matrix<double, -1, -1>::Zero(n_class, n_tests); //
 //   std::vector<Eigen::Matrix<double, -1, -1 > > U_Omega_grad_array =  vec_of_mats_test(n_tests, n_tests, n_class); //
 //   Eigen::Matrix<double, -1, 1 > L_Omega_grad_vec(n_corrs + (n_class * n_tests)); //
 //   Eigen::Matrix<double, -1, 1 > U_Omega_grad_vec(n_corrs); //
 //   Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(n_class); //
 //   Eigen::Matrix<double, -1, 1>  prev_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(n_class); //
 //   Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec_out =   Eigen::Matrix<double, -1, 1>::Zero(n_class - 1); //
 //   Eigen::Matrix<double, -1, -1> u_grad_array_CM   =  Eigen::Matrix<double, -1, -1>::Zero(N, n_tests);  ////////////////////////////////////////////////
 //   ///////////////////////////////////////////////
 //
 //
 //
 //   double log_posterior = 0;
 //
 //   theta.head(n_us) =    theta.head(n_us).array().tanh() ;
 //   double log_jac_u  =    (  0.5 *   (1 -  ( theta.head(n_us).cast<double>().array()   *  theta.head(n_us).cast<double>().array()   ) )   ).log().matrix().sum();
 //
 //
 //   {
 //
 //
 //
 //     ///////////////////////////////////////////////
 //     std::vector<Eigen::Matrix<double, -1, -1 > >  Z_std_norm =  vec_of_mats_test(chunk_size, n_tests, n_class); //////////////////////////////
 //     std::vector<Eigen::Matrix<double, -1, -1 > >  Bound_Z =  vec_of_mats_test(chunk_size, n_tests, n_class); //////////////////////////////
 //     ///////////////////////////////////////////////
 //
 //
 //     ///////////////////////////////////////////////
 //     Eigen::Matrix<int, -1, -1>  y_sign_chunk  =  Eigen::Matrix<int, -1, -1>::Zero(chunk_size, n_tests); /////
 //     Eigen::Matrix<double, -1, -1>  y_m_ysign_x_u_array =   Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;
 //     Eigen::Matrix<float, -1, -1> y1_or_log_phi_Bound_Z =  Eigen::Matrix<float, -1, -1>::Zero(chunk_size, n_tests);
 //     Eigen::Matrix<float, -1, -1> log_phi_Z_recip_or_u_array = Eigen::Matrix<float, -1, -1>::Zero(chunk_size, n_tests);
 //     ///////////////////////////////////////////////
 //
 //
 //     ///////////////////////////////////////////////
 //     std::vector<Eigen::Matrix<float, -1, -1 > >  log_prob   = vec_of_mats_test_float(chunk_size, n_tests, n_class);  // can be logged (> 0)
 //     ///////////////////////////////////////////////
 //     Eigen::Matrix<double, -1, 1> prod_container_or_inc_array  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
 //     Eigen::Matrix<float, -1, 1> log_prob_n  =  Eigen::Matrix<float, -1, 1>::Zero(chunk_size); // can be logged (> 0)
 //     ///////////////////////////////////////////////
 //     ///////////////////////////////////////////////
 //     Eigen::Matrix<float, -1, -1>     log_common_grad_term_1   =  Eigen::Matrix<float, -1, -1>::Zero(chunk_size, n_tests); // can be logged (> 0)
 //     Eigen::Matrix<float, -1, -1 >    log_prop_rowwise_prod_temp   =  Eigen::Matrix<float, -1, -1>::Zero(chunk_size, n_tests); // can be logged (> 0)
 //     Eigen::Matrix<float, -1, 1> log_prop_rowwise_prod_temp_all  =  Eigen::Matrix<float, -1, 1>::Zero(chunk_size); // can be logged (> 0)
 //
 //     Eigen::Matrix<double, -1, -1 >    y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 //     Eigen::Matrix<double, -1, -1 >    y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 //     Eigen::Matrix<double, -1, -1> grad_prob =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 //     Eigen::Matrix<double, -1, -1> z_grad_term = Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 //     Eigen::Matrix<double, -1, 1> derivs_chain_container_vec  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
 //
 //     ///////////////////////////////////////////////
 //
 //
 //     //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 //     int iiii = 0;
 //     int iiiiii = 0;
 //     double sqrt_2_pi_recip =   1 / sqrt(2 * M_PI) ; //  0.3989422804;
 //
 //
 //     for (int nc = 0; nc < n_chunks; nc++) {
 //
 //       int chunk_counter = nc;
 //
 //       log_phi_Z_recip_or_u_array.array() = ( 0.5 * (  theta.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).reshaped(chunk_size, n_tests).array() + 1 ).array() ).cast<float>() ;
 //
 //
 //       y_sign_chunk.array() =     ( y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array() + (  y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array() - 1).array() ).array() ;
 //       y_m_ysign_x_u_array.array()  =   ( (  (   y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array()   - y_sign_chunk.array()    *  log_phi_Z_recip_or_u_array.cast<double>().array()    ).array() ) ) ; //////// checked
 //
 //
 //       {
 //
 //         Eigen::Matrix<float, -1, -1>     lp_array  =  Eigen::Matrix<float, -1, -1>::Zero(chunk_size, n_class);   // can be float (> 0)
 //         Eigen::Matrix<float, -1, -1 >    log_Phi_Z_temp   =  Eigen::Matrix<float, -1, -1>::Zero(chunk_size, n_tests) ;  // can be logged (> 0)
 //         Eigen::Matrix<float, -1, -1 >    log_Bound_U_Phi_Bound_Z_temp   =  Eigen::Matrix<float, -1, -1>::Zero(chunk_size, n_tests);   // can be logged (> 0)
 //
 //         for (int c = 0; c < n_class; c++) {
 //
 //           prod_container_or_inc_array.array()  = 0; // needs to be reset to 0
 //
 //           for (int t = 0; t < n_tests; t++) {
 //
 //            // Bound_Z[c].col(t).array() =   ( ((  - ( beta_double_array(c, t) +      prod_container_or_inc_array.array()   )  ) / L_Omega_double[c](t, t) )  )  ;
 //             log_abs_Bound_Z[c].col(t).array() =   ( ((  - ( beta_double_array(c, t) +      prod_container_or_inc_array.array()   )  ) / L_Omega_double[c](t, t) )  ).abs().log()  ;
 //
 //             if (Phi_type == 3) { // stable and accurate but slower
 //               // Bound_U_Phi_Bound_Z_temp.col(t).array() =  Eigen::Select(    stan::math::abs(Bound_Z[c].col(t).array()) < ub_threshold_phi_approx ,
 //               //                              0.5 *  ( -  sqrt_2_recip * Bound_Z[c].col(t).array() ).erfc().array()  ,
 //               //                              stan::math::inv_logit(1.702 *  Bound_Z[c].col(t) )    ) ;
 //             } else if (Phi_type == 1) { ////////////////////// standard Phi
 //               log_Bound_U_Phi_Bound_Z_temp.col(t).array() =  ( 0.5 *  ( -  sqrt_2_recip * Bound_Z[c].col(t).array() ).erfc().array() ).log()  ; // Phi
 //             }
 //
 //
 //             log_Phi_Z_temp.col(t).array()    =  (   y.col(t).segment(chunk_size * chunk_counter, chunk_size).array().cast<float>()  *       log_Bound_U_Phi_Bound_Z_temp.col(t).array().cast<double>().exp() +
 //                                                (  y.col(t).segment(chunk_size * chunk_counter, chunk_size).array().cast<float>()  -   log_Bound_U_Phi_Bound_Z_temp.col(t).array().cast<double>().exp() ) * y_sign_chunk.col(t).array().cast<float>() * log_phi_Z_recip_or_u_array.col(t).array()  ).array().log()   ;  //////// checked
 //
 //             if (Phi_type == 3) { // stable and accurate but slower
 //               // Z_std_norm[c].col(t).array() =  Eigen::Select(     stan::math::abs(Bound_Z[c].col(t).array()) < ub_threshold_phi_approx ,
 //               //                   qnorm_rcpp_vec(   log_Phi_Z_temp.col(t).cast<double>().exp() ).array()  ,
 //               //                   stan::math::logit(   log_Phi_Z_temp.col(t).cast<double>().exp() ).array() / 1.702    ) ;
 //             } else if (Phi_type == 1) { //////////////////////// standard Phi
 //               Z_std_norm[c].col(t).array() =  qnorm_rcpp_vec(   log_Phi_Z_temp.col(t).cast<double>().exp() ).array()  ;
 //             }
 //
 //
 //             if (t < n_tests - 1)       prod_container_or_inc_array.array()  =   ( Z_std_norm[c].block(0, 0, chunk_size, t + 1)  *   ( L_Omega_double[c].row(t+1).head(t+1).transpose()  ) ) ; //////// checked
 //
 //           } // end of t loop
 //
 //
 //           y1_or_log_phi_Bound_Z.array() =   (  y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array() * ( 1 - log_Bound_U_Phi_Bound_Z_temp.array().cast<double>().exp() ) +
 //                                            (  y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array() - 1  ).array()   * log_Bound_U_Phi_Bound_Z_temp.array().cast<double>().exp() * y_sign_chunk.array() ).array().log().cast<float>().array() ;
 //
 //
 //
 //           lp_array.col(c).array() =    y1_or_log_phi_Bound_Z.array().rowwise().sum().array() +  log_prev(0,c) ;
 //
 //           log_prob[c] =   y1_or_log_phi_Bound_Z.array() ; // .cast<double>().array().exp();
 //
 //         } // end of c loop
 //
 //         log_lik.segment(chunk_size * chunk_counter, chunk_size).array()   = (  lp_array.array().maxCoeff() + (lp_array.array() - lp_array.array().maxCoeff() ).array().exp().rowwise().sum().array().log() ).cast<float>().array()  ; // correct & stable
 //         log_prob_n =   log_lik.segment(chunk_size * chunk_counter, chunk_size) ; // log_lik.segment(chunk_size * chunk_counter, chunk_size).array().exp().matrix(); // correct & stable
 //
 //
 //
 //       }
 //
 //
 //       {
 //
 //
 //         for (int c = 0; c < n_class; c++) {
 //
 //           for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
 //             int t = n_tests - (i+1) ;
 //            // prop_rowwise_prod_temp.col(t).array()   =   prob[c].block(0, t + 0, chunk_size, i + 1).rowwise().prod().array() ;
 //             log_prop_rowwise_prod_temp.col(t).array()   =   log_prob[c].block(0, t + 0, chunk_size, i + 1).array().abs().log().matrix().rowwise().sum().array() ;
 //           }
 //
 //           // prop_rowwise_prod_temp_all.array() = prob[c].block(0, 0, chunk_size, n_tests).rowwise().prod().array()  ;
 //           log_prop_rowwise_prod_temp_all.array() = log_prob[c].block(0, 0, chunk_size, n_tests).array().abs().log().matrix().rowwise().sum().array()  ;
 //
 //           for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
 //             int t = n_tests - (i + 1) ;
 //             //common_grad_term_1.col(t) =   (  ( prev(0,c) / prob_n.array() ) * ( prop_rowwise_prod_temp_all.array() /  prop_rowwise_prod_temp.col(t).array()  ).array() )  ;
 //             log_common_grad_term_1.col(t) =  ( log(abs(prev(0,c) )) -   log_prob_n.array().abs().log() ) +  ( log_prop_rowwise_prod_temp_all.array()   - log_prop_rowwise_prod_temp.col(t).array()  )  ; //   (  ( prev(0,c) / prob_n.array() ) * ( prop_rowwise_prod_temp_all.array() /  prop_rowwise_prod_temp.col(t).array()  ).array() )  ;
 //           }
 //
 //
 //           if (Phi_type == 3) { // stable and accurate but slower
 //             // // for numerical stability
 //             // log_phi_Z_recip_or_u_array.array() =    Eigen::Select(   Bound_Z[c].array().abs() < ub_threshold_phi_approx ,
 //             //                                                         0.5 * log(2 * M_PI)  +  0.5 * Z_std_norm[c].array() * Z_std_norm[c].array() , //  sqrt_2_pi_recip *  ( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).exp().array()   ,
 //             //                                                       (  1.702 * (1 / stan::math::square( stan::math::exp(Z_std_norm[c] * (1/(2*s)) ) + stan::math::exp( - Z_std_norm[c] *  (1/(2*s)) ) ).array()  ) ).abs().log()  ).array().cast<float>().array() ;
 //             // // for numerical stability
 //             // y1_or_log_phi_Bound_Z.array() =    Eigen::Select(   Bound_Z[c].array().abs() < ub_threshold_phi_approx ,
 //             //                                              - 0.5 * log(2 * M_PI) -  0.5 * Bound_Z[c].array() * Bound_Z[c].array()  , //  sqrt_2_pi_recip *  ( - 0.5 * Bound_Z[c].array() *  Bound_Z[c].array() ).exp().array()   ,
 //             //                                              ( 1.702 * (1 / stan::math::square( stan::math::exp(Bound_Z[c] *  (1/(2*s)) ) + stan::math::exp( - Bound_Z[c] *  (1/(2*s)) ) ).array()  )  ).abs().log() ).array().cast<float>().array()  ;
 //           } else if (Phi_type == 1) { //////////////////////// standard Phi
 //             log_phi_Z_recip_or_u_array.array()  =  - ( - 0.5 * log(2 * M_PI)  +  - 0.5 * Z_std_norm[c].array() * Z_std_norm[c].array() ).cast<float>().array()   ; //    1 / (  sqrt_2_pi_recip *  ( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).exp().array() ) ;
 //             y1_or_log_phi_Bound_Z.array() =              ( - 0.5 * log(2 * M_PI)  +  - 0.5 * Bound_Z[c].array() * Bound_Z[c].array()  ).cast<float>().array()  ; //    sqrt_2_pi_recip *  ( - 0.5 * Bound_Z[c].array()    *  Bound_Z[c].array()    ).exp().array() ;
 //           }
 //
 //
 //
 //           for (int t = 0; t < n_tests; t++) {
 //             y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t) =         y_sign_chunk.col(t).array() *   (  y1_or_log_phi_Bound_Z.col(t).cast<double>().array().exp()     * ( 1 / L_Omega_double[c](t,t)  ) ) ; //
 //             y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t) =    (y_m_ysign_x_u_array.col(t).array() * (  log_phi_Z_recip_or_u_array.col(t).array()   +  y1_or_log_phi_Bound_Z.col(t).array().exp().array()  ).cast<double>().array().exp()    * ( 1 / L_Omega_double[c](t,t)  )  )   ;
 //           }
 //           //
 //
 //
 //
 //           ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grad of nuisance parameters / u's (manual)
 //           u_grad_array_CM.col(n_tests - 1).segment( chunk_size * chunk_counter, chunk_size).array() +=  0;
 //
 //           ///// then second-to-last term (test T - 1)
 //             int t = n_tests - 1;
 //
 //             u_grad_array_CM.col(n_tests - 2).segment( chunk_size * chunk_counter, chunk_size).array()  +=  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t).array()   *  (  1 /  L_Omega_double[c](t,t - 1)   ) *
 //                                                                                                           ( log_common_grad_term_1.col(t).array()   +   log_phi_Z_recip_or_u_array.col(t-1).array()   + log_prob[c].col(t-1).array() ).cast<double>().array().exp()  ;
 //
 //
 //             { ///// then third-to-last term (test T - 2)
 //               t = n_tests - 2;
 //
 //               z_grad_term.col(0) =   ( log_phi_Z_recip_or_u_array.col(t-1).array() +  log_prob[c].col(t-1).array()  ).cast<double>().array().exp()   ;
 //               grad_prob.col(0) =        y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t).array()   *     L_Omega_double[c](t, t - 1) *   z_grad_term.col(0).array() ; // lp(T-1) - part 2;
 //               z_grad_term.col(1).array()  =      L_Omega_double[c](t,t-1) *   z_grad_term.col(0).array() *       y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t).array() ;
 //
 //               grad_prob.col(1)  =         (   y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t+1).array()   ) *  (  z_grad_term.col(0).array() *  L_Omega_double[c](t + 1,t - 1)  -   z_grad_term.col(1).array()  * L_Omega_double[c](t+1,t)) ;
 //
 //               u_grad_array_CM.col(n_tests - 3).segment( chunk_size * chunk_counter, chunk_size).array()  +=  log_common_grad_term_1.col(t).array().cast<double>().array().exp()   *  (  grad_prob.col(1).array() * log_prob[c].col(t).cast<double>().array().exp()   +      grad_prob.col(0).array() *  log_prob[c].col(t+1).cast<double>().array().exp()   );  // ----------   correct
 //             }
 //
 //
 //
 //             // then rest of terms
 //             for (int i = 1; i < n_tests - 2; i++) { // i goes from 1 to 3
 //
 //
 //               grad_prob.array() = 0;
 //               z_grad_term.array() = 0;
 //
 //               int t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)
 //
 //               z_grad_term.col(0) =  ( log_phi_Z_recip_or_u_array.col(t-1).array()   + log_prob[c].col(t-1).array() ).cast<double>().array().exp() ;
 //               grad_prob.col(0) =         y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t).array()   *   L_Omega_double[c](t, t - 1) *   z_grad_term.col(0).array() ; // lp(T-1) - part 2;
 //
 //               for (int ii = 0; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1 u_grad_z u_grad_term
 //                 if (ii == 0)    prod_container_or_inc_array  = (   (z_grad_term.block(0, 0, chunk_size, ii + 1) ) *  (fn_first_element_neg_rest_pos(L_Omega_double[c].row( t + (ii-1) + 1).segment(t - 1, ii + 1))).transpose()  )      ;
 //                 z_grad_term.col(ii+1)  =           y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t + ii).array() *  -   prod_container_or_inc_array.array() ;
 //                 prod_container_or_inc_array  = (   (z_grad_term.block(0, 0, chunk_size, ii + 2) ) *  (fn_first_element_neg_rest_pos(L_Omega_double[c].row( t + (ii) + 1).segment(t - 1, ii + 2))).transpose()  )      ;
 //                 grad_prob.col(ii+1)  =       (    y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t+ii+1).array()  ) *     -    prod_container_or_inc_array.array()  ;
 //               } // end of ii loop
 //
 //               {
 //                 derivs_chain_container_vec.array() = 0;
 //
 //                 for (int ii = 0; ii < i + 2; ii++) {
 //                   derivs_chain_container_vec.array()  +=  ( grad_prob.col(ii).array()    * (       log_prop_rowwise_prod_temp.col(t).array()  -   log_prob[c].col(t + ii).array()  ).cast<double>().array().exp()     ).array()  ;
 //                 }
 //                 u_grad_array_CM.col(n_tests - (i+3)).segment( chunk_size * chunk_counter, chunk_size).array()    +=   (  ( (     log_common_grad_term_1.col(t).array().cast<double>().array().exp()   *  derivs_chain_container_vec.array() ) ).array()  ).array() ;
 //               }
 //
 //             }
 //
 //             // /////////////////////////////////////////////////////////////////////////// Grad of intercepts / coefficients (beta's)
 //             // ///// last term first (test T)
 //
 //             {
 //
 //               int t = n_tests - 1;
 //
 //               beta_grad_array(c, t) +=     (log_common_grad_term_1.col(t).array().cast<double>().array().exp()  * y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t).array()    ).sum();
 //
 //               ///// then second-to-last term (test T - 1)
 //               {
 //                 t = n_tests - 2;
 //                 grad_prob.col(0) =          y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t).array()   ;
 //                 z_grad_term.col(1)   =     - y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t).array()         ;
 //                 grad_prob.col(1)  =         y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t+1).array()      *    L_Omega_double[c](t + 1,t) *      z_grad_term.col(1).array()   ;
 //                 beta_grad_array(c, t) +=  (log_common_grad_term_1.col(t).array().cast<double>().array().exp()    * ( grad_prob.col(1).array() * log_prob[c].col(t).array().cast<double>().array().exp()  +         grad_prob.col(0).array() *  log_prob[c].col(t+1).array().cast<double>().array().exp()  ) ).sum() ;
 //               }
 //
 //               // then rest of terms
 //               for (int i = 1; i < n_tests - 1; i++) { // i goes from 1 to 3
 //
 //                 t = n_tests - (i+2) ;
 //
 //                 grad_prob.col(0)  =     y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t)      ;
 //
 //                 // component 2 (second-to-earliest test)
 //                 z_grad_term.col(1)  =        - y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t).array()       ;
 //                 grad_prob.col(1) =        y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t + 1).array()    *       L_Omega_double[c](t + 1,t) *   z_grad_term.col(1).array()  ;
 //
 //                 // rest of components
 //                 for (int ii = 1; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1
 //                   if (ii == 1)  prod_container_or_inc_array  = (    z_grad_term.block(0, 1, chunk_size, ii)  *   L_Omega_double[c].row( t + (ii - 1) + 1).segment(t + 0, ii + 0).transpose()  );
 //                   z_grad_term.col(ii+1)  =        -y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t + ii).array()    *   prod_container_or_inc_array.array();
 //                   prod_container_or_inc_array  = (    z_grad_term.block(0, 1, chunk_size, ii + 1)  *   L_Omega_double[c].row( t + (ii) + 1).segment(t + 0, ii + 1).transpose()  );
 //                   grad_prob.col(ii+1) =      (   y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t + ii + 1).array()  ).array()     *  prod_container_or_inc_array.array();
 //
 //                 }
 //
 //                 {
 //
 //                   derivs_chain_container_vec.array() = 0;
 //
 //                   ///// attempt at vectorising  // bookmark
 //                   for (int ii = 0; ii < i + 2; ii++) {
 //                     derivs_chain_container_vec.array() +=  ( grad_prob.col(ii).array()  * (      log_prop_rowwise_prod_temp.col(t).array()  -   log_prob[c].col(t + ii).array()   ).cast<double>().array().exp()   ).array() ;
 //                   }
 //                   beta_grad_array(c, t) +=        ( log_common_grad_term_1.col(t).array().cast<double>().array().exp()   *  derivs_chain_container_vec.array() ).sum();
 //                 }
 //
 //               }
 //
 //             }
 //
 //
 //
 //             ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grad of L_Omega ('s)
 //             {
 //               {
 //                 ///////////////////////// deriv of diagonal elements (not needed if using the "standard" or "Stan" Cholesky parameterisation of Omega)
 //
 //                 //////// w.r.t last diagonal first
 //                 {
 //                   int  t1 = n_tests - 1;
 //
 //                   U_Omega_grad_array[c](t1, t1) +=   ( ( log_common_grad_term_1.col(t1).array().cast<double>().array().exp()   *   y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array() ).array() * (   Bound_Z[c].col(t1).array()     )   ).sum() ;
 //                 }
 //
 //
 //                 //////// then w.r.t the second-to-last diagonal
 //                 int  t1 = n_tests - 2;
 //
 //                 grad_prob.col(0).array()  =  (   y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array()  *   (      Bound_Z[c].col(t1).array()     ) )  ;     // correct  (standard form)
 //
 //                 z_grad_term.col(0).array()  =      (  ( (  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array()   ).array()     *  Bound_Z[c].col(t1).array()  )  )   ;  // correct
 //
 //                 prod_container_or_inc_array.array()  =   (  L_Omega_double[c](t1 + 1, t1)    *   z_grad_term.col(0).array()   ) ; // sequence
 //                 grad_prob.col(1).array()  =               (   y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1 + 1).array()   *     (   (   (     prod_container_or_inc_array.array()   ) .array()   ) )  ).array()  ;    // correct   (standard form)
 //
 //                 U_Omega_grad_array[c](t1, t1) +=   ( ( (   log_common_grad_term_1.col(t1).array()  +  log_prob[c].col(t1 + 1).array() ).cast<double>().array().exp()  *   grad_prob.col(0).array()  )    +     (   log_prob[c].col(t1).array().cast<double>().array().exp()  *      grad_prob.col(1).array()   )  ).sum()   ;
 //
 //               }
 //
 //               // //////// then w.r.t the third-to-last diagonal .... etc
 //               {
 //
 //                 for (int i = 3; i < n_tests + 1; i++) {
 //
 //                   int  t1 = n_tests - i;
 //
 //                   //////// 1st component
 //                   // 1st grad_Z term and 1st grad_prob term (simplest terms)
 //                   grad_prob.col(0).array()  =   (  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array() )  *  ( Bound_Z[c].col(t1).array()   ).array()  ; // correct  (standard form)
 //                   z_grad_term.col(0).array()  =    - y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t1).array()   *  ( Bound_Z[c].col(t1).array()    ).array()   ;   // correct  (standard form)
 //
 //                   // 2nd   grad_Z term and 2nd grad_prob  (more complicated than 1st term)
 //                   prod_container_or_inc_array.array() =    L_Omega_double[c](t1 + 1, t1)   * z_grad_term.col(0).array()  ; // correct  (standard form)
 //                   grad_prob.col(1).array()  =   (  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1 + 1).array()  )   *  (    prod_container_or_inc_array.array() ).array()  ; // correct  (standard form)
 //
 //
 //                   for (int ii = 1; ii < i - 1; ii++) {
 //                     z_grad_term.col(ii).array()  =    - y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t1 + ii).array()     *   (    prod_container_or_inc_array.array() ).array()  ;   // correct  (standard form)       // grad_z term
 //                     prod_container_or_inc_array.matrix() =   (  L_Omega_double[c].row(t1 + ii + 1).segment(t1, ii + 1) *   z_grad_term.block(0, 0, chunk_size, ii + 1).transpose() ).transpose().matrix(); // correct  (standard form)
 //                     grad_prob.col(ii + 1).array()  =   (  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1 + ii + 1).array()  )   *   (   prod_container_or_inc_array.array() ).array() ;  // correct  (standard form)     //    grad_prob term
 //                   }
 //
 //                   {
 //
 //                     derivs_chain_container_vec.array() = 0;
 //
 //                     ///// attempt at vectorising  // bookmark
 //                     for (int iii = 0; iii <  i; iii++) {
 //                    //   derivs_chain_container_vec.array()  +=    grad_prob.col(iii).array()  * (       prop_rowwise_prod_temp.col(t1).array()    /  prob[c].col(t1 + iii).array()  ).array()  ;  // correct  (standard form)
 //                       derivs_chain_container_vec.array() +=  ( grad_prob.col(iii).array()  * (      log_prop_rowwise_prod_temp.col(t1).array()  -   log_prob[c].col(t1 + iii).array()   ).cast<double>().array().exp()   ).array() ;
 //
 //                     }
 //
 //                     U_Omega_grad_array[c](t1, t1)   +=       ( log_common_grad_term_1.col(t1).array().cast<double>().array().exp()   * derivs_chain_container_vec.array() ).sum()  ; // correct  (standard form)
 //                   }
 //
 //                 }
 //
 //
 //
 //               }
 //
 //             }
 //
 //
 //
 //
 //             {
 //
 //               { ///////////////////// last row first
 //                 int t1_dash = 0;  // t1 = n_tests - 1
 //
 //                 int t1 = n_tests - (t1_dash + 1); //  starts at n_tests - 1;  // if t1_dash = 0 -> t1 = T - 1
 //                 int t2 = n_tests - (t1_dash + 2); //  starts at n_tests - 2;
 //
 //                 U_Omega_grad_array[c](t1,t2) +=      ( ( log_common_grad_term_1.col(t1).array().cast<double>().array().exp()      * - y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array() ).array() *   (     (-  Z_std_norm[c].col(t2).array()  )   ).array() ).sum() ;
 //
 //                 if (t1 > 1) { // starts at  L_{T, T-2}
 //                   {
 //                     t2 =   n_tests - (t1_dash + 3); // starts at n_tests - 3;
 //                     U_Omega_grad_array[c](t1,t2) +=     (  log_common_grad_term_1.col(t1).array().cast<double>().array().exp()  *   (  - y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array()  ).array()  *   ( (      ( - Z_std_norm[c].col(t2).array() )  ).array() ) ).sum()  ;
 //                   }
 //                 }
 //
 //                 if (t1 > 2) {// starts at  L_{T, T-3}
 //                   for (int t2_dash = 3; t2_dash < n_tests; t2_dash++ ) { // t2 < t1
 //                     t2 = n_tests - (t1_dash + t2_dash + 1); // starts at T - 4
 //                     if (t2 < n_tests - 1) {
 //                       U_Omega_grad_array[c](t1,t2)  +=   (log_common_grad_term_1.col(t1).array().cast<double>().array().exp() *   (  - y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array() ).array() * ( (    - Z_std_norm[c].col(t2).array()  ) ).array()).sum() ;
 //                     }
 //                   }
 //                 }
 //               }
 //             }
 //
 //
 //
 //
 //             {
 //               /////////////////// then rest of rows (second-to-last row, then third-to-last row, .... , then first row)
 //               for (int t1_dash = 1; t1_dash <  n_tests - 1;  t1_dash++) {
 //                 int  t1 = n_tests - (t1_dash + 1);
 //
 //                 for (int t2_dash = t1_dash + 1; t2_dash <  n_tests;  t2_dash++) {
 //                   int t2 = n_tests - (t2_dash + 1); // starts at t1 - 1, then t1 - 2, up to 0
 //
 //
 //                   {
 //
 //
 //                     //prod_container_or_inc_array.array()  =  Z_std_norm[c].block(0, t2, chunk_size, t1 - t2) * deriv_L_t1.head(t1 - t2) ;
 //                     prod_container_or_inc_array.array()  =  Z_std_norm[c].col(t2) ;
 //                     grad_prob.col(0) =      (( -  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1).array()   ).array() *   (      (     -    prod_container_or_inc_array.array() ) ).array())  ;
 //
 //                     z_grad_term.col(0).array()  =               ( (  y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t1).array()    ).array()   ).array()  *   ( (   (    -    prod_container_or_inc_array.array()     ).array()  )   ).array()  ;
 //
 //                     if (t1_dash > 0) {
 //                       for (int t1_dash_dash = 1; t1_dash_dash <  t1_dash + 1;  t1_dash_dash++) {
 //                         if (t1_dash_dash > 1) {
 //                           z_grad_term.col(t1_dash_dash - 1)   =           (  (  y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z_times_L_Omega_diag_recip.col(t1 + t1_dash_dash - 1).array()    ).array()   ).array()  *  ( - prod_container_or_inc_array.array() )    ;
 //                         }
 //                         prod_container_or_inc_array.array()  =            (   z_grad_term.block(0, 0, chunk_size, t1_dash_dash) *   L_Omega_double[c].row(t1 + t1_dash_dash).segment(t1, t1_dash_dash).transpose()   ) ;
 //                         grad_prob.col(t1_dash_dash)  =            (  ( ( -  y_sign_chunk_times_phi_Bound_Z_x_L_Omega_diag_recip.col(t1 + t1_dash_dash).array()     ).array() )  )  *    (  -    prod_container_or_inc_array.array()  ) ;
 //                       }
 //                     }
 //
 //                     {
 //
 //                       derivs_chain_container_vec.array() = 0;
 //
 //                       ///// attempt at vectorising  // bookmark
 //                       for (int ii = 0; ii <  t1_dash + 1; ii++) {
 //                         derivs_chain_container_vec.array() += ( grad_prob.col(ii).array()  * ( log_prop_rowwise_prod_temp.col(t1).array()    -  log_prob[c].col(t1 + ii).array()  ).cast<double>().array().exp()  ).array() ; // correct i think
 //                       }
 //                       U_Omega_grad_array[c](t1, t2)   +=       ( log_common_grad_term_1.col(t1).array().cast<double>().array().exp()   * derivs_chain_container_vec.array() ).sum()  ; // correct  (standard form)
 //
 //                     }
 //
 //
 //
 //
 //                   }
 //                 }
 //               }
 //
 //             }
 //
 //
 //             prev_grad_vec(c)  +=   (  ( 1 / log_prob_n.cast<double>().array().exp() ).array() * log_prob[c].cast<double>().array().exp().matrix().rowwise().prod().array()     ).matrix().sum()  ; // (   - log_prob_n.array()  + log_prob[c].array().abs().log().matrix().rowwise().sum().array() ).cast<double>().array().exp().matrix().sum()    ; //    ( 1 / prob_n.array() ) * prob[c].rowwise().prod().array()     ).matrix().sum()  ;
 //
 //
 //
 //
 //         } // end of c loop
 //
 //       }
 //
 //
 //
 //     }  // end of chunk loop
 //
 //
 //
 //
 //
 //     //////////////////////// gradients for latent class membership probabilitie(s) (i.e. disease prevalence)
 //     for (int c = 0; c < n_class; c++) {
 //       prev_unconstrained_grad_vec(c)  =   prev_grad_vec(c)   * deriv_p_wrt_pu_double ;
 //     }
 //     prev_unconstrained_grad_vec(0) = prev_unconstrained_grad_vec(1) - prev_unconstrained_grad_vec(0) - 2 * tanh_u_prev[1];
 //     prev_unconstrained_grad_vec_out(0) = prev_unconstrained_grad_vec(0);
 //
 //
 //     log_prob_out += log_lik.sum();
 //
 //     if (exclude_priors == false)  log_prob_out += prior_densities;
 //
 //     log_prob_out +=  log_jac_u;
 //
 //     log_posterior = (double) log_prob_out;
 //
 //     int i = 0; // probs_all_range.prod() cancels out
 //     for (int c = 0; c < n_class; c++) {
 //       for (int t = 0; t < n_tests; t++) {
 //         if (exclude_priors == false) {
 //           beta_grad_array(c, t) +=  - ((beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) * (1/ prior_coeffs_sd(t,c) ) ;     // add normal prior density derivative to gradient
 //         }
 //         beta_grad_vec(i) = beta_grad_array(c, t);
 //         i += 1;
 //       }
 //     }
 //
 //
 //
 //
 //     {
 //       int i = 0;
 //       for (int c = 0; c < n_class; c++ ) {
 //         for (int t1 = 0; t1 < n_tests; t1++ ) {
 //           for (int t2 = 0; t2 < t1 + 1; t2++ ) {
 //             L_Omega_grad_vec(i) = U_Omega_grad_array[c](t1,t2);
 //             i += 1;
 //           }
 //         }
 //       }
 //     }
 //
 //
 //
 //     Eigen::Matrix<double, -1, 1>  grad_wrt_L_Omega_nd =   L_Omega_grad_vec.segment(0, dim_choose_2 + n_tests);
 //     Eigen::Matrix<double, -1, 1>  grad_wrt_L_Omega_d =   L_Omega_grad_vec.segment(dim_choose_2 + n_tests, dim_choose_2 + n_tests);
 //
 //     U_Omega_grad_vec.segment(0, dim_choose_2) =  ( grad_wrt_L_Omega_nd.transpose()  *  deriv_L_wrt_unc_full[0].cast<double>() ).transpose() ;
 //     U_Omega_grad_vec.segment(dim_choose_2, dim_choose_2) =   ( grad_wrt_L_Omega_d.transpose()  *  deriv_L_wrt_unc_full[1].cast<double>() ).transpose()  ;
 //
 //
 //
 //
 //
 //   }
 //
 //   ////////////////////////////////////////////////////////////////////////////////////// output vec
 //   Eigen::Matrix<double, -1, 1> out_mat    =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N);
 //   //////////////////////////////////////////////////////////////////////////////////////
 //
 //
 //   {
 //
 //     // out_mat.segment(1, n_us).array() =    u_grad_array_RM.reshaped<RowMajor>()      ;
 //
 //     for (int nc = 0; nc < n_chunks; nc++) {
 //
 //       int chunk_counter = nc;
 //       out_mat.segment(1, n_us).segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)  =    u_grad_array_CM.block(chunk_size * chunk_counter, 0, chunk_size, n_tests).reshaped().cast<double>()     ;
 //
 //     }
 //
 //   }
 //
 //
 //
 //
 //   {
 //
 //     ////////////////////////////  outputs // add log grad and sign stuff';///////////////
 //     out_mat(0) =  log_posterior;
 //     out_mat.segment(1 + n_us, n_corrs) = target_AD_grad.cast<double>();
 //     out_mat.segment(1 + n_us, n_corrs) += U_Omega_grad_vec.cast<double>()  ;
 //     out_mat.segment(1 + n_us + n_corrs, n_coeffs) = beta_grad_vec.cast<double>() ;
 //     out_mat(n_params, 0) = ((grad_prev_AD +  prev_unconstrained_grad_vec_out(0)));
 //     out_mat.segment(1, n_us).array() =      ( out_mat.segment(1, n_us).array().cast<double>() *  ( 0.5 * (1 -  ( theta.head(n_us).cast<double>().array() * theta.head(n_us).cast<double>().array() )  )  ) - 2 * theta.head(n_us).cast<double>().array() ).cast<double>() ;
 //     out_mat.segment( 1 + n_params, N) = log_lik.array().matrix().cast<double>() ;
 //
 //
 //   }
 //
 //   return(out_mat);






































// [[Rcpp::export]]
Eigen::Matrix<double, -1, -1>    Rcpp_fn_wo_list_ELMC_multiple_leapfrogs_EUC_EFISH_HI_with_MIXED_M_NT_us( int n_cores,
                                                                                                          Eigen::Matrix<double, -1, 1  > theta,
                                                                                                          Eigen::Matrix<int, -1, -1>	 y,
                                                                                                          std::vector<Eigen::Matrix<double, -1, -1 > >  X,
                                                                                                          bool dense_G_indicator,
                                                                                                          double numerical_diff_e,
                                                                                                          int L,
                                                                                                          double eps,
                                                                                                          double log_posterior,
                                                                                                          Eigen::Matrix<double, -1,  1  > M_main_vec,
                                                                                                          Eigen::Matrix<double, -1,  1  > M_inv_us_vec, //////////////////////////////////////////////
                                                                                                          Eigen::Matrix<double, -1, -1  > M_dense_main,
                                                                                                          Eigen::Matrix<double, -1, -1  > M_inv_dense_main,
                                                                                                          Eigen::Matrix<double, -1, -1  > M_inv_dense_main_chol,
                                                                                                          int n_us,
                                                                                                          int n_params_main,
                                                                                                          bool exclude_priors,
                                                                                                          bool CI,
                                                                                                          Eigen::Matrix<double, -1,  1> lkj_cholesky_eta,
                                                                                                          Eigen::Matrix<double, -1, -1> prior_coeffs_mean,
                                                                                                          Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                                                          int n_class,
                                                                                                          int n_tests,
                                                                                                          int ub_threshold_phi_approx,
                                                                                                          int n_chunks,
                                                                                                          bool corr_force_positive,
                                                                                                          std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                                                          std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                                                          bool corr_prior_beta ,
                                                                                                          bool corr_prior_norm ,
                                                                                                          std::vector<Eigen::Matrix<double, -1, -1 > >   lb_corr,
                                                                                                          std::vector<Eigen::Matrix<double, -1, -1 > >   ub_corr,
                                                                                                          std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                                                          std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                                                          double prev_prior_a,
                                                                                                          double prev_prior_b,
                                                                                                          int Phi_type,
                                                                                                          int sampling_option,
                                                                                                          bool generate_velocity,
                                                                                                          Eigen::Matrix<double, -1, 1  > velocity_0,
                                                                                                          int tanh_option,
                                                                                                          bool approx_exp_and_log_for_log_lik,
                                                                                                          bool approx_exp_and_log_for_grad
                                                                                                       )  {




   int n_params = theta.rows() ;
   int n_bs_LT = n_tests * n_class;
   int n_corrs = n_class * n_tests * (n_tests - 1) * 0.5 ;
   int N = y.rows();


   ////////////////////// make complete parameter vector (log_diffs then coeffs)
   double half_eps = eps/2;

   double log_posterior_0 = 0.0;

  // Eigen::Matrix<double, -1, 1  > velocity_0(n_params) ;   //////////////////////////////////////////////

   if (generate_velocity == true)  {

           Eigen::Matrix<double, -1, 1>  std_norm_vec_1(n_params_main);
           for (int d = 0; d < n_params_main; d++) {
             std_norm_vec_1(d) = R::rnorm(0, 1);
           }
           velocity_0.segment(n_us, n_params_main)  = M_inv_dense_main_chol * std_norm_vec_1;


         Eigen::Array<double, -1, 1  > M_inv_us_vec_sqrt = M_inv_us_vec.array().sqrt() ;  //////////////////////////////////////////////

         for (int d = 0; d < n_us; d++) {
           velocity_0(d)  = R::rnorm(0,  M_inv_us_vec_sqrt(d));
         }

   }

    Eigen::Matrix<double, -1, 1> velocity = velocity_0;   //////////////////////////////////////////////
    Eigen::Matrix<double, -1, 1>   individual_log_lik(N);




   // Perform L leapfrogs


    {

    // Eigen::Matrix<double, -1, 1>  grad(n_params);
     Eigen::Matrix<double, -1, 1> lp_and_grad_outs  =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N);   ///////////////////////////////////////////////

           for (int l = -1; l < L; l++) {


                             if (l > -1) {
                               velocity.segment(n_us, n_params_main)  = velocity.segment(n_us, n_params_main) - half_eps *  M_inv_dense_main *  (- lp_and_grad_outs.segment(n_us + 1, n_params_main).array()).matrix()   ;  // update velocity for MAIN params (DENSE G)
                               velocity.head(n_us).array()  = velocity.head(n_us).array() - half_eps * (- lp_and_grad_outs.segment(1, n_us).array()).array() * (M_inv_us_vec.head(n_us).array()  );  // update velocity for NUISANCE params (diag G)


                               theta.array()  = theta.array()  + eps  * velocity.array(); //// update params by full step
                             }


                               if (sampling_option == 11) {

                                 Eigen::Matrix<double, -1, 1  > theta_main =    theta.segment(n_us, n_params_main).matrix() ;
                                 Eigen::Matrix<double, -1, 1  > theta_us   =    theta.head(n_us).matrix() ;

                                   // lp_and_grad_outs   =        fn_wo_list_log_posterior_and_gradient_Chol_Schur_MD_and_AD_1(   n_cores,
                                   //                                                                                             theta_main,
                                   //                                                                                             theta_us,
                                   //                                                                                              y,
                                   //                                                                                              X,
                                   //                                                                                             exclude_priors,
                                   //                                                                                              CI,
                                   //                                                                                             lkj_cholesky_eta,
                                   //                                                                                              prior_coeffs_mean ,
                                   //                                                                                             prior_coeffs_sd,
                                   //                                                                                              n_class,
                                   //                                                                                              n_tests,
                                   //                                                                                              ub_threshold_phi_approx,
                                   //                                                                                              n_chunks,
                                   //                                                                                              corr_force_positive,
                                   //                                                                                            prior_for_corr_a,
                                   //                                                                                               prior_for_corr_b,
                                   //                                                                                              corr_prior_beta ,
                                   //                                                                                              corr_prior_norm ,
                                   //                                                                                              lb_corr,
                                   //                                                                                               ub_corr,
                                   //                                                                                                known_values_indicator,
                                   //                                                                                              known_values,
                                   //                                                                                              prev_prior_a,
                                   //                                                                                              prev_prior_b,
                                   //                                                                                              Phi_type,
                                   //                                                                                              tanh_option) ;
                               } else if (sampling_option == 10) {  // AD - Schur

                                 // lp_and_grad_outs   =      fn_wo_list_log_posterior_and_gradient_Chol_Schur_AD_float(        n_cores,
                                 //                                                                                             theta.matrix(),
                                 //                                                                                             y,
                                 //                                                                                             X,
                                 //                                                                                             exclude_priors,
                                 //                                                                                             CI,
                                 //                                                                                             lkj_cholesky_eta,
                                 //                                                                                             prior_coeffs_mean ,
                                 //                                                                                             prior_coeffs_sd,
                                 //                                                                                             n_class,
                                 //                                                                                             n_tests,
                                 //                                                                                             ub_threshold_phi_approx,
                                 //                                                                                             n_chunks,
                                 //                                                                                             corr_force_positive,
                                 //                                                                                             prior_for_corr_a,
                                 //                                                                                             prior_for_corr_b,
                                 //                                                                                             corr_prior_beta ,
                                 //                                                                                             corr_prior_norm ,
                                 //                                                                                             lb_corr,
                                 //                                                                                             ub_corr,
                                 //                                                                                             known_values_indicator,
                                 //                                                                                             known_values,
                                 //                                                                                             prev_prior_a,
                                 //                                                                                             prev_prior_b,
                                 //                                                                                             Phi_type,
                                 //                                                                                             tanh_option) ;

                               } else if (sampling_option == 100) {


                                 Eigen::Matrix<double, -1, 1  > theta_main =    theta.segment(n_us, n_params_main).matrix() ;
                                 Eigen::Matrix<double, -1, 1  > theta_us   =    theta.head(n_us).matrix() ;
                                 //
                                 lp_and_grad_outs   =        fn_wo_list_log_posterior_and_gradient_Chol_Schur_MD_and_AD_3( n_cores,
                                                                                                                           theta_main,
                                                                                                                           theta_us,
                                                                                                                           y,
                                                                                                                           X,
                                                                                                                           exclude_priors,
                                                                                                                           CI,
                                                                                                                           lkj_cholesky_eta,
                                                                                                                           prior_coeffs_mean ,
                                                                                                                           prior_coeffs_sd,
                                                                                                                           n_class,
                                                                                                                           n_tests,
                                                                                                                           ub_threshold_phi_approx,
                                                                                                                           n_chunks,
                                                                                                                           corr_force_positive,
                                                                                                                           prior_for_corr_a,
                                                                                                                           prior_for_corr_b,
                                                                                                                           corr_prior_beta ,
                                                                                                                           corr_prior_norm ,
                                                                                                                           lb_corr,
                                                                                                                           ub_corr,
                                                                                                                           known_values_indicator,
                                                                                                                           known_values,
                                                                                                                           prev_prior_a,
                                                                                                                           prev_prior_b,
                                                                                                                           Phi_type,
                                                                                                                           tanh_option,
                                                                                                                           approx_exp_and_log_for_log_lik,
                                                                                                                           approx_exp_and_log_for_grad) ;

                               } else if  (sampling_option == 101)  {

                                 // Eigen::Matrix<double, -1, 1  > theta_main =    theta.segment(n_us, n_params_main).matrix() ;
                                 // Eigen::Matrix<double, -1, 1  > theta_us   =    theta.head(n_us).matrix() ;
                                 //
                                 // lp_and_grad_outs   =        fn_wo_list_log_posterior_and_gradient_Chol_Schur_MD_and_AD_4( n_cores,
                                 //                                                                                           theta_main,
                                 //                                                                                           theta_us,
                                 //                                                                                           y,
                                 //                                                                                           X,
                                 //                                                                                           exclude_priors,
                                 //                                                                                           CI,
                                 //                                                                                           lkj_cholesky_eta,
                                 //                                                                                           prior_coeffs_mean ,
                                 //                                                                                           prior_coeffs_sd,
                                 //                                                                                           n_class,
                                 //                                                                                           n_tests,
                                 //                                                                                           ub_threshold_phi_approx,
                                 //                                                                                           n_chunks,
                                 //                                                                                           corr_force_positive,
                                 //                                                                                           prior_for_corr_a,
                                 //                                                                                           prior_for_corr_b,
                                 //                                                                                           corr_prior_beta ,
                                 //                                                                                           corr_prior_norm ,
                                 //                                                                                           lb_corr,
                                 //                                                                                           ub_corr,
                                 //                                                                                           known_values_indicator,
                                 //                                                                                           known_values,
                                 //                                                                                           prev_prior_a,
                                 //                                                                                           prev_prior_b,
                                 //                                                                                           Phi_type,
                                 //                                                                                           tanh_option,
                                 //                                                                                           approx_exp_and_log_for_log_lik,
                                 //                                                                                           approx_exp_and_log_for_grad) ;


                               }



                            // grad.array() = - lp_and_grad_outs.segment(1, n_params).array();
                             log_posterior =  lp_and_grad_outs(0);

                             if (l == -1)     log_posterior_0 = lp_and_grad_outs(0);


                             if (l > -1) {
                               velocity.segment(n_us, n_params_main)  = velocity.segment(n_us, n_params_main) - half_eps *  M_inv_dense_main *  (- lp_and_grad_outs.segment(n_us + 1, n_params_main).array()).matrix()   ;  // update velocity for MAIN params (DENSE G)
                               velocity.head(n_us).array()  = velocity.head(n_us).array() - half_eps * (- lp_and_grad_outs.segment(1, n_us).array()).array() * (M_inv_us_vec.head(n_us).array()  );  // update velocity for NUISANCE params (diag G)
                             }



           }

           individual_log_lik = lp_and_grad_outs.segment(1 + n_params, N);

    }



  int div = 0; // handles in R currently

   if  ((sampling_option > 11)  && (sampling_option < 15)  )  { // for latent trait
     for (int i = n_us + n_bs_LT; i < n_us + n_corrs; i++) {
           velocity(i) = 0 ;
           velocity_0(i) = 0 ;
           theta(i) =   R::rnorm(0, 1);
     }
   }


   Eigen::Matrix<double, -1, -1>  out_mat =   Eigen::Matrix<double, -1, -1>::Zero(n_params, 4); //////////////////////////////////////////////

   out_mat(0, 0) = log_posterior_0;
   out_mat(1, 0) = log_posterior;
   out_mat.col(1) = theta;
   out_mat.col(2) = velocity_0;
   out_mat.col(3) = velocity;

   out_mat.col(0).segment(2, N) =  individual_log_lik;


   return(out_mat);

 }










 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1>    Rcpp_fn_no_list_HMC_single_iter(              int n_cores,
                                                                               Eigen::Matrix<double, -1, 1 >  theta_initial,  //////////////////////////////////////////////
                                                                               Eigen::Matrix<int, -1, -1>	 y,  /////////////////////////////////////////////
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  X,  /////////////////////////////////////////////
                                                                               bool dense_G_indicator,
                                                                               int L,
                                                                               double eps,
                                                                               double log_posterior_initial,
                                                                               Eigen::Matrix<double, -1, 1  > M_main_vec,
                                                                               Eigen::Matrix<double, -1, 1  > M_inv_us_vec, //////////////////////////////////////////////
                                                                               Eigen::Matrix<double, -1, -1  > M_dense_main,
                                                                               Eigen::Matrix<double, -1, -1  > M_inv_dense_main,
                                                                               Eigen::Matrix<double, -1, -1  > M_inv_dense_main_chol,
                                                                               int n_us,
                                                                               int n_params_main,
                                                                               bool exclude_priors,
                                                                               bool CI,
                                                                               Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                               Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                               Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                               int n_class,
                                                                               int n_tests,
                                                                               int ub_threshold_phi_approx,
                                                                               int n_chunks,
                                                                               bool corr_force_positive,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                               bool corr_prior_beta ,
                                                                               bool corr_prior_norm ,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
                                                                               std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                               double prev_prior_a,
                                                                               double prev_prior_b,
                                                                               int Phi_type,
                                                                               int sampling_option,
                                                                               bool generate_velocity,
                                                                               Eigen::Matrix<double, -1, 1  > velocity_0,
                                                                               int tanh_option,
                                                                               bool approx_exp_and_log_for_log_lik,
                                                                               bool approx_exp_and_log_for_grad


 )  {

   int N = y.rows();
   int n_params = n_us + n_params_main;
   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
   int n_coeffs = n_class * n_tests * 1;


     Eigen::Matrix<double, -1, 1 >  theta = theta_initial;  //////////////////////////////////////////////


     double U_x_initial = - log_posterior_initial;
     double U_x = - log_posterior_initial;

     double log_posterior  =   log_posterior_initial;
     double log_posterior_prop = log_posterior;



   Eigen::Matrix<double, -1, 1 >   individual_log_lik(N);

   {


     Eigen::Matrix<double, -1, -1>  out_mat_for_leapfrog  =   Rcpp_fn_wo_list_ELMC_multiple_leapfrogs_EUC_EFISH_HI_with_MIXED_M_NT_us(                 n_cores,
                                                                                                                                                       theta_initial,  //////////////////////////////////////////////
                                                                                                                                            y,
                                                                                                                                            X,
                                                                                                                                            dense_G_indicator,
                                                                                                                                            0.0001, // num_diff_e
                                                                                                                                            L,
                                                                                                                                            eps,
                                                                                                                                            log_posterior_initial, ///
                                                                                                                                            M_main_vec,
                                                                                                                                            M_inv_us_vec, //////////////////////////////////////////////
                                                                                                                                            M_dense_main,
                                                                                                                                            M_inv_dense_main,
                                                                                                                                            M_inv_dense_main_chol,
                                                                                                                                            n_us,
                                                                                                                                            n_params_main,
                                                                                                                                            exclude_priors,
                                                                                                                                            CI,
                                                                                                                                            lkj_cholesky_eta,
                                                                                                                                            prior_coeffs_mean ,
                                                                                                                                            prior_coeffs_sd,
                                                                                                                                            n_class,
                                                                                                                                            n_tests,
                                                                                                                                            ub_threshold_phi_approx,
                                                                                                                                            n_chunks,
                                                                                                                                            corr_force_positive,
                                                                                                                                            prior_for_corr_a,
                                                                                                                                            prior_for_corr_b,
                                                                                                                                            corr_prior_beta ,
                                                                                                                                            corr_prior_norm ,
                                                                                                                                            lb_corr,
                                                                                                                                            ub_corr,
                                                                                                                                            known_values_indicator,
                                                                                                                                            known_values,
                                                                                                                                            prev_prior_a,
                                                                                                                                            prev_prior_b,
                                                                                                                                            Phi_type,
                                                                                                                                            sampling_option,
                                                                                                                                            generate_velocity,
                                                                                                                                            velocity_0,
                                                                                                                                            tanh_option,
                                                                                                                                            approx_exp_and_log_for_log_lik,
                                                                                                                                            approx_exp_and_log_for_grad);


           log_posterior = out_mat_for_leapfrog(1, 0) ;
           log_posterior_prop = log_posterior ;
           U_x = - log_posterior;
           log_posterior_initial = out_mat_for_leapfrog(0, 0) ;
           U_x_initial =  - log_posterior_initial;


           individual_log_lik =  out_mat_for_leapfrog.col(0).segment(2, N);



              double energy_old = U_x_initial ;
              energy_old +=  0.5 * ( out_mat_for_leapfrog.col(2).segment(n_us, n_params_main).array() * Rcpp_mult_mat_by_col_vec(M_dense_main, out_mat_for_leapfrog.col(2).segment(n_us, n_params_main)).array()).matrix().sum() ;
              energy_old +=  0.5 * ( stan::math::square( out_mat_for_leapfrog.col(2).head(n_us) ).array() * ( 1 / M_inv_us_vec.array() ) ).array().sum() ;

              double energy_new = U_x ;
              energy_new +=  0.5  * (out_mat_for_leapfrog.col(3).segment(n_us, n_params_main).array() * Rcpp_mult_mat_by_col_vec(M_dense_main, out_mat_for_leapfrog.col(3).segment(n_us, n_params_main)).array()).matrix().sum() ;
              energy_new +=  0.5 * ( stan::math::square( out_mat_for_leapfrog.col(3).head(n_us) ).array() * ( 1 / M_inv_us_vec.array() ) ).array().sum() ;

              double log_ratio = - energy_new + energy_old;

              Eigen::Matrix<double, -1, 1 >  p_jump_vec(2);
              p_jump_vec(0) = 1;
              p_jump_vec(1) = std::exp(log_ratio);

              double p_jump = stan::math::min(p_jump_vec);

              double accept = 0;

              int div = 0;


              if  ((R::runif(0, 1) > p_jump) || (div == 1)) {  // # reject proposal

                           accept = 0;
                           theta =    theta_initial ;

              } else {   // # accept proposal


                           accept = 1;
                           theta = out_mat_for_leapfrog.col(1) ; //  theta_prop ; // out_mat_for_leapfrog.col(1).segment(1, n_params) ;

              }

    }



//   Eigen::Matrix<double, -1, -1>  out_mat =   Eigen::Matrix<double, -1, -1>::Zero(n_params, 2);  //////////////////////////////////////////////

   Eigen::Matrix<double, -1, 1>  out_mat =   Eigen::Matrix<double, -1, 1>::Zero(n_params + N);  //////////////////////////////////////////////

   out_mat.head(n_params) = theta;
   out_mat.segment(n_params, N) = individual_log_lik;

   return(out_mat);

 }



//
//
//










 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, -1>    Rcpp_fn_no_list_HMC_single_iter_burnin(     int n_cores,
                                                                              Eigen::Matrix<double, -1, 1 >  theta_initial,  //////////////////////////////////////////////
                                                                             Eigen::Matrix<int, -1, -1>	 y,
                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  X,
                                                                             bool dense_G_indicator,
                                                                             int L,
                                                                             double eps,
                                                                             double log_posterior_initial,
                                                                             Eigen::Matrix<double, -1, 1  > M_main_vec,
                                                                             Eigen::Matrix<double, -1, 1  > M_inv_us_vec, //////////////////////////////////////////////
                                                                             Eigen::Matrix<double, -1, -1  > M_dense_main,
                                                                             Eigen::Matrix<double, -1, -1  > M_inv_dense_main,
                                                                             Eigen::Matrix<double, -1, -1  > M_inv_dense_main_chol,
                                                                             int n_us,
                                                                             int n_params_main,
                                                                             bool exclude_priors,
                                                                             bool CI,
                                                                             Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                             Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                             Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                             int n_class,
                                                                             int n_tests,
                                                                             int ub_threshold_phi_approx,
                                                                             int n_chunks,
                                                                             bool corr_force_positive,
                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                             bool corr_prior_beta ,
                                                                             bool corr_prior_norm ,
                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
                                                                             std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                             double prev_prior_a,
                                                                             double prev_prior_b,
                                                                             int Phi_type,
                                                                             int sampling_option,
                                                                             bool generate_velocity,
                                                                             Eigen::Matrix<double, -1, 1  > velocity_0,
                                                                             int tanh_option,
                                                                             bool approx_exp_and_log_for_log_lik,
                                                                             bool approx_exp_and_log_for_grad


 )  {

   int N = y.rows();
   int n_params = n_us + n_params_main;
   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
   int n_coeffs = n_class * n_tests * 1;


   Eigen::Matrix<double, -1, 1 >  theta = theta_initial;  //////////////////////////////////////////////
   Eigen::Matrix<double, -1, 1 >  theta_prop = theta_initial;  //////////////////////////////////////////////

   double U_x_initial = - log_posterior_initial;
   double U_x = - log_posterior_initial;

   double log_posterior  =   log_posterior_initial;
   double log_posterior_prop = log_posterior;


     Eigen::Matrix<double, -1, 1 >    velocity_prop = velocity_0 ; // (n_params) ;  // (n_params);  //////////////////////////////////////////////
     Eigen::Matrix<double, -1, 1 >    velocity = velocity_0; // (n_params) ;  // (n_params);  //////////////////////////////////////////////

     int div = 0;
     double p_jump = 0;
     double accept = 0;


   {
        Eigen::Matrix<double, -1, -1>  out_mat_for_leapfrog =   Eigen::Matrix<double, -1, -1>::Zero(n_params, 4);

     // try {
                        out_mat_for_leapfrog  =   Rcpp_fn_wo_list_ELMC_multiple_leapfrogs_EUC_EFISH_HI_with_MIXED_M_NT_us(             n_cores,
                                                                                                                                       theta_initial,  //////////////////////////////////////////////
                                                                                                                                      y,
                                                                                                                                      X,
                                                                                                                                      dense_G_indicator,
                                                                                                                                      0.0001, // num_diff_e
                                                                                                                                      L,
                                                                                                                                      eps,
                                                                                                                                      log_posterior_initial, ///
                                                                                                                                      M_main_vec,
                                                                                                                                      M_inv_us_vec, //////////////////////////////////////////////
                                                                                                                                      M_dense_main,
                                                                                                                                      M_inv_dense_main,
                                                                                                                                      M_inv_dense_main_chol,
                                                                                                                                      n_us,
                                                                                                                                      n_params_main,
                                                                                                                                      exclude_priors,
                                                                                                                                      CI,
                                                                                                                                      lkj_cholesky_eta,
                                                                                                                                      prior_coeffs_mean ,
                                                                                                                                      prior_coeffs_sd,
                                                                                                                                      n_class,
                                                                                                                                      n_tests,
                                                                                                                                      ub_threshold_phi_approx,
                                                                                                                                      n_chunks,
                                                                                                                                      corr_force_positive,
                                                                                                                                      prior_for_corr_a,
                                                                                                                                      prior_for_corr_b,
                                                                                                                                      corr_prior_beta ,
                                                                                                                                      corr_prior_norm ,
                                                                                                                                      lb_corr,
                                                                                                                                      ub_corr,
                                                                                                                                      known_values_indicator,
                                                                                                                                      known_values,
                                                                                                                                      prev_prior_a,
                                                                                                                                      prev_prior_b,
                                                                                                                                      Phi_type,
                                                                                                                                      sampling_option,
                                                                                                                                      generate_velocity,
                                                                                                                                      velocity_0,
                                                                                                                                      tanh_option,
                                                                                                                                      approx_exp_and_log_for_log_lik,
                                                                                                                                      approx_exp_and_log_for_grad);

      div = 0;


     // } catch (...) {
     //   div = 1;
     // }



     theta_prop = out_mat_for_leapfrog.col(1);

     log_posterior = out_mat_for_leapfrog(1, 0) ;
     log_posterior_prop = log_posterior ;
     U_x = - log_posterior_prop;

     log_posterior_initial = out_mat_for_leapfrog(0, 0) ;
     U_x_initial =  - log_posterior_initial;

   //if (generate_velocity == true) {
          velocity_0 = out_mat_for_leapfrog.col(2);
          velocity_prop = out_mat_for_leapfrog.col(3);
  // }



     double energy_old = U_x_initial ;
     energy_old +=  0.5 * ( velocity_0.segment(n_us, n_params_main).array() * Rcpp_mult_mat_by_col_vec(M_dense_main, velocity_0.segment(n_us, n_params_main)).array()).matrix().sum() ;
     energy_old +=  0.5 * ( stan::math::square( velocity_0.head(n_us) ).array() * ( 1 / M_inv_us_vec.array() ) ).array().sum() ;

     double energy_new = U_x ;
     energy_new +=  0.5  * (velocity_prop.segment(n_us, n_params_main).array() * Rcpp_mult_mat_by_col_vec(M_dense_main, velocity_prop.segment(n_us, n_params_main)).array()).matrix().sum() ;
     energy_new +=  0.5 * ( stan::math::square( velocity_prop.head(n_us) ).array() * ( 1 / M_inv_us_vec.array() ) ).array().sum() ;

     double log_ratio = - energy_new + energy_old;

     Eigen::Matrix<double, -1, 1 >  p_jump_vec(2);
     p_jump_vec(0) = 1;
     p_jump_vec(1) = std::exp(log_ratio);

     p_jump = stan::math::min(p_jump_vec);

     accept = 0;


     if  ((R::runif(0, 1) > p_jump) || (div == 1)) {  // # reject proposal

             accept = 0;
             theta =    theta_initial ;

             U_x  = U_x_initial  ;
             log_posterior = log_posterior_initial ;

             velocity = velocity_0;

     } else {   // # accept proposal

             accept = 1;
             theta = theta_prop;

             log_posterior = log_posterior_prop;
             U_x  = - log_posterior;

             velocity = velocity_prop;

     }



   }


   Eigen::Matrix<double, -1, -1>  out_mat =   Eigen::Matrix<double, -1, -1>::Zero(n_params, 7);  //////////////////////////////////////////////

   out_mat(0, 0) = log_posterior;
   out_mat(1, 0) = log_posterior_initial;
   out_mat(2, 0) = log_posterior_prop;
   out_mat(3, 0) = div;
   out_mat(4, 0) = p_jump;
   out_mat(5, 0) = accept;

   out_mat.col(1) = theta;
   out_mat.col(2) = theta_initial;
   out_mat.col(3) = theta_prop;

   out_mat.col(4) = velocity;
   out_mat.col(5) = velocity_0;
   out_mat.col(6) = velocity_prop;



   return(out_mat);

 }











//
//
//
 //
 //
 // // [[Rcpp::export]]
 // Eigen::Matrix<double, -1, -1>    Rcpp_fn_no_list_HMC_single_iter_burnin_float(     int n_cores,
 //                                                                              Eigen::Matrix<float, -1, 1 >  theta_initial,  //////////////////////////////////////////////
 //                                                                              Eigen::Matrix<int, -1, -1>	 y,
 //                                                                              std::vector<Eigen::Matrix<float, -1, -1 > >  X,
 //                                                                              bool dense_G_indicator,
 //                                                                              int L,
 //                                                                              float eps,
 //                                                                              float log_posterior_initial,
 //                                                                              Eigen::Matrix<float, -1, 1  > M_main_vec,
 //                                                                              Eigen::Matrix<float, -1, 1  > M_inv_us_vec, //////////////////////////////////////////////
 //                                                                              Eigen::Matrix<float, -1, -1  > M_dense_main,
 //                                                                              Eigen::Matrix<float, -1, -1  > M_inv_dense_main,
 //                                                                              Eigen::Matrix<float, -1, -1  > M_inv_dense_main_chol,
 //                                                                              int n_us,
 //                                                                              int n_params_main,
 //                                                                              bool exclude_priors,
 //                                                                              bool CI,
 //                                                                              Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
 //                                                                              Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
 //                                                                              Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
 //                                                                              int n_class,
 //                                                                              int n_tests,
 //                                                                              int ub_threshold_phi_approx,
 //                                                                              int n_chunks,
 //                                                                              bool corr_force_positive,
 //                                                                              std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
 //                                                                              std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
 //                                                                              bool corr_prior_beta ,
 //                                                                              bool corr_prior_norm ,
 //                                                                              std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
 //                                                                              std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
 //                                                                              std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
 //                                                                              std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
 //                                                                              double prev_prior_a,
 //                                                                              double prev_prior_b,
 //                                                                              int Phi_type,
 //                                                                              int sampling_option,
 //                                                                              bool generate_velocity,
 //                                                                              Eigen::Matrix<float>, -1, 1  > velocity_0
 //
 //
 // )  {
 //
 //   int N = y.rows();
 //   int n_params = n_us + n_params_main;
 //   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
 //   int n_coeffs = n_class * n_tests * 1;
 //
 //
 //   Eigen::Matrix<float, -1, 1 >  theta = theta_initial;  //////////////////////////////////////////////
 //   Eigen::Matrix<float, -1, 1 >  theta_prop = theta_initial;  //////////////////////////////////////////////
 //
 //   float U_x_initial = - log_posterior_initial;
 //   float U_x = - log_posterior_initial;
 //
 //   float log_posterior  =   log_posterior_initial;
 //   float log_posterior_prop = log_posterior;
 //
 //
 //
 //   //Eigen::Matrix<float, -1, 1 >    velocity_0(n_params) ;  //  (n_params);  //////////////////////////////////////////////
 //   Eigen::Matrix<float, -1, 1 >    velocity_prop = velocity_0 ; // (n_params) ;  // (n_params);  //////////////////////////////////////////////
 //   Eigen::Matrix<float, -1, 1 >    velocity = velocity_0; // (n_params) ;  // (n_params);  //////////////////////////////////////////////
 //
 //   int div = 0;
 //   float p_jump = 0;
 //   float accept = 0;
 //
 //
 //   {
 //     Eigen::Matrix<float, -1, -1>  out_mat_for_leapfrog =   Eigen::Matrix<float, -1, -1>::Zero(n_params, 4);
 //
 //     // try {
 //     out_mat_for_leapfrog  =   Rcpp_fn_wo_list_ELMC_multiple_leapfrogs_EUC_EFISH_HI_with_MIXED_M_NT_us_float(             n_cores,
 //                                                                                                                    theta_initial,  //////////////////////////////////////////////
 //                                                                                                                    y,
 //                                                                                                                    X,
 //                                                                                                                    dense_G_indicator,
 //                                                                                                                    0.0001, // num_diff_e
 //                                                                                                                    L,
 //                                                                                                                    eps,
 //                                                                                                                    log_posterior_initial, ///
 //                                                                                                                    M_main_vec,
 //                                                                                                                    M_inv_us_vec, //////////////////////////////////////////////
 //                                                                                                                    M_dense_main,
 //                                                                                                                    M_inv_dense_main,
 //                                                                                                                    M_inv_dense_main_chol,
 //                                                                                                                    n_us,
 //                                                                                                                    n_params_main,
 //                                                                                                                    exclude_priors,
 //                                                                                                                    CI,
 //                                                                                                                    lkj_cholesky_eta,
 //                                                                                                                    prior_coeffs_mean ,
 //                                                                                                                    prior_coeffs_sd,
 //                                                                                                                    n_class,
 //                                                                                                                    n_tests,
 //                                                                                                                    ub_threshold_phi_approx,
 //                                                                                                                    n_chunks,
 //                                                                                                                    corr_force_positive,
 //                                                                                                                    prior_for_corr_a,
 //                                                                                                                    prior_for_corr_b,
 //                                                                                                                    corr_prior_beta ,
 //                                                                                                                    corr_prior_norm ,
 //                                                                                                                    lb_corr,
 //                                                                                                                    ub_corr,
 //                                                                                                                    known_values_indicator,
 //                                                                                                                    known_values,
 //                                                                                                                    prev_prior_a,
 //                                                                                                                    prev_prior_b,
 //                                                                                                                    Phi_type,
 //                                                                                                                    sampling_option,
 //                                                                                                                    generate_velocity,
 //                                                                                                                    velocity_0);
 //
 //     div = 0;
 //
 //
 //     // } catch (...) {
 //     //   div = 1;
 //     // }
 //
 //
 //
 //     theta_prop = out_mat_for_leapfrog.col(1);
 //
 //     log_posterior = out_mat_for_leapfrog(1, 0) ;
 //     log_posterior_prop = log_posterior ;
 //     U_x = - log_posterior_prop;
 //
 //     log_posterior_initial = out_mat_for_leapfrog(0, 0) ;
 //     U_x_initial =  - log_posterior_initial;
 //
 //     //if (generate_velocity == true) {
 //     velocity_0 = out_mat_for_leapfrog.col(2);
 //     velocity_prop = out_mat_for_leapfrog.col(3);
 //     // }
 //
 //
 //
 //     float energy_old = U_x_initial ;
 //     energy_old +=  0.5 * ( velocity_0.segment(n_us, n_params_main).array() * Rcpp_mult_mat_by_col_vec(M_dense_main, velocity_0.segment(n_us, n_params_main)).array()).matrix().sum() ;
 //     energy_old +=  0.5 * ( stan::math::square( velocity_0.head(n_us) ).array() * ( 1 / M_inv_us_vec.array() ) ).array().sum() ;
 //
 //     float energy_new = U_x ;
 //     energy_new +=  0.5  * (velocity_prop.segment(n_us, n_params_main).array() * Rcpp_mult_mat_by_col_vec(M_dense_main, velocity_prop.segment(n_us, n_params_main)).array()).matrix().sum() ;
 //     energy_new +=  0.5 * ( stan::math::square( velocity_prop.head(n_us) ).array() * ( 1 / M_inv_us_vec.array() ) ).array().sum() ;
 //
 //     float log_ratio = - energy_new + energy_old;
 //
 //     Eigen::Matrix<float, -1, 1 >  p_jump_vec(2);
 //     p_jump_vec(0) = 1;
 //     p_jump_vec(1) = std::exp(log_ratio);
 //
 //     p_jump = stan::math::min(p_jump_vec);
 //
 //     accept = 0;
 //
 //
 //     if  ((R::runif(0, 1) > p_jump) || (div == 1)) {  // # reject proposal
 //
 //       accept = 0;
 //       theta =    theta_initial ;
 //
 //       U_x  = U_x_initial  ;
 //       log_posterior = log_posterior_initial ;
 //
 //       velocity = velocity_0;
 //
 //     } else {   // # accept proposal
 //
 //       accept = 1;
 //       theta = theta_prop;
 //
 //       log_posterior = log_posterior_prop;
 //       U_x  = - log_posterior;
 //
 //       velocity = velocity_prop;
 //
 //     }
 //
 //
 //
 //   }
 //
 //
 //   Eigen::Matrix<float, -1, -1>  out_mat =   Eigen::Matrix<float, -1, -1>::Zero(n_params, 7);  //////////////////////////////////////////////
 //
 //   out_mat(0, 0) = log_posterior;
 //   out_mat(1, 0) = log_posterior_initial;
 //   out_mat(2, 0) = log_posterior_prop;
 //   out_mat(3, 0) = div;
 //   out_mat(4, 0) = p_jump;
 //   out_mat(5, 0) = accept;
 //
 //   out_mat.col(1) = theta.cast;
 //   out_mat.col(2) = theta_initial.cast;
 //   out_mat.col(3) = theta_prop.cast;
 //
 //   out_mat.col(4) = velocity.cast;
 //   out_mat.col(5) = velocity_0.cast;
 //   out_mat.col(6) = velocity_prop.cast;
 //
 //
 //
 //   return(out_mat.cast<double>());
 //
 // }
 //





 // class ProgressBar {
 // public:
 //   virtual ~ProgressBar() = 0;
 //   virtual void display() = 0;
 //   virtual void update(float progress) = 0;
 //   virtual void end_display() = 0;
 // };



 // class MinimalProgressBar: public ProgressBar{
 // public:
 //   MinimalProgressBar()  {
 //     _finalized = false;
 //   }
 //
 //   ~MinimalProgressBar() {}
 //
 //   void display() {
 //     REprintf("Progress: ");
 //   }
 //
 //   void update(float progress) {
 //     if (_finalized) return;
 //     REprintf("+");
 //   }
 //
 //   void end_display() {
 //     if (_finalized) return;
 //     REprintf("\n");
 //     _finalized = true;
 //   }
 //
 // private:
 //
 //   bool _finalized;
 //
 // };

// Rcpp::List
//





 // [[Rcpp::export]]
Rcpp::List   Rcpp_fn_run_leapfrog_integrator_non_parellel_test(      int n_cores,
                                                                     int n_iter_test,
                                                                      int n_chain_for_loading_bar,
                                                                                            double tau,
                                                                                            Eigen::Matrix<double, -1, 1 >  theta_initial,  //////////////////////////////////////////////
                                                                                            Eigen::Matrix<int, -1, -1>	 y,
                                                                                            std::vector<Eigen::Matrix<double, -1, -1 > >  X,
                                                                                            bool dense_G_indicator,
                                                                                            double numerical_diff_e,
                                                                                            int L,
                                                                                            double eps,
                                                                                            double log_posterior,
                                                                                            Eigen::Matrix<double, -1, 1  > M_main_vec,
                                                                                            Eigen::Matrix<double, -1, 1  > M_inv_us_vec, //////////////////////////////////////////////
                                                                                            Eigen::Matrix<double, -1, -1  > M_dense_main,
                                                                                            Eigen::Matrix<double, -1, -1  > M_inv_dense_main,
                                                                                            Eigen::Matrix<double, -1, -1  > M_inv_dense_main_chol,
                                                                                            int n_us,
                                                                                            int n_params_main,
                                                                                            bool exclude_priors,
                                                                                            bool CI,
                                                                                            Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                                            Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                                            Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                                            int n_class,
                                                                                            int n_tests,
                                                                                            int ub_threshold_phi_approx,
                                                                                            int n_chunks,
                                                                                            bool corr_force_positive,
                                                                                            std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                                            std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                                            bool corr_prior_beta ,
                                                                                            bool corr_prior_norm ,
                                                                                            std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                                            std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
                                                                                            std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                                            std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                                            double prev_prior_a,
                                                                                            double prev_prior_b,
                                                                                            int Phi_type,
                                                                                            int sampling_option,
                                                                                            bool generate_velocity,
                                                                                            Eigen::Matrix<double, -1, 1  > velocity_0,
                                                                                            bool tau_jittered,
                                                                                            int tanh_option,
                                                                                            bool approx_exp_and_log_for_log_lik,
                                                                                            bool approx_exp_and_log_for_grad

 )  {


   int n_params = n_us + n_params_main;
   int N = y.rows();

   Eigen::Matrix<double, -1, -1 >   theta_main_trace  = Eigen::Matrix<double, -1, -1  >::Zero(n_params_main, n_iter_test);
 //  Eigen::Matrix<double, -1, -1 >   log_lik_trace  = Eigen::Matrix<double, -1, -1  >::Zero(N, n_iter_test);
   Eigen::Matrix<double, -1, 1 >       theta_previous_iter = theta_initial;

   Eigen::Matrix<int, -1, 1 >   div_vec  = Eigen::Matrix<int, -1, 1  >::Zero(n_iter_test);

     bool display_progress = false;
     if (n_chain_for_loading_bar == 1)    display_progress = true;


      Progress p(n_iter_test, display_progress);


     double tau_main_ii = tau;


 for (int ii = 0; ii < n_iter_test; ++ii)  {

     if (n_chain_for_loading_bar == 1)  {
         p.increment(); // update progress
     }

     if (Progress::check_abort() )    return -1;




              if (tau_jittered == true)     tau_main_ii = R::runif(0,  2*tau);
              else                          tau_main_ii = tau;

              double L_main_ii = std::ceil(tau_main_ii / eps);





              //   if (L_main_ii < 1) L_main_ii == 1;



                 {


               try {

                     Eigen::Matrix<double, -1, 1 >   single_iter_out =   Rcpp_fn_no_list_HMC_single_iter(    n_cores,
                                                                                                              theta_previous_iter,   //////////////////////////////////////////////
                                                                                                                 y,
                                                                                                                 X,
                                                                                                                 dense_G_indicator, //  5
                                                                                                                 L_main_ii,
                                                                                                                 eps,
                                                                                                                 log_posterior,
                                                                                                                 M_main_vec,
                                                                                                                 M_inv_us_vec,  //  10    //////////////////////////////////////////////
                                                                                                                 M_dense_main,
                                                                                                                 M_inv_dense_main,
                                                                                                                 M_inv_dense_main_chol,
                                                                                                                 n_us,
                                                                                                                 n_params_main ,   //  15
                                                                                                                 exclude_priors,
                                                                                                                 CI,
                                                                                                                 lkj_cholesky_eta,
                                                                                                                 prior_coeffs_mean ,
                                                                                                                 prior_coeffs_sd,   //  20
                                                                                                                 n_class,
                                                                                                                 n_tests,
                                                                                                                 ub_threshold_phi_approx,
                                                                                                                 n_chunks,
                                                                                                                 corr_force_positive,   //  25
                                                                                                                 prior_for_corr_a,
                                                                                                                 prior_for_corr_b,
                                                                                                                 corr_prior_beta ,
                                                                                                                 corr_prior_norm ,
                                                                                                                 lb_corr,           //  30
                                                                                                                 ub_corr,
                                                                                                                 known_values_indicator,
                                                                                                                 known_values,
                                                                                                                 prev_prior_a,
                                                                                                                 prev_prior_b,       //  35
                                                                                                                 Phi_type,
                                                                                                                 sampling_option,
                                                                                                                 generate_velocity,
                                                                                                                 velocity_0,
                                                                                                                 tanh_option,
                                                                                                                 approx_exp_and_log_for_log_lik,
                                                                                                                 approx_exp_and_log_for_grad) ; // //  40

                     theta_previous_iter = single_iter_out.head(n_params) ; // .cast<float>();
                  //   theta_previous_previous_iter = theta_previous_iter;
                     theta_main_trace.col(ii) = single_iter_out.head(n_params).segment(n_us, n_params_main) ; // .cast<float>();
                   //  log_lik_trace.col(ii) = single_iter_out.col(1).head(N);


                   } catch (...) {
                     div_vec(ii) = 1;
                    //   theta_previous_iter =  theta_previous_previous_iter;
                       theta_main_trace.col(ii) =   theta_main_trace.col(ii - 1);
                     //  log_lik_trace.col(ii) =   log_lik_trace.col(ii - 1);
                       theta_previous_iter = theta_previous_iter;
                   }


                 }




   }




   Rcpp::List out_list(5);

   out_list(0) = theta_main_trace;
 //  out_list(1) = log_lik_trace;
   out_list(2) = div_vec;

   return(out_list);

 }




















 // [[Rcpp::export]]
 Rcpp::List   Rcpp_fn_post_burnin_HMC_post_adaptation_phase(      int n_cores,
                                                                      int n_iter_test,
                                                                      int n_chain_for_loading_bar,
                                                                      double tau,
                                                                      Eigen::Matrix<double, -1, 1 >  theta_initial,  //////////////////////////////////////////////
                                                                      Eigen::Matrix<int, -1, -1>	 y,
                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  X,
                                                                      bool dense_G_indicator,
                                                                      double numerical_diff_e,
                                                                      int L,
                                                                      double eps,
                                                                      double log_posterior,
                                                                      Eigen::Matrix<double, -1, 1  > M_main_vec,
                                                                      Eigen::Matrix<double, -1, 1  > M_inv_us_vec, //////////////////////////////////////////////
                                                                      Eigen::Matrix<double, -1, -1  > M_dense_main,
                                                                      Eigen::Matrix<double, -1, -1  > M_inv_dense_main,
                                                                      Eigen::Matrix<double, -1, -1  > M_inv_dense_main_chol,
                                                                      int n_us,
                                                                      int n_params_main,
                                                                      bool exclude_priors,
                                                                      bool CI,
                                                                      Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                      Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                      Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                      int n_class,
                                                                      int n_tests,
                                                                      int ub_threshold_phi_approx,
                                                                      int n_chunks,
                                                                      bool corr_force_positive,
                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                      bool corr_prior_beta ,
                                                                      bool corr_prior_norm ,
                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
                                                                      std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                      double prev_prior_a,
                                                                      double prev_prior_b,
                                                                      int Phi_type,
                                                                      int sampling_option,
                                                                      int tanh_option,
                                                                      bool approx_exp_and_log_for_log_lik,
                                                                      bool approx_exp_and_log_for_grad
                                                                      )  {


   int n_params = n_us + n_params_main;
   int N = y.rows();

   Eigen::Matrix<double, -1, -1 >   theta_main_trace  = Eigen::Matrix<double, -1, -1  >::Zero(n_params_main, n_iter_test);
   //  Eigen::Matrix<double, -1, -1 >   log_lik_trace  = Eigen::Matrix<double, -1, -1  >::Zero(N, n_iter_test);
   Eigen::Matrix<double, -1, 1 >       theta_previous_iter = theta_initial;

   Eigen::Matrix<int, -1, 1 >   div_vec  = Eigen::Matrix<int, -1, 1  >::Zero(n_iter_test);

   bool display_progress = false;
   if (n_chain_for_loading_bar == 1)    display_progress = true;


   Progress p(n_iter_test, display_progress);

   int Phi_type_original = Phi_type;

   for (int ii = 0; ii < n_iter_test; ++ii)  {



                         Eigen::Matrix<double, -1, 1  > velocity_0(n_params) ;   //////////////////////////////////////////////

                         {

                                 Eigen::Matrix<double, -1, 1>  std_norm_vec_1(n_params_main);
                                 for (int d = 0; d < n_params_main; d++) {
                                   std_norm_vec_1(d) = R::rnorm(0, 1);
                                 }
                                 velocity_0.segment(n_us, n_params_main)  = M_inv_dense_main_chol * std_norm_vec_1;


                                 Eigen::Array<double, -1, 1  > M_inv_us_vec_sqrt = M_inv_us_vec.array().sqrt() ;  //////////////////////////////////////////////

                                 for (int d = 0; d < n_us; d++) {
                                   velocity_0(d)  = R::rnorm(0,  M_inv_us_vec_sqrt(d));
                                 }

                         }


                     if (n_chain_for_loading_bar == 1)  {
                       p.increment(); // update progress
                     }

                     if (Progress::check_abort() )    return -1;

                     double tau_main_ii = R::runif(0,  2*tau);
                     double L_main_ii = std::ceil(tau_main_ii / eps);
                   //  if (L_main_ii < 1) L_main_ii == 1;

                     bool skip = false;
                     for (int attempt = 0; attempt < 2; ++attempt)  {


                                       if (skip == true) {
                                         skip = false;
                                         continue;
                                       }

                                       if (attempt == 0)   {
                                         Phi_type = Phi_type_original;
                                       } else {
                                         Phi_type = 3;
                                       }

                                       div_vec(ii) = 0;


                               {


                                 try {

                                   Eigen::Matrix<double, -1, 1 >   single_iter_out =   Rcpp_fn_no_list_HMC_single_iter(    n_cores,
                                                                                                                           theta_previous_iter,   //////////////////////////////////////////////
                                                                                                                           y,
                                                                                                                           X,
                                                                                                                           dense_G_indicator, //  5
                                                                                                                           L_main_ii,
                                                                                                                           eps,
                                                                                                                           log_posterior,
                                                                                                                           M_main_vec,
                                                                                                                           M_inv_us_vec,  //  10    //////////////////////////////////////////////
                                                                                                                           M_dense_main,
                                                                                                                           M_inv_dense_main,
                                                                                                                           M_inv_dense_main_chol,
                                                                                                                           n_us,
                                                                                                                           n_params_main ,   //  15
                                                                                                                           exclude_priors,
                                                                                                                           CI,
                                                                                                                           lkj_cholesky_eta,
                                                                                                                           prior_coeffs_mean ,
                                                                                                                           prior_coeffs_sd,   //  20
                                                                                                                           n_class,
                                                                                                                           n_tests,
                                                                                                                           ub_threshold_phi_approx,
                                                                                                                           n_chunks,
                                                                                                                           corr_force_positive,   //  25
                                                                                                                           prior_for_corr_a,
                                                                                                                           prior_for_corr_b,
                                                                                                                           corr_prior_beta ,
                                                                                                                           corr_prior_norm ,
                                                                                                                           lb_corr,           //  30
                                                                                                                           ub_corr,
                                                                                                                           known_values_indicator,
                                                                                                                           known_values,
                                                                                                                           prev_prior_a,
                                                                                                                           prev_prior_b,       //  35
                                                                                                                           Phi_type,
                                                                                                                           sampling_option,
                                                                                                                           false, // generate_velocity
                                                                                                                           velocity_0,
                                                                                                                           tanh_option,
                                                                                                                           approx_exp_and_log_for_log_lik,
                                                                                                                           approx_exp_and_log_for_grad) ; // //  40

                                   theta_previous_iter = single_iter_out.head(n_params) ;
                                   theta_main_trace.col(ii) = single_iter_out.head(n_params).segment(n_us, n_params_main) ;
                                   //  log_lik_trace.col(ii) = single_iter_out.col(1).head(N);
                                   div_vec(ii) = 0;


                                 } catch (...) {
                                   div_vec(ii) = 1;
                                   //   theta_previous_iter =  theta_previous_previous_iter;
                                   theta_main_trace.col(ii) =   theta_main_trace.col(ii - 1);
                                   //  log_lik_trace.col(ii) =   log_lik_trace.col(ii - 1);
                                   theta_previous_iter = theta_previous_iter;
                                 }




                                 if  ( (attempt  == 0) ) {

                                         if  ( ( div_vec(ii)  == 0) && (Phi_type_original == 1)   ) {
                                           skip = true;
                                           Phi_type = Phi_type_original;
                                         }

                                         if  ( ( div_vec(ii)  == 1) && (Phi_type_original == 1)   ) {   //  # if div  on  attempt 1, try attempt 2
                                         skip = false;
                                         Phi_type = 3;
                                         }

                                 }


                               }

                   }



   }





   Rcpp::List out_list(5);

   out_list(0) = theta_main_trace;
   //  out_list(1) = log_lik_trace;
   out_list(2) = div_vec;

   return(out_list);

 }










 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1>    fn_mult_scalar_x_vec_using_log_sign_arrays_double( double x,
                                                                                    Eigen::Matrix<double, -1, 1  > y
 ) {


  // return( sign(a) * sign(b) *  exp(  log(abs(a)) + log(abs(b))  ) )
   return  ( fn_sign_float(x) * y.array().sign()   *  (   log(abs(x))  + y.array().abs().log()  ).exp().array()  ).matrix() ;

 }



 Eigen::Matrix<float, -1, 1>    fn_mult_scalar_x_vec_using_log_sign_arrays_float( float x,
                                                                                  Eigen::Matrix<float, -1, 1  > y
 ) {


  return  ( fn_sign_float(x) * y.array().sign()   *  (   log(abs(x))  + y.array().abs().log()  ).exp().array()  ).matrix() ;

 }



 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1>    fn_mult_vec_x_vec_using_log_sign_arrays_double( Eigen::Matrix<double, -1, 1  > x,
                                                                                 Eigen::Matrix<double, -1, 1  > y
 ) {

   return  ( x.array().sign() * y.array().sign()   *  (    x.array().abs().log()  + y.array().abs().log()  ).exp().array()  ).matrix()  ;

 }



 Eigen::Matrix<float, -1, 1>    fn_mult_vec_x_vec_using_log_sign_arrays_float( Eigen::Matrix<float, -1, 1  > x,
                                                                               Eigen::Matrix<float, -1, 1  > y
 ) {

   return  ( x.array().sign() * y.array().sign()   *  (    x.array().abs().log()  + y.array().abs().log()  ).exp().array()  ).matrix()  ;

 }





 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, -1>    fn_mult_mat_x_mat_using_log_sign_arrays_double( Eigen::Matrix<double, -1, -1  > x,
                                                                                  Eigen::Matrix<double, -1, -1  > y
 ) {

   return  ( x.array().sign() * y.array().sign()   *  (    x.array().abs().log()  + y.array().abs().log()  ).exp().array()  ).matrix()  ;

 }



 Eigen::Matrix<float, -1, -1>    fn_mult_mat_x_mat_using_log_sign_arrays_float( Eigen::Matrix<float, -1, -1  > x,
                                                                                Eigen::Matrix<float, -1, -1  > y
 ) {

   return  ( x.array().sign() * y.array().sign()   *  (    x.array().abs().log()  + y.array().abs().log()  ).exp().array()  ).matrix()  ;

 }

















 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, -1>    fn_log_abs_sum_exp_vectorised_double(    Eigen::Array<double, -1, 1  > x_signs,
                                                                         Eigen::Array<double, -1, 1  > y_signs,
                                                                         Eigen::Array<double, -1, 1  > log_x,
                                                                         Eigen::Array<double, -1, 1  > log_y
 ) {

   Eigen::Array<double, -1, 1> max_vals  =      Eigen::Array<double, -1, 1>::Zero(x_signs.rows()) ;
   Eigen::Array<double, -1, 1> sum_exp_vals  =  Eigen::Array<double, -1, 1>::Zero(x_signs.rows()) ;

   {
     Eigen::Array<double, -1, -1> signs_v  =  Eigen::Array<double, -1, -1>::Zero(x_signs.rows(), 2) ;

     {
       signs_v.col(0)  = x_signs.array() ;
       signs_v.col(1)  = y_signs.array() ;
     }

     {
       Eigen::Array<double, -1, -1>    log_abs_v  =  Eigen::Array<double, -1, -1>::Zero(x_signs.rows(), 2) ;

       log_abs_v.col(0) = log_x.array();
       log_abs_v.col(1) = log_y.array();

       max_vals    =  (signs_v * log_abs_v).rowwise().maxCoeff() ;   // #    max(signs_v * log_abs_v);
       sum_exp_vals =  ( (log_abs_v - max_vals).exp() * signs_v).rowwise().sum();
     }
   }

   Eigen::Matrix<double, -1, -1>   out_mat(x_signs.rows(), 2) ; //   =   ( sum_exp_vals.sign() * ( max_vals +  sum_exp_vals.abs().log() ).abs() ).matrix() ; //   out_mat(x.rows());
   out_mat.col(0) =  (   ( max_vals +  sum_exp_vals.abs().log() )  ).matrix()  ; // answer on log scale - no sign info
   out_mat.col(1) =  (   sum_exp_vals.sign()  ).matrix()  ; // signs stored in seperate vector

   return  out_mat;

 }















// [[Rcpp::export]]
 Eigen::Matrix<double, -1, -1>    fn_log_abs_sum_exp_mult_mat_by_col_vec_double(     Eigen::Array<double, -1, -1  > signs_A_mat,
                                                                                    Eigen::Array<double, -1, 1   > signs_b_vec,
                                                                                    Eigen::Array<double, -1, -1  > log_abs_A_mat,
                                                                                    Eigen::Array<double, -1, 1   > log_abs_b_vec
 ) {

   Eigen::Array<double, -1, -1> signs_B_mat   = log_abs_A_mat;
   Eigen::Array<double, -1, -1> log_abs_B_mat = log_abs_A_mat;

   int dim = signs_A_mat.rows();

   // # put b (vector) into a mat, with each row being identical
   for (int i = 0; i < dim; i++) {
     signs_B_mat.row(i)     = signs_b_vec.transpose() ;
     log_abs_B_mat.row(i)   = log_abs_b_vec.transpose() ;
   }

   // # apply logsumexp
   Eigen::Array<double, -1, -1>   log_abs_v  =  ( log_abs_A_mat +   log_abs_B_mat ) ;
   Eigen::Array<double, -1, -1>   signs_v = signs_A_mat * signs_B_mat;


   Eigen::Array<double, -1, 1> max_vals  =     (signs_v * log_abs_v).rowwise().maxCoeff() ;
   Eigen::Array<double, -1, 1>  sum_exp_vals =  ( (log_abs_v - max_vals).cast<double>().exp() * signs_v.cast<double>()).rowwise().sum();


   Eigen::Matrix<double, -1, -1>   out_mat(dim, 2) ; //   =   ( sum_exp_vals.sign() * ( max_vals +  sum_exp_vals.abs().log() ).abs() ).matrix() ; //   out_mat(x.rows());
   out_mat.col(0) =  (   ( max_vals +  sum_exp_vals.abs().log().cast<double>() )  ).matrix()  ; // answer on log scale - no sign info
   out_mat.col(1) =  (   sum_exp_vals.cast<double>().sign()  ).matrix()  ; // signs stored in seperate vector

   return  out_mat;


 }












 Eigen::Matrix<float, -1, -1>    fn_log_abs_sum_exp_vectorised_float(    Eigen::Array<float, -1, 1  > x_signs,
                                                                        Eigen::Array<float, -1, 1  > y_signs,
                                                                        Eigen::Array<float, -1, 1  > log_x,
                                                                        Eigen::Array<float, -1, 1  > log_y
 ) {




           Eigen::Array<float, -1, -1> signs_v  =  Eigen::Array<float, -1, -1>::Zero(x_signs.rows(), 2) ;


               signs_v.col(0)  = x_signs.array() ;
               signs_v.col(1)  = y_signs.array() ;

                Eigen::Array<float, -1, -1>    log_abs_v  =  Eigen::Array<float, -1, -1>::Zero(x_signs.rows(), 2) ;

                log_abs_v.col(0) = log_x.array();
                log_abs_v.col(1) = log_y.array();

               Eigen::Array<float, -1, 1> max_vals  =      Eigen::Array<float, -1, 1>::Zero(x_signs.rows()) ;
               Eigen::Array<double, -1, 1> sum_exp_vals  =  Eigen::Array<double, -1, 1>::Zero(x_signs.rows()) ;

                max_vals    =  (signs_v * log_abs_v).rowwise().maxCoeff() ;   // #    max(signs_v * log_abs_v);
                sum_exp_vals =  ( (log_abs_v - max_vals).cast<double>().exp() * signs_v.cast<double>()).rowwise().sum();



   Eigen::Matrix<float, -1, -1>   out_mat(x_signs.rows(), 2) ; //   =   ( sum_exp_vals.sign() * ( max_vals +  sum_exp_vals.abs().log() ).abs() ).matrix() ; //   out_mat(x.rows());
   out_mat.col(0) =  (   ( max_vals +  sum_exp_vals.abs().log().cast<float>()  )  ).matrix()  ; // answer on log scale - no sign info
   out_mat.col(1) =  (   sum_exp_vals.cast<float>().sign()  ).matrix()  ; // signs stored in seperate vector

   return  out_mat;

 }






 Eigen::Matrix<float, -1, -1>    fn_log_abs_sum_exp_mult_mat_by_col_vec_float(       Eigen::Array<float, -1, -1  > signs_A_mat,
                                                                                    Eigen::Array<float, -1, 1   > signs_b_vec,
                                                                                    Eigen::Array<float, -1, -1  > log_abs_A_mat,
                                                                                    Eigen::Array<float, -1, 1   > log_abs_b_vec
 ) {


   Eigen::Array<float, -1, -1> signs_B_mat   = log_abs_A_mat;
   Eigen::Array<float, -1, -1> log_abs_B_mat = log_abs_A_mat;

   int dim = signs_A_mat.rows();

   // # put b (vector) into a mat, with each row being identical
   for (int i = 0; i < dim; i++) {
     signs_B_mat.row(i)     = signs_b_vec.transpose() ;
     log_abs_B_mat.row(i)   = log_abs_b_vec.transpose() ;
   }

   // # apply logsumexp
   Eigen::Array<float, -1, -1>   log_abs_v  =  ( log_abs_A_mat +   log_abs_B_mat ) ;
   Eigen::Array<float, -1, -1>   signs_v = signs_A_mat * signs_B_mat;


   Eigen::Array<float, -1, 1> max_vals  =     (signs_v * log_abs_v).rowwise().maxCoeff() ;
   Eigen::Array<double, -1, 1>  sum_exp_vals =  ( (log_abs_v - max_vals).cast<double>().exp() * signs_v.cast<double>()).rowwise().sum();


   Eigen::Matrix<float, -1, -1>   out_mat(dim, 2) ; //   =   ( sum_exp_vals.sign() * ( max_vals +  sum_exp_vals.abs().log() ).abs() ).matrix() ; //   out_mat(x.rows());
   out_mat.col(0) =  (   ( max_vals +  sum_exp_vals.abs().log().cast<float>() )  ).matrix()  ; // answer on log scale - no sign info
   out_mat.col(1) =  (   sum_exp_vals.cast<float>().sign()  ).matrix()  ; // signs stored in seperate vector

   return  out_mat;

 }














//
//
//





Eigen::Matrix<double, -1, 1>    Rcpp_fn_no_list_HMC_single_iter_float(         int n_cores,
                                                                               Eigen::Matrix<double, -1, 1 >  theta_initial_main,
                                                                               Eigen::Matrix<double, -1, 1 >  theta_initial_us,   /////////////////////////////////////////////////////////////////////////////////////////
                                                                               Eigen::Matrix<int, -1, -1>	 y,   /////////////////////////////////////////////////////////////////////////////////////////
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  X, /////////////////////////////////////////////////////////////////////////////////////////
                                                                               bool dense_G_indicator,
                                                                               int L,
                                                                               double eps,
                                                                               double log_posterior_initial,
                                                                               Eigen::Array<double, -1, 1  > M_inv_us_array, /////////////////////////////////////////////////////////////////////////////////////////
                                                                               Eigen::Matrix<double, -1, -1  > M_dense_main,
                                                                               Eigen::Matrix<double, -1, -1  > M_inv_dense_main,
                                                                               Eigen::Matrix<double, -1, -1  > M_inv_dense_main_chol,
                                                                               int n_us,
                                                                               int n_params_main,
                                                                               bool exclude_priors,
                                                                               bool CI,
                                                                               Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                               Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                               Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                               int n_class,
                                                                               int n_tests,
                                                                               int ub_threshold_phi_approx,
                                                                               int n_chunks,
                                                                               bool corr_force_positive,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                               bool corr_prior_beta ,
                                                                               bool corr_prior_norm ,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
                                                                               std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                               double prev_prior_a,
                                                                               double prev_prior_b,
                                                                               int Phi_type,
                                                                               int sampling_option,
                                                                               bool generate_velocity,
                                                                               bool log_scale,
                                                                               int tanh_option,
                                                                               bool approx_exp_and_log_for_log_lik,
                                                                               bool approx_exp_and_log_for_grad
 )  {

   int N = y.rows();
   int n_params = n_us + n_params_main;
   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
   int n_coeffs = n_class * n_tests * 1;
   int n_bs_LT = n_tests * n_class;

   double U_x_initial = 0 ; //  - log_posterior_initial;
   double U_x = 0 ; // - log_posterior_initial;



   double log_posterior  =   0 ; // log_posterior_initial;
   double log_posterior_prop = 0 ;// log_posterior;

     ////////////////////// make complete parameter vector (log_diffs then coeffs)
     double minus_half_eps = -  eps/2;

     double energy_old = 0;
     double log_posterior_0 = 0.0;

     Eigen::Array<double,  -1, 1  > velocity_us_array(n_us); //  = velocity_0_us_array;//.cast<float>()  ; ////////////////////////////////////////////////////////////////////////////////////////////
     Eigen::Array<double, -1, 1  > velocity_main_array(n_params_main) ;

     {
               Eigen::Array<double,  -1, 1  > velocity_0_us_array(n_us) ; /////////////////////////////////////////////////////////////////////////////////////////
               Eigen::Array<double,  -1, 1  > velocity_0_main_array(n_params_main) ;

               {
                  // Eigen::Array<double, -1, 1  > velocity_0_array(n_params) ;   /////////////////////////////////////////////////////////////////////////////////////////

                     {

                       Eigen::Matrix<double, -1, 1>  std_norm_vec_main(n_params_main);
                       for (int d = 0; d < n_params_main; d++) {
                         std_norm_vec_main(d) =   R::rnorm(0, 1); //  zigg.norm();   // R::rnorm(0, 1);
                       }
                       velocity_0_main_array.matrix()  = M_inv_dense_main_chol * std_norm_vec_main;


                       Eigen::Array<double, -1, 1  > M_inv_us_vec_sqrt = stan::math::sqrt(M_inv_us_array.matrix().cast<double>()).cast<double>() ; /////////////////////////////////////////////////////////////////////////////////////////

                       for (int d = 0; d < n_us; d++) {
                         velocity_0_us_array(d)  =  R::rnorm(0,  M_inv_us_vec_sqrt(d)); //  zigg.norm()  ; // * M_inv_us_vec_sqrt(d) ;   // R::rnorm(0,  M_inv_us_vec_sqrt(d));
                       }

                        //  velocity_0_us_array.array() = velocity_0_us_array.array() * M_inv_us_vec_sqrt.array() ;
                     }


                     //  velocity_0_us_array =    velocity_0_array.head(n_us).cast<float>() ;  /////////////////////////////////////////////////////////////////////////////////////////
                     //  velocity_0_main_array =  velocity_0_array.segment(n_us, n_params_main);//.cast<double>()  ;

               }

               velocity_us_array = velocity_0_us_array;
               velocity_main_array = velocity_0_main_array;

               energy_old +=  0.5 * ( velocity_0_main_array.cast<double>() * Rcpp_mult_mat_by_col_vec(M_dense_main.cast<double>(), velocity_0_main_array.cast<double>().matrix()).array() ).matrix().sum() ;
               energy_old +=  0.5 * ( stan::math::square( velocity_0_us_array.matrix().cast<double>() ).array() * ( 1 / M_inv_us_array.cast<double>()   ) ).cast<double>().matrix().sum() ; /////////////////////////////////////////////////////////////////////////////////////////
      }

     Eigen::Matrix<double, -1, 1>   individual_log_lik  =  Eigen::Matrix<double, -1, 1>::Zero(N)  ; ////////////////////////////////////////////////////////////////////////////////////////////
     Eigen::Array<double,  -1, 1>   theta_us_array    =   theta_initial_us;//.cast<float>() ;   ////////////////////////////////////////////////////////////////////////////////////////////

     Eigen::Array<double,  -1, 1>   theta_main_array  =   theta_initial_main;//.cast<double>() ;

     int chunk_counter = 0;
     int chunk_size  = std::round( N / n_chunks  / 2) * 2;  ; // N / n_chunks;

     // ---------------------------------------------------------------------------------------------------------------///    Perform L leapfrogs   ///-----------------------------------------------------------------------------------------------------------------------------------------
     {

       Eigen::Matrix<double, -1, 1>  neg_lp_and_grad_outs  =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N) ;   /////////////////////////////////////////////////////////////////////////////////////////////


       for (int l = -1; l < L; l++) {


                           if (l > -1) {

                                   for (int chunk_counter = 0; chunk_counter < n_chunks; chunk_counter++) {

                                     velocity_us_array.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)    +=   minus_half_eps *
                                                                                                                                     neg_lp_and_grad_outs.segment(1 + chunk_size * n_tests * chunk_counter , chunk_size * n_tests).cast<double>().array() *
                                                                                                                                     M_inv_us_array.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).array()  ;

                                          theta_us_array.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)    +=   eps   * velocity_us_array.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests) ;

                                   }

                                   velocity_main_array +=   minus_half_eps *  ( M_inv_dense_main  *  ( neg_lp_and_grad_outs.segment(n_us + 1, n_params_main).cast<double>().array()).matrix()  ).array() ;
                                   theta_main_array  +=   eps  *  velocity_main_array; //// update params by full step

                           }

                           if (sampling_option == 11) {

                                       // neg_lp_and_grad_outs.array()    =    - fn_wo_list_log_posterior_and_gradient_Chol_Schur_MD_and_AD_1(  n_cores,
                                       //                                                                                                      theta_main_array , // .cast<double>().matrix(),
                                       //                                                                                                      theta_us_array , //  .cast<double>() , // .matrix(), // needs tto be a double? check
                                       //                                                                                                      y,
                                       //                                                                                                      X,
                                       //                                                                                                      exclude_priors,
                                       //                                                                                                      CI,
                                       //                                                                                                      lkj_cholesky_eta,
                                       //                                                                                                      prior_coeffs_mean ,
                                       //                                                                                                      prior_coeffs_sd,
                                       //                                                                                                      n_class,
                                       //                                                                                                      n_tests,
                                       //                                                                                                      ub_threshold_phi_approx,
                                       //                                                                                                      n_chunks,
                                       //                                                                                                      corr_force_positive,
                                       //                                                                                                      prior_for_corr_a,
                                       //                                                                                                      prior_for_corr_b,
                                       //                                                                                                      corr_prior_beta ,
                                       //                                                                                                      corr_prior_norm ,
                                       //                                                                                                      lb_corr,
                                       //                                                                                                      ub_corr,
                                       //                                                                                                      known_values_indicator,
                                       //                                                                                                      known_values,
                                       //                                                                                                      prev_prior_a,
                                       //                                                                                                      prev_prior_b,
                                       //                                                                                                      Phi_type,
                                       //                                                                                                      tanh_option).array() ; // .cast<double>() ;


                           }  else if (sampling_option == 100) {

                                         neg_lp_and_grad_outs.array()    =    - fn_wo_list_log_posterior_and_gradient_Chol_Schur_MD_and_AD_3(  n_cores,
                                                                                                                                                     theta_main_array , // .cast<double>().matrix(),
                                                                                                                                                     theta_us_array , //  .cast<double>() , // .matrix(), // needs tto be a double? check
                                                                                                                                                     y,
                                                                                                                                                     X,
                                                                                                                                                     exclude_priors,
                                                                                                                                                     CI,
                                                                                                                                                     lkj_cholesky_eta,
                                                                                                                                                     prior_coeffs_mean ,
                                                                                                                                                     prior_coeffs_sd,
                                                                                                                                                     n_class,
                                                                                                                                                     n_tests,
                                                                                                                                                     ub_threshold_phi_approx,
                                                                                                                                                     n_chunks,
                                                                                                                                                     corr_force_positive,
                                                                                                                                                     prior_for_corr_a,
                                                                                                                                                     prior_for_corr_b,
                                                                                                                                                     corr_prior_beta ,
                                                                                                                                                     corr_prior_norm ,
                                                                                                                                                     lb_corr,
                                                                                                                                                     ub_corr,
                                                                                                                                                     known_values_indicator,
                                                                                                                                                     known_values,
                                                                                                                                                     prev_prior_a,
                                                                                                                                                     prev_prior_b,
                                                                                                                                                     Phi_type,
                                                                                                                                                     tanh_option,
                                                                                                                                                     approx_exp_and_log_for_log_lik,
                                                                                                                                                     approx_exp_and_log_for_grad).array() ; // .cast<double>() ;




                                  } else  if (sampling_option == 10) {

                                                                               //
                                                                               // Eigen::Matrix<double,  -1, 1  > theta_full(n_params) ;
                                                                               // theta_full.head(n_us) = theta_us_array.matrix();
                                                                               // theta_full.segment(n_us, n_params_main) = theta_main_array.matrix();
                                                                               //
                                                                               // neg_lp_and_grad_outs.array()    =    - fn_wo_list_log_posterior_and_gradient_Chol_Schur_AD_float(    n_cores,
                                                                               //                                                                                                        theta_full.matrix() , // .cast<double>().matrix(),
                                                                               //                                                                                                        y,
                                                                               //                                                                                                        X,
                                                                               //                                                                                                        exclude_priors,
                                                                               //                                                                                                        CI,
                                                                               //                                                                                                        lkj_cholesky_eta,
                                                                               //                                                                                                        prior_coeffs_mean ,
                                                                               //                                                                                                        prior_coeffs_sd,
                                                                               //                                                                                                        n_class,
                                                                               //                                                                                                        n_tests,
                                                                               //                                                                                                        ub_threshold_phi_approx,
                                                                               //                                                                                                        n_chunks,
                                                                               //                                                                                                        corr_force_positive,
                                                                               //                                                                                                        prior_for_corr_a,
                                                                               //                                                                                                        prior_for_corr_b,
                                                                               //                                                                                                        corr_prior_beta ,
                                                                               //                                                                                                        corr_prior_norm ,
                                                                               //                                                                                                        lb_corr,
                                                                               //                                                                                                        ub_corr,
                                                                               //                                                                                                        known_values_indicator,
                                                                               //                                                                                                        known_values,
                                                                               //                                                                                                        prev_prior_a,
                                                                               //                                                                                                        prev_prior_b,
                                                                               //                                                                                                        Phi_type,
                                                                               //                                                                                                        tanh_option).array() ; // .cast<double>() ;


                                         }




                                   if (l == -1)      log_posterior_0 = - neg_lp_and_grad_outs(0)  ;


                                   if (l > -1) {

                                     for (int chunk_counter = 0; chunk_counter < n_chunks; chunk_counter++) {

                                       velocity_us_array.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)    +=   minus_half_eps *
                                                                                                                                      neg_lp_and_grad_outs.segment(1 + chunk_size * n_tests * chunk_counter , chunk_size * n_tests).cast<double>().array() *
                                                                                                                                      M_inv_us_array.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).array()  ;

                                     }

                                     velocity_main_array +=   minus_half_eps *  ( M_inv_dense_main  *  ( neg_lp_and_grad_outs.segment(n_us + 1, n_params_main).cast<double>().array()).matrix()  ).array() ;

                                   }




       }

       individual_log_lik.array() = - neg_lp_and_grad_outs.segment(1 + n_params, N).array().cast<double>()  ;   /////////////////////////////////////////////////////////////////////////////////////////
       log_posterior =  - neg_lp_and_grad_outs(0) ;

     }
     //




     int div = 0; // handles in R currently

     if  ((sampling_option > 11)  && (sampling_option < 15)  )  { // for latent trait
       for (int i = 0 + n_bs_LT; i < 0 + n_corrs; i++) {
        // velocity_0_main_array(i) = 0 ;
         // velocity_main_array(i) = 0 ;
         theta_main_array(i) =   R::rnorm(0, 1);
       }
     }





     //////////////////////////////////////////////////////////////////    M-H acceptance step  (i.e, Accept/Reject step)
     log_posterior_prop = log_posterior ;
     U_x = - log_posterior;

     log_posterior_initial = log_posterior_0 ;
     U_x_initial =  - log_posterior_initial;



     energy_old += U_x_initial ;
     // double energy_old = U_x_initial ;
     // energy_old +=  0.5 * ( velocity_0_main_array.cast<double>() * Rcpp_mult_mat_by_col_vec(M_dense_main.cast<double>(), velocity_0_main_array.cast<double>().matrix()).array() ).matrix().sum() ;
     // energy_old +=  0.5 * ( stan::math::square( velocity_0_us_array.matrix().cast<double>() ).array() * ( 1 / M_inv_us_array.cast<double>()   ) ).cast<double>().matrix().sum() ; /////////////////////////////////////////////////////////////////////////////////////////

     double energy_new = U_x ;
     energy_new +=   0.5 * ( velocity_main_array.cast<double>() * Rcpp_mult_mat_by_col_vec(M_dense_main.cast<double>(), velocity_main_array.cast<double>().matrix()).array() ).matrix().sum() ;
     energy_new +=   0.5 * ( stan::math::square( velocity_us_array.matrix().cast<double>() ).array() * ( 1 / M_inv_us_array.cast<double>()   ) ).cast<double>().matrix().sum() ;  /////////////////////////////////////////////////////////////////////////////////////////



     double log_ratio = - energy_new + energy_old;

     Eigen::Matrix<double, -1, 1 >  p_jump_vec(2);
     p_jump_vec(0) = 1;
     p_jump_vec(1) = std::exp(log_ratio);

     double p_jump = stan::math::min(p_jump_vec);

     int accept = 0;


     Eigen::Matrix<double, -1, 1>  out_mat =   Eigen::Matrix<double, -1, 1>::Zero(n_params + N);   /////////////////////////////////////////////////////////////////////////////////////////

     if  ((R::runif(0, 1) > p_jump) || (div == 1)) {  // # reject proposal

       accept = 0;
       out_mat.head(n_us) = theta_initial_us;// .cast<double>()  ;   /////////////////////////////////////////////////////////////////////////////////////////
       out_mat.segment(n_us, n_params_main) = theta_initial_main.cast<double>()  ;

     } else {   // # accept proposal


       accept = 1;
       out_mat.head(n_us) = theta_us_array ;//.cast<double>()  ;   /////////////////////////////////////////////////////////////////////////////////////////
       out_mat.segment(n_us, n_params_main) = theta_main_array.cast<double>()  ;

     }


   out_mat.segment(n_params, N) = individual_log_lik ; // .cast<double>() ; /////////////////////////////////////////////////////////////////////////////////////////

   return(out_mat);

 }


//
//
//
//
//
//
//
//
//
//
//

// //
//
 // [[Rcpp::export]]
 Rcpp::List   Rcpp_fn_post_burnin_HMC_post_adaptation_phase_float(      int n_cores,
                                                                        int n_iter_test,
                                                                        int n_chain_for_loading_bar,
                                                                        double tau,
                                                                        Eigen::Matrix<double, -1, 1 >  theta_initial_main,
                                                                        Eigen::Matrix<double, -1, 1 >  theta_initial_us,   //////////////////////////////////////////////
                                                                        Eigen::Matrix<int, -1, -1>	 y, /////////////////////////////////////////////
                                                                        std::vector<Eigen::Matrix<double, -1, -1 > >  X, /////////////////////////////////////////////
                                                                        bool dense_G_indicator,
                                                                        double numerical_diff_e,
                                                                        int L,
                                                                        double eps,
                                                                        double log_posterior,
                                                                        Eigen::Array<double, -1, 1  > M_inv_us_array, //////////////////////////////////////////////
                                                                        Eigen::Matrix<double, -1, -1  > M_dense_main,
                                                                        Eigen::Matrix<double, -1, -1  > M_inv_dense_main,
                                                                        Eigen::Matrix<double, -1, -1  > M_inv_dense_main_chol,
                                                                        int n_us,
                                                                        int n_params_main,
                                                                        bool exclude_priors,
                                                                        bool CI,
                                                                        Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                        Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                        Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                        int n_class,
                                                                        int n_tests,
                                                                        int ub_threshold_phi_approx,
                                                                        int n_chunks,
                                                                        bool corr_force_positive,
                                                                        std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                        std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                        bool corr_prior_beta ,
                                                                        bool corr_prior_norm ,
                                                                        std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                        std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
                                                                        std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                        std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                        double prev_prior_a,
                                                                        double prev_prior_b,
                                                                        int Phi_type,
                                                                        int sampling_option,
                                                                        bool log_scale,
                                                                        bool tau_jittered,
                                                                        int tanh_option,
                                                                        bool approx_exp_and_log_for_log_lik,
                                                                        bool approx_exp_and_log_for_grad
 )  {


   int n_params = n_us + n_params_main;
   int N = y.rows();

   Eigen::Matrix<double, -1, -1 >   theta_main_trace  = Eigen::Matrix<double, -1, -1  >::Zero(n_params_main, n_iter_test);
   Eigen::Matrix<double, -1, 1 >       theta_main_previous_iter = theta_initial_main.cast<double>();
   Eigen::Matrix<double, -1, 1 >       theta_us_previous_iter = theta_initial_us.cast<double>();
   //  Eigen::Matrix<double, -1, -1 >   log_lik_trace  = Eigen::Matrix<double, -1, -1  >::Zero(N, n_iter_test);
   Eigen::Matrix<int, -1, 1 >   div_vec  = Eigen::Matrix<int, -1, 1  >::Zero(n_iter_test);

   bool display_progress = false;
   if (n_chain_for_loading_bar == 1)    display_progress = true;

   Progress p(n_iter_test, display_progress);
   int Phi_type_original = Phi_type;

   double L_main_ii = 0;

   for (int ii = 0; ii < n_iter_test; ++ii)  {




                 if (n_chain_for_loading_bar == 1)  {
                   p.increment(); // update progress
                 }

                 if (Progress::check_abort() )    return -1;

                 if (tau_jittered == true) {
                     double tau_main_ii = R::runif(0,  2*tau);
                   L_main_ii = std::ceil(tau_main_ii / eps);
                 } else {
                   L_main_ii = std::ceil(tau / eps);
                 }


                 bool skip = false;
                 for (int attempt = 0; attempt < 2; ++attempt)  {


                   if (skip == true) {
                     skip = false;
                     continue;
                   }

                   if (attempt == 0)   {
                     Phi_type = Phi_type_original;
                   } else {
                     Phi_type = 3;
                   }

                   div_vec(ii) = 0;


                   {



                     try {

                     //    Eigen::Matrix<float, -1, 1  > log_M_us_vec =  ( - log_M_inv_us_vec.array() ).matrix() ;

                       Eigen::Matrix<double, -1, 1 >   single_iter_out =   Rcpp_fn_no_list_HMC_single_iter_float(    n_cores,
                                                                                                                     theta_main_previous_iter, // .cast<double>(),   //////////////////////////////////////////////
                                                                                                                     theta_us_previous_iter , // .cast<float>(),   //////////////////////////////////////////////
                                                                                                                     y,  //////////////////////////////////////////////
                                                                                                                     X,  //////////////////////////////////////////////
                                                                                                                     dense_G_indicator, //  5
                                                                                                                     L_main_ii,
                                                                                                                     eps,
                                                                                                                     log_posterior,
                                                                                                                     M_inv_us_array, //////////////////////////////////////////////
                                                                                                                     M_dense_main,
                                                                                                                     M_inv_dense_main,  //  10
                                                                                                                     M_inv_dense_main_chol,
                                                                                                                     n_us,
                                                                                                                     n_params_main ,   //  15
                                                                                                                     exclude_priors,
                                                                                                                     CI,
                                                                                                                     lkj_cholesky_eta,
                                                                                                                     prior_coeffs_mean ,
                                                                                                                     prior_coeffs_sd,   //  20
                                                                                                                     n_class,
                                                                                                                     n_tests,
                                                                                                                     ub_threshold_phi_approx,
                                                                                                                     n_chunks,
                                                                                                                     corr_force_positive,   //  25
                                                                                                                     prior_for_corr_a,
                                                                                                                     prior_for_corr_b,
                                                                                                                     corr_prior_beta ,
                                                                                                                     corr_prior_norm ,
                                                                                                                     lb_corr,           //  30
                                                                                                                     ub_corr,
                                                                                                                     known_values_indicator,
                                                                                                                     known_values,
                                                                                                                     prev_prior_a,
                                                                                                                     prev_prior_b,       //  35
                                                                                                                     Phi_type,
                                                                                                                     sampling_option,
                                                                                                                     false, // generate_velocity
                                                                                                                     log_scale,
                                                                                                                     tanh_option,
                                                                                                                     approx_exp_and_log_for_log_lik,
                                                                                                                     approx_exp_and_log_for_grad) ; // .cast<double>() ;

                       theta_main_previous_iter =  single_iter_out.segment(n_us, n_params_main).cast<double>() ;
                       theta_main_trace.col(ii) =  single_iter_out.segment(n_us, n_params_main).cast<double>() ;
                       theta_us_previous_iter   =  single_iter_out.head(n_us)  ; // .cast<float>() ;

                       //  log_lik_trace.col(ii) = single_iter_out.......cast<double>();
                       div_vec(ii) = 0;


                     } catch (...) {
                       div_vec(ii) = 1;
                       if (ii > 0) theta_main_trace.col(ii) =   theta_main_trace.col(ii - 1)  ;
                       //  log_lik_trace.col(ii) =   log_lik_trace.col(ii - 1);
                     }




                     if   (attempt == 0)  {

                       if  ( ( div_vec(ii)  == 0) && (Phi_type_original != 3)   ) {
                         skip = true;
                         Phi_type = Phi_type_original;
                       }

                       if  ( ( div_vec(ii)  == 1) && (Phi_type_original != 3)   ) {   //  # if div  on  attempt 1, try attempt 2
                         skip = false;
                         Phi_type = 3;
                       }

                     }


                   }

                 }



   }





   Rcpp::List out_list(5);

   out_list(0) = theta_main_trace.cast<double>();
   //  out_list(1) = log_lik_trace;
   out_list(2) = div_vec;

   return(out_list);

 }







 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1>  draw_std_norm_vec_Rcpp( int N ) {

   Eigen::Matrix<double, -1, 1> vec_out(N);

   for (int d = 0; d < N; d++) {
      vec_out(d) = R::rnorm(0, 1);
   }

   return vec_out;


 }












 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1>  draw_mean_zero_norm_Rcpp( Eigen::Matrix<double, -1, 1>  draws_vec,
                                                         Eigen::Matrix<double, -1, 1>  SD_vec) {

   for (int d = 0; d < draws_vec.rows(); d++) {
     draws_vec(d) = R::rnorm(0, 1);
   }

   draws_vec.array() = draws_vec.array() * SD_vec.array() ;

   return draws_vec;

 }







 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1>  draw_mean_zero_norm_using_Zigg_Rcpp(  Eigen::Matrix<double, -1, 1>  draws_vec,
                                                                     Eigen::Matrix<double, -1, 1>  SD_vec) {

   for (int d = 0; d < draws_vec.rows(); d++) {
     draws_vec(d) =  zigg.norm() ;
   }

   draws_vec.array() = draws_vec.array() * SD_vec.array() ;

   return draws_vec;

 }






 // [[Rcpp::export]]
 Rcpp::List   Rcpp_fn_post_burnin_HMC_post_adaptation_phase_float_big_version(      int n_cores,
                                                                        int n_iter_test,
                                                                        int n_chain_for_loading_bar,
                                                                        double tau,
                                                                        Eigen::Array<double, -1, 1 >  theta_main_array,
                                                                        Eigen::Array<double, -1, 1 >  theta_us_array,   //////////////////////////////////////////////
                                                                        Eigen::Matrix<int, -1, -1>	 y, /////////////////////////////////////////////
                                                                        std::vector<Eigen::Matrix<double, -1, -1 > >  X, /////////////////////////////////////////////
                                                                        bool dense_G_indicator,
                                                                        double numerical_diff_e,
                                                                        int L,
                                                                        double eps,
                                                                        double log_posterior,
                                                                        Eigen::Array<double, -1, 1  > M_inv_us_array, //////////////////////////////////////////////
                                                                        Eigen::Matrix<double, -1, -1  > M_dense_main,
                                                                        Eigen::Matrix<double, -1, -1  > M_inv_dense_main,
                                                                        Eigen::Matrix<double, -1, -1  > M_inv_dense_main_chol,
                                                                        int n_us,
                                                                        int n_params_main,
                                                                        bool exclude_priors,
                                                                        bool CI,
                                                                        Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                        Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                        Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                        int n_class,
                                                                        int n_tests,
                                                                        int ub_threshold_phi_approx,
                                                                        int n_chunks,
                                                                        bool corr_force_positive,
                                                                        std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                        std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                        bool corr_prior_beta ,
                                                                        bool corr_prior_norm ,
                                                                        std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                        std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
                                                                        std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                        std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                        double prev_prior_a,
                                                                        double prev_prior_b,
                                                                        int Phi_type,
                                                                        int sampling_option,
                                                                        bool log_scale,
                                                                        bool tau_jittered,
                                                                        int tanh_option,
                                                                        bool approx_exp_and_log_for_log_lik,
                                                                        bool approx_exp_and_log_for_grad
 )  {


   int N = y.rows();
   int n_params = n_us + n_params_main;
   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
   int n_coeffs = n_class * n_tests * 1;
   int n_bs_LT = n_tests * n_class;

   Eigen::Array<double, -1, -1 >   theta_main_trace  = Eigen::Matrix<double, -1, -1  >::Zero(n_params_main, n_iter_test);
   Eigen::Array<double, -1, 1 >       theta_main_previous_iter = theta_main_array.cast<double>();
   Eigen::Array<double, -1, 1 >       theta_us_previous_iter = theta_us_array.cast<double>();
   //  Eigen::Matrix<double, -1, -1 >   log_lik_trace  = Eigen::Matrix<double, -1, -1  >::Zero(N, n_iter_test);
   Eigen::Matrix<int, -1, 1 >   div_vec  = Eigen::Matrix<int, -1, 1  >::Zero(n_iter_test);

   bool display_progress = false;
   if (n_chain_for_loading_bar == 1)    display_progress = true;

   Progress p(n_iter_test, display_progress);
  //  int Phi_type_original = Phi_type;

   double L_main_ii = 0;

   Eigen::Matrix<double, -1, 1>   individual_log_lik  =  Eigen::Matrix<double, -1, 1>::Zero(N)  ; ////////////////////////////////////////////////////////////////////////////////////////////

   int chunk_counter = 0;
   int chunk_size  = std::round( N / n_chunks  / 2) * 2;  ; // N / n_chunks;

   for (int ii = 0; ii < n_iter_test; ++ii)  {

                                 // theta_main_previous_iter = theta_main_array;
                                 // theta_us_previous_iter = theta_us_array;


                                 if (n_chain_for_loading_bar == 1)  {
                                   p.increment(); // update progress
                                 }

                                 if (Progress::check_abort() )    return -1;

                                 if (tau_jittered == true) {
                                   double tau_main_ii = R::runif(0,  2*tau);
                                   L_main_ii = std::ceil(tau_main_ii / eps);
                                 } else {
                                   L_main_ii = std::ceil(tau / eps);
                                 }


                           // bool skip = false;
                           // int n_attempts;
                           //
                           // if (Phi_type_original == 3)  {
                           //   n_attempts = 1;
                           // } else if (Phi_type_original == 4) {
                           //   n_attempts = 1; // 2;
                           // } else if (Phi_type_original == 5) {
                           //   n_attempts = 1;
                           // } else {
                           //   n_attempts = 2; //  3;
                           // }


                           double U_x_initial = 0 ; //  - log_posterior_initial;
                           double U_x = 0 ; // - log_posterior_initial;
                           double log_posterior  =   0 ; // log_posterior_initial;
                           double log_posterior_prop = 0 ;// log_posterior;

                           ////////////////////// make complete parameter vector (log_diffs then coeffs)
                           double minus_half_eps = -  eps/2;

                           double energy_old_wo_U = 0;
                           double log_posterior_0 = 0.0;

                           Eigen::Array<double,  -1, 1  > velocity_us_array_pre_attempts(n_us); //  = velocity_0_us_array;//.cast<double>()  ; ////////////////////////////////////////////////////////////////////////////////////////////
                           Eigen::Array<double,  -1, 1  > velocity_main_array_pre_attempts(n_params_main) ;



                           {
                                     Eigen::Array<double,  -1, 1  > velocity_0_us_array(n_us) ; /////////////////////////////////////////////////////////////////////////////////////////
                                     Eigen::Array<double,  -1, 1  > velocity_0_main_array(n_params_main) ;

                                     {
                                       Eigen::Matrix<double, -1, 1>  std_norm_vec_main(n_params_main);
                                       for (int d = 0; d < n_params_main; d++) {
                                         //   std_norm_vec_main(d) =      zigg.norm();
                                         std_norm_vec_main(d) =       R::rnorm(0, 1);
                                       }
                                       velocity_0_main_array.matrix()  = M_inv_dense_main_chol * std_norm_vec_main;

                                       velocity_0_us_array =  draw_mean_zero_norm_using_Zigg_Rcpp(velocity_0_us_array,  M_inv_us_array.sqrt().matrix() ) ;

                                     }

                                     velocity_us_array_pre_attempts = velocity_0_us_array;
                                     velocity_main_array_pre_attempts = velocity_0_main_array;

                                     energy_old_wo_U +=  0.5 * ( velocity_0_main_array * Rcpp_mult_mat_by_col_vec(M_dense_main, velocity_0_main_array.matrix()).array() ).matrix().sum() ;
                                     energy_old_wo_U +=  0.5 * ( stan::math::square( velocity_0_us_array.matrix() ).array() * ( 1 / M_inv_us_array.array()    ) ).matrix().sum() ; /////////////////////////////////////////////////////////////////////////////////////////
                           }



                           theta_main_previous_iter = theta_main_array;
                           theta_us_previous_iter = theta_us_array;


                        {
                      //  for (int attempt = 0; attempt < n_attempts; ++attempt)  {

//
//                                    if (skip == true) {
//                                      skip = false;
//                                      continue;
//                                    }

                                   Eigen::Array<double,  -1, 1  > velocity_us_array =  velocity_us_array_pre_attempts; // reset velocity
                                   Eigen::Array<double,  -1, 1  > velocity_main_array = velocity_main_array_pre_attempts;  // reset velocity

                                   theta_main_array = theta_main_previous_iter; // reset theta
                                   theta_us_array = theta_us_previous_iter;  // reset theta


                                   // if (attempt == 0)   {
                                   //   Phi_type = Phi_type_original;
                                   // } else if (attempt == 1) {
                                   //   Phi_type = 4;
                                   // } else {  // attempt == 2
                                   //   Phi_type = 3;
                                   // }
                                   //
                                   div_vec(ii) = 0;  // reset div


                              try {



                               // ---------------------------------------------------------------------------------------------------------------///    Perform L leapfrogs   ///-----------------------------------------------------------------------------------------------------------------------------------------
                               Eigen::Array<double,  -1, 1  > theta_main_array_proposed = theta_main_array;
                               Eigen::Array<double,  -1, 1  > theta_us_array_proposed = theta_us_array;

                             {
                               Eigen::Matrix<double, -1, 1>  neg_lp_and_grad_outs  =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N) ;   /////////////////////////////////////////////////////////////////////////////////////////////



                               for (int l = -1; l < L; l++) {

                                                       if (l > -1) {

                                                                   for (int nc = 0; nc < n_chunks; nc++) {

                                                                     int chunk_counter = nc ;

                                                                     velocity_us_array.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)    +=   minus_half_eps *
                                                                                                                                                                    neg_lp_and_grad_outs.segment(1 + chunk_size * n_tests * chunk_counter , chunk_size * n_tests).array() *
                                                                                                                                                                    M_inv_us_array.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).array()  ;

                                                                     theta_us_array_proposed.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)    +=   eps   * velocity_us_array.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests) ;

                                                                   }

                                                                   velocity_main_array +=   minus_half_eps *  ( M_inv_dense_main  *    neg_lp_and_grad_outs.segment(n_us + 1, n_params_main).matrix()  ).array() ;
                                                                   theta_main_array_proposed  +=   eps  *  velocity_main_array; //// update params by full step

                                                         }



                                                         neg_lp_and_grad_outs.array()    =    - fn_wo_list_log_posterior_and_gradient_Chol_Schur_MD_and_AD_3(    n_cores,
                                                                                                                                                                      theta_main_array_proposed , // .cast<double>().matrix(),
                                                                                                                                                                      theta_us_array_proposed , //  .cast<double>() , // .matrix(), // needs tto be a double? check
                                                                                                                                                                      y,
                                                                                                                                                                      X,
                                                                                                                                                                      exclude_priors,
                                                                                                                                                                      CI,
                                                                                                                                                                      lkj_cholesky_eta,
                                                                                                                                                                      prior_coeffs_mean ,
                                                                                                                                                                      prior_coeffs_sd,
                                                                                                                                                                      n_class,
                                                                                                                                                                      n_tests,
                                                                                                                                                                      ub_threshold_phi_approx,
                                                                                                                                                                      n_chunks,
                                                                                                                                                                        corr_force_positive,
                                                                                                                                                                      prior_for_corr_a,
                                                                                                                                                                      prior_for_corr_b,
                                                                                                                                                                      corr_prior_beta ,
                                                                                                                                                                      corr_prior_norm ,
                                                                                                                                                                      lb_corr,
                                                                                                                                                                      ub_corr,
                                                                                                                                                                      known_values_indicator,
                                                                                                                                                                      known_values,
                                                                                                                                                                      prev_prior_a,
                                                                                                                                                                      prev_prior_b,
                                                                                                                                                                      Phi_type,
                                                                                                                                                                      tanh_option,
                                                                                                                                                                      approx_exp_and_log_for_log_lik,
                                                                                                                                                                      approx_exp_and_log_for_grad).array() ; // .cast<double>() ;








                                                         if (l == -1)      log_posterior_0 = - neg_lp_and_grad_outs(0)  ;


                                                         if (l > -1) {

                                                           for (int nc = 0; nc < n_chunks; nc++) {

                                                             int chunk_counter = nc ;

                                                             velocity_us_array.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)    +=   minus_half_eps *
                                                                                                                                                            neg_lp_and_grad_outs.segment(1 + chunk_size * n_tests * chunk_counter , chunk_size * n_tests).array() *
                                                                                                                                                            M_inv_us_array.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).array()  ;

                                                           }

                                                           velocity_main_array +=   minus_half_eps *  ( M_inv_dense_main  *    neg_lp_and_grad_outs.segment(n_us + 1, n_params_main).matrix()  ).array() ;

                                                         }




                                     }

                                     individual_log_lik.array() = - neg_lp_and_grad_outs.segment(1 + n_params, N).array().cast<double>()  ;   /////////////////////////////////////////////////////////////////////////////////////////
                                     log_posterior =  - neg_lp_and_grad_outs(0) ;

                             }



                                         if  ((sampling_option > 11)  && (sampling_option < 15)  )  { // for latent trait
                                           for (int i = 0 + n_bs_LT; i < 0 + n_corrs; i++) {
                                             theta_main_array(i) =   R::rnorm(0, 1);
                                           }
                                         }


                                         //////////////////////////////////////////////////////////////////    M-H acceptance step  (i.e, Accept/Reject step)
                                         log_posterior_prop = log_posterior ;
                                         U_x = - log_posterior_prop;
                                         U_x_initial =  - log_posterior_0;

                                         double energy_old = U_x_initial  + energy_old_wo_U ;
                                         // double energy_old = U_x_initial ;
                                         // energy_old +=  0.5 * ( velocity_0_main_array.cast<double>() * Rcpp_mult_mat_by_col_vec(M_dense_main.cast<double>(), velocity_0_main_array.cast<double>().matrix()).array() ).matrix().sum() ;
                                         // energy_old +=  0.5 * ( stan::math::square( velocity_0_us_array.matrix().cast<double>() ).array() * ( 1 / M_inv_us_array.cast<double>()   ) ).cast<double>().matrix().sum() ; /////////////////////////////////////////////////////////////////////////////////////////

                                         double energy_new = U_x ;
                                         energy_new +=   0.5 * ( velocity_main_array.cast<double>() * Rcpp_mult_mat_by_col_vec(M_dense_main.cast<double>(), velocity_main_array.cast<double>().matrix()).array() ).matrix().sum() ;
                                         energy_new +=   0.5 * ( stan::math::square( velocity_us_array.matrix().cast<double>() ).array() * ( 1 / M_inv_us_array.cast<double>()   ) ).cast<double>().matrix().sum() ;  /////////////////////////////////////////////////////////////////////////////////////////



                                         double log_ratio = - energy_new + energy_old;

                                         Eigen::Matrix<double, -1, 1 >  p_jump_vec(2);
                                         p_jump_vec(0) = 1;
                                         p_jump_vec(1) = std::exp(log_ratio);

                                         double p_jump = stan::math::min(p_jump_vec);

                                         int accept = 0;


                                         //Eigen::Matrix<double, -1, 1>  out_mat =   Eigen::Matrix<double, -1, 1>::Zero(n_params + N);   /////////////////////////////////////////////////////////////////////////////////////////

                                         if  ((R::runif(0, 1) > p_jump) ) {  // # reject proposal

                                                 accept = 0;
                                                 theta_us_array = theta_us_previous_iter;// .cast<double>()  ;   /////////////////////////////////////////////////////////////////////////////////////////
                                                 theta_main_array = theta_main_previous_iter; // .cast<double>()  ;

                                         } else {   // # accept proposal


                                                 accept = 1;
                                                 theta_us_array = theta_us_array_proposed ;//.cast<double>()  ;   /////////////////////////////////////////////////////////////////////////////////////////
                                                 theta_main_array = theta_main_array_proposed ; // .cast<double>()  ;

                                         }


                                        // out_mat.segment(n_params, N) = individual_log_lik ; // .cast<double>() ; /////////////////////////////////////////////////////////////////////////////////////////


                                         ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                                       //  theta_main_previous_iter =  theta_main_array
                                         theta_main_trace.col(ii) =  theta_main_array ;
                                       //  theta_us_previous_iter   =  theta_us_array

                                         div_vec(ii) = 0;




                                             // if   (attempt == 0)  {
                                             //
                                             //   if  ( ( div_vec(ii)  == 0) && (Phi_type_original != 4)   ) {
                                             //     skip = true;
                                             //     Phi_type = Phi_type_original;
                                             //   }
                                             //
                                             //   if  ( ( div_vec(ii)  == 1) && (Phi_type_original != 4)   ) {   //  # if div  on  attempt 1, try attempt 2
                                             //     skip = false;
                                             //     Phi_type = 4;
                                             //   }
                                             //
                                             // } else if (attempt == 1)  {
                                             //
                                             //
                                             //   if  ( ( div_vec(ii)  == 0) && (Phi_type_original != 3)   ) {
                                             //     skip = true;
                                             //     Phi_type = Phi_type_original;
                                             //     div_vec(ii) = 2; //  diverged on 1st attempt, success on 2nd attempt
                                             //   }
                                             //
                                             //   if  ( ( div_vec(ii)  == 1) && (Phi_type_original != 3)   ) {   //  # if div  on  attempt 1, try attempt 2
                                             //     skip = false;
                                             //     Phi_type = 3;
                                             //   }
                                             //
                                             // }
                                             //



                                     } catch (...) {

                                               div_vec(ii) = 1;
                                               if (ii > 0) theta_main_trace.col(ii) =   theta_main_trace.col(ii - 1)  ;
                                               //  log_lik_trace.col(ii) =   log_lik_trace.col(ii - 1);



//
//                                                if   (attempt == 0)  {
//
//                                                  if  ( ( div_vec(ii)  == 0) && (Phi_type_original != 4)   ) {
//                                                    skip = true;
//                                                    Phi_type = Phi_type_original;
//                                                  }
//
//                                                  if  ( ( div_vec(ii)  == 1) && (Phi_type_original != 4)   ) {   //  # if div  on  attempt 1, try attempt 2
//                                                    skip = false;
//                                                    Phi_type = 4;
//                                                  }
//
//                                                } else if (attempt == 1)  {
//
//
//                                                  if  ( ( div_vec(ii)  == 0) && (Phi_type_original != 3)   ) {
//                                                    skip = true;
//                                                    Phi_type = Phi_type_original;
//                                                  }
//
//                                                  if  ( ( div_vec(ii)  == 1) && (Phi_type_original != 3)   ) {   //  # if div  on  attempt 1, try attempt 2
//                                                    skip = false;
//                                                    Phi_type = 3;
//                                                  }
//
//                                                }



                                     }






                                 }



   }





   Rcpp::List out_list(5);

   out_list(0) = theta_main_trace.cast<double>();
   //  out_list(1) = log_lik_trace;
   out_list(2) = div_vec;

   return(out_list);

 }

//
//
// //

// //
//
//
// // 
// 
// 
  