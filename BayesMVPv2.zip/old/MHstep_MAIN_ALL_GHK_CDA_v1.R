
# MVP-GHK - Single iteration (calls Rcpp or R leapfrog integrator function)  --------------------------------------------------------------------
LMC_CDA_single_iteration_subset_only_diag_or_dense_G_simple        <- function(theta.,
                                                                           autodiff.,
                                                                           Euclidean_M_main.,
                                                                           dense_G_indicator.,
                                                                           n_burnin.,
                                                                        #   R_diag.,
                                                                        #   A_dense.,
                                                                          # Empirical_Fisher_mat.,
                                                                         #  sample_us.,
                                                                           lp_and_grad_args.,
                                                                        #   third_order_derivs.,
                                                                           iter.,
                                                                         #  testing.,
                                                                           velocity_0.,
                                                                        #   momentum_0.,
                                                                           M_main_vec_if_Euclidean.,
                                                                           M_us_vec_if_Euclidean.,
                                                                           M_dense_main., ##
                                                                           M_inv_dense_main., ##
                                                                           M_inv_dense_main_chol., ## 
                                                                         #  soft_abs.,
                                                                         #  soft_abs_alpha.,
                                                                           numerical_diff_e.,
                                                                           L.,
                                                                           epsilon.,
                                                                           grad_initial.,
                                                                           log_posterior_initial.,
                                                                           #G_initial_full_diag_vec.,
                                                                           # G_dense_main_initial., ## 
                                                                           # G_inv_dense_main_initial., ##
                                                                           # G_inv_chol_dense_main_initial.,
                                                                           y.,
                                                                          # index_us.,
                                                                           index_main.,
                                                                           NT_us.,
                                                                           individual_log_lik_initial.
  
) {
  
  

  
  { 
  
    n_class = 2 # lp_and_grad_args.[[12]];
    n_tests = lp_and_grad_args.[[13]];
    
    N =  nrow(y.)
    n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
    n_coeffs = n_class * n_tests * 1;
    n_us =  1 *  N * n_tests;
    
    n_params = length(theta.)
    n_params_main = n_params - n_us;
    
    index_us. = 1:n_us
  
  
  # 
  # n_us <- length(index_us.)
  # n_params_main <- length(index_main.)
  # 
 
  theta_vec_initial <- theta.
  theta <- theta_vec_initial
  
  grad_x <-  grad_initial.
  
 

  
 
  Delta <- 0  
  
 
 
     index_subset <-  1:n_params # index_main.
 
  
  velocity_0 <-  velocity_0. 
  velocity <- velocity_0.
  
  # momentum_0 <-  momentum_0. 
  # momentum <- momentum_0.
    
  leapfrog_outs <- NA
  
  individual_log_lik = individual_log_lik_initial.

  
  }


 # try({
 # 
 #          leapfrog_outs <-     BayesMVP::wr_fn_LMC_multiple_leapfrogs_main_only_diag_G_simple_GHK_MVP_USING_RCPP(  theta. = theta.,
 #                                                                                                                       autodiff. = autodiff., 
 #                                                                                                         # Euclidean_M_main. = Euclidean_M_main.,
 #                                                                                                          dense_G_indicator. = dense_G_indicator.,
 #                                                                                                          n_burnin. = n_burnin.,
 #                                                                                                          lp_and_grad_args. = lp_and_grad_args.,
 #                                                                                                          iter. = iter.,
 #                                                                                                          velocity_0. = velocity_0. ,
 #                                                                                                        #  momentum_0. = momentum_0.,
 #                                                                                                          M_main_vec_if_Euclidean. =  M_main_vec_if_Euclidean.,
 #                                                                                                          M_us_vec_if_Euclidean. = M_us_vec_if_Euclidean.,
 #                                                                                                          M_dense_main. = M_dense_main.,
 #                                                                                                          M_inv_dense_main. = M_inv_dense_main.,
 #                                                                                                          M_inv_dense_main_chol. = M_inv_dense_main_chol.,
 #                                                                                                          numerical_diff_e. = numerical_diff_e.,
 #                                                                                                          L. = L.,
 #                                                                                                          epsilon. =  epsilon.,
 #                                                                                                          grad_initial. = grad_initial.,
 #                                                                                                          log_posterior_initial. = log_posterior_initial.,
 #                                                                                                          y. = y.,
 #                                                                                                          individual_log_lik_initial. = individual_log_lik_initial.)
 #                  
 #          try({
 #          theta[index_subset] <-   leapfrog_outs$theta[index_subset]
 #          prop <-  theta
 # 
 #          grad_x[index_subset] <-    leapfrog_outs$grad_x[index_subset]
 #          grad_0 <- grad_initial.
 #          grad_0[index_subset] <-    leapfrog_outs$grad_0[index_subset]
 #          })
 # 
 # 
 # 
 # 
 #  })


      
 
               # try({
               #   theta[index_subset] <-   leapfrog_outs$theta[index_subset]
               #   prop <-  theta
               #   
               #   grad_x[index_subset] <-    leapfrog_outs$grad_x[index_subset]  
               #   grad_0 <- grad_initial.
               #   grad_0[index_subset] <-    leapfrog_outs$grad_0[index_subset]  
               #   
               #   log_posterior <-  leapfrog_outs$log_posterior
               #   log_posterior_initial. <- leapfrog_outs$log_posterior_0
               #     
               # #  G_initial_full_diag_vec. <-  leapfrog_outs$G_initial_full_diag_vec.
               #   
               #   # diag_Hessian <- - G_initial_full_diag_vec.
               #   # diag_Hessian[index_subset] <-   leapfrog_outs$diag_Hessian[index_subset]
               #   # diag_Hessian_prop <- diag_Hessian
               #   
               # 
               # 
               #   velocity[index_subset] <-  leapfrog_outs$velocity[index_subset]
               #   velocity_0[index_subset] <- leapfrog_outs$velocity_0[index_subset]
               #   velocity_prop <- velocity
               # 
               #   # 
               #   # momentum[index_subset] <-  leapfrog_outs$momentum[index_subset]
               #   # momentum_prop <- momentum
               #   # 
               #   # momentum_0 <- momentum_0.
               #   # momentum_0 <-  leapfrog_outs$momentum_0
               # 
               # 
               #   # dense_Hessian_main  <-  leapfrog_outs$dense_Hessian_main
               #   # G_dense_main  <-   leapfrog_outs$G_dense_main
               #   # G_dense_main_prop <- leapfrog_outs$G_dense_main
               #   # G_inv_dense_main <-   leapfrog_outs$G_inv_dense_main
               #   # G_inv_dense_main_prop <-  leapfrog_outs$G_inv_dense_main
               #   
               #   # G_dense_main_initial.  <-   leapfrog_outs$G_dense_main_initial
               #   # G_inv_dense_main_initial.  <-   leapfrog_outs$G_inv_dense_main_initial
               #   # 
               #   # G_inv_chol_dense_main <-  leapfrog_outs$G_inv_chol_dense_main
               #   
               #   log_acceptance_prob_GALA =  NA 
               #   
               # 
               #    #   neg_Hessian_proposed =   leapfrog_outs$neg_Hessian_proposed
               # 
               #       
               #       
               #       individual_log_lik_proposed = leapfrog_outs$individual_log_lik
               #       individual_log_lik = individual_log_lik_proposed
               # })
        
 

  



  # 
  log_posterior  <- log_posterior_initial.
  U_x_initial <- - log_posterior_initial.   
  
  
  # if ((any(is.na(theta))) || (any(is.na(grad_x))) )  { 
  # 
  #   comment(print(paste("div - main")))
  #   
  #         div <- 1
  #         p_jump <- 0
  # 
  #         # G_dense_main  <-  G_dense_main_initial.
  #         # G_inv_dense_main <-  G_inv_dense_main_initial.
  #         
  #         
  #         grad_x <- grad_initial.
  #         grad_prop <- grad_x
  #         grad_0 <- grad_initial.
  #         
  #         U_x  <- U_x_initial 
  #         log_posterior <- log_posterior_initial.
  #         
  #      #    G_full_diag_vec <- G_initial_full_diag_vec.
  #      # #   diag_Hessian <-  - G_initial_full_diag_vec.
  #      #    G_full_diag_vec_prop <- G_initial_full_diag_vec.
  #         
  # 
  #         theta <- theta_vec_initial
  #         
  #         velocity <- velocity_0
  #       #  momentum <- momentum_0
  #         
  # 
  #           
  #         log_ratio <- -1000000
  #         
  # } else { 
    
    div = 0 
    
  #  div = leapfrog_outs$div
    
          grad_prop <- grad_x
          
          # G_full_diag_vec <- - diag_Hessian
          # G_full_diag_vec_prop <- G_full_diag_vec
            
                 U_x <- - log_posterior   
                 
          #        energy_old <- U_x_initial
          #        energy_old = energy_old   +  0.5 *  sum(   c( BayesMVP::Rcpp_mult_mat_by_col_vec(mat = M_dense_main., colvec =    velocity_0[index_main.]) )  * velocity_0[index_main.]  )
          #        energy_old = energy_old   +  0.5 *  sum(velocity_0[index_us.]^2 * (  M_us_vec_if_Euclidean. )  )
          # 
          # 
          # 
          #       energy_new <- U_x
          #       energy_new = energy_new  + 0.5 *  sum(   c( BayesMVP::Rcpp_mult_mat_by_col_vec(mat = M_dense_main., colvec =    velocity[index_main.]) )  * velocity[index_main.]  )
          #       energy_new = energy_new  + 0.5 *  sum(velocity[index_us.]^2 *   (  M_us_vec_if_Euclidean. )  )
          #     
          #       
          # 
          #  log_ratio <-  - energy_new + energy_old   #  + delta_log_det  
          # 
          # 
          #  p_jump_new <-  min(1, exp(  + log_ratio)) ; p_jump_new
          # 
          # 
          # 
          # p_jump <- p_jump_new  ; p_jump
          
          
          CDA <-    lp_and_grad_args.[[106]]
          
          if (CDA == TRUE) {
            
             # log_ratio_CDA_proposal_part <-  - energy_new + energy_old
    
    
            try({
              # MALA_proposal_log_dens_star  <-       LaplacesDemon::dmvn(x = prop[index_main.], mu = theta_vec_initial[index_main.], Sigma =  epsilon. *  M_inv_dense_main., log = TRUE) +
              #                                       dnorm(x = prop[index_us.], mean = theta_vec_initial[index_us.], sd = epsilon. * sqrt(   (1 / M_us_vec_if_Euclidean. ) ), log = TRUE)
              # MALA_proposal_log_dens_reverse  <-    LaplacesDemon::dmvn(x = theta_vec_initial[index_main.], mu = prop[index_main.], Sigma =  epsilon. *  M_inv_dense_main., log = TRUE) +
              #                                        dnorm(x = theta_vec_initial[index_us.], mean = prop[index_us.], sd = epsilon. * sqrt( epsilon. * (1 / M_us_vec_if_Euclidean. ) ), log = TRUE)

              outs_manual_grad <-  BayesMVP::fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float(theta = theta_vec_initial,
                                                                                                      y = y.,
                                                                                                      lp_and_grad_args.)
              
           #   lp_r1_b0_initial  <- outs_manual_grad[1]    ; lp_r1_b0_initial
              grad_init <-    -head(outs_manual_grad[-1], n_params)
              
              M_inv_vec <- 1 / c( M_us_vec_if_Euclidean., M_main_vec_if_Euclidean. )
              
              prop = rnorm(n = n_params, mean =  theta_vec_initial + 0.5 * (epsilon.)  * (epsilon.) * (M_inv_vec)    *   - grad_init,   sd = (epsilon.)  * sqrt(M_inv_vec) )
              
              outs_manual_grad <-  BayesMVP::fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float(theta = prop,
                                                                                                      y = y.,
                                                                                                      lp_and_grad_args.)
              
             # lp_r1_b0_prop  <- outs_manual_grad[1]    ; lp_r1_b0_prop
              grad_prop <-   - head(outs_manual_grad[-1], n_params)
              
              MALA_proposal_log_dens_star  <-         sum(dnorm(x =  prop ,
                                                            mean = theta_vec_initial + 0.5 * (epsilon.)  * (epsilon.)  * (M_inv_vec)    *  -  grad_init,
                                                            sd =   (epsilon.) * sqrt(M_inv_vec)  , log = TRUE))

              MALA_proposal_log_dens_reverse  <-      sum(dnorm(x =  theta_vec_initial ,
                                                             mean = prop + 0.5 * (epsilon.)  * (epsilon.)  * (M_inv_vec)    * - grad_prop,
                                                            sd =   (epsilon.) * sqrt(M_inv_vec)  , log = TRUE))



              log_ratio_CDA_proposal_part <-  MALA_proposal_log_dens_reverse - MALA_proposal_log_dens_star

 
 
              CDA_r <- array(1, dim = c(n_class, n_tests))
              CDA_b <- array(0, dim = c(n_class, n_tests))
 
              lp_and_grad_args.[[107]] = CDA_r
              lp_and_grad_args.[[108]] = CDA_b
              
              outs_manual_grad <-  BayesMVP::fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float(theta = theta_vec_initial,
                                                                                                      y = y.,
                                                                                                      lp_and_grad_args.)
              
              lp_r1_b0_initial  <- outs_manual_grad[1]    ; lp_r1_b0_initial
              
              
              outs_manual_grad <-  BayesMVP::fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float(theta = prop,
                                                                                                      y = y.,
                                                                                                      lp_and_grad_args.)
              
              lp_r1_b0_prop  <- outs_manual_grad[1]    ; lp_r1_b0_prop




              CDA_r1_b0_log_p_jump_lp_ratio <- lp_r1_b0_prop - lp_r1_b0_initial
              

              
              log_ratio <- log_ratio_CDA_proposal_part  +  CDA_r1_b0_log_p_jump_lp_ratio

              p_jump <-  min(1, exp(  + log_ratio)) ; p_jump
              
              log_posterior <- lp_r1_b0_prop

              velocity_prop = velocity
              
            })

            
          }
          
          
          
          
          
          if   (  (is.na(p_jump)) ||  (is.null(p_jump)) )  { 
            p_jump <- 0
            comment(print("aaaaaaaaaaaaaa - MAIN"))
            comment(print(U_x))
            comment(print(U_x_initial))
          }
          
  # }
  
  
  

  ### MH step   
 # if (rexp(1) < Delta) { # reject proposal
 if  ( (runif(n = 1, 0, 1) > p_jump) || (div == 1)  )  { # reject proposal
   
                accept <- 0
                
                theta <- theta_vec_initial
                grad_x <- grad_0
                
                U_x  <- U_x_initial 
                log_posterior <- log_posterior_initial.
                
             #   G_full_diag_vec <- G_initial_full_diag_vec.
              #  diag_Hessian <-  - G_initial_full_diag_vec.
 
                velocity <- velocity_0
              #  momentum <- momentum_0
                
               # #  dense_Hessian_main  <- dense_Hessian_main_initial.
               #  G_dense_main  <-  G_dense_main_initial.
               #  G_inv_dense_main <-  G_inv_dense_main_initial.
                  
                  individual_log_lik = individual_log_lik_initial.
       
                
  } else {    # accept proposal
    
                accept <- 1
                theta  <- theta
                   
               #    individual_log_lik = individual_log_lik_proposed
                
  } 
  
  

 
 
  
  return(list(
    
    theta_vec_initial = theta_vec_initial ,
    theta = theta, # final parameter vector 
    prop = prop,
    
    log_ratio = log_ratio,
 
    # R_diag. = R_diag.,
    # R_diag_previous =  R_diag., # R_diag_previous,
    # A_dense. = A_dense.,
 
   # G_dense_main = G_dense_main,
   # G_inv_dense_main = G_inv_dense_main,
   # G_inv_chol_dense_main = G_inv_chol_dense_main,
    
   log_posterior =  log_posterior,
    log_posterior_prop = log_posterior, 
    log_posterior_0 =  log_posterior_initial.,
 
   div = div,
   
    U_x = U_x, # U_x,

 
 # neg_Hessian_accepted = neg_Hessian_accepted,
 # neg_Hessian_proposed = neg_Hessian_proposed,
 
    p_jump = p_jump,
    accept = accept,
    
  
    
    grad_x = grad_x,
    grad_prop = grad_prop,
    grad_0 = grad_0,
    
    # G_full_diag_vec = G_full_diag_vec,
    # G_full_diag_vec_prop = G_full_diag_vec_prop,

    velocity = velocity,
    velocity_0 = velocity_0,
   velocity_prop = velocity_prop,
   
  # momentum = momentum,
  # momentum_0 = momentum_0,
  # momentum_prop = momentum_prop,
   
 
   delta_log_det = 0,
 individual_log_lik = individual_log_lik
   

  ))
  
}








