
 
// #include <random>
// #include <xoshiro.h>
// #include <dqrng_distribution.h>
// #include <dqrng_generator.h>

// [[Rcpp::depends(RcppEigen)]]  
// [[Rcpp::depends(StanHeaders)]]   
// [[Rcpp::depends(RcppProgress)]]


#include <omp.h>

#include <progress.hpp>
#include <progress_bar.hpp>
#include <R_ext/Print.h>

#include <stan/math/rev.hpp>
#include <stan/math/fwd.hpp>
#include <stan/math/mix.hpp> // then stuff from mix/ must come next
//////#include <stan/math.hpp> 

 
#include <stan/math/prim/fun/Eigen.hpp>
#include <stan/math/prim/fun/typedefs.hpp>
#include <stan/math/prim/fun/value_of_rec.hpp>
#include <stan/math/prim/err/check_pos_definite.hpp>
#include <stan/math/prim/err/check_square.hpp>
#include <stan/math/prim/err/check_symmetric.hpp>
 
 
#include <stan/math/prim/fun/cholesky_decompose.hpp>
#include <stan/math/prim/fun/sqrt.hpp>
#include <stan/math/prim/fun/log.hpp>
#include <stan/math/prim/fun/transpose.hpp>
#include <stan/math/prim/fun/dot_product.hpp>
#include <stan/math/prim/fun/norm2.hpp>
#include <stan/math/prim/fun/diagonal.hpp>
#include <stan/math/prim/fun/cholesky_decompose.hpp>
#include <stan/math/prim/fun/eigenvalues_sym.hpp>
#include <stan/math/prim/fun/diag_post_multiply.hpp>
 
 
 
 
#include <stan/math/prim/prob/multi_normal_cholesky_lpdf.hpp>
#include <stan/math/prim/prob/lkj_corr_cholesky_lpdf.hpp>
#include <stan/math/prim/prob/weibull_lpdf.hpp>
#include <stan/math/prim/prob/gamma_lpdf.hpp>
#include <stan/math/prim/prob/beta_lpdf.hpp>
 
 
 
 
 

#include <RcppEigen.h> 
#include <Rcpp.h> 

 // #include <random>
//#include <pcg_random.hpp>
// #include <dqrng_sample.h>
 
 
#include <unsupported/Eigen/SpecialFunctions>
 
 // [[Rcpp::plugins(openmp)]]
 
#define EIGEN_USE_MKL_ALL
#include "Eigen/src/Core/util/MKL_support.h"

// [[Rcpp::plugins(cpp17)]]      



using namespace Rcpp;    
using namespace Eigen;      





 
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1 >    Rcpp_mult_mat_by_col_vec( Eigen::Matrix<double, -1, -1  >  mat,
                                                            Eigen::Matrix<double, -1, 1 >  colvec) {
   
   return(  mat * colvec  );
   
 }
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, -1  >    Rcpp_mult_mat_by_mat(    Eigen::Matrix<double, -1, -1  >  mat_1,
                                                             Eigen::Matrix<double, -1, -1  >  mat_2) {
   
   return(  mat_1 * mat_2  );
   
 }
 
 
 
 
 // [[Rcpp::export]]
 double   Rcpp_det( Eigen::Matrix<double, -1, -1  >  mat) {
   
   return(   mat.determinant()   ) ;
   
 }
 
 
 
 
 // [[Rcpp::export]]
 double   Rcpp_log_det( Eigen::Matrix<double, -1, -1  >  mat) {
   
   return(  log( std::abs( mat.determinant())  )  ) ;
   
 }
 
 
 
 
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, -1  >    Rcpp_solve( Eigen::Matrix<double, -1, -1  >  mat) {
   
   return(mat.inverse());
   
 }
 
 
 
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, -1  >    Rcpp_Chol( Eigen::Matrix<double, -1, -1  >  mat) {
   
   return( mat.llt().matrixL()  );
   
 }
 
 
 
 
 
 
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, -1 >    mat_out_test(int n_rows, 
                                                int n_cols) { 
   
   Eigen::Matrix<double, -1, -1 > my_vec(n_rows, n_cols);
   
   for (int i = 0; i < n_rows; ++i) {
     for (int j = 0; j < n_cols; ++j) {
       my_vec(i,j) = 0;
     }
   } 
   
   
   
   return(my_vec);
   
 }
 
 
 Eigen::Matrix<stan::math::var, -1, -1 >    mat_out_test_var(int n_rows, 
                                                             int n_cols) {
   
   Eigen::Matrix<stan::math::var, -1, -1 > my_vec(n_rows, n_cols);
   
   for (int i = 0; i < n_rows; ++i) {
     for (int j = 0; j < n_cols; ++j) {
       my_vec(i,j) = 0;
     }
   } 
   
   return(my_vec);
   
 }
 
 
 
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1 >    col_vec_out(int n_elements) {
   
   Eigen::Matrix<double, -1, 1 > my_vec(n_elements);
   
   for (int j = 0; j < n_elements; ++j) {
     my_vec(j) = 0;
   }
   
   
   return(my_vec);
   
 }
 
 Eigen::Matrix<stan::math::var, -1, 1 >    col_vec_out_var(int n_elements) {
   
   Eigen::Matrix<stan::math::var, -1, 1 > my_vec(n_elements);
   
   for (int j = 0; j < n_elements; ++j) {
     my_vec(j) = 0;
   }
   
   
   return(my_vec);
   
 }
 
 
 
 
 // [[Rcpp::export]]
 std::vector<Eigen::Matrix<double, -1, -1 > > vec_of_mats_test(int n_rows,
                                                               int n_cols,
                                                               int n_mats) {
   
   /// need to figure out more efficient way to do this + make work for all types easily (not just double)
   std::vector<Eigen::Matrix<double, -1, -1 > > my_vec(n_mats);
   Eigen::Matrix<double, -1, -1 > mat_sizes(n_rows, n_cols);
   
   //double counter = 0.0;
   
   for (int c = 0; c < n_mats; ++c) {
     my_vec[c] = mat_sizes;
     for (int i = 0; i < n_rows; ++i) {
       for (int j = 0; j < n_cols; ++j) {
         my_vec[c](i,j) = 0;
         //     counter = counter + 1;
       }
     }
   }
   
   
   return(my_vec); 
   
 }
 
 
 
 
 
 
 std::vector<Eigen::Matrix<float, -1, -1 > > vec_of_mats_test_float(int n_rows,
                                                               int n_cols,
                                                               int n_mats) {
   
 
   std::vector<Eigen::Matrix<float, -1, -1 > > my_vec(n_mats);
   Eigen::Matrix<float, -1, -1 > mat_sizes(n_rows, n_cols);
   
 
   
   for (int c = 0; c < n_mats; ++c) {
     my_vec[c] = mat_sizes;
     for (int i = 0; i < n_rows; ++i) {
       for (int j = 0; j < n_cols; ++j) {
         my_vec[c](i,j) = 0;
         //     counter = counter + 1;
       }
     }
   }
   
   
   return(my_vec); 
   
 }
 
 
 
 
 
 //   
 std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > vec_of_mats_test_var(int n_rows,
                                                                            int n_cols,
                                                                            int n_mats) {
   
   /// need to figure out more efficient way to do this + make work for all types easily (not just double)
   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > my_vec(n_mats);
   Eigen::Matrix<stan::math::var, -1, -1 > mat_sizes(n_rows, n_cols);
   
   //double counter = 0.0;
   
   for (int c = 0; c < n_mats; ++c) {
     my_vec[c] = mat_sizes;
     for (int i = 0; i < n_rows; ++i) {
       for (int j = 0; j < n_cols; ++j) {
         my_vec[c](i,j) = 0;
         //  counter = counter + 1;
       }
     }
   }
   
   
   return(my_vec);
   
 }
 
 
 
 
 // function for use in the log-posterior function (i.e. the function to calculate gradients for)
 stan::math::var fn_Phi_approx_FWD_AD_2(stan::math::var x) {
   stan::math::var y = 1/(1 + exp(-(0.07056*x*x*x + 1.5976*x)));
   return(y);
 }
 
 // build template
 template <typename T>
 T fn_Phi_approx_2(T x) {
   return(1/(1 + exp(-(1.702*x))));
 }
 
 // specialise template for ReturnType = double
 template <>
 double fn_Phi_approx_2(double x) {
   return(1/(1 + exp(-(1.702*x))));
 }
 
 // specialise template for ReturnType = stan::math::var (for autodiff)
 template <>
 stan::math::var fn_Phi_approx_2(stan::math::var x) {
   return(1/(1 + exp(-(1.702*x))));
 }
 
 // build template
 template <typename T>
 T fn_Phi_approx(T x) {
   return(1/(1 + exp(-(0.07056*x*x*x + 1.5976*x))));
 }
 
 // specialise template for ReturnType = double
 template <>
 double fn_Phi_approx(double x) {
   return(1/(1 + exp(-(0.07056*x*x*x + 1.5976*x))));
 }
 
 // specialise template for ReturnType = stan::math::var (for autodiff)
 template <>
 stan::math::var fn_Phi_approx(stan::math::var x) {
   return(1/(1 + exp(-(0.07056*x*x*x + 1.5976*x))));
 }
 
 // call with e.g. fn_Phi_approx<stan::math::var>(x)
 
 
 // function for use in the log-posterior function (i.e. the function to calculate gradients for)
 Eigen::Matrix<stan::math::var, -1, -1>	  fn_calculate_cutpoints_FWD_AD( 
     Eigen::Matrix<stan::math::var, -1, 1> log_diffs, //this is aparameter (col vec)
     stan::math::var first_cutpoint, // this is constant
     int K) {
   
   Eigen::Matrix<stan::math::var, -1, -1> cutpoints_set_full(K+1, 1);
   
   cutpoints_set_full(0,0) = -1000;
   cutpoints_set_full(1,0) = first_cutpoint;
   cutpoints_set_full(K,0) = +1000;
   
   for (int k=2; k < K; ++k) 
     cutpoints_set_full(k,0) =     cutpoints_set_full(k-1,0)  + (exp(log_diffs(k-2))) ;
   
   return cutpoints_set_full; // output is a parameter to use in the log-posterior function to be differentiated 
 }
 
 
 // NEED TO MAKE INTO A TEMPLATE!!!
 // function for use in the log-posterior function (i.e. the function to calculate gradients for)
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, -1>	  fn_calculate_cutpoints( 
     Eigen::Matrix<double, -1, 1> log_diffs, //this is a parameter (col vec)
     double first_cutpoint, // this is constant
     int K) {
   
   Eigen::Matrix<double, -1, -1> cutpoints_set_full(K+1, 1);
   
   cutpoints_set_full(0,0) = -1000;
   cutpoints_set_full(1,0) = first_cutpoint;
   cutpoints_set_full(K,0) = +1000;
   
   for (int k=2; k < K; ++k) 
     cutpoints_set_full(k,0) =     cutpoints_set_full(k-1,0)  + (exp(log_diffs(k-2))) ;
   
   return cutpoints_set_full; // output is a parameter to use in the log-posterior function to be differentiated 
 }
 
 
 
 
 // outputs 3d array, input vector - DOUBLE
 // [[Rcpp::export]]
 std::vector<Eigen::Matrix<double, -1, -1 > >   fn_convert_std_vec_to_3d_array( 
     
     std::vector<double>    input_vec, 
     int n_rows,
     int n_cols,
     int n_arrays) {
   
   
   
   std::vector<Eigen::Matrix<double, -1, -1 > >  output_array = vec_of_mats_test(n_rows, n_cols, n_arrays); // 3d array to output
   
   int i = 0;
   for (int c = 0; c < n_arrays; ++c) {
     for (int t = 0; t < n_rows; ++t)  {
       for (int k=0; k < n_cols; ++k) { // equiv to 1 to K - 2 in R
         output_array[c](t,k) = input_vec[i];
         i = i + 1;
       }
     }
   }
   
   
   return output_array; // output is a parameter to use in the log-posterior function to be differentiated 
 }
 
 
 
 // outputs vector, input 3d array - DOUBLE
 // [[Rcpp::export]]
 std::vector<double>    fn_convert_3d_array_to_std_vec( 
     std::vector<Eigen::Matrix<double, -1, -1 > >  input_array, 
     int n_rows,
     int n_cols,
     int n_arrays) {
   
   std::vector<double>   output_vec(n_arrays * n_rows * n_cols); // 1d vector to output
   
   
   int i = 0;
   for (int c = 0; c < n_arrays; ++c) {
     for (int t = 0; t < n_rows; ++t)  {
       for (int k=0; k < n_cols; ++k) { // equiv to 1 to K - 2 in R
         output_vec[i] = input_array[c](t,k);
         i = i + 1; 
       }
     }
   }
   
   
   return output_vec; // output is a parameter to use in the log-posterior function to be differentiated 
 }
 
 
 // outputs 3d array, input vector - var
 std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >   fn_convert_std_vec_to_3d_array_var( 
     
     std::vector<stan::math::var>    input_vec, 
     int n_rows,
     int n_cols,
     int n_arrays) {
   
   
   
   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  output_array = vec_of_mats_test_var(n_rows, n_cols, n_arrays); // 3d array to output
   
   int i = 0;
   for (int c = 0; c < n_arrays; ++c) {
     for (int t = 0; t < n_rows; ++t)  {
       for (int k=0; k < n_cols; ++k) { // equiv to 1 to K - 2 in R
         output_array[c](t,k) = input_vec[i];
         i = i + 1;
       }
     }
   }
   
   
   return output_array; // output is a parameter to use in the log-posterior function to be differentiated 
 }
 
 
 
 // outputs vector, input 3d array - var
 std::vector<stan::math::var>    fn_convert_3d_array_to_std_vec_var( 
     std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  input_array, 
     int n_rows,
     int n_cols,
     int n_arrays) {
   
   std::vector<stan::math::var>   output_vec(n_arrays * n_rows * n_cols); // 1d vector to output
   
   
   int i = 0;
   for (int c = 0; c < n_arrays; ++c) {
     for (int t = 0; t < n_rows; ++t)  {
       for (int k=0; k < n_cols; ++k) { // equiv to 1 to K - 2 in R
         output_vec[i] = input_array[c](t,k);
         i = i + 1; 
       }
     }
   }
   
   
   return output_vec; // output is a parameter to use in the log-posterior function to be differentiated 
 }
 
 
 // input vector, outputs upper-triangular 3d array of corrs- double
 
 // [[Rcpp::export]]
 std::vector<Eigen::Matrix<double, -1, -1 > >   fn_convert_std_vec_of_corrs_to_3d_array( 
     std::vector<double>   input_vec, 
     int n_rows,
     int n_arrays) {
   
   std::vector<Eigen::Matrix<double, -1, -1 > >   output_array = vec_of_mats_test(n_rows, n_rows, n_arrays); // 1d vector to output
   
   int k = 0;
   for (int c = 0; c < n_arrays; ++c) {
     for (int i = 1; i < n_rows; ++i)  {
       for (int j = 0; j < i; ++j) { // equiv to 1 to K - 2 in R
         output_array[c](i,j) =  input_vec[k];
         k = k + 1; 
       }
     }
   }
   
   return output_array; // output is a parameter to use in the log-posterior function to be differentiated 
 }
 
 
 
 
 
 
 // input vector, outputs upper-triangular 3d array of corrs- double
 std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >   fn_convert_std_vec_of_corrs_to_3d_array_var( 
     std::vector<stan::math::var>   input_vec, 
     int n_rows,
     int n_arrays) {
   
   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >   output_array = vec_of_mats_test_var(n_rows, n_rows, n_arrays); // 1d vector to output
   
   int k = 0;
   for (int c = 0; c < n_arrays; ++c) {
     for (int i = 1; i < n_rows; ++i)  {
       for (int j = 0; j < i; ++j) { // equiv to 1 to K - 2 in R
         output_array[c](i,j) =  input_vec[k];
         k = k + 1; 
       }
     }
   }
   
   return output_array; // output is a parameter to use in the log-posterior function to be differentiated 
 }
 
 
 
 
 
 // outputs vector, input upper-triangular 3d array of corrs- double
 // [[Rcpp::export]]
 std::vector<double>    fn_convert_3d_array_of_corrs_to_std_vec( 
     std::vector<Eigen::Matrix<double, -1, -1 > >  input_array, 
     int n_rows,
     int n_arrays) {
   
   std::vector<double>   output_vec(n_arrays * 0.5 * n_rows * (n_rows - 1)); // 1d vector to output
   
   int k = 0;
   for (int c = 0; c < n_arrays; ++c) {
     for (int i = 1; i < n_rows; ++i)  {
       for (int j = 0; j < i; ++j) { // equiv to 1 to K - 2 in R
         output_vec[k] = input_array[c](i,j);
         k = k + 1; 
       }
     }
   }
   
   return output_vec; // output is a parameter to use in the log-posterior function to be differentiated 
 }
 
 
 
 
 
 
 
 // outputs vector, input upper-triangular 3d array of corrs- var
 std::vector<stan::math::var>    fn_convert_3d_array_of_corrs_to_std_vec_var( 
     std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  input_array, 
     int n_rows,
     int n_arrays) {
   
   std::vector<stan::math::var>   output_vec(n_arrays * 0.5 * n_rows * (n_rows - 1)); // 1d vector to output
   
   int k = 0;
   for (int c = 0; c < n_arrays; ++c) {
     for (int i = 1; i < n_rows; ++i)  {
       for (int j = 0; j < i; ++j) { // equiv to 1 to K - 2 in R
         output_vec[k] = input_array[c](i,j);
         k = k + 1; 
       }
     }
   } 
   
   return output_vec; // output is a parameter to use in the log-posterior function to be differentiated  
 }
 
 
 
 
 
 // convert std vec to eigen vec - var
 Eigen::Matrix<stan::math::var, -1, 1> std_vec_to_eigen_vec_var(std::vector<stan::math::var> std_vec) {
   
   Eigen::Matrix<stan::math::var, -1, 1>  eigen_vec(std_vec.size());
   
   for (int i = 0; i < std_vec.size(); ++i) {
     eigen_vec(i) = std_vec[i];
   }
   
   return(eigen_vec);
 }
 
 
 
 
 // convert std vec to eigen vec - double
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1> std_vec_to_eigen_vec(std::vector<double> std_vec) {
   
   Eigen::Matrix<double, -1, 1>  eigen_vec(std_vec.size());
   
   for (int i = 0; i < std_vec.size(); ++i) {
     eigen_vec(i) = std_vec[i];
   }
   
   return(eigen_vec);
 }
 
 // [[Rcpp::export]]
 std::vector<double> eigen_vec_to_std_vec(Eigen::Matrix<double, -1, 1> eigen_vec) {
   
   std::vector<double>  std_vec(eigen_vec.rows());
   
   for (int i = 0; i < eigen_vec.rows(); ++i) {
     std_vec[i] = eigen_vec(i);
   }
   
   return(std_vec);
 }
 
 
 std::vector<stan::math::var> eigen_vec_to_std_vec_var(Eigen::Matrix<stan::math::var, -1, 1> eigen_vec) {
   
   std::vector<stan::math::var>  std_vec(eigen_vec.rows());
   
   for (int i = 0; i < eigen_vec.rows(); ++i) {
     std_vec[i] = eigen_vec(i);
   }
   
   return(std_vec);
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 // [[Rcpp::export]]
 std::vector<std::vector<Eigen::Matrix<double, -1, -1 > > > vec_of_vec_of_mats_test(int n_rows,
                                                                                    int n_cols,
                                                                                    int n_mats_inner, 
                                                                                    int n_mats_outer) {
   
   /// need to figure out more efficient way to do this + make work for all types easily (not just double)
   std::vector<std::vector<Eigen::Matrix<double, -1, -1 > > > my_vec_of_vecs(n_mats_outer);
   Eigen::Matrix<double, -1, -1 > mat_sizes(n_rows, n_cols);
   
   
   
   for (int c1 = 0; c1 < n_mats_outer; ++c1) {
     std::vector<Eigen::Matrix<double, -1, -1 > > my_vec(n_mats_inner);
     my_vec_of_vecs[c1] = my_vec; 
     for (int c2 = 0; c2 < n_mats_inner; ++c2) {
       my_vec_of_vecs[c1][c2] = mat_sizes;
       for (int i = 0; i < n_rows; ++i) {
         for (int j = 0; j < n_cols; ++j) {
           my_vec_of_vecs[c1][c2](i, j) = 0;
         }
       }
     }
   }
   
   
   return(my_vec_of_vecs);
   
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 std::vector<std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > > vec_of_vec_of_mats_test_var(int n_rows,
                                                                                                 int n_cols,
                                                                                                 int n_mats_inner, 
                                                                                                 int n_mats_outer) {
   
   /// need to figure out more efficient way to do this + make work for all types easily (not just double)
   std::vector<std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > > my_vec_of_vecs(n_mats_outer);
   Eigen::Matrix<stan::math::var, -1, -1 > mat_sizes(n_rows, n_cols);
   
   
   
   for (int c1 = 0; c1 < n_mats_outer; ++c1) {
     std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > my_vec(n_mats_inner);
     my_vec_of_vecs[c1] = my_vec; 
     for (int c2 = 0; c2 < n_mats_inner; ++c2) {
       my_vec_of_vecs[c1][c2] = mat_sizes;
       for (int i = 0; i < n_rows; ++i) {
         for (int j = 0; j < n_cols; ++j) {
           my_vec_of_vecs[c1][c2](i,j) = 0;
         }
       }
     }
   }
   
   
   return(my_vec_of_vecs);
   
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 // [[Rcpp::export]]
 std::vector<Eigen::Matrix<double, -1, -1  > >    fn_convert_unconstrained_to_corrs_double(Eigen::Matrix<double, -1, -1  > Omega_unconstrained
 ) { 
   
   
   int dim = Omega_unconstrained.rows();
   
   ///////////  (1) define lower-triangular matrix Z (tanh transform of Omega_unconstrained)
   Eigen::Matrix<double, -1, -1  > Omega_Z = mat_out_test(dim, dim);
   
   
   
   // diagonal of zero's (i = j)
   for (int i = 0; i < dim; ++i) {
     Omega_Z(i,i) = 0;
   }
   
   // upper triangle of zero's (j > i ) 
   for (int j = 1; j < dim; ++j)  {
     for (int i = 0; i < j; ++i) { // equiv to 1 to K - 2 in R
       Omega_Z(i,j) = 0;
     }
   } 
   
   
   
   // lower triangle of tanh transforms (j < i)
   for (int i = 1; i < dim; ++i)  {
     for (int j = 0; j < i; ++j) { // equiv to 1 to K - 2 in R
       Omega_Z(i,j) = (exp(2 * Omega_unconstrained(i,j)) - 1 ) /   (exp(2 * Omega_unconstrained(i,j)) + 1 );
     }
   }
   
   // convert to a vector
   std::vector<Eigen::Matrix<double, -1, -1  > > Omega_Z_array = vec_of_mats_test(dim, dim, 1);
   Omega_Z_array[0] = Omega_Z;
   
   Eigen::Matrix<double, -1, 1  > Omega_Z_vec = std_vec_to_eigen_vec(fn_convert_3d_array_of_corrs_to_std_vec(Omega_Z_array, 
                                                                                                             dim, 
                                                                                                             1));
   
   ///////////// (2) then map Omega_Z -> LOWER - triangular cholesky factor corr's
   Eigen::Matrix<double, -1, -1  > L_Omega_lower = mat_out_test(dim, dim);
   
   
   int counter = 0;
   
   L_Omega_lower(0,0) = 1;  // 1 if i = j = 1
   
   double term_2 = 0.0;
   
   
   Eigen::Matrix<double, -1, -1  > sqrt_term = mat_out_test(dim, dim);
   Eigen::Matrix<double, -1, -1  > term_inv = mat_out_test(dim, dim);
   
   
   for (int i = 1; i < dim; ++i) {
     
     //  L_Omega_lower(i, 0) = Omega_Z_vec(counter);
     L_Omega_lower(i, 0) = Omega_Z(i, 0);
     counter = counter + 1;
     
     double temp_sum_square = L_Omega_lower(i, 0) * L_Omega_lower(i, 0);
     
     for (int j = 1; j < i + 1; ++j) {
       
       if (j == i) { continue; }
       
       
       // 
       if (j != i) {
         
         term_2 += 0.5 * stan::math::log1m(temp_sum_square);
         
         L_Omega_lower(i, j) =  Omega_Z(i, j) * sqrt( 1 - temp_sum_square);
         
         sqrt_term(i, j) = sqrt( 1 - temp_sum_square);
         term_inv(i, j) = (1 /  sqrt_term(i, j)) * (1 /  sqrt_term(i, j));
         
         temp_sum_square += L_Omega_lower(i, j) * L_Omega_lower(i, j);
         
         
       }
       
     }
     L_Omega_lower(i, i) =  sqrt(1 - temp_sum_square);
     
   }
   
   
   //////////// (3) calculate correlation matrix 
   Eigen::Matrix<double, -1, -1  > Omega = L_Omega_lower * L_Omega_lower.transpose();
   
   for (int i = 0; i < dim; ++i) {
     Omega(i,i) = 1;
   }
   
   //////////////////// calculate Jacobian adjustment
   // make vector of unconstrained params
   Eigen::Matrix<double, -1, 1  > Omega_y_vec =   Omega_Z_vec;
   Eigen::Matrix<double, -1, 1  > jac_vec =   Omega_Z_vec;
   
   for (int i = 0; i < Omega_Z_vec.rows(); ++i) {
     Omega_y_vec(i) = 0.5 * log( (1 + Omega_Z_vec(i)) / (1 - Omega_Z_vec(i)) );  // undo tanh transform
     jac_vec(i) = log( ( exp( Omega_y_vec(i) ) +  exp( - Omega_y_vec(i) ) ) / 2 ); // cosh(y)
   }
   
   double term_1 = -2 * jac_vec.sum();
   
   double log_det_jacobian = term_1 + term_2;
 
   
   //////// outputs
   std::vector<Eigen::Matrix<double, -1, -1  > > out = vec_of_mats_test(dim, dim, 6) ;
   
   out[0] = L_Omega_lower;
   out[1] = Omega;
   out[2] = Omega_Z;
   out[3](0,0) = log_det_jacobian;
   out[4] = sqrt_term;
   out[5] =  term_inv;
   
   
   return(out);
   
 }
 
 
 
 
 
 
 
 /////////////// for var corr's
 std::vector<Eigen::Matrix<stan::math::var, -1, -1  > >    fn_convert_unconstrained_to_corrs_var(Eigen::Matrix<stan::math::var, -1, -1  > Omega_unconstrained
 ) { 
   
   
   int dim = Omega_unconstrained.rows();
   
   ///////////  (1) define lower-triangular matrix Z (tanh transform of Omega_unconstrained)
   Eigen::Matrix<stan::math::var, -1, -1  > Omega_Z = mat_out_test_var(dim, dim);
   
   // diagonal of zero's (i = j)
   for (int i = 0; i < dim; ++i) {
     Omega_Z(i,i) = 0;
   }
   
   // upper triangle of zero's (j > i ) 
   for (int j = 1; j < dim; ++j)  {
     for (int i = 0; i < j; ++i) { 
       Omega_Z(i,j) = 0;
     }
   }
   
   // lower triangle of tanh transforms (j < i)
   for (int i = 1; i < dim; ++i)  {
     for (int j = 0; j < i; ++j) { 
       Omega_Z(i,j) = (exp(2 * Omega_unconstrained(i,j)) - 1 ) /   (exp(2 * Omega_unconstrained(i,j)) + 1 );
     }
   }
   
   // convert to a vector
   std::vector<Eigen::Matrix<stan::math::var, -1, -1  > > Omega_Z_array = vec_of_mats_test_var(dim, dim, 1);
   Omega_Z_array[0] = Omega_Z;
   
   Eigen::Matrix<stan::math::var, -1, 1  > Omega_Z_vec = std_vec_to_eigen_vec_var(fn_convert_3d_array_of_corrs_to_std_vec_var(Omega_Z_array, 
                                                                                                                              dim, 
                                                                                                                              1));
   
   ///////////// (2) then map Omega_Z -> LOWER - triangular cholesky factor corr's
   Eigen::Matrix<stan::math::var, -1, -1  > L_Omega_lower = mat_out_test_var(dim, dim);
   
   Eigen::Matrix<stan::math::var, -1, -1  > sqrt_term =  L_Omega_lower;
   Eigen::Matrix<stan::math::var, -1, -1  > term_inv = mat_out_test(dim, dim);
   
   L_Omega_lower(0,0) = 1;  // 1 if i = j = 1
   stan::math::var term_2 = 0.0;
   
   for (int i = 1; i < dim; ++i) {
     
     L_Omega_lower(i, 0) = Omega_Z(i, 0);
     
     stan::math::var temp_sum_square = L_Omega_lower(i, 0) * L_Omega_lower(i, 0);
     
     for (int j = 1; j < i + 1; ++j) {
       
       if (j == i) { continue; }
       
       
       if (j != i) {
         
         term_2 += 0.5 * stan::math::log1m(temp_sum_square);
         
         sqrt_term(i, j) = sqrt( 1 - temp_sum_square);
         term_inv(i, j) = (1 /  sqrt_term(i, j)) * (1 /  sqrt_term(i, j));
         
         L_Omega_lower(i, j) =  Omega_Z(i, j) * sqrt( 1 - temp_sum_square);
         
         temp_sum_square += L_Omega_lower(i, j) * L_Omega_lower(i, j);
         
         
       }
       
     }
     
     L_Omega_lower(i, i) =  sqrt(1 - temp_sum_square);
     
   }
   
   
   //////////// (3) calculate correlation matrix 
   Eigen::Matrix<stan::math::var, -1, -1  > Omega = L_Omega_lower * L_Omega_lower.transpose();
   
   for (int i = 0; i < dim; ++i) {
     Omega(i,i) = 1;
   }
   
   //////////////////// calculate Jacobian adjustment
   // make vector of unconstrained params
   Eigen::Matrix< stan::math::var, -1, 1  > Omega_y_vec(dim, dim) ; // =   Omega_Z_vec;
   Eigen::Matrix< stan::math::var, -1, 1  > jac_vec(dim, dim) ; //  =   Omega_Z_vec;
   
   for (int i = 0; i < Omega_Z_vec.rows(); ++i) {
     Omega_y_vec(i) = 0.5 * log( (1 + Omega_Z_vec(i)) / (1 - Omega_Z_vec(i)) );  // undo tanh transform
     jac_vec(i) = log( ( exp( Omega_y_vec(i) ) +  exp( - Omega_y_vec(i) ) ) / 2 ); // cosh(y)
   }
   
   
   stan::math::var term_1 =   -2 * jac_vec.sum();
   
   
   Eigen::Matrix< stan::math::var, -1, -1  > jac_mtx = mat_out_test_var(dim, dim);
   
   
   
   stan::math::var log_det_jacobian = term_1 + term_2;
   
   ////////// outputs
   
   std::vector<Eigen::Matrix<stan::math::var, -1, -1  > > out = vec_of_mats_test_var(dim, dim, 6) ;
   
   out[0] = L_Omega_lower;
   out[1] = Omega;
   out[2] = Omega_Z;
   out[3](0,0) = log_det_jacobian;
   out[4] = sqrt_term;
   out[5] =  term_inv;
   
   return(out);
   
 }
 
 
 
 
 
 
 
 
 
 // [[Rcpp::export]]
 double phi_sq_sum(Eigen::Matrix<double, -1, -1>  phi) {
   
   Eigen::Matrix<double, -1, 1> phi_sq(phi.rows(), 1);
   
   double M_inv_x_phi_sq_sum;
   Eigen::Matrix<double, -1, 1> M_inv_x_phi_sq;
   
   for (int k = 0; k < phi.rows(); ++k) {
     phi_sq(k,0) = phi(k,0) * phi(k,0);
   }
   
   M_inv_x_phi_sq =  phi_sq;
   
   M_inv_x_phi_sq_sum = M_inv_x_phi_sq.sum();
   
   return(M_inv_x_phi_sq_sum);
   
 }
 
 
 // [[Rcpp::export]]
 double phi_sq_x_M_inv_sum(Eigen::Matrix<double, -1, -1>  phi,
                           Eigen::Matrix<double, -1, -1>  M_inv) {
   
   
   double M_inv_x_phi_sq_sum;
   Eigen::Matrix<double, -1, -1> M_inv_x_phi_sq_sum_mat;
   
   M_inv_x_phi_sq_sum_mat = phi.transpose() * M_inv * phi;
   
   M_inv_x_phi_sq_sum = M_inv_x_phi_sq_sum_mat(0,0);
   
   return(M_inv_x_phi_sq_sum);
   
 }
 
 
 
 
 
 // for general Phi both overflow and underflow of concern
 stan::math::var Phi_approx_underflow_overflow(stan::math::var x)  {     
   
   if ((x >= -5) || (x <= 5)) { 
     return((stan::math::Phi_approx(x)));
   } else if (x < - 5)  { 
     return(exp(-0.5 * x * x - 4.8 + 2509 * ( (x-13)/((x-40)*(x-40)*(x-5)) )));
   } else { 
     return((0.5 * (1 + stan::math::sqrt(1 - stan::math::exp(-2*x*x/3.14159265359)))));
   }
   
 }
 
 // for log(Phi), UNDERFLOW is concern so use stable approx for x < -5
 stan::math::var log_Phi_approx(stan::math::var x)  {     
   
   if ((x > -5)) { 
     return(stan::math::log(stan::math::Phi_approx(x)));
   } else  { 
     return((-0.5 * x * x - 4.8 + 2509 * ( (x-13)/((x-40)*(x-40)*(x-5)) )));
   } 
   
 }
 
 // for log1m, OVERFLOW of Phi is concern so use stable approx for x > 5
 stan::math::var log_1m_Phi_approx(stan::math::var x)  {     
   
   
   if (x < 5) { 
     return(stan::math::log1m(stan::math::Phi_approx(x)));
   } else { 
     return(stan::math::log1m(0.5 * (1 + stan::math::sqrt(1 - stan::math::exp(-2*x*x/3.14159265359)))));
   }
   
   
 }
 
 
 
 
 
 
 
 stan::math::var    fn_log_1m_Phi_var(    stan::math::var x    ) {
   
   
   
   if (x < 5) { // low x not an issue for log(1 - Phi(x)) [goes to 0]
     stan::math::var y = stan::math::log1m(stan::math::Phi(x));
     return(y);
   } else { 
     stan::math::var y = - stan::math::log(x + sqrt(x*x + 2)) - 0.5 * stan::math::log(M_PI/2) - 0.5*x*x;
     return(y);
   }
   
 }
 
 
 stan::math::var    fn_log_Phi_var(    stan::math::var x    ) {
   
   
   
   if (x > -37) { // high x not an issue for log(Phi(x)) [ goes to 0]
     stan::math::var y = stan::math::log(stan::math::Phi(x));
     return(y);
   } else { 
     x = stan::math::fabs(x);
     stan::math::var y = - stan::math::log(x + sqrt(x*x + 2)) - 0.5 * stan::math::log(M_PI/2) - 0.5*x*x;
     return(y);
   }
   
 }
 
 stan::math::var    fn_log_Phi_diff_var(    stan::math::var x1, 
                                            stan::math::var x2) {
   
   
   
   if ((x1 < 5) || (x2 < 5)) { 
     stan::math::var y = stan::math::log(stan::math::Phi(x1) - stan::math::Phi(x2));
     return(y);
   } else { 
     stan::math::var y =  stan::math::log(-stan::math::exp(fn_log_1m_Phi_var(x2)) + stan::math::exp(fn_log_1m_Phi_var(x1)));
     return(y);
   }
   
 }
 
 
 // [[Rcpp::export]]
 double    fn_log_1m_Phi_double(   double x    ) {
   
   
   
   if (x < 5) { // low x not an issue for log(1 - Phi(x)) [goes to 0]
     // double y = stan::math::log1m(stan::math::Phi(x));
     double y = R::pnorm(x, 0, 1, false, true); 
     return(y);
   } else { 
     double y = - stan::math::log(x + sqrt(x*x + 2)) - 0.5 * stan::math::log(M_PI/2) - 0.5*x*x;
     return(y);
   }
   
 }
 
 Eigen::Matrix<double, -1, 1>     fn_log_1m_Phi_double_vec(   Eigen::Matrix<double, -1, 1>  x    ) {
   
   int N = x.rows();
   
   Eigen::Matrix<double, -1, 1> y   = stan::math::log1m(stan::math::Phi(x)); // apply standard Phi first
   
   for (int n = 0; n < N; ++n ) {
     if (x(n) > 5) { // low x not an issue for log(1 - Phi(x)) [goes to 0]
       double x_sq = x(n) * x(n);
       y(n) = - stan::math::log(x(n) + sqrt(x_sq + 2)) - 0.5 * stan::math::log(M_PI/2) - 0.5*x_sq;
     }
   }
   
   return(y);
   
 }
 
 // [[Rcpp::export]]
 double    fn_log_Phi_double(    double x    ) {
   
   
   
   if (x > -37) { // high x not an issue for log(Phi(x)) [ goes to 0]
     // double y = stan::math::log(stan::math::Phi(x));
     double y = R::pnorm(x, 0, 1, true, true); 
     return(y);
   } else { 
     x = stan::math::fabs(x);
     double y = - stan::math::log(x + sqrt(x*x + 2)) - 0.5 * stan::math::log(M_PI/2) - 0.5*x*x;
     return(y);
   }
   
 }
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1>     fn_log_Phi_double_vec(    Eigen::Matrix<double, -1, 1> x    ) {
   
   
   int N = x.rows();
   
   Eigen::Matrix<double, -1, 1> y   = stan::math::log(stan::math::Phi(x)); // apply standard Phi first
   
   for (int n = 0; n < N; ++n ) {
     if (x(n) < -37) { // high x not an issue for log(Phi(x)) [ goes to 0 ]
       x(n) = stan::math::fabs(x(n));
       double x_sq = x(n) * x(n);
       y(n) = - stan::math::log(x(n) + sqrt(x_sq + 2)) - 0.5 * stan::math::log(M_PI/2) - 0.5*x_sq;
     }
   }
   
   return(y);
   
 }
 
 
 
 
 
 
 
 
 Eigen::Matrix<double, 1, -1>     fn_first_element_neg_rest_pos(   
     Eigen::Matrix<double, 1, -1>  row_vec 
 ) {
   
   row_vec(0) = - row_vec(0);
   
   return(row_vec);
   
 }
 
 
 Eigen::Matrix<float, 1, -1>     fn_first_element_neg_rest_pos_float(   
     Eigen::Matrix<float, 1, -1>  row_vec 
 ) {
   
   row_vec(0) = - row_vec(0);
   
   return(row_vec);
   
 }
 
 
 
 
 Eigen::Matrix<stan::math::var, 1, -1>     fn_first_element_neg_rest_pos_var(   
     Eigen::Matrix<stan::math::var, 1, -1>  row_vec 
 ) {
   
   row_vec(0) = - row_vec(0);
   
   return(row_vec);
   
 }
 
 
 
 
 
 
//  
//  
//  
//  
//  
//  
//  
//  
//  
//  
//  // [[Rcpp::export]]
//  Eigen::Matrix<double, -1, -1  >   balance_matrix(  Eigen::Matrix<double, -1, -1  >  A
//                                                       
//  ) {
//    // https://arxiv.org/pdf/1401.5766.pdf (Algorithm #3)
//    const int p = 2;
//    double beta = 2; // Radix base (2?)
//    
//    Eigen::Matrix<double, -1, -1  >  Aprime = A; 
//    Eigen::Matrix<double, -1, -1  >   D = Eigen::Matrix<double, -1, -1  >::Identity(A.rows(), A.cols());
//  
//    bool converged = false;
//    do {
//      converged = true;
//      for (int i = 0; i < A.rows(); ++i) {
//        double c = Aprime.col(i).lpNorm<p>();
//        double r = Aprime.row(i).lpNorm<p>();
//        double s = pow(c, p) + pow(r, p);
//        double f = 1;
//        while (c < r / beta) {
//          c *= beta;
//          r /= beta;
//          f *= beta;
//        }
//        while (c >= r*beta) {
//          c /= beta;
//          r *= beta;
//          f /= beta;
//        }
//        if (pow(c, p) + pow(r, p) < 0.95*s) {
//          converged = false;
//          D(i, i) *= f;
//          Aprime.col(i) *= f;
//          Aprime.row(i) /= f;
//        }
//      }
//    } while (!converged);
//    
//    return(Aprime); 
//    
//  }
// 
// 
// 
// 
// 
// 
// //  
// 
// 
// // [[Rcpp::export]]
// Eigen::Matrix<double, -1, -1  >  Rcpp_elimination_matrix_E_diag(int dim) {
//   
//   
//   Eigen::Matrix<double, -1, -1> out_elimination_matrix_E_diag   =  Eigen::Matrix<double, -1, -1>::Zero(dim, dim * dim) ; 
//   
//   out_elimination_matrix_E_diag(0, 0) = 1; 
//   
//   int gap = 0;
//   int second_index = (dim + 2) - 1; 
//   
//   for (int i = 1; i < dim; ++i) {
//     out_elimination_matrix_E_diag(i,  second_index + gap)  = 1; 
//     gap =  gap + dim + 1;
//   }
//   
//   return(out_elimination_matrix_E_diag); 
//   
// }
// 
// 
// 
// 
// 
// 
// // [[Rcpp::export]]
// Eigen::Matrix<double, -1, -1  >  Rcpp_elimination_matrix_E_lower(int dim) {
//   
//   
//   Eigen::Matrix<double, -1, -1> out_elimination_matrix_E_lower   =  Eigen::Matrix<double, -1, -1>::Zero(0.5 * dim * (dim-1), dim * dim) ; 
//   
//   int gap = 0;
//   int length_ones = 4;
//   int skip_seq_length = 2;
//   int second_index = 2;
//   
//   Eigen::Matrix<int, -1, 1> skip_seq(dim);  
//   
//   skip_seq(0) =  (second_index + dim - gap - 1);
//   skip_seq(1) =  skip_seq(0) + 1;
//   
//   
//   
//   int start_index = skip_seq(0) - length_ones;
//   
//   for (int i = 0; i < ( 0.5 * dim * (dim-1)); ++i) {
//     
//     if  (  (  (second_index + gap) <   skip_seq(0) ) || (  (second_index + gap) >   skip_seq(skip_seq_length - 1) )  )     {
//       out_elimination_matrix_E_lower(i, second_index + gap - 1) = 1; 
//     }
//     
//     
//     if ((second_index + gap) == (skip_seq(0) - 1))  {
//       second_index =  skip_seq.segment(skip_seq_length - 1, 1).eval()(0, 0); //  tail(skip_seq, 1)   
//       gap  += 1;
//       skip_seq_length += 1;
//       skip_seq(0) =  (second_index + dim - gap);
//       for (int j = 1; j < skip_seq_length; ++j)   skip_seq(j) =  skip_seq(j - 1) + 1;      // skip_seq =  (second_index + dim - gap   ):(second_index + dim + 1) ;   
//       length_ones  =  length_ones - 1; 
//       start_index =  skip_seq(0) - length_ones ; 
//       second_index = start_index - gap;
//     } else { 
//       second_index  += 1;   
//     }
//     
//     
//   }
//   
//   
//   return(out_elimination_matrix_E_lower); 
//   
// }
// 
// 
// 
// 
// // [[Rcpp::export]]
// Eigen::Matrix<double, -1, -1  >  Rcpp_elimination_matrix_E_upper(int dim) {
//   
//   
//   int n_choose_2 = dim * (dim - 1) * 0.5 ; 
//   
//   Eigen::Matrix<double, -1, -1> out_elimination_matrix_E_upper  =  Eigen::Matrix<double, -1, -1>::Zero(n_choose_2, dim * dim) ; 
//  
//   
//   int mat_col_num_elements_counter = dim - 1; 
//   int i_for_given_col = 1; 
//   int mat_col_num = 1; 
//   int condition_counter = 1; 
//   
//   
//   
//   Eigen::Matrix<int, -1, 1> mat_seq_for_given_col(dim - 1);  
//   
//   mat_seq_for_given_col(0) =  dim + 1;
//   for (int i = 1; i < dim - 1; ++i)   mat_seq_for_given_col(i) = mat_seq_for_given_col(i-1) + dim; 
//   
//   Eigen::Matrix<int, -1, 1> mat_seq_for_given_col_old = mat_seq_for_given_col; 
//  
//   
//   for (int i = 0; i < n_choose_2; ++i) {
//     
//     out_elimination_matrix_E_upper(i, mat_seq_for_given_col(i_for_given_col - 1) - 1) = 1;
//     
//     
//     if (i_for_given_col == mat_col_num_elements_counter) { 
//       
//       mat_col_num = 2;
//       i_for_given_col = 0;      
//       mat_col_num_elements_counter -= 1; 
//       mat_seq_for_given_col_old = mat_seq_for_given_col; 
//       
//       mat_seq_for_given_col(0) = mat_seq_for_given_col_old(mat_col_num - 1) + 1;
//       if (mat_col_num_elements_counter > 1) for (int j = 1; j < (mat_col_num_elements_counter-1) + 1; ++j)  mat_seq_for_given_col(j) = mat_seq_for_given_col(j-1) + dim ; 
//         condition_counter += 1;
//     }
//     
//     i_for_given_col += 1; 
//     
//     if (condition_counter == dim) break ; 
//       
//   }
//   
//   
//   return(out_elimination_matrix_E_upper); 
//   
// }
// 
// 
// 
// 
// 
// 
// 
// // [[Rcpp::export]]
// Eigen::Matrix<double, -1, -1  >  Rcpp_rearrange_mat_indexes( Eigen::Matrix<double, -1, -1>  mat, 
//                                                             int dim
// ) {
//   
//   
//   int n_choose_2 = dim * (dim - 1) * 0.5 ; 
//   
//   Eigen::Matrix<double, -1, 1> index_mapping_mat  =  Eigen::Matrix<double, -1, 1>::Zero(n_choose_2) ; 
//   
//   
//   int mat_col_num_elements_counter = 2;
//   int i_for_given_col = 1; 
//   int condition_counter = 1; 
//   
//   
//   
//   Eigen::Matrix<int, -1, 1> mat_seq_for_given_col(dim - 1);  
//   
//   mat_seq_for_given_col(0) =  2; 
//   mat_seq_for_given_col(1) =  dim; 
//   
//   Eigen::Matrix<int, -1, 1> mat_seq_for_given_col_old = mat_seq_for_given_col; 
//   
//   index_mapping_mat(0) = 1; 
//   
//   for (int i = 1; i < n_choose_2; ++i) {
//     
//     index_mapping_mat(i) = mat_seq_for_given_col(i_for_given_col - 1);
//     
//     
//     if (i_for_given_col == mat_col_num_elements_counter) { 
//       
//  
//           i_for_given_col = 0;      
//           mat_col_num_elements_counter += 1; 
//           
//           mat_seq_for_given_col_old = mat_seq_for_given_col; 
//           
//           mat_seq_for_given_col(0) = mat_seq_for_given_col_old(0) + 1;
//           int jj = mat_seq_for_given_col(0);
//           int jump = 3;
//           
//           for (int j = 1; j < (mat_col_num_elements_counter-1) + 1; ++j) {
//                 jj += jump;
//                 mat_seq_for_given_col(j) = jj; 
//                 jump -= 1;
//           }
//           
//           condition_counter += 1;
//       
//     }
//     
//     i_for_given_col += 1; 
//     
//     if (condition_counter == dim) break ; 
//     
//   }
//   
//   
//   
//   Eigen::Matrix<double, -1, -1>  out_mat_rearranged =  Eigen::Matrix<double, -1, -1>::Zero(n_choose_2, n_choose_2);
// 
//   for (int i = 0; i < n_choose_2; ++i) {
//     for (int j = 0; j < n_choose_2; ++j) {
//       out_mat_rearranged(i, j) = mat(index_mapping_mat(i) - 1, index_mapping_mat(j) - 1);
//     }
//   }
//   
//   
//   
//   return(out_mat_rearranged); 
//   
// }
// 
//  
//  
//  
//  
//  // Function translated from Sean Pinkney's Stan function on GitHub - Archakov Omega parameterisation
//  
//  // [[Rcpp::export]]
//  Eigen::Matrix<double, -1, -1  > corr_constrain_Archakov_Spinkney_double( Eigen::Matrix<double, -1, -1> gamma_in_matrix, 
//                                                          int dim, 
//                                                          double tol
// ) {
//    
//    Eigen::Matrix<double, -1, -1> C   =  Eigen::Matrix<double, -1, -1>::Zero(dim,  dim); 
//    Eigen::Matrix<double, -1, -1> A   =  Eigen::Matrix<double, -1, -1>::Zero(dim,  dim); 
//    Eigen::Matrix<double, -1, 1> diag_vec   =  Eigen::Matrix<double, -1, 1>::Zero(dim); 
//    double dist = sqrt(dim); 
//    
//    
//   //  gamma_in_matrix = balance_matrix(gamma_in_matrix); 
//      
//    // Place elements from gamma into off-diagonal parts   and put zeros on the main diagonal of nxn symmetric matrix A
//    
//    for (int i = 0; i < dim; ++i) {
//      A(i, i) = 0;
//    }
// 
//    for (int i = 1; i < (dim); ++i)  {
//      for (int j = 0; j < i; ++j) { // equiv to 1 to K - 2 in 
//        A(i, j) = gamma_in_matrix(i, j); 
//        A(j, i) =   A(i, j) ; 
//      }
//    }
//   
//    A = balance_matrix(A); 
//      
//    Eigen::Matrix<double, -1, 1> A_eigen_values = stan::math::eigenvalues_sym(A);
//    Eigen::Matrix<double, -1, -1> A_eigen_vectors = stan::math::eigenvectors_sym(A);
//    
//    double sqrt_dim = sqrt(dim);
//    
//    Eigen::Matrix<double, -1, 1> diag_delta   =   stan::math::log(stan::math::diagonal(stan::math::abs(C))); 
//    
//    while (dist > (sqrt_dim * tol) ) {
//      
//           A_eigen_values = stan::math::eigenvalues_sym(A);
//           A_eigen_vectors = stan::math::eigenvectors_sym(A);
//          
//           C = stan::math::diag_post_multiply(A_eigen_vectors, stan::math::exp(A_eigen_values)) * A_eigen_vectors.transpose();
//          
//           diag_delta   =   stan::math::log(stan::math::diagonal(stan::math::abs(C)));  
//           diag_vec -= diag_delta;
//           A = stan::math::add_diag(A, - stan::math::diagonal(A) + diag_vec);
//           A = balance_matrix(A); 
//           dist = stan::math::norm2(diag_delta);
//      
//    }
//  
//    
//    for (int i = 0; i < dim; ++i) { 
//      C(i, i) = 1.0;
//    }
//    
//    ////// output log|J| and 
//     Eigen::Matrix<double, -1, -1> C_chol = stan::math::cholesky_decompose(C) ; 
//     
//     
//     //# -------------------------------------------------------------------------
//     //# -------------------------------------------------------------------------
//     C = balance_matrix(C); 
//     
//     Eigen::Matrix<double, -1, 1>  C_eigen_values = stan::math::eigenvalues_sym(C);
//     Eigen::Matrix<double, -1, -1> C_eigen_vectors = stan::math::eigenvectors_sym(C);
//     Eigen::Matrix<double, -1, -1> diag_eigen_vals_C = C_eigen_values.asDiagonal(); 
//     
//     Eigen::Matrix<double, -1, -1>  V = C_eigen_vectors;
//     Eigen::Matrix<double, -1, -1>  Lambda = diag_eigen_vals_C; 
//     
//     Eigen::Matrix<double, -1, -1>  R =  Eigen::Matrix<double, -1, -1>::Zero(dim,  dim); 
//     
//     for (int j = 0; j < dim ; ++j) {
//       for (int k = 0; k < dim; ++k) {
//         if (Lambda(j, j) != Lambda(k, k))    R(j, k)  = (log(stan::math::abs(Lambda(j, j))) - log(stan::math::abs(Lambda(k, k) )) ) / ( ((Lambda(j, j)) - Lambda(k, k)  ) ) ; 
//         else                                 R(j, k) =   (1 / Lambda(k, k)) ; 
//       } 
//     }
//     
//     //# now we can compute A_x
//     Eigen::Matrix<double, -1, -1>  V_kronecker_V = Eigen::kroneckerProduct(V, V) ; 
//     Eigen::Matrix<double, -1, -1>  V_kronecker_V_transpose = (V_kronecker_V).transpose() ; 
//     
//     Eigen::Matrix<double, -1, 1>  Vec_R =  Eigen::Matrix<double, -1, 1>::Zero(dim*dim); 
//     
//     int counter = 0;
//     for (int j = 0; j < dim ; ++j) {
//       for (int i = 0; i < dim ; ++i) {
//         Vec_R(counter) = R(i, j) ; 
//         counter +=1;
//       }
//     }
//     
//     Eigen::Matrix<double, -1, -1> A_x =  (V_kronecker_V  *  Vec_R.asDiagonal() *  V_kronecker_V_transpose).inverse() ; 
//     
//     //# Now, since we have the Jacobian of log(C) - A - we can compute the final Jacobian
//     Eigen::Matrix<double, -1, -1> E_d = Rcpp_elimination_matrix_E_diag(dim);
//     Eigen::Matrix<double, -1, -1> E_l = Rcpp_elimination_matrix_E_lower(dim);
//     Eigen::Matrix<double, -1, -1> E_u = Rcpp_elimination_matrix_E_upper(dim);
//     Eigen::Matrix<double, -1, -1> identity_dim_squared = Eigen::Matrix<double, -1, -1>::Identity(dim*dim,  dim*dim);
//     
//     Eigen::Matrix<double, -1, -1>  inner_inner_mat =  (E_d * A_x * (E_d).transpose() ).inverse() ; 
//     Eigen::Matrix<double, -1, -1>  inner_mat =  A_x * (E_d).transpose() *  inner_inner_mat *  E_d ; 
//     
//     Eigen::Matrix<double, -1, -1>  Jacobian = E_u *  (identity_dim_squared - inner_mat) * A_x * (E_u + E_l).transpose() ; 
//     
//     
//     ////// output log|J|  and J  
//     Eigen::Matrix<double, -1, -1> out_mat   =  Eigen::Matrix<double, -1, -1>::Zero(dim + 10  + 0.5 *  dim * (dim - 1) ,  0.5 *  dim * (dim - 1) ); 
//     
//     double log_abs_jac = stan::math::log_determinant(Jacobian) ; 
//     
//     
//     out_mat(0, 0) = log_abs_jac;
//     out_mat.block(1, 0, dim, dim) = C_chol;
//     out_mat.block(1 + dim, 0, 0.5 *  dim * (dim - 1), 0.5 *  dim * (dim - 1)) = Rcpp_rearrange_mat_indexes(Jacobian, dim) ; 
//     out_mat.block(1 + dim + 0.5 *  dim * (dim - 1), 0, dim, dim )  = A; 
//     
//    
//    return(out_mat); 
//    
//  }
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// // [[Rcpp::export]]
// Rcpp::List corr_constrain_Archakov_Spinkney_double_list_out( Eigen::Matrix<double, -1, -1> gamma_in_matrix, 
//                                                              int dim, 
//                                                              double tol
// ) {
//   
//   Eigen::Matrix<double, -1, -1> C   =  Eigen::Matrix<double, -1, -1>::Zero(dim,  dim); 
//   Eigen::Matrix<double, -1, -1> A   =  Eigen::Matrix<double, -1, -1>::Zero(dim,  dim); 
//   Eigen::Matrix<double, -1, 1> diag_vec   =  Eigen::Matrix<double, -1, 1>::Zero(dim); 
//   double dist = sqrt(dim); 
//   
//   
//   //  gamma_in_matrix = balance_matrix(gamma_in_matrix); 
//   
//   // Place elements from gamma into off-diagonal parts   and put zeros on the main diagonal of nxn symmetric matrix A
//   
//   for (int i = 0; i < dim; ++i) {
//     A(i, i) = 0;
//   }
//   
//   for (int i = 1; i < (dim ); ++i)  {
//     for (int j = 0; j < i; ++j) { // equiv to 1 to K - 2 in 
//       A(i, j) = gamma_in_matrix(i, j); 
//       A(j, i) =   A(i, j) ; 
//     }
//   }
//   
//    A = balance_matrix(A); 
//   
//   Eigen::Matrix<double, -1, 1> A_eigen_values = stan::math::eigenvalues_sym(A);
//   Eigen::Matrix<double, -1, -1> A_eigen_vectors = stan::math::eigenvectors_sym(A);
//   
//   double sqrt_dim = sqrt(dim);
//   
//   Eigen::Matrix<double, -1, 1> diag_delta   =    stan::math::log(stan::math::diagonal(stan::math::abs(C))); 
//   
//   while (dist > (sqrt_dim * tol) ) {
//     
//     A_eigen_values = stan::math::eigenvalues_sym(A);
//     A_eigen_vectors = stan::math::eigenvectors_sym(A);
//     
//     C = stan::math::diag_post_multiply(A_eigen_vectors, stan::math::exp(A_eigen_values)) * A_eigen_vectors.transpose(); // C = expm(A)
//     
//     diag_delta   =   stan::math::log(stan::math::diagonal(stan::math::abs(C))); 
//     diag_vec -= diag_delta;
//     A = stan::math::add_diag(A, - stan::math::diagonal(A) + diag_vec); // updat diagonal of A
//     A = balance_matrix(A); 
//     dist = stan::math::norm2(diag_delta);
//     
//   }
// 
//   
//   for (int i = 0; i < dim; ++i) { 
//     C(i, i) = 1.0;
//   }
//   
//   ////// output log|J|   
//   Eigen::Matrix<double, -1, -1> C_chol = stan::math::cholesky_decompose(C) ; 
//   
//   
//   //# -------------------------------------------------------------------------
//   //# -------------------------------------------------------------------------
//   C = balance_matrix(C); 
//   
//   Eigen::Matrix<double, -1, 1>  C_eigen_values = stan::math::eigenvalues_sym(C);
//   Eigen::Matrix<double, -1, -1> C_eigen_vectors = stan::math::eigenvectors_sym(C);
//   Eigen::Matrix<double, -1, -1> diag_eigen_vals_C = C_eigen_values.asDiagonal(); 
//   
//   Eigen::Matrix<double, -1, -1>  V = C_eigen_vectors;
//   Eigen::Matrix<double, -1, -1>  Lambda = diag_eigen_vals_C; 
//   
//   Eigen::Matrix<double, -1, -1>  R =  Eigen::Matrix<double, -1, -1>::Zero(dim,  dim); 
//   
//   for (int j = 0; j < dim ; ++j) {
//     for (int k = 0; k < dim; ++k) {
//       if (Lambda(j, j) != Lambda(k, k))    R(j, k)  = (log(stan::math::abs(Lambda(j, j))) - log(stan::math::abs(Lambda(k, k) )) ) / ( ((Lambda(j, j)) - Lambda(k, k)  ) ) ; 
//       else                                 R(j, k) =   (1 / Lambda(k, k)) ; 
//     } 
//   }
//   
//   //# now we can compute A_x
//   Eigen::Matrix<double, -1, -1>  V_kronecker_V = Eigen::kroneckerProduct(V, V) ; 
//   Eigen::Matrix<double, -1, -1>  V_kronecker_V_transpose = (V_kronecker_V).transpose() ; 
//   
//   Eigen::Matrix<double, -1, 1>  Vec_R =  Eigen::Matrix<double, -1, 1>::Zero(dim*dim); 
//   
//   int counter = 0;
//   for (int j = 0; j < dim ; ++j) {
//     for (int i = 0; i < dim ; ++i) {
//         Vec_R(counter) = R(i, j) ; 
//         counter +=1;
//     }
//   }
//     
//   Eigen::Matrix<double, -1, -1> A_x =  (V_kronecker_V  *  Vec_R.asDiagonal() *  V_kronecker_V_transpose).inverse() ; 
//   
//   //# Now, since we have the Jacobian of log(C) - A - we can compute the final Jacobian
//   Eigen::Matrix<double, -1, -1> E_d = Rcpp_elimination_matrix_E_diag(dim);
//   Eigen::Matrix<double, -1, -1> E_l = Rcpp_elimination_matrix_E_lower(dim);
//   Eigen::Matrix<double, -1, -1> E_u = Rcpp_elimination_matrix_E_upper(dim);
//   Eigen::Matrix<double, -1, -1> identity_dim_squared = Eigen::Matrix<double, -1, -1>::Identity(dim*dim,  dim*dim);
//   
//   Eigen::Matrix<double, -1, -1>  inner_inner_mat =  (E_d * A_x * (E_d).transpose() ).inverse() ; 
//   Eigen::Matrix<double, -1, -1>  inner_mat =  A_x * (E_d).transpose() *  inner_inner_mat *  E_d ; 
//   
// //  Eigen::Matrix<double, -1, -1>  Jacobian_d_rho_d_gamma = E_u *  (identity_dim_squared - inner_mat) * A_x * (E_u + E_l).transpose() ; 
// //  Jacobian_d_rho_d_gamma = Rcpp_rearrange_mat_indexes(Jacobian_d_rho_d_gamma, dim); 
// 
//   Eigen::Matrix<double, -1, -1>  Jacobian_d_rho_d_gamma = E_l *  (identity_dim_squared - inner_mat) * A_x * (E_u + E_l).transpose() ; 
//   
// 
//     
//   double log_abs_jac = stan::math::log_determinant(Jacobian_d_rho_d_gamma) ; 
//   // # -------------------------------------------------------------------------
//   // # -------------------------------------------------------------------------
//   ////// output log|J|  and J  
//   // Eigen::Matrix<double, -1, -1> out_mat   =  Eigen::Matrix<double, -1, -1>::Zero(dim + 10  + 0.5 *  dim * (dim - 1) ,  0.5 *  dim * (dim - 1) ); 
//   
//   Rcpp::List out_list(20); 
//   
//   out_list(0) = log_abs_jac;
//   out_list(1) = C;
//   out_list(2) = Jacobian_d_rho_d_gamma;
//   out_list(3) = A;  
//   out_list(4) = A_eigen_values;  
//   out_list(5) = A_eigen_vectors;
//   out_list(6) = diag_delta;
//   out_list(7) = diag_vec;
//   out_list(8) = A_x;
//   out_list(9) = R;
//   //  out_list(10) = Epsilon_mat;
//   
//   return(out_list); 
//   
// }
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
//  
//  
//  Eigen::Matrix<stan::math::var, -1, -1  >   balance_matrix_var(  Eigen::Matrix<stan::math::var, -1, -1  >  A
//                                                       
//  ) {
//    // https://arxiv.org/pdf/1401.5766.pdf (Algorithm #3)
//    const int p = 2;
//    stan::math::var beta = 2.0; // Radix base (2?)
//    
//    Eigen::Matrix<stan::math::var, -1, -1  >  Aprime = A; 
//    Eigen::Matrix<stan::math::var, -1, -1  >  D = Eigen::Matrix<stan::math::var, -1, -1  >::Identity(A.rows(), A.cols());
//    
//    bool converged = false;
//    do {
//      converged = true;
//      for (int i = 0; i < A.rows(); ++i) {
//        stan::math::var c = Aprime.col(i).lpNorm<p>();
//        stan::math::var r = Aprime.row(i).lpNorm<p>();
//        stan::math::var s = pow(c, p) + pow(r, p);
//        stan::math::var f = 1.0;
//        while (c < r / beta) {
//          c *= beta;
//          r /= beta;
//          f *= beta;
//        }
//        while (c >= r*beta) {
//          c /= beta;
//          r *= beta;
//          f /= beta;
//        }
//        if (pow(c, p) + pow(r, p) < 0.95*s) {
//          converged = false;
//          D(i, i) *= f;
//          Aprime.col(i) *= f;
//          Aprime.row(i) /= f;
//        }
//      }
//    } while (!converged);
//    
//    return(Aprime); 
//    
//  }
// 
// 
// 
// 
// 
// 
// 
// //  
// Eigen::Matrix<stan::math::var, -1, -1  >  Rcpp_elimination_matrix_E_diag_var(int dim) {
// 
// 
//   Eigen::Matrix<stan::math::var, -1, -1> out_elimination_matrix_E_diag   =  Eigen::Matrix<stan::math::var, -1, -1>::Zero(dim, dim * dim) ;
// 
//   out_elimination_matrix_E_diag(0, 0) = 1;
// 
//   int gap = 0;
//   int second_index = (dim + 2) - 1;
// 
//   for (int i = 1; i < dim; ++i) {
//     out_elimination_matrix_E_diag(i,  second_index + gap)  = 1;
//     gap =  gap + dim + 1;
//   }
// 
//   return(out_elimination_matrix_E_diag);
// 
// }
// 
// 
// 
// 
// 
// 
// 
// Eigen::Matrix<stan::math::var, -1, -1  >  Rcpp_elimination_matrix_E_lower_var(int dim) {
// 
// 
//   Eigen::Matrix<stan::math::var, -1, -1> out_elimination_matrix_E_lower   =  Eigen::Matrix<stan::math::var, -1, -1>::Zero(0.5 * dim * (dim-1), dim * dim) ;
// 
//   int gap = 0;
//   int length_ones = 4;
//   int skip_seq_length = 2;
//   int second_index = 2;
// 
//   Eigen::Matrix<int, -1, 1> skip_seq(dim);
// 
//   skip_seq(0) =  (second_index + dim - gap - 1);
//   skip_seq(1) =  skip_seq(0) + 1;
// 
// 
// 
//   int start_index = skip_seq(0) - length_ones;
// 
//   for (int i = 0; i < ( 0.5 * dim * (dim-1)); ++i) {
// 
//     if  (  (  (second_index + gap) <   skip_seq(0) ) || (  (second_index + gap) >   skip_seq(skip_seq_length - 1) )  )     {
//       out_elimination_matrix_E_lower(i, second_index + gap - 1) = 1;
//     }
// 
// 
//     if ((second_index + gap) == (skip_seq(0) - 1))  {
//       second_index =  skip_seq.segment(skip_seq_length - 1, 1).eval()(0, 0); //  tail(skip_seq, 1)
//       gap  += 1;
//       skip_seq_length += 1;
//       skip_seq(0) =  (second_index + dim - gap);
//       for (int j = 1; j < skip_seq_length; ++j)   skip_seq(j) =  skip_seq(j - 1) + 1;      // skip_seq =  (second_index + dim - gap   ):(second_index + dim + 1) ;
//       length_ones  =  length_ones - 1;
//       start_index =  skip_seq(0) - length_ones ;
//       second_index = start_index - gap;
//     } else {
//       second_index  += 1;
//     }
// 
// 
//   }
// 
// 
//   return(out_elimination_matrix_E_lower);
// 
// }
// 
// 
// 
// 
// 
// 
// 
// Eigen::Matrix<stan::math::var, -1, -1  >  Rcpp_elimination_matrix_E_upper_var(int dim) {
// 
// 
//   int n_choose_2 = dim * (dim - 1) * 0.5 ;
// 
//   Eigen::Matrix<stan::math::var, -1, -1> out_elimination_matrix_E_upper  =  Eigen::Matrix<stan::math::var, -1, -1>::Zero(n_choose_2, dim * dim) ;
// 
// 
//   int mat_col_num_elements_counter = dim - 1;
//   int i_for_given_col = 1;
//   int mat_col_num = 1;
//   int condition_counter = 1;
// 
// 
// 
//   Eigen::Matrix<int, -1, 1> mat_seq_for_given_col(dim - 1);
// 
//   mat_seq_for_given_col(0) =  dim + 1;
//   for (int i = 1; i < dim - 1; ++i)   mat_seq_for_given_col(i) = mat_seq_for_given_col(i-1) + dim;
// 
//   Eigen::Matrix<int, -1, 1> mat_seq_for_given_col_old = mat_seq_for_given_col;
// 
// 
//   for (int i = 0; i < n_choose_2; ++i) {
// 
//     out_elimination_matrix_E_upper(i, mat_seq_for_given_col(i_for_given_col - 1) - 1) = 1;
// 
// 
//     if (i_for_given_col == mat_col_num_elements_counter) {
// 
//       mat_col_num = 2;
//       i_for_given_col = 0;
//       mat_col_num_elements_counter -= 1;
//       mat_seq_for_given_col_old = mat_seq_for_given_col;
// 
//       mat_seq_for_given_col(0) = mat_seq_for_given_col_old(mat_col_num - 1) + 1;
//       if (mat_col_num_elements_counter > 1) for (int j = 1; j < (mat_col_num_elements_counter-1) + 1; ++j)  mat_seq_for_given_col(j) = mat_seq_for_given_col(j-1) + dim ;
//       condition_counter += 1;
//     }
// 
//     i_for_given_col += 1;
// 
//     if (condition_counter == dim) break ;
// 
//   }
// 
// 
//   return(out_elimination_matrix_E_upper);
// 
// }
//  
// 
// 
// 
//  
// Eigen::Matrix<stan::math::var, -1, -1  >  Rcpp_rearrange_mat_indexes_var( Eigen::Matrix<stan::math::var, -1, -1>  mat, 
//                                                              int dim
// ) {
//   
//   
//   int n_choose_2 = dim * (dim - 1) * 0.5 ; 
//   
//   Eigen::Matrix<int, -1, 1> index_mapping_mat  =  Eigen::Matrix<int, -1, 1>::Zero(n_choose_2) ; 
//   
//   
//   int mat_col_num_elements_counter = 2;
//   int i_for_given_col = 1; 
//   int condition_counter = 1; 
//   
//   
//   
//   Eigen::Matrix<int, -1, 1> mat_seq_for_given_col(dim - 1);  
//   
//   mat_seq_for_given_col(0) =  2; 
//   mat_seq_for_given_col(1) =  dim; 
//   
//   Eigen::Matrix<int, -1, 1> mat_seq_for_given_col_old = mat_seq_for_given_col; 
//   
//   index_mapping_mat(0) = 1; 
//   
//   for (int i = 1; i < n_choose_2; ++i) {
//     
//     index_mapping_mat(i) = mat_seq_for_given_col(i_for_given_col - 1);
//     
//     
//     if (i_for_given_col == mat_col_num_elements_counter) { 
//       
//       
//       i_for_given_col = 0;      
//       mat_col_num_elements_counter += 1; 
//       
//       mat_seq_for_given_col_old = mat_seq_for_given_col; 
//       
//       mat_seq_for_given_col(0) = mat_seq_for_given_col_old(0) + 1;
//       int jj = mat_seq_for_given_col(0);
//       int jump = 3;
//       
//       for (int j = 1; j < (mat_col_num_elements_counter-1) + 1; ++j) {
//         jj += jump;
//         mat_seq_for_given_col(j) = jj; 
//         jump -= 1;
//       }
//       
//       condition_counter += 1;
//       
//     }
//     
//     i_for_given_col += 1; 
//     
//     if (condition_counter == dim) break ; 
//     
//   }
//   
//   
//   
//   Eigen::Matrix<stan::math::var, -1, -1>  out_mat_rearranged =  Eigen::Matrix<stan::math::var, -1, -1>::Zero(n_choose_2, n_choose_2);
//   
//   for (int i = 0; i < n_choose_2; ++i) {
//     for (int j = 0; j < n_choose_2; ++j) {
//       out_mat_rearranged(i, j) = mat(index_mapping_mat(i) - 1, index_mapping_mat(j) - 1);
//     }
//   }
//   
//   
//   
//   return(out_mat_rearranged); 
//   
// }
// 
// 
//         
//         
//         
//         
// ////////////////////////////  var version of corr_constrain_Archakov_Spinkney_double
// Eigen::Matrix<stan::math::var, -1, -1>    corr_constrain_Archakov_Spinkney_var( Eigen::Matrix<stan::math::var, -1, -1> gamma_in_matrix,
//                                                                          int dim, 
//                                                                          double tol
// ) {
//   
//   Eigen::Matrix<stan::math::var, -1, -1> C   =  Eigen::Matrix<stan::math::var, -1, -1>::Zero(dim,  dim); 
//   Eigen::Matrix<stan::math::var, -1, -1> log_C   =  Eigen::Matrix<stan::math::var, -1, -1>::Zero(dim,  dim); 
//   Eigen::Matrix<stan::math::var, -1, 1> diag_vec   =  Eigen::Matrix<stan::math::var, -1, 1>::Zero(dim); 
//   stan::math::var dist = stan::math::sqrt(stan::math::to_var(dim)); 
//   
//  
//   for (int i = 0; i < dim; ++i) {
//     log_C(i, i) = 0;
//   }
//  
//   
//   // Place elements from gamma into off-diagonal parts
//   // and put zeros on the main diagonal of nxn symmetric matrix A
//  // int count = 0;
//  for (int i = 1; i < (dim); ++i)  {
//    for (int j = 0; j < i; ++j) { // equiv to 1 to K - 2 in R
//      log_C(i, j) = gamma_in_matrix(i, j); 
//      log_C(j, i) =   log_C(i, j) ; 
//    }
//  }
//  
//   
//   Eigen::Matrix<stan::math::var, -1, 1> A_eigen_values = stan::math::eigenvalues_sym(log_C);
//   Eigen::Matrix<stan::math::var, -1, -1> A_eigen_vectors = stan::math::eigenvectors_sym(log_C);
//   
//   stan::math::var  sqrt_dim = sqrt(dim);
//   
//   Eigen::Matrix<stan::math::var, -1, 1> diag_delta   =   stan::math::log(stan::math::abs(stan::math::diagonal(C))); 
//   
// //  log_C = balance_matrix_var(log_C); 
//   int iter = 0;
//   while (dist > sqrt_dim * tol) {
//           
//           C = stan::math::diag_post_multiply(A_eigen_vectors, stan::math::exp(A_eigen_values)) * A_eigen_vectors.transpose();
//           
//           diag_delta   =   stan::math::log(stan::math::abs(stan::math::diagonal(C))); 
//           diag_vec -= diag_delta;
//           log_C = stan::math::add_diag(log_C, - stan::math::diagonal(log_C) + diag_vec);
//           
//           //  log_C = balance_matrix_var(log_C);
//           A_eigen_values = stan::math::eigenvalues_sym(log_C);
//           A_eigen_vectors = stan::math::eigenvectors_sym(log_C);
//           
//          
//           dist = stan::math::norm2(diag_delta);
//           
//           iter += 1;
//           if (iter > 100) break; 
//   }
//   
//  
//   for (int i = 0; i < dim; ++i)      C(i, i) = 1.0;
//  
//  //# -------------------------------------------------------------------------
//  //# -------------------------------------------------------------------------
//  //  C = balance_matrix_var(C); 
//   
//  
//   Eigen::Matrix<stan::math::var, -1, -1> C_eigen_vectors = A_eigen_vectors ; // stan::math::eigenvectors_sym(C);
//   Eigen::Matrix<stan::math::var, -1, -1> diag_eigen_vals_C =  stan::math::exp(A_eigen_values).asDiagonal() ; // C_eigen_values.asDiagonal();
// 
//   Eigen::Matrix<stan::math::var, -1, -1>  V = C_eigen_vectors;  // C_eigen_vectors
//   Eigen::Matrix<stan::math::var, -1, -1>  Lambda =  diag_eigen_vals_C  ;  
// 
//   Eigen::Matrix<stan::math::var, -1, -1>  R =  Eigen::Matrix<stan::math::var, -1, -1>::Zero(dim,  dim);
// 
//   for (int j = 0; j < dim ; ++j) {
//     for (int k = 0; k < dim; ++k) {
//       if (Lambda(j, j) != Lambda(k, k))    R(j, k)  = (log(stan::math::abs(Lambda(j, j))) - log(stan::math::abs(Lambda(k, k) )) ) / ( ((Lambda(j, j)) - Lambda(k, k)  ) ) ;
//       else                                 R(j, k) =   (1 / Lambda(k, k)) ;
//     }
//   }
// 
//   //# now we can compute A_x
//   Eigen::Matrix<stan::math::var, -1, -1>  V_kronecker_V = Eigen::kroneckerProduct(V, V) ;
//   Eigen::Matrix<stan::math::var, -1, -1>  V_kronecker_V_transpose = (V_kronecker_V).transpose() ;
// 
//   Eigen::Matrix<stan::math::var, -1, 1>  Vec_R =  Eigen::Matrix<stan::math::var, -1, 1>::Zero(dim*dim);
// 
//   int counter = 0;
//   for (int j = 0; j < dim ; ++j) {
//     for (int i = 0; i < dim ; ++i) {
//       Vec_R(counter) = R(i, j) ;
//       counter +=1;
//     }
//   }
// 
//   // Eigen::Matrix<stan::math::var, -1, -1> A_x =  (V_kronecker_V  *  Vec_R.asDiagonal() *  V_kronecker_V_transpose).inverse() ;
// 
//   Eigen::Matrix<stan::math::var, -1, -1> A_x =  (V_kronecker_V  *  (1 / Vec_R.array()).matrix().asDiagonal() *  V_kronecker_V_transpose)  ;
//   
//   
//   
//   Eigen::Matrix<stan::math::var, -1, -1> E_d = stan::math::to_var(Rcpp_elimination_matrix_E_diag(dim));
//   Eigen::Matrix<stan::math::var, -1, -1> E_l = stan::math::to_var(Rcpp_elimination_matrix_E_lower(dim));
//   Eigen::Matrix<stan::math::var, -1, -1> E_u = stan::math::to_var(Rcpp_elimination_matrix_E_upper(dim));
//   Eigen::Matrix<stan::math::var, -1, -1> identity_dim_squared = Eigen::Matrix<stan::math::var, -1, -1>::Identity(dim*dim,  dim*dim);
// 
//   Eigen::Matrix<stan::math::var, -1, -1>  inner_inner_mat =  (E_d * A_x * (E_d).transpose() ).inverse() ;
//   Eigen::Matrix<stan::math::var, -1, -1>  inner_mat =  A_x * (E_d).transpose() *  inner_inner_mat *  E_d ;
// 
//    Eigen::Matrix<stan::math::var, -1, -1>  Jacobian = E_u *  (identity_dim_squared - inner_mat) * A_x * (E_u + E_l).transpose() ;
//  // Eigen::Matrix<stan::math::var, -1, -1>  Jacobian = E_l *  (identity_dim_squared - inner_mat) * A_x * (E_u + E_l).transpose() ;
//   
//   Jacobian = Rcpp_rearrange_mat_indexes_var(Jacobian, dim) ;
// 
//   stan::math::var log_abs_jac = stan::math::log_determinant(Jacobian) ;   //////////
//   
//   
//   // # -------------------------------------------------------------------------
//   // # -------------------------------------------------------------------------
//   
//   
//   // # -------------------------------------------------------------------------
//    Eigen::Matrix<stan::math::var, -1, -1> out_mat   =  Eigen::Matrix<stan::math::var, -1, -1>::Zero(dim + 1 + dim*dim, dim  + dim*dim ); 
//  //   Eigen::Matrix<stan::math::var, -1, -1> C_chol = stan::math::cholesky_decompose(C) ; 
//     
//   out_mat(0, 0) = log_abs_jac;
//   out_mat.block(1, 0, dim, dim) = C; 
//   
//   out_mat.block(1 + dim, 0, 0.5 *  dim * (dim - 1), 0.5 *  dim * (dim - 1)) =  Jacobian  ; 
// 
//   return(out_mat); 
//   
// }
// 
// 
// 






  

 
 
 
 
 
 std::unique_ptr<size_t[]> get_commutation_unequal_vec
  (unsigned const n, unsigned const m, bool const transpose){
   unsigned const nm = n * m, 
     nnm_p1 = n * nm + 1L, 
     nm_pm = nm + m;
   std::unique_ptr<size_t[]> out(new size_t[nm]);
   size_t * const o_begin = out.get();
   size_t idx = 0L;
   for(unsigned i = 0; i < n; ++i, idx += nm_pm){
     size_t idx1 = idx;
     for(unsigned j = 0; j < m; ++j, idx1 += nnm_p1)
       if(transpose)
         *(o_begin + idx1 / nm) = (idx1 % nm);
       else
         *(o_begin + idx1 % nm) = (idx1 / nm);
   }
   
   return out;
 }

// [[Rcpp::export(rng = false)]]
Rcpp::NumericVector commutation_dot
  (unsigned const n, unsigned const m, Rcpp::NumericVector x, 
   bool const transpose){
  size_t const nm = n * m;
  Rcpp::NumericVector out(nm);
  auto const indices = get_commutation_unequal_vec(n, m, transpose);
  
  for(size_t i = 0; i < nm; ++i)
    out[i] = x[*(indices.get() +i )];
  
  return out;
}

Rcpp::NumericMatrix get_commutation_unequal
  (unsigned const n, unsigned const m){
  
  unsigned const nm = n * m, 
    nnm_p1 = n * nm + 1L, 
    nm_pm = nm + m;
  Rcpp::NumericMatrix out(nm, nm);
  double * o = &out[0];
  for(unsigned i = 0; i < n; ++i, o += nm_pm){
    double *o1 = o;
    for(unsigned j = 0; j < m; ++j, o1 += nnm_p1)
      *o1 = 1.;
  }
  
  return out;
}

Rcpp::NumericMatrix get_commutation_equal(unsigned const m){
  unsigned const mm = m * m, 
    mmm = mm * m, 
    mmm_p1 = mmm + 1L, 
    mm_pm = mm + m;
  Rcpp::NumericMatrix out(mm, mm);
  double * const o = &out[0];
  unsigned inc_i(0L);
  for(unsigned i = 0; i < m; ++i, inc_i += m){
    double *o1 = o + inc_i + i * mm, 
      *o2 = o + i     + inc_i * mm;
    for(unsigned j = 0; j < i; ++j, o1 += mmm_p1, o2 += mm_pm){
      *o1 = 1.;
      *o2 = 1.;
    }
    *o1 += 1.;
  }
  return out;
}

// [[Rcpp::export(rng = false)]]
Eigen::Matrix<double, -1, -1  >  get_commutation(unsigned const n, unsigned const m) {
  
  if (n == m)  {
    
    Rcpp::NumericMatrix commutation_mtx_Nuemric_Matrix =  get_commutation_equal(n);
    
    double n_rows = commutation_mtx_Nuemric_Matrix.nrow(); 
    double n_cols = commutation_mtx_Nuemric_Matrix.ncol(); 
    
    Eigen::Matrix<double, -1, -1>  commutation_mtx_Eigen   =  Eigen::Matrix<double, -1, -1>::Zero(n_rows, n_cols); 
    
    
    for (int i = 0; i < n_rows; ++i) {
      for (int j = 0; j < n_cols; ++j) {
        commutation_mtx_Eigen(i, j) = commutation_mtx_Nuemric_Matrix(i, j) ; 
      }
    }
    
    return commutation_mtx_Eigen;
    
    
  } else { 
    
    Rcpp::NumericMatrix commutation_mtx_Nuemric_Matrix =  get_commutation_unequal(n, m);
    
    double n_rows = commutation_mtx_Nuemric_Matrix.nrow(); 
    double n_cols = commutation_mtx_Nuemric_Matrix.ncol(); 
    
    Eigen::Matrix<double, -1, -1>  commutation_mtx_Eigen   =  Eigen::Matrix<double, -1, -1>::Zero(n_rows, n_cols); 
    
    
    for (int i = 0; i < n_rows; ++i) {
      for (int j = 0; j < n_cols; ++j) {
        commutation_mtx_Eigen(i, j) = commutation_mtx_Nuemric_Matrix(i, j) ; 
      }
    }
    
    return commutation_mtx_Eigen;
    
    
  }
  
  
  
  
  
}







// [[Rcpp::export(rng = false)]]
Eigen::Matrix<double, -1, -1  > elimination_matrix(const int &n) {
  
  Eigen::Matrix<double, -1, -1> out   =  Eigen::Matrix<double, -1, -1>::Zero((n*(n+1))/2,  n*n); 
  
  for (int j = 0; j < n; ++j) {
    Eigen::Matrix<double, 1, -1> e_j   =  Eigen::Matrix<double, 1, -1>::Zero(n); 
    
    e_j(j) = 1.0;
    
    for (int i = j; i < n; ++i) {
      Eigen::Matrix<double, -1, 1> u   =  Eigen::Matrix<double, -1, 1>::Zero((n*(n+1))/2); 
      u(j*n+i-((j+1)*j)/2) = 1.0;
      Eigen::Matrix<double, 1, -1> e_i   =  Eigen::Matrix<double, 1, -1>::Zero(n); 
      e_i(i) = 1.0;
      
      out += Eigen::kroneckerProduct(u, Eigen::kroneckerProduct(e_j, e_i)); 
    }
  }
  
  return out;
}




// [[Rcpp::export(rng = false)]]
Eigen::Matrix<double, -1, -1  > duplication_matrix(const int &n) {
  
  //arma::mat out((n*(n+1))/2, n*n, arma::fill::zeros);
  Eigen::Matrix<double, -1, -1> out   =  Eigen::Matrix<double, -1, -1>::Zero((n*(n+1))/2,  n*n); 
  
  for (int j = 0; j < n; ++j) {
    for (int i = j; i < n; ++i) {
      // arma::vec u((n*(n+1))/2, arma::fill::zeros);
      Eigen::Matrix<double, -1, 1> u   =  Eigen::Matrix<double, -1, 1>::Zero((n*(n+1))/2);
      u(j*n+i-((j+1)*j)/2) = 1.0;
      
      //       arma::mat T(n,n, arma::fill::zeros);
      Eigen::Matrix<double, -1, -1> T   =  Eigen::Matrix<double, -1, -1>::Zero(n, n);
      T(i,j) = 1.0;
      T(j,i) = 1.0;
      
      Eigen::Map<Eigen::Matrix<double, -1, 1> > T_vec(T.data(), n*n);
      
      out += u * T_vec.transpose();
    }
  }
  
  return out.transpose(); 
  
}




 
 
 // [[Rcpp::export(rng = false)]]
 double notExp2_double( double x) { 
   
   double d = 25 ;
   double b = 1/d ; 

   return( stan::math::exp( d * stan::math::sin(x*b)  ) ) ; 
   
   
 }


// [[Rcpp::export(rng = false)]]
Eigen::Matrix<double, -1, 1 > notExp2_vec(  Eigen::Matrix<double, -1, 1 >  x) { 
  
  double d = 25 ;
  double b = 1/d ; 
  x.array() = stan::math::exp( d * stan::math::sin( (x.array() * b).matrix() ).array()  ) ;  
  
  
  return( x.matrix() ); 
  
}


 
 
 // [[Rcpp::export(rng = false)]]
double  notExp2_deriv_double(  double  x) { 
   
   double d = 25 ;
  double b = 1/d ; 
   x  = ( stan::math::exp( d * stan::math::sin( (x  * b)  ) )   * stan::math::cos(b * x  )   )  ;  
   
   
   return(  x  ); 
   
 }




// [[Rcpp::export(rng = false)]]
Eigen::Matrix<double, -1, 1 > notExp2_deriv_vec(  Eigen::Matrix<double, -1, 1 >  x) { 
  
  double d = 25 ;
  double b = 1/d ; 
  x.array() = ( stan::math::exp( d * stan::math::sin( (x.array() * b).matrix() ) ).array()  * stan::math::cos(b * x.array() ).array()  ).array() ;  
  
  
  return( x.matrix() ); 
  
}






 
 stan::math::var notExp2_var( stan::math::var x) { 
  
  double d = 25 ;
   double b = 1/d ; 
  
  return( stan::math::exp( d * stan::math::sin(x*b)  ) ) ; 
  
  
}


 
Eigen::Matrix<stan::math::var, -1, 1 > notExp2_vec_var(  Eigen::Matrix<stan::math::var, -1, 1 >  x) { 
  
  double d = 25 ;
  double b = 1/d ; 
  x.array() = stan::math::exp( d * stan::math::sin( (x.array() * b).matrix() ).array()  ) ;  
  
  
  return( x.matrix() ); 
  
}



 
Eigen::Matrix<stan::math::var, -1, 1 > notExp2_deriv_vec_var(  Eigen::Matrix<stan::math::var, -1, 1 >  x) { 
  
  double d = 25 ;
  double b = 1/d ; 
  x.array() = ( stan::math::exp( d * stan::math::sin( (x.array() * b).matrix() ) ).array()  * stan::math::cos(b * x.array() ).array()  ).array() ;  
  
  
  return( x.matrix() ); 
  
}












 
// [[Rcpp::export(rng = false)]]
double notLog2_double( double x) { 
  
  double d = 25;
  double b = 1/d ; 
  x = stan::math::log(x)/d;
  x = std::min(1.0, x);
  x = std::min(-1.0, x);
    
  return(stan::math::asin(x)/b); 
  
}


// [[Rcpp::export(rng = false)]]
Eigen::Matrix<double, -1, 1 > notLog2_vec(  Eigen::Matrix<double, -1, 1 >  x) { 
  
  double d = 25;
  double b = 1/d ; 
  x.array() = stan::math::log(x).array() / d;
  
  for (int i = 0; i < x.rows(); ++i) {
    x(i) = std::min(1.0, x(i));
    x(i) = std::min(-1.0, x(i));
  }
  
  return( (x.array().asin()/b).matrix() ); 
  
}


 
 
 
 
 
 
 
 
 
 
 
 
 
 Eigen::Matrix<stan::math::var, -1, 1 >                        lb_ub_lp (stan::math::var  y,
                                                                         stan::math::var lb,
                                                                         stan::math::var ub) {
   
   stan::math::var target = 0 ;
   
   // stan::math::var val   = (lb  + (ub  - lb) * stan::math::inv_logit(y)) ;
   stan::math::var val   =  lb +  (ub - lb) *  0.5 * (1 +  stan::math::tanh(y));
   
   // target += stan::math::log(ub - lb) + stan::math::log_inv_logit(y) + stan::math::log1m_inv_logit(y);
   target +=  stan::math::log(ub - lb) - log(2)  + stan::math::log1m(stan::math::square(stan::math::tanh(y)));
   
   Eigen::Matrix<stan::math::var, -1, 1 > out_mat  = Eigen::Matrix<stan::math::var, -1, 1 >::Zero(2);
   out_mat(0) = target;
   out_mat(1) = val;
   
   return(out_mat) ;
   
 }
 
 
 
 
 
 
 Eigen::Matrix<stan::math::var, -1, 1 >   lb_ub_lp_vec_y (Eigen::Matrix<stan::math::var, -1, 1 > y,
                                                          Eigen::Matrix<stan::math::var, -1, 1 > lb,
                                                          Eigen::Matrix<stan::math::var, -1, 1 > ub) {
   
   stan::math::var target = 0 ;
   
   
   //   stan::math::var val   =  lb +  (ub - lb) *  0.5 * (1 +  stan::math::tanh(y));
   Eigen::Matrix<stan::math::var, -1, 1 >  vec =   (lb.array() +  (ub.array()  - lb.array() ) *  0.5 * (1 +  stan::math::tanh(y).array() )).matrix();
   
   //  target += (stan::math::log( (ub.array() - lb.array()).matrix()).array() + stan::math::log_inv_logit(y).array() + stan::math::log1m_inv_logit(y).array()).matrix().sum() ;
   target +=  (stan::math::log((ub.array() - lb.array()).matrix()).array() - log(2)  +  stan::math::log1m(stan::math::square(stan::math::tanh(y))).array()).matrix().sum();
   
   Eigen::Matrix<stan::math::var, -1, 1 > out_mat  = Eigen::Matrix<stan::math::var, -1, 1 >::Zero(vec.rows() + 1);
   out_mat(0) = target;
   out_mat.segment(1, vec.rows()) = vec;
   
   return(out_mat);
   
 }
 
 
 //  
 //  
 //  
 //  
 
 
 
 Eigen::Matrix<stan::math::var, -1, -1 >    Spinkney_cholesky_corr_transform_opt( int n,
                                                                                  Eigen::Matrix<stan::math::var, -1, -1 >  lb,
                                                                                  Eigen::Matrix<stan::math::var, -1, -1 >  ub,
                                                                                  Eigen::Matrix<stan::math::var, -1, -1 >  Omega_theta_unconstrained_array,
                                                                                  Eigen::Matrix<int, -1, -1 >  known_values_indicator,
                                                                                  Eigen::Matrix<double, -1, -1 >  known_values) {
   
   
   stan::math::var target = 0 ;
   
   
   Eigen::Matrix<stan::math::var, -1, -1 > L = Eigen::Matrix<stan::math::var, -1, -1 >::Zero(n, n);
   Eigen::Matrix<stan::math::var, -1, 1 > first_col = Omega_theta_unconstrained_array.col(0).segment(1, n - 1);
   
   Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_vec_y_outs = lb_ub_lp_vec_y(first_col, lb.col(0), ub.col(0)) ;  // logit bounds
   target += lb_ub_lp_vec_y_outs.eval()(0);
   
   Eigen::Matrix<stan::math::var, -1, 1 >  z = lb_ub_lp_vec_y_outs.segment(1, n - 1);
   L.col(0).segment(1, n - 1) = z;
   
   for (int i = 2; i < n + 1; ++i) {
     if (known_values_indicator(i-1, 0) == 1) {
       L(i-1, 0) = stan::math::to_var(known_values(i-1, 0));
       Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_vec_y_out = lb_ub_lp(first_col(i-2), lb(i-1, 0), ub(i-1, 0)) ;  // logit bounds
       target += - lb_ub_lp_vec_y_out.eval()(0); // undo jac adjustment
     }
   }
   L(1, 1) = stan::math::sqrt(1 - stan::math::square(L(1, 0))) ;
   
   for (int i = 3; i < n + 1; ++i) {
     
     Eigen::Matrix<stan::math::var, 1, -1 >  row_vec_rep = stan::math::rep_row_vector(stan::math::sqrt(1 - L(i - 1, 0)* L(i - 1, 0)), i - 1) ;
     L.row(i - 1).segment(1, i - 1) = row_vec_rep;
     
     for (int j = 2; j < i; ++j) {
       
       stan::math::var   l_ij_old = L(i-1, j-1);
       stan::math::var   l_ij_old_x_l_jj = l_ij_old * L(j-1, j-1); // new
       stan::math::var b1 = stan::math::dot_product(L.row(j - 1).segment(0, j - 1), L.row(i - 1).segment(0, j - 1)) ;
       // stan::math::var b2 = L(j - 1, j - 1) * L(i - 1, j - 1) ; // old
       
       // stan::math::var  low = std::min(   std::max( b1 - b2, lb(i-1, j-1) / stan::math::abs(L(i-1, j-1)) ), b1 + b2 ); // old
       // stan::math::var   up = std::max(   std::min( b1 + b2, ub(i-1, j-1) / stan::math::abs(L(i-1, j-1)) ), b1 - b2 ); // old
       
       stan::math::var  low =   std::max( -l_ij_old_x_l_jj, (lb(i-1, j-1) - b1)    );   // new
       stan::math::var   up =   std::min( +l_ij_old_x_l_jj, (ub(i-1, j-1) - b1)    ); // new
       
       if (known_values_indicator(i-1, j-1) == 1) {
         // L(i-1, j-1) *= ( stan::math::to_var(known_values(i-1, j-1))  - b1) / b2; // old
         L(i-1, j-1)  = stan::math::to_var(known_values(i-1, j-1)) / L(j-1, j-1);  // new
       } else {
         Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_outs = lb_ub_lp(Omega_theta_unconstrained_array(i-1, j-1), low,  up) ;
         target += lb_ub_lp_outs.eval()(0); // old
         
         stan::math::var x = lb_ub_lp_outs.eval()(1);    // logit bounds
         target +=  - stan::math::log(L(j-1, j-1)) ;  //  Jacobian for transformation  z -> L_Omega
         
         //   L(i-1, j-1) *= (x - b1) / b2; // old
         L(i-1, j-1)  = x / L(j-1, j-1); //  low + (up - low) * x; // new
       }
       
       //    target += - stan::math::log(L(j-1, j-1)); // old
       
       stan::math::var   l_ij_new = L(i-1, j-1);
       L.row(i - 1).segment(j, i - j).array() *= stan::math::sqrt(  1 -  ( (l_ij_new / l_ij_old) * (l_ij_new / l_ij_old)  )  );
       
     }
     
   }
   L(0, 0) = 1;
   
   //////////// output
   Eigen::Matrix<stan::math::var, -1, -1 > out_mat = Eigen::Matrix<stan::math::var, -1, -1 >::Zero(1 + n , n);
   
   out_mat(0, 0) = target;
   out_mat.block(1, 0, n, n) = L;
   
   return(out_mat);
   
 }
 
 
 
 Eigen::Matrix<stan::math::var, -1, -1 >    Spinkney_LDL_bounds_opt( int K,
                                                                     Eigen::Matrix<stan::math::var, -1, -1 >  lb,
                                                                     Eigen::Matrix<stan::math::var, -1, -1 >  ub,
                                                                     Eigen::Matrix<stan::math::var, -1, -1 >  Omega_theta_unconstrained_array,
                                                                     Eigen::Matrix<int, -1, -1 >  known_values_indicator,
                                                                     Eigen::Matrix<double, -1, -1 >  known_values) {
   
   
   stan::math::var target = 0 ;
   
   Eigen::Matrix<stan::math::var, -1, 1 > first_col = Omega_theta_unconstrained_array.col(0).segment(1, K - 1);
   Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_vec_y_outs = lb_ub_lp_vec_y(first_col, lb.col(0), ub.col(0)) ;  // logit bounds
   target += lb_ub_lp_vec_y_outs.eval()(0);
   Eigen::Matrix<stan::math::var, -1, 1 >  z = lb_ub_lp_vec_y_outs.segment(1, K - 1);
   
   Eigen::Matrix<stan::math::var, -1, -1 > L = Eigen::Matrix<stan::math::var, -1, -1 >::Zero(K, K);
   
   for (int i = 0; i < K; ++i) {
     L(i, i) = 1;
   }
   
   Eigen::Matrix<stan::math::var, -1, 1 >  D = Eigen::Matrix<stan::math::var, -1, 1 >::Zero(K);
   
   D(0) = 1;
   L.col(0).segment(1, K - 1) = z;
   D(1) = 1 -  stan::math::square(L(1, 0)) ;
   
   for (int i = 2; i < K + 1; ++i) {
     if (known_values_indicator(i-1, 0) == 1) {
       L(i-1, 0) = stan::math::to_var(known_values(i-1, 0));
       Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_vec_y_out = lb_ub_lp(first_col(i-2), lb(i-1, 0), ub(i-1, 0)) ;  // logit bounds
       target += - lb_ub_lp_vec_y_out.eval()(0); // undo jac adjustment
     }
   }
   
   for (int i = 3; i < K + 1; ++i) {
     
     D(i-1) = 1 - stan::math::square(L(i-1, 0)) ;
     Eigen::Matrix<stan::math::var, 1, -1 >  row_vec_rep = stan::math::rep_row_vector(1 - stan::math::square(L(i-1, 0)), i - 2) ;
     L.row(i - 1).segment(1, i - 2) = row_vec_rep;
     stan::math::var   l_ij_old = L(i-1, 1);
     
     for (int j = 2; j < i; ++j) {
       
       stan::math::var b1 = stan::math::dot_product(L.row(j - 1).head(j - 1), (D.head(j - 1).transpose().array() *  L.row(i - 1).head(j - 1).array() ).matrix()  ) ;
       
       Eigen::Matrix<stan::math::var, -1, 1 > low_vec_to_max(2);
       Eigen::Matrix<stan::math::var, -1, 1 > up_vec_to_min(2);
       low_vec_to_max(0) = - stan::math::sqrt(l_ij_old) * D(j-1) ;
       low_vec_to_max(1) =   (lb(i-1, j-1) - b1) ;
       up_vec_to_min(0) =    stan::math::sqrt(l_ij_old) * D(j-1) ;
       up_vec_to_min(1) =    (ub(i-1, j-1) - b1)  ;
       
       stan::math::var  low =    stan::math::max( low_vec_to_max   );   // new
       stan::math::var  up  =    stan::math::min( up_vec_to_min    );   // new
       
       if (known_values_indicator(i-1, j-1) == 1) {
         L(i-1, j-1) =  stan::math::to_var(known_values(i-1, j-1)) /  D(j-1)  ; // new
       } else {
         Eigen::Matrix<stan::math::var, -1, 1 >  lb_ub_lp_outs = lb_ub_lp(Omega_theta_unconstrained_array(i-1, j-1), low,  up) ;
         target += lb_ub_lp_outs.eval()(0);
         stan::math::var x = lb_ub_lp_outs.eval()(1);    // logit bounds
         L(i-1, j-1)  = x / D(j-1) ;
         target += -0.5 * stan::math::log(D(j-1)) ;
         // target += -  stan::math::log(D(j-1)) ;
       }
       
       l_ij_old *= 1 - (D(j-1) *  stan::math::square(L(i-1, j-1) )) / l_ij_old;
     }
     D(i-1) = l_ij_old;
   }
   //L(0, 0) = 1;
   
   //////////// output
   Eigen::Matrix<stan::math::var, -1, -1 > out_mat = Eigen::Matrix<stan::math::var, -1, -1 >::Zero(1 + K , K);
   
   out_mat(0, 0) = target;
   // out_mat.block(1, 0, n, n) = L;
   out_mat.block(1, 0, K, K) = stan::math::diag_post_multiply(L, stan::math::sqrt(stan::math::abs(D)));
   
   return(out_mat);
   
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 //  Rcpp::List
 //   Eigen::Matrix<double, -1, 1 > 
 
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1 >        fn_log_posterior_and_gradient_latent_trait_MD_and_AD(  Eigen::Matrix<double, -1, 1  > theta,
                                                                                           Eigen::Matrix<int, -1, -1>	 y,
                                                                                           Rcpp::List other_args
                                                                                             
                                                                                             
 ) {
   
   
   
   
   bool exclude_priors = other_args(0);
   int lkj_prior_method = other_args(1);
   bool grad_main = other_args(2);
   bool grad_nuisance = other_args(3);
   bool CI = other_args(4);
   bool rough_approx = other_args(5);
   bool homog_corr = other_args(6);
   bool lkj_cholesky= other_args(7);
   Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta = other_args(8);
   Eigen::Matrix<double, -1, -1> prior_coeffs_mean = other_args(9);
   Eigen::Matrix<double, -1, -1> prior_coeffs_sd = other_args(10);
   int n_class = other_args(11);
   int n_tests = other_args(12);
   
   
   bool Phi_exact_indicator_if_not_using_rough_approx = other_args(16);
   int lb_threshold_phi_approx = other_args(17);
   int ub_threshold_phi_approx = other_args(18);
   
   int n_chunks = other_args(26);
   
   int N = y.rows();
   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
   int n_bs_LT = n_class * n_tests;
   int n_coeffs = n_class * n_tests * 1;
   int n_us =  1 *  N * n_tests;
   
   int n_params = theta.rows() ; // n_corrs + n_coeffs + n_us + n_class;
   int n_params_main = n_params - n_us;
   
   bool corr_force_positive = other_args(29);
   
   std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a =  other_args(49);
   std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b =  other_args(50);
   
   bool corr_priors_LKJ_only = other_args(51);
   bool corr_param_Archakov = other_args(52);
   bool use_AD_for_chol_derivs = other_args(53);
   double constant_1 = other_args(54);
   double tol  = other_args(55);
   
   bool Archakov_corr_prior_beta =  other_args(56);
   bool Archakov_corr_prior_norm =  other_args(57);
   
   double corr_pos_offset =  other_args(63); 
   
   Eigen::Matrix<double, -1, -1> LT_b_priors_shape  =  other_args(90);  
   Eigen::Matrix<double, -1, -1> LT_b_priors_scale  =  other_args(91); 
   
   Eigen::Matrix<double, -1, -1> LT_known_bs_indicator  =  other_args(92); 
   Eigen::Matrix<double, -1, -1> LT_known_bs_values =  other_args(93);
   
   
   // corrs / b's
   Eigen::Matrix<double, -1, 1  >  bs_raw_vec_double = theta.segment(n_us, n_bs_LT) ;  
   Eigen::Matrix<stan::math::var, -1, 1  >  bs_raw_vec_var =  stan::math::to_var(bs_raw_vec_double) ; 
   Eigen::Matrix<stan::math::var, -1, -1 > bs_mat =    Eigen::Matrix<stan::math::var, -1, -1 >::Zero(n_class, n_tests);
   Eigen::Matrix<stan::math::var, -1, -1 > bs_raw_mat =  Eigen::Matrix<stan::math::var, -1, -1 >::Zero(n_class, n_tests);

 
   
   bs_raw_mat.row(0) =  bs_raw_vec_var.segment(0, n_tests).transpose();
   bs_raw_mat.row(1) =  bs_raw_vec_var.segment(n_tests, n_tests).transpose();
   
   bs_mat.row(0) = stan::math::exp( bs_raw_mat.row(0)) ; 
   bs_mat.row(1) = stan::math::exp( bs_raw_mat.row(1)) ; 

   stan::math::var known_bs_raw_sum = 0.0;
   
   // for (int c = 0; c < n_class; ++c) {
   //   for (int t = 0; t < n_tests; ++t) {
   //     if (LT_known_bs_indicator(c, t) == 1) {
   //         bs_mat(c, t) =  LT_known_bs_values(c, t); 
   //         bs_raw_mat(c, t) = stan::math::log(bs_mat(c, t)); 
   //         known_bs_raw_sum +=  bs_raw_mat(c, t);
   //     }
   //   }
   // }

     
   Eigen::Matrix<stan::math::var, -1, 1 > bs_nd  =   bs_mat.row(0).transpose() ; //  bs_constrained_raw_vec_var.head(n_tests);
   Eigen::Matrix<stan::math::var, -1, 1 > bs_d   =   bs_mat.row(1).transpose() ; //  bs_constrained_raw_vec_var.segment(n_tests, n_tests);
   
   // coeffs
   Eigen::Matrix<stan::math::var, -1, -1  > LT_theta(n_class, n_tests);
   Eigen::Matrix<stan::math::var, -1, -1  > LT_a(n_class, n_tests);
   
   Eigen::Matrix<double, -1, 1  > coeffs_vec_double(n_coeffs);
   Eigen::Matrix<stan::math::var, -1, 1  > coeffs_vec_var(n_coeffs);
   
   coeffs_vec_double = theta.segment(n_us + n_corrs, n_coeffs); 
   coeffs_vec_var = stan::math::to_var(coeffs_vec_double); 
   
   {
     int i = 0 ; // n_us + n_corrs;
     for (int c = 0; c < n_class; ++c) {
       for (int t = 0; t < n_tests; ++t) {
         LT_a(c, t) = coeffs_vec_var(i);
         i = i + 1;
       }
     }
   }
   
   //// LT_theta as TRANSFORMED parameter (need Jacobian adj. if wish to put prior on theta!!!)
   for (int t = 0; t < n_tests; ++t) {
     LT_theta(1, t)   =    LT_a(1, t) /  stan::math::sqrt(1 + ( bs_d(t) * bs_d(t)));
     LT_theta(0, t)   =    LT_a(0, t) /  stan::math::sqrt(1 + ( bs_nd(t) * bs_nd(t)));
   }
 
   
   // prev
   double u_prev_diseased = theta(n_params - 1);
   
   
   ////////////////// u (double / manual diff)
   Eigen::Matrix<double, -1, 1 >   tanh_uu(n_us); ///////////////////////
   tanh_uu.array() =     ( stan::math::exp(theta.head(n_us)).array()    -   stan::math::exp( - theta.head(n_us) ).array()  )    /   
     ( stan::math::exp(theta.head(n_us)).array()    +   stan::math::exp( - theta.head(n_us) ).array()  )  ;
   double log_jac_u  =   +   (  0.5 *   (1 -  ( tanh_uu.array()  *  tanh_uu.array()  ) )   ).array().log().matrix().sum();
   
   //////////////// output vec
   Eigen::Matrix<double, -1, 1> out_mat    =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N);  ///////////////
   
   
   ////////////////////////////////////// AD part  -   for non-LKJ corr priors
   int n_choose_2 = n_tests * (n_tests - 1) * 0.5 ; 
   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  L_Omega_var_copy = vec_of_mats_test_var(n_tests, n_tests, n_class);
   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  Omega_var_copy  = vec_of_mats_test_var(n_tests, n_tests, n_class);


   Eigen::Matrix<stan::math::var, -1, -1 > identity_dim_T =     Eigen::Matrix<stan::math::var, -1, -1 > ::Zero(n_tests, n_tests) ; //  stan::math::diag_matrix(  stan::math::rep_vector(1, n_tests)  ) ; 
   
   
   Eigen::Matrix<double, -1, 1 >   bs_d_double(n_tests); 
   Eigen::Matrix<double, -1, 1 >   bs_nd_double(n_tests); 
   
   for (int i = 0; i < n_tests; ++i) {
     identity_dim_T(i, i) = 1;
     bs_d_double(i) = bs_d(i).val() ; 
     bs_nd_double(i) = bs_nd(i).val() ; 
   }
   
 
   Omega_var_copy[0] = identity_dim_T +  bs_nd * bs_nd.transpose();
   Omega_var_copy[1] = identity_dim_T +  bs_d * bs_d.transpose();
   
   stan::math::var target_AD = 0;
 
   
   for (int c = 0; c < n_class; ++c) {
     L_Omega_var_copy[c]   = stan::math::cholesky_decompose( Omega_var_copy[c]) ; 
   }
   
   
   //////////////// Jacobian L_Sigma -> b's
   
   std::vector< std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > > Jacobian_d_L_Sigma_wrt_b_3d_arrays_var = vec_of_vec_of_mats_test_var(n_tests, n_tests, n_tests, n_class);
   std::vector< std::vector<Eigen::Matrix<double, -1, -1 > > > Jacobian_d_L_Sigma_wrt_b_3d_arrays_double = vec_of_vec_of_mats_test(n_tests, n_tests, n_tests, n_class);
   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > Jacobian_d_L_Sigma_wrt_b_matrix_var = vec_of_mats_test_var(n_choose_2 + n_tests, n_tests, n_class);
   std::vector<Eigen::Matrix<double, -1, -1 > > Jacobian_d_L_Sigma_wrt_b_matrix = vec_of_mats_test(n_choose_2 + n_tests, n_tests, n_class);
 
   for (int c = 0; c < n_class; ++c) {

       //  # -----------  wrt last b first
         int t = n_tests;
         stan::math::var sum_sq_1 = 0.0;
         for (int j = 1; j < t; ++j) {
           Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](t-1, j-1) = ( L_Omega_var_copy[c](n_tests-1, j-1) / bs_mat(c, n_tests-1) ) ;//* bs_nd(n_tests-1) ;
           sum_sq_1 +=   bs_mat(c, j-1) * bs_mat(c, j-1) ;
         }
         stan::math::var big_denom_p1 =  1 + sum_sq_1;
         Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](t-1, n_tests-1) =   (1 / L_Omega_var_copy[c](n_tests-1, n_tests-1) ) * ( bs_mat(c, n_tests-1) / big_denom_p1 ) ;//* bs_nd(n_tests-1) ;

        //  # -----------  wrt 2nd-to-last b
        t = n_tests - 1;
        sum_sq_1 = 0;
        stan::math::var  sum_sq_2 = 0.0;
        for (int j = 1; j < t + 1; ++j) {
          Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](t-1, j-1) = ( L_Omega_var_copy[c](t-1, j-1) / bs_mat(c, t-1) );// * bs_nd(t-1) ;
          sum_sq_1 +=   bs_mat(c, j-1) * bs_mat(c, j-1) ;
          if (j < (t))   sum_sq_2 +=  bs_mat(c, j-1) * bs_mat(c, j-1) ;
        }
        big_denom_p1 =  1 + sum_sq_1;
        stan::math::var big_denom_p2 =  1 + sum_sq_2;
        stan::math::var  big_denom_part =  big_denom_p1 * big_denom_p2;
        Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](t-1, t-1) =   (1 / L_Omega_var_copy[c](t-1, t-1)) * ( bs_mat(c, t-1) / big_denom_p2 );// * bs_nd(t-1) ;

        for (int j = t+1; j < n_tests + 1; ++j) {
          Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](j-1, t-1) =   ( 1/L_Omega_var_copy[c](j-1, t-1) ) * (bs_mat(c, j-1) *  bs_mat(c, j-1)  ) * (   bs_mat(c, t-1)  / big_denom_part) * (1 - ( bs_mat(c, t-1) * bs_mat(c, t-1)  / big_denom_p1 ) );// * bs_nd(t-1)   ;
        }

        Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](t, t)   =  - ( 1/L_Omega_var_copy[c](t, t) ) * (bs_mat(c, t) * bs_mat(c, t)) * ( bs_mat(c, t-1)  / (big_denom_p1*big_denom_p1));//*  bs_nd(t-1) ;

        // # -----------  wrt rest of b's
          for (int t = 1; t < (n_tests - 2) + 1; ++t) {

            sum_sq_1  = 0;
            sum_sq_2  = 0;

          for (int j = 1; j < t + 1; ++j) {
            if (j < (t)) Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](t-1, j-1) = ( L_Omega_var_copy[c](t-1, j-1) /  bs_mat(c, t-1) ) ;//* ;// bs_nd(t-1) ;
            sum_sq_1 +=   bs_mat(c, j-1) *   bs_mat(c, j-1) ;
            if (j < (t))   sum_sq_2 +=    bs_mat(c, j-1) *   bs_mat(c, j-1) ;
          }
            big_denom_p1 = 1 + sum_sq_1;
            big_denom_p2 = 1 + sum_sq_2;
            big_denom_part =  big_denom_p1 * big_denom_p2;

          Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](t-1, t-1) =   (1 / L_Omega_var_copy[c](t-1, t-1) ) * (  bs_mat(c, t-1) / big_denom_p2 ) ;//*  bs_nd(t-1) ;

          for (int j = t + 1; j < n_tests + 1; ++j) {
            Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](j-1, t-1)  =   (1/L_Omega_var_copy[c](j-1, t-1)) * (  bs_mat(c, j-1) *   bs_mat(c, j-1) ) * (   bs_mat(c, t-1) / big_denom_part) * (1 - ( ( bs_mat(c, t-1) *  bs_mat(c, t-1) ) / big_denom_p1 ) ) ;//*  bs_nd(t-1) ;
          }

          for (int j = t + 1; j < n_tests ; ++j) {
            Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](j-1, j-1) =  - (1/L_Omega_var_copy[c](j-1, j-1)) * (  bs_mat(c, j-1) *   bs_mat(c, j-1) ) * ( bs_mat(c, t-1) / (big_denom_p1*big_denom_p1)) ;//*  bs_nd(t-1) ;
            big_denom_p1 = big_denom_p1 +   bs_mat(c, j-1) *   bs_mat(c, j-1) ;
            big_denom_p2 = big_denom_p2 + bs_mat(c, j-2) * bs_mat(c, j-2) ;
            big_denom_part =  big_denom_p1 * big_denom_p2 ;
            if (t < n_tests - 1) {
                for (int k = j + 1; k < n_tests + 1; ++k) {
                  Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](k-1, j-1) =   (-1 / L_Omega_var_copy[c](k-1, j-1)) * (  bs_mat(c, k-1) *   bs_mat(c, k-1) ) * (  bs_mat(c, j-1) *   bs_mat(c, j-1) ) * (  bs_mat(c, t-1) / big_denom_part ) * ( ( 1 / big_denom_p2 )  +  ( 1 / big_denom_p1 ) ) ;//*  bs_nd(t-1) ;
              }
            }
          }

          Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t-1](n_tests-1, n_tests-1) =  - (1/L_Omega_var_copy[c](n_tests-1, n_tests-1)) * (bs_mat(c, n_tests-1) * bs_mat(c, n_tests-1)) * ( bs_mat(c, t-1) / (big_denom_p1*big_denom_p1)) ;//*  bs_nd(t-1) ;

        }

 

   }
   
   

   
 
   //  // ///////////////////// priors for corr
   for (int t = 0; t < n_tests; ++t) {
     target_AD += stan::math::weibull_lpdf(  bs_nd(t) ,   LT_b_priors_shape(0, t), LT_b_priors_scale(0, t)  );
     target_AD += stan::math::weibull_lpdf(  bs_d(t)  ,   LT_b_priors_shape(1, t), LT_b_priors_scale(1, t)  );
   }
   
   target_AD +=  (bs_raw_mat).sum()  - known_bs_raw_sum ; // Jacobian b -> raw_b
   
 
   
   /// priors and Jacobians for coeffs
   for (int c = 0; c < n_class; ++c) {
     for (int t = 0; t < n_tests; ++t) {
       target_AD += stan::math::normal_lpdf(LT_theta(c, t), prior_coeffs_mean(t, c), prior_coeffs_sd(t, c));
       target_AD +=  - 0.5 * stan::math::log(1 + stan::math::square(stan::math::abs(bs_mat(c, t) ))); // Jacobian for LT_theta -> LT_a
     }
   }
 
   //  /////////////////////// 
   stan::math::set_zero_all_adjoints();
   target_AD.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
   out_mat.segment(1 + n_us, n_bs_LT) = bs_raw_vec_var.adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
   stan::math::set_zero_all_adjoints();
   //////////////////////////////////////////////////////////// end of AD part
   

 

   //  /////////////////////// 
   stan::math::set_zero_all_adjoints();
   target_AD.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
   out_mat.segment(1 + n_us + n_corrs, n_coeffs)  = coeffs_vec_var.adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
   stan::math::set_zero_all_adjoints();
   //////////////////////////////////////////////////////////// end of AD part
     
 

   
   ///////////////// get cholesky factor's (lower-triangular) of corr matrices
   // convert to 3d var array
   std::vector<Eigen::Matrix<double, -1, -1 > > L_Omega_var = vec_of_mats_test(n_tests, n_tests, n_class);
   std::vector<Eigen::Matrix<double, -1, -1 > >  Omega_var = L_Omega_var;
   std::vector<Eigen::Matrix<double, -1, -1 > >  L_Omega_inv = L_Omega_var;
   
   for (int c = 0; c < n_class; ++c) {
     for (int t1 = 0; t1 < n_tests; ++t1) {
       for (int t2 = 0; t2 < n_tests; ++t2) {
         L_Omega_var[c](t1, t2) =   L_Omega_var_copy[c](t1, t2).val();
         Omega_var[c](t1, t2)   =   Omega_var_copy[c](t1, t2).val();
       }
     }
     
     L_Omega_inv[c] = L_Omega_var[c].inverse(); 
     
   }
   
   
   /////////////  prev stuff
   std::vector<double> 	 u_prev_var_vec(n_class, 0.0);
   std::vector<double> 	 prev_var_vec(n_class, 0.0);
   std::vector<double> 	 tanh_u_prev(n_class, 0.0);
   Eigen::Matrix<double, -1, -1>	 prev(1, n_class);
   
   u_prev_var_vec[1] = (u_prev_diseased);
   tanh_u_prev[1] = ( exp(2*u_prev_var_vec[1] ) - 1) / ( exp(2*u_prev_var_vec[1] ) + 1) ;
   u_prev_var_vec[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) )  ;
   tanh_u_prev[0] = (exp(2*u_prev_var_vec[0] ) - 1) / ( exp(2*u_prev_var_vec[0] ) + 1) ;
   
   prev_var_vec[1] = 0.5 * ( tanh_u_prev[1] + 1);
   prev_var_vec[0] =  0.5 * ( tanh_u_prev[0] + 1);
   prev(0,1) =  prev_var_vec[1];
   prev(0,0) =  prev_var_vec[0];
   
 
   double tanh_pu_deriv = ( 1 - tanh_u_prev[1] * tanh_u_prev[1]  );
   double deriv_p_wrt_pu_double = 0.5 *  tanh_pu_deriv;
   double tanh_pu_second_deriv  = -2 * tanh_u_prev[1]  * tanh_pu_deriv;
   double log_jac_p_deriv_wrt_pu  = ( 1 / deriv_p_wrt_pu_double) * 0.5 * tanh_pu_second_deriv; // for gradient of u's
   double  log_jac_p =    log( deriv_p_wrt_pu_double );
   
   
   ///////////////////////////////////////////////////////////////////////// prior densities
   double prior_densities = target_AD.val() ; // target_AD_coeffs.val() + target_AD_corrs.val();
 
   /////////////////////////////////////////////////////////////////////////////////////////////////////
   ///////// likelihood
   
   
   double s = 1/1.702;
   
   int chunk_counter = 0;
   int chunk_size  = std::round( N / n_chunks  / 2) * 2;  ; // N / n_chunks;
   
   
   double log_prob_out = 0.0;
   
   
   Eigen::Matrix<double, -1, -1 >  log_prev = prev;
   
   
   for (int c = 0; c < n_class; c++) {
     log_prev(0,c) =  log(prev(0,c));
     for (int t = 0; t < n_tests; t++) {
       if (CI == true)      L_Omega_var[c](t,t) = 1;
     }
   }
   
   
   Eigen::Matrix<double, -1, -1> u_array   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   
   std::vector<Eigen::Matrix<double, -1, -1 > >  prob   = vec_of_mats_test(chunk_size, n_tests, n_class);
   std::vector<Eigen::Matrix<double, -1, -1 > >  Z_std_norm =  prob;
   std::vector<Eigen::Matrix<double, -1, -1 > >  Phi_Z =  prob;
   std::vector<Eigen::Matrix<double, -1, -1 > >  Bound_Z =  prob;
   std::vector<Eigen::Matrix<double, -1, -1 > >  Bound_U_Bound_Phi_Z =  prob;
   
   Eigen::Matrix<int, -1, -1> y_sign   =  Eigen::Matrix<int, -1, -1>::Zero(chunk_size, n_tests);
   Eigen::Matrix<double, -1, 1> prob_n  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
   Eigen::Matrix<double, -1, 1 >  log_lik_chunk   =   Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
   Eigen::Matrix<double, -1, 1 >  log_lik   =   Eigen::Matrix<double, -1, 1>::Zero(N);  //////////////////
   
   
   Eigen::Matrix<double, -1, -1> lp_array  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_class);
   std::vector<Eigen::Matrix<double, -1, -1 > > 	 inc_array = prob ;
   std::vector<Eigen::Matrix<double, -1, -1 > > 	 y1_array = prob ;
   
   std::vector<Eigen::Matrix<double, -1, -1 > >  phi_Z  =  vec_of_mats_test(chunk_size, n_tests, n_class) ;
   std::vector<Eigen::Matrix<double, -1, -1 > >  phi_Bound_Z  =  vec_of_mats_test(chunk_size, n_tests, n_class) ;
   std::vector<Eigen::Matrix<double, -1, -1 > >  common_grad_term_1  =  vec_of_mats_test(chunk_size, n_tests, n_class) ;
   
   Eigen::Matrix<double, -1, -1> derivs_chain_container_vec_array  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   Eigen::Matrix<double, -1, -1> z_grad_term  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   Eigen::Matrix<double, -1, -1> prob_term  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   Eigen::Matrix<double, -1, 1> prod_container  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
   
   Eigen::Matrix<double, -1, -1> u_grad_array   =  Eigen::Matrix<double, -1, -1>::Zero(N, n_tests);    //////////////////

   
   
   Eigen::Matrix< double , -1, 1>  beta_grad_vec   =  Eigen::Matrix<double, -1, 1>::Zero(n_coeffs);
   Eigen::Matrix<double, -1, -1>   beta_grad_array  =  Eigen::Matrix<double, -1, -1>::Zero(n_class, n_tests);
   
   std::vector<Eigen::Matrix<double, -1, -1 > > U_Omega_grad_array =  vec_of_mats_test(n_tests, n_tests, n_class);
   Eigen::Matrix<double, -1, 1 > U_Omega_grad_vec(n_corrs);
   
   Eigen::Matrix<double, -1, 1>  deriv_L_t1 =     Eigen::Matrix<double, -1, 1>::Zero( n_tests);
   Eigen::Matrix<double, -1, 1>  deriv_L_t1_output_vec =     Eigen::Matrix<double, -1, 1>::Zero( n_tests);
   
   Eigen::Matrix<double, -1, -1 >   deriv_inc  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   Eigen::Matrix<double, -1, 1> deriv_comp_2  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
   
   Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(n_class);
   Eigen::Matrix<double, -1, 1>  prev_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(n_class);
   Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec_out =   Eigen::Matrix<double, -1, 1>::Zero(n_class - 1);
   
   Eigen::Matrix<double, -1, -1 >  y_m_ysign_x_u_array =   Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;  ;
   
   
   std::vector<Eigen::Matrix<double, -1, -1 > >  grad_bound_z = vec_of_mats_test(chunk_size, n_tests*2, n_class) ; 
   std::vector<Eigen::Matrix<double, -1, -1 > >  grad_Phi_bound_z = vec_of_mats_test(chunk_size, n_tests*2, n_class) ; 
   std::vector<Eigen::Matrix<double, -1, -1 > >  deriv_Bound_Z_x_L = vec_of_mats_test(chunk_size, n_tests*2, n_class) ; 
   std::vector<Eigen::Matrix<double, -1, -1 > >  grad_prob = vec_of_mats_test(chunk_size, n_tests*2, n_class) ; 
   std::vector<Eigen::Matrix<double, -1, -1 > >  grad_z_mat = vec_of_mats_test(chunk_size, n_tests*2, n_class) ;  
   
   Eigen::Matrix< double , -1, 1>  temp_L_Omega_x_grad_z_sum_1(chunk_size);
   
   
   Eigen::Matrix<double, -1, -1>  grad_pi_wrt_b_raw =  Eigen::Matrix<double, -1, -1>::Zero(n_class, n_tests) ; 
   
   
   int iiii = 0;
   int iiiiii = 0;
   int nn = 0;
   double sqrt_2_pi_recip =   1 / sqrt(2 * M_PI) ; //  0.3989422804;
   
   for (int nc = 0; nc < n_chunks; nc++) {
     
     prob = vec_of_mats_test(chunk_size, n_tests, n_class);
     Z_std_norm =  prob;
     Phi_Z =  prob;
     Bound_Z =  prob;
     Bound_U_Bound_Phi_Z =  prob;
     
     y_sign   =  Eigen::Matrix<int, -1, -1>::Zero(chunk_size, n_tests);
     prob_n  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
     log_lik_chunk   =   Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
     
     lp_array  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_class);
     inc_array = prob ;
     y1_array = prob ;
     
     phi_Z  =  vec_of_mats_test(chunk_size, n_tests, n_class) ;
     phi_Bound_Z = phi_Z;
     common_grad_term_1 = phi_Z;
     
     derivs_chain_container_vec_array  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     z_grad_term  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     prob_term  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     prod_container  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
     
     deriv_inc  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
     deriv_comp_2  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
     
     y_m_ysign_x_u_array =   Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;  ;
     
     
     for (int nc_index = 0; nc_index < chunk_size; nc_index++ ) {
       
       for (int t = 0; t < n_tests; t++) {
         
         
         u_array(nc_index, t) =   0.5 * ( tanh_uu(iiii) + 1) ; // u_vec(iiii);
         iiii = iiii + 1;
         
         for (int c = 0; c < n_class; c++) {
           inc_array[c](nc_index, t) = 0;
         }
         
         
         if ( y(nn,t) == 1 ) {
           y_sign(nc_index, t) = +1;
         } else {
           y_sign(nc_index, t) = -1;
         }
         
         
         
       }
       
       nn += 1; // counter for individual
       
     }
     
     
     
     y_m_ysign_x_u_array.array()  =   ( (  (y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array()  - y_sign.array()  *  u_array.array()  ).array() ) ) ;
     
     
     
     for (int t = 0; t < n_tests; t++) {
       
       for (int c = 0; c < n_class; c++) {
         
         Bound_Z[c].col(t).array() =   ( ((  0 - ( LT_a(c, t).val() +    inc_array[c].col(t).array()    )  ) / L_Omega_var[c](t, t) )  ).array() ;
         
         if (rough_approx == true)  {
           Bound_U_Bound_Phi_Z[c].col(t).array() =  ( stan::math::inv_logit(  1.702 *  Bound_Z[c].col(t) ) ).array() ;
         }  else  {
           if (   ( Phi_exact_indicator_if_not_using_rough_approx == false) ) {     // for numerical stability
             Bound_U_Bound_Phi_Z[c].col(t) =   (  stan::math::abs(Bound_Z[c].col(t).array()) > ub_threshold_phi_approx ).select(  ( stan::math::inv_logit(  1.702 *  Bound_Z[c].col(t) ) ) ,  stan::math::Phi_approx( Bound_Z[c].col(t) ) ) ;   
           } else {    // for numerical stability
             Bound_U_Bound_Phi_Z[c].col(t) =   (  stan::math::abs(Bound_Z[c].col(t).array()) > ub_threshold_phi_approx ).select(  ( stan::math::inv_logit(  1.702 *  Bound_Z[c].col(t) ) ) ,  stan::math::Phi( Bound_Z[c].col(t) ) ) ;   
             
           }
         }
         
         Phi_Z[c].col(t).array()    =     y.col(t).segment(chunk_size * chunk_counter, chunk_size).array() *    Bound_U_Bound_Phi_Z[c].col(t).array() +   (  y.col(t).segment(chunk_size * chunk_counter, chunk_size).array()  -   Bound_U_Bound_Phi_Z[c].col(t).array() ) * y_sign.col(t).array() * u_array.col(t).array() ;
         
         y1_array[c].col(t) =  ( (  y.col(t).segment(chunk_size * chunk_counter, chunk_size).array() == 1 ).array()  ).select( stan::math::log1m( Bound_U_Bound_Phi_Z[c].col(t)),   Bound_U_Bound_Phi_Z[c].col(t).array().log().matrix() ) ; 
         
         Bound_U_Bound_Phi_Z[c].col(t)  =   (  stan::math::abs(Bound_Z[c].col(t).array()) > ub_threshold_phi_approx ).array().select(  stan::math::inv_logit(1.702 *  Bound_Z[c].col(t))  ,    stan::math::Phi(Bound_Z[c].col(t)) ) ;   
         
         
         prob[c].col(t) =   y1_array[c].col(t).array().exp();
         
         if (rough_approx == true)  {
           Z_std_norm[c].col(t).array()  =     (  (  Phi_Z[c].col(t).array().log() ).array() -   stan::math::log1m(   Phi_Z[c].col(t) ).array()    )   * s ;  // logit(..) * s
         } else {
           // for numerical stability
           Z_std_norm[c].col(t).array() = Eigen::Select(    stan::math::fabs(Bound_Z[c].col(t).array()) > ub_threshold_phi_approx ,
                             (  (  Phi_Z[c].col(t).array().log() ).array() -    ( stan::math::log1m(   Phi_Z[c].col(t)).array()  ) ).array()     * s  ,
                             stan::math::inv_Phi( Phi_Z[c].col(t)  ).array() );
           
        //   Z_std_norm[c].col(t) =   (  stan::math::abs(Bound_Z[c].col(t).array()) > ub_threshold_phi_approx ).array().select(  ((  (  Phi_Z[c].col(t).array().log() ).array() -    ( stan::math::log1m(   Phi_Z[c].col(t)).array()  ) ).array()     * s ).matrix() ,   stan::math::inv_Phi(Phi_Z[c].col(t)) ) ; 
           
         }
         
         if (CI == false) {
           if (t < n_tests - 1) {
             inc_array[c].col(t + 1)    =   ( Z_std_norm[c].block(0, 0, chunk_size, t + 1)  *   ( L_Omega_var[c].row(t+1).head(t+1).transpose()  ) ) ;
           }
         }
         
       } // end of c loop
       
     } // end of t loop
 
     for (int c = 0; c < n_class; c++) {
       lp_array.col(c).array() = y1_array[c].rowwise().sum().array() +  log_prev(0,c) ;
     }
     
     log_lik_chunk.array()   =  lp_array.array().maxCoeff() +   (lp_array.array() - lp_array.array().maxCoeff() ).array().exp().rowwise().sum().array().log() ;  //  log_sum_exp(lp);
     log_lik.segment( chunk_size * chunk_counter, chunk_size).array() =  log_lik_chunk.array() ;
     
     prob_n =   log_lik_chunk.array().exp().matrix();
     
     log_prob_out += log_lik_chunk.sum();
     
     
     
     // /////////////////////////////////////////////////////////////////////////////////////// Manual gradients
     bool grad;
     if (grad_nuisance == true) grad = true;
     if (grad_main == true) grad = true;
     
     if (grad == true) {
       
       if (rough_approx == true)  {
         for (int c = 0; c < n_class; c++) {
           phi_Z[c].array()  =        Phi_Z[c].array() * (1 -        Phi_Z[c].array() ) * (1/s);
           phi_Bound_Z[c].array()      =  Bound_U_Bound_Phi_Z[c].array() * ( 1 - Bound_U_Bound_Phi_Z[c].array()  ) * (1/s);
         }
       } else {
         for (int c = 0; c < n_class; c++) {
           
           phi_Z[c] =   (  stan::math::abs(Bound_Z[c].array()) > ub_threshold_phi_approx ).array().select(  (  Phi_Z[c].array() * (1 -        Phi_Z[c].array() ) * (1/s)  ).matrix(),   sqrt_2_pi_recip *  ( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).exp().array().matrix()  ) ; 
           
           phi_Bound_Z[c] =   (  stan::math::abs(Bound_Z[c].array()) > ub_threshold_phi_approx ).array().select(  (  Bound_U_Bound_Phi_Z[c].array() * (1 -        Bound_U_Bound_Phi_Z[c].array() ) * (1/s)  ).matrix(),   sqrt_2_pi_recip *  ( - 0.5 * Bound_Z[c].array() *  Bound_Z[c].array() ).exp().array().matrix()  ) ; 
           
         }
       }
       
       
       for (int c = 0; c < n_class; c++) {
         for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
           int t = n_tests - (i + 1) ;
           common_grad_term_1[c].col(t) =   ( prev(0,c) / prob_n.array() ) * ( prob[c].block(0, 0, n_chunks, n_tests).rowwise().prod().array()  /  prob[c].block(0, t + 0, n_chunks, i + 1).rowwise().prod().array()  ).array();
         }
       }
       
     }
     
     //  ///////////////////////////////////////////////////////////////////////////////// Grad of nuisance parameters / u's (manual)
     if (grad_nuisance == true) {
       
       for (int c = 0; c < n_class; c++) {
         
         u_grad_array.col(n_tests - 1).array() = 0; // ----------   correct
         
         ///// then second-to-last term (test T - 1)
         int t = n_tests - 1;
         
         u_grad_array.col(n_tests - 2).segment( chunk_size * chunk_counter, chunk_size).array()  +=   common_grad_term_1[c].col(t).array()  * (y_sign.col(t).array()  * phi_Bound_Z[c].col(t).array() * (1 / L_Omega_var[c](t,t)  ) *  // lp(T)
           L_Omega_var[c](t,t - 1) * ( 1 /phi_Z[c].col(t-1).array() )  * prob[c].col(t-1).array()).array(); // lp(T)    // ----------   correct
         
         
           { ///// then third-to-last term (test T - 2)
             t = n_tests - 2;
             
             z_grad_term.col(0) = (1 / phi_Z[c].col(t-1).array())  * prob[c].col(t-1).array() ;
             prob_term.col(0) =     y_sign.col(t).array()  *    phi_Bound_Z[c].col(t).array() * (1 / L_Omega_var[c](t,t)  ) *     L_Omega_var[c](t, t - 1) *   z_grad_term.col(0).array() ; // lp(T-1) - part 2;
             z_grad_term.col(1).array()  = (1 /phi_Z[c].col(t).array() ) * phi_Bound_Z[c].col(t).array() * (1 / L_Omega_var[c](t,t))  * L_Omega_var[c](t,t-1) *   z_grad_term.col(0).array() *       y_m_ysign_x_u_array.col(t).array() ;
             
             prob_term.col(1)  =       y_sign.col(t + 1).array()   *   (   phi_Bound_Z[c].col(t+1).array()  *  (1 / L_Omega_var[c](t+1,t+1)  ) ) *
               (  z_grad_term.col(0).array() *  L_Omega_var[c](t + 1,t - 1)  -   z_grad_term.col(1).array()  * L_Omega_var[c](t+1,t)) ;
             
             u_grad_array.col(n_tests - 3).segment( chunk_size * chunk_counter, chunk_size).array()  +=  common_grad_term_1[c].col(t).array()   *  (  prob_term.col(1).array() * prob[c].col(t).array()  +      prob_term.col(0).array() *  prob[c].col(t+1).array()  );  // ----------   correct
           }
           
       }
       
       
       ///// then rest of terms
       for (int c = 0; c < n_class; c++) {
         
         // then rest of terms
         for (int i = 1; i < n_tests - 2; i++) { // i goes from 1 to 3
           
           for (int nc_index = 0; nc_index < chunk_size; nc_index++ ) {
             prod_container(nc_index) = 0;
             for (int t = 0; t < n_tests; t++) {
               prob_term(nc_index, t) = 0;
               z_grad_term(nc_index, t) = 0;
             }
           }
           
           int t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)
           
           z_grad_term.col(0) = (1 / phi_Z[c].col(t-1).array())  * prob[c].col(t-1).array() ;
           
           prob_term.col(0) =     y_sign.col(t).array()  *    phi_Bound_Z[c].col(t).array() * (1 / L_Omega_var[c](t,t)  ) *  // lp(T-1) - part 1
             L_Omega_var[c](t, t - 1) *   z_grad_term.col(0).array() ; // lp(T-1) - part 2;
             
             for (int ii = 0; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1 u_grad_z u_grad_term
               
               if (ii == 0)    prod_container  = (   (z_grad_term.block(0, 0, chunk_size, ii + 1) ) *  (fn_first_element_neg_rest_pos(L_Omega_var[c].row( t + (ii-1) + 1).segment(t - 1, ii + 1))).transpose()  )      ;
               z_grad_term.col(ii+1)  =  (1 /phi_Z[c].col( t+(ii-1)+1).array() ).array() * phi_Bound_Z[c].col(t+(ii-1)+1).array() * (1 / L_Omega_var[c](t+(ii-1)+1,t+(ii-1)+1))   *   y_m_ysign_x_u_array.col(t + ii).array() *  -   prod_container.array() ;
               prod_container  = (   (z_grad_term.block(0, 0, chunk_size, ii + 2) ) *  (fn_first_element_neg_rest_pos(L_Omega_var[c].row( t + (ii) + 1).segment(t - 1, ii + 2))).transpose()  )      ;
               prob_term.col(ii+1)  =    y_sign.col(t + ii + 1).array()  *   (    phi_Bound_Z[c].col(t+ii+1).array() *  (1 / L_Omega_var[c](t+ii+1,t+ii+1)  )) *     -    prod_container.array()  ;
               
             } // end of ii loop
             
             for (int ii = 0; ii < i + 2; ii++) {
               derivs_chain_container_vec_array.col(ii)  =  ( prob_term.col(ii).array()  * (    prob[c].block(0, t + 0, chunk_size, i + 2).rowwise().prod().array() /  prob[c].col(t + ii).array()  ).array() ).matrix() ;
             }
             u_grad_array.col(n_tests - (i+3)).segment( chunk_size * chunk_counter, chunk_size)  +=    ( common_grad_term_1[c].col(t).array()   *  derivs_chain_container_vec_array.block(0, 0, chunk_size, i + 2).rowwise().sum().array() ).matrix() ;
             
         }
         
       } // end of c loop
       
     }
     
     /////////////////////////////////////////////////////////////////////////// Grad of intercepts / coefficients (beta's)
     for (int c = 0; c < n_class; c++) {
       
       if (grad_main == true) {
         
         ///// last term first (test T)
         int t = n_tests - 1;
         
         beta_grad_array(c, t) +=     (common_grad_term_1[c].col(t).array()  *   ( - y_sign.col(t).array()   * phi_Bound_Z[c].col(t).array()  * ( - 1 / L_Omega_var[c](t,t)  ))).sum();
         
         ///// then second-to-last term (test T - 1)
         {
           t = n_tests - 2;
           prob_term.col(0) =       ( (- y_sign.col(t).array()   )  * phi_Bound_Z[c].col(t).array() * (- 1 / L_Omega_var[c](t,t)  ) ) ;
           z_grad_term.col(1)   =      (1 /phi_Z[c].col(t).array()  ) *  y_m_ysign_x_u_array.col(t).array() *   phi_Bound_Z[c].col(t).array()  * (- 1 / L_Omega_var[c](t,t))     ;
           prob_term.col(1)  =       ( - y_sign.col(t+1).array()    ) *  (   phi_Bound_Z[c].col(t+1).array()  *  (- 1 / L_Omega_var[c](t+1,t+1)  ) ) * (   L_Omega_var[c](t + 1,t) *      z_grad_term.col(1).array() ) ;
           
           beta_grad_array(c, t) +=  (common_grad_term_1[c].col(t).array()   * ( prob_term.col(1).array() * prob[c].col(t).array() +         prob_term.col(0).array() *  prob[c].col(t+1).array() ) ).sum() ;
         }
         
         // then rest of terms
         for (int i = 1; i < n_tests - 1; i++) { // i goes from 1 to 3
           
               t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)
               
               // component 1 (earliest test)
               for (int nc_index = 0; nc_index < chunk_size; ++nc_index ) {
                 z_grad_term(nc_index, 0) = 0;
               }
               prob_term.col(0)  =    ( ( - y_sign.col(t).array()  )  * phi_Bound_Z[c].col(t).array()  * (- 1 / L_Omega_var[c](t,t)  ) ) ;
               
               // component 2 (second-to-earliest test)
               z_grad_term.col(1)  =     (1 /phi_Z[c].col(t).array()  ) *  y_m_ysign_x_u_array.col(t).array() *    phi_Bound_Z[c].col(t).array()  * (- 1 / L_Omega_var[c](t,t))    ;
               prob_term.col(1) =        - y_sign.col(t + 1).array()   * (   phi_Bound_Z[c].col(t+1).array() *  (- 1 / L_Omega_var[c](t+1,t+1)  ) ) *    (   L_Omega_var[c](t + 1,t) *   z_grad_term.col(1).array() ) ;
               
               // rest of components
               for (int ii = 1; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1
                     if (ii == 1)  prod_container  = (    z_grad_term.block(0, 1, chunk_size, ii)  *   L_Omega_var[c].row( t + (ii - 1) + 1).segment(t + 0, ii + 0).transpose()  );
                     z_grad_term.col(ii+1)  =      (1 /phi_Z[c].col(t+(ii-1)+1).array() ).array() * y_m_ysign_x_u_array.col(t + ii).array() *
                     phi_Bound_Z[c].col(t+(ii-1)+1).array() * (- 1 / L_Omega_var[c](t+(ii-1)+1,t+(ii-1)+1))  *   prod_container.array();
                     prod_container  = (    z_grad_term.block(0, 1, chunk_size, ii + 1)  *   L_Omega_var[c].row( t + (ii) + 1).segment(t + 0, ii + 1).transpose()  );
                     prob_term.col(ii+1) =      (  - y_sign.col(t + ii + 1).array()  ).array() *   (    phi_Bound_Z[c].col(t+ii+1).array() *  (- 1 / L_Omega_var[c](t+ii+1,t+ii+1)  ) ).array()   *  prod_container.array();
               }
               
               ///// attempt at vectorising  // bookmark
               for (int ii = 0; ii < i + 2; ii++) {
                 derivs_chain_container_vec_array.col(ii)  =  ( prob_term.col(ii).array()  * (    prob[c].block(0, t + 0, chunk_size, i + 2).rowwise().prod().array() /  prob[c].col(t + ii).array()  ).array() ).matrix() ;
               }
               beta_grad_array(c, t) +=        ( common_grad_term_1[c].col(t).array()   *  derivs_chain_container_vec_array.block(0, 0, chunk_size, i + 2).rowwise().sum().array() ).sum();
           
         }
         
       }
       
     }
     ////////////////////////////////////////////////////////////////////////////////////////////////// Grad of L_Omega ('s)
     for (int c = 0; c < n_class; c++) {
 
         
         ///////////////////////// deriv of diagonal elements (not needed if using the "standard" or "Stan" Cholesky parameterisation of Omega)
         
         //////// w.r.t last diagonal first
         {
           int  t1 = n_tests - 1;
         
         
         
         double deriv_L_T_T_inv =  ( - 1 /  ( L_Omega_var[c](t1,t1)  * L_Omega_var[c](t1,t1) ) )   *   Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1, t1).val()  ;
         
         deriv_Bound_Z_x_L[c].col(0).array() = 0;
         for (int t = 0; t < t1; t++) {
           deriv_Bound_Z_x_L[c].col(0).array() +=   Z_std_norm[c].col(t).array() *  Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1, t).val();
         }
 
         double deriv_a = 0 ; //  stan::math::pow( (1 + (bs_mat(c, t1).val()*bs_mat(c, t1).val()) ), -0.5) * bs_mat(c, t1).val()  * LT_theta(c, t1)  ;
         deriv_Bound_Z_x_L[c].col(0).array()   = deriv_a -     deriv_Bound_Z_x_L[c].col(0).array();
           
         grad_bound_z[c].col(0).array() =   deriv_L_T_T_inv * (Bound_Z[c].col(t1).array() * L_Omega_var[c](t1,t1)  ) +  (1 / L_Omega_var[c](t1, t1)) *   deriv_Bound_Z_x_L[c].col(0).array()  ;         
         grad_Phi_bound_z[c].col(0)  =  ( phi_Bound_Z[c].col(t1).array() *  (  grad_bound_z[c].col(0).array() )  ) .matrix();   // correct  (standard form)
         grad_prob[c].col(0)   =  (   - y_sign.col(t1).array()  *   grad_Phi_bound_z[c].col(0).array() ).matrix() ;     // correct  (standard form)
         
         
         grad_pi_wrt_b_raw(c, t1)  +=   (   common_grad_term_1[c].col(t1).array()    *            grad_prob[c].col(0).array()    ).matrix().sum()   ; // correct  (standard form)
         
 
         }
         
         
         //////// then w.r.t the second-to-last diagonal
         {
           int  t1 = n_tests - 2;
           
           double deriv_L_T_T_inv =  ( - 1 /   ( L_Omega_var[c](t1,t1)  * L_Omega_var[c](t1,t1) ) )  * Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1, t1).val()  ;
           
           deriv_Bound_Z_x_L[c].col(0).array() = 0;
           for (int t = 0; t < t1; t++) {
             deriv_Bound_Z_x_L[c].col(0).array() += Z_std_norm[c].col(t).array() *  Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1, t).val();
           }
 
           double deriv_a = 0 ; //   stan::math::pow( (1 + (bs_mat(c, t1).val()*bs_mat(c, t1).val()) ), -0.5) * bs_mat(c, t1).val()   * LT_theta(c, t1)   ;
           deriv_Bound_Z_x_L[c].col(0).array()   = deriv_a -     deriv_Bound_Z_x_L[c].col(0).array();
           
           
           grad_bound_z[c].col(0).array() =  deriv_L_T_T_inv * (Bound_Z[c].col(t1).array() * L_Omega_var[c](t1,t1)  ) +  (1 / L_Omega_var[c](t1, t1)) *     deriv_Bound_Z_x_L[c].col(0).array()  ;   
           grad_Phi_bound_z[c].col(0)  =  ( phi_Bound_Z[c].col(t1).array() *  (  grad_bound_z[c].col(0).array() )  ) .matrix();   // correct  (standard form)
           grad_prob[c].col(0)   =  (   - y_sign.col(t1).array()  *   grad_Phi_bound_z[c].col(0).array() ).matrix() ;     // correct  (standard form)
           
           
           grad_z_mat[c].col(0).array()  =      (  ( (  y_m_ysign_x_u_array.col(t1).array()   / phi_Z[c].col(t1).array()  ).array()    * phi_Bound_Z[c].col(t1).array() *   grad_bound_z[c].col(0).array()  ).array() ).matrix()  ;  // correct  (standard form)
           
           deriv_L_T_T_inv =  ( - 1 /  ( L_Omega_var[c](t1+1,t1+1)  * L_Omega_var[c](t1+1,t1+1)  )  )  * Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1+1, t1+1).val()  ;
           deriv_Bound_Z_x_L[c].col(1).array()  =    L_Omega_var[c](t1+1,t1) *   grad_z_mat[c].col(0).array()     +   Z_std_norm[c].col(t1).array() *  Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1+1, t1).val();
           grad_bound_z[c].col(1).array() =  deriv_L_T_T_inv * (Bound_Z[c].col(t1+1).array() * L_Omega_var[c](t1+1,t1+1)  ) +  (1 / L_Omega_var[c](t1+1, t1+1)) * -   deriv_Bound_Z_x_L[c].col(1).array()  ; 
           
           grad_Phi_bound_z[c].col(1) =   ( phi_Bound_Z[c].col(t1 + 1).array() *  (    grad_bound_z[c].col(1).array()   ) ).matrix();   // correct  (standard form)
           grad_prob[c].col(1)   =   (  - y_sign.col(t1 + 1).array()  *     grad_Phi_bound_z[c].col(1).array()  ).array().matrix() ;    // correct   (standard form)
           
           grad_pi_wrt_b_raw(c, t1) +=   ( ( common_grad_term_1[c].col(t1).array() )    *
                                   ( prob[c].col(t1 + 1).array()  *      grad_prob[c].col(0).array()  +   prob[c].col(t1).array()  *         grad_prob[c].col(1).array()   ) ).sum() ;
         }
         
         
         //////// then w.r.t the third-to-last diagonal .... etc
         {
           
           //   int i = 4;
           for (int i = 3; i < n_tests + 1; i++) {
             
             int  t1 = n_tests - i;
             
             double deriv_L_T_T_inv =  ( - 1 /   ( L_Omega_var[c](t1,t1)  * L_Omega_var[c](t1,t1) ) )  * Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1, t1).val()  ;
             
             deriv_Bound_Z_x_L[c].col(0).array() = 0;
             for (int t = 0; t < t1; t++) {
               deriv_Bound_Z_x_L[c].col(0).array() += Z_std_norm[c].col(t).array() *  Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1, t).val();
             }
 
            double deriv_a = 0 ; //  stan::math::pow( (1 + (bs_mat(c, t1).val()*bs_mat(c, t1).val()) ), -0.5) * bs_mat(c, t1).val() *   LT_theta(c, t1)   ;
             deriv_Bound_Z_x_L[c].col(0).array()   = deriv_a -     deriv_Bound_Z_x_L[c].col(0).array();
             
             
             grad_bound_z[c].col(0).array() =  deriv_L_T_T_inv * (Bound_Z[c].col(t1).array() * L_Omega_var[c](t1,t1)  ) +  (1 / L_Omega_var[c](t1, t1)) *    deriv_Bound_Z_x_L[c].col(0).array()  ;   
             grad_Phi_bound_z[c].col(0)  =  ( phi_Bound_Z[c].col(t1).array() *  (  grad_bound_z[c].col(0).array() )  ) .matrix();   // correct  (standard form)
             grad_prob[c].col(0)   =  (   - y_sign.col(t1).array()  *   grad_Phi_bound_z[c].col(0).array() ).matrix() ;     // correct  (standard form)
             
             
             grad_z_mat[c].col(0).array()  =      (  ( (  y_m_ysign_x_u_array.col(t1).array()   / phi_Z[c].col(t1).array()  ).array()    * phi_Bound_Z[c].col(t1).array() *   grad_bound_z[c].col(0).array()  ).array() ).matrix()  ;  // correct  (standard form)
             
             deriv_L_T_T_inv =  ( - 1 /  ( L_Omega_var[c](t1+1,t1+1)  * L_Omega_var[c](t1+1,t1+1)  )  )  * Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1+1, t1+1).val()  ;
             deriv_Bound_Z_x_L[c].col(1).array()  =    L_Omega_var[c](t1+1,t1) *   grad_z_mat[c].col(0).array()     +   Z_std_norm[c].col(t1).array() *  Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1+1, t1).val();
             grad_bound_z[c].col(1).array() =  deriv_L_T_T_inv * (Bound_Z[c].col(t1+1).array() * L_Omega_var[c](t1+1,t1+1)  ) +  (1 / L_Omega_var[c](t1+1, t1+1)) * -  deriv_Bound_Z_x_L[c].col(1).array()  ; 
             
             grad_Phi_bound_z[c].col(1) =   ( phi_Bound_Z[c].col(t1 + 1).array() *  (    grad_bound_z[c].col(1).array()   ) ).matrix();   // correct  (standard form)
             grad_prob[c].col(1)  =   (  - y_sign.col(t1 + 1).array()  *     grad_Phi_bound_z[c].col(1).array()  ).array().matrix() ;    // correct   (standard form)
             
             
             for (int ii = 1; ii < i - 1; ii++) {
                 grad_z_mat[c].col(ii).array()  =    (  ( (  y_m_ysign_x_u_array.col(t1 + ii).array()   / phi_Z[c].col(t1 + ii).array()  ).array()    * phi_Bound_Z[c].col(t1 + ii).array() *   grad_bound_z[c].col(ii).array()  ).array() ).matrix() ;     // correct  (standard form)
                 
                 deriv_L_T_T_inv =  ( - 1 /  (  L_Omega_var[c](t1 + ii + 1,t1 + ii + 1)  * L_Omega_var[c](t1 + ii + 1,t1 + ii + 1) )  )  * Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1 + ii + 1, t1 + ii + 1).val()  ;
                 
                 deriv_Bound_Z_x_L[c].col(ii + 1).array()   =  0;
                 for (int jj = 0; jj < ii + 1; jj++) {
                   deriv_Bound_Z_x_L[c].col(ii + 1).array()  +=    L_Omega_var[c](t1 + ii + 1,t1 + jj)     *   grad_z_mat[c].col(jj).array()     +   Z_std_norm[c].col(t1 + jj).array()     *  Jacobian_d_L_Sigma_wrt_b_3d_arrays_var[c][t1](t1 + ii + 1, t1 + jj).val() ;// + 
                 }
                 grad_bound_z[c].col(ii + 1).array() =  deriv_L_T_T_inv * (Bound_Z[c].col(t1 + ii + 1).array() * L_Omega_var[c](t1 + ii + 1,t1 + ii + 1)  ) +  (1 / L_Omega_var[c](t1 + ii + 1, t1 + ii + 1)) * -   deriv_Bound_Z_x_L[c].col(ii + 1).array()  ; 
                 grad_Phi_bound_z[c].col(ii + 1).array()  =     phi_Bound_Z[c].col(t1 + ii + 1).array()  *   grad_bound_z[c].col(ii + 1).array() ;   // correct  (standard form)
                 grad_prob[c].col(ii + 1).array()  =   ( - y_sign.col(t1 + ii + 1).array()  ) *    grad_Phi_bound_z[c].col(ii + 1).array() ;  // correct  (standard form)
               
             }
             
             
             
             ///// attempt at vectorising  // bookmark
             for (int iii = 0; iii <  i; iii++) {
               derivs_chain_container_vec_array.col(iii)  =  (    grad_prob[c].col(iii).array()  * (    prob[c].block(0, t1 + 0, chunk_size, i).rowwise().prod().array() /  prob[c].col(t1 + iii).array()  ).array() ).matrix() ; // correct  (standard form)
             }
             
             grad_pi_wrt_b_raw(c, t1) +=        ( common_grad_term_1[c].col(t1).transpose()   *  derivs_chain_container_vec_array.block(0, 0, chunk_size, i).rowwise().sum() ).eval()(0, 0)  ; // correct  (standard form)
             
           }
           
           
           
         }
 
         
         
         prev_grad_vec(c)  +=  ( ( 1 / prob_n.array() ) * prob[c].rowwise().prod().array() ).matrix().sum() ;
         
   
       
       
     } // end of c loop
     
     
     
     chunk_counter += 1;
     
     
   }  // end of chunk loop
   
   
   
   //////////////////////// gradients for latent class membership probabilitie(s) (i.e. disease prevalence)
   if (grad_main == true) {
     for (int c = 0; c < n_class; c++) {
       prev_unconstrained_grad_vec(c)  =   prev_grad_vec(c)   * deriv_p_wrt_pu_double ;
     }
     prev_unconstrained_grad_vec(0) = prev_unconstrained_grad_vec(1) - prev_unconstrained_grad_vec(0) - 2 * tanh_u_prev[1];
     prev_unconstrained_grad_vec_out(0) = prev_unconstrained_grad_vec(0);
   }
   
   if (exclude_priors == false)     log_prob_out += prior_densities;

   double log_prob_out_wo_jacs = log_prob_out;
   
   log_prob_out +=  log_jac_u;
   log_prob_out +=  log_jac_p;
   
   auto log_prob = log_prob_out;
   
 
   int i = 0; // probs_all_range.prod() cancels out
   for (int c = 0; c < n_class; c++) {
     for (int t = 0; t < n_tests; t++) {
       //  if (exclude_priors == false)      beta_grad_array(c, t) +=  - ((LT_a(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) * (1/ prior_coeffs_sd(t,c) ) ;     // add normal prior density derivative to gradient
         beta_grad_vec(i) = beta_grad_array(c, t);
         i += 1;
     }
   }
   
   for (int n = 0; n < N; n++ ) {
     for (int t = 0; t < n_tests; t++) {
       out_mat(iiiiii + 1) = u_grad_array(n, t);
       iiiiii += 1;
     }
   }
   
   Eigen::Matrix<double, -1, 1 >  bs_grad_vec_nd =  (grad_pi_wrt_b_raw.row(0).transpose().array() * bs_nd_double.array()).matrix() ; //     ( deriv_log_pi_wrt_L_Omega[0].asDiagonal().diagonal().array() * bs_nd_double.array()  ).matrix()  ; //  Jacobian_d_L_Sigma_wrt_b_matrix[0].transpose() * deriv_log_pi_wrt_L_Omega_vec_nd;
   Eigen::Matrix<double, -1, 1 >  bs_grad_vec_d =   (grad_pi_wrt_b_raw.row(1).transpose().array() * bs_d_double.array()).matrix() ; //    ( deriv_log_pi_wrt_L_Omega[1].asDiagonal().diagonal().array() * bs_d_double.array()  ).matrix()  ; //   Jacobian_d_L_Sigma_wrt_b_matrix[1].transpose()  * deriv_log_pi_wrt_L_Omega_vec_d;
   
   Eigen::Matrix<double, -1, 1 >   bs_grad_vec(n_bs_LT);
   bs_grad_vec.head(n_tests)              = bs_grad_vec_nd ;
   bs_grad_vec.segment(n_tests, n_tests)  = bs_grad_vec_d;
 
   stan::math::recover_memory();
   
   ////////////////////////////  outputs
   out_mat(0) = log_prob;
   
 
   out_mat.segment(1 + n_us, n_bs_LT)  += bs_grad_vec ; 
   out_mat.segment(1 + n_us + n_corrs, n_coeffs) += beta_grad_vec;//.cast<float>();
   out_mat(n_params) = prev_unconstrained_grad_vec_out(0); // cast<float>()(0);
   out_mat.segment(1, n_us).array() =   (out_mat.segment(1, n_us).array() *   0.5 * (1 - tanh_uu.array() *  tanh_uu.array() )  - 2 * tanh_uu.array()) ;
   
   out_mat.segment(1 + n_params, N) = log_lik;
   
   
   int LT_cnt_2 = 0;
   for (int c = 0; c < n_class; ++c) {
     for (int t = 0; t < n_tests; ++t) {
       if (LT_known_bs_indicator(c, t) == 1) {
         out_mat(1 + n_us + LT_cnt_2) = 0;
       }
       LT_cnt_2 += 1;
     }
   }
   
   
    return(out_mat);
   
   
   
   
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 //  
 // //
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1>     fn_wo_list_log_posterior_and_gradient_Chol_Schur_AD_float( int n_cores, 
                                                                                             Eigen::Matrix<double, -1, 1  > theta,
                                                                                             Eigen::Matrix<int, -1, -1>	 y,
                                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  X,
                                                                                             bool exclude_priors,
                                                                                             bool CI,
                                                                                             Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                                             Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                                             Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                                             int n_class,
                                                                                             int n_tests,
                                                                                             int ub_threshold_phi_approx,
                                                                                             int n_chunks,
                                                                                             bool corr_force_positive,
                                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                                             bool corr_prior_beta ,
                                                                                             bool corr_prior_norm ,
                                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
                                                                                             std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                                             double prev_prior_a,
                                                                                             double prev_prior_b,
                                                                                             int Phi_type
                                                                                  
 ) {
   
   // 

   
   
   
   // bool exclude_priors = other_args(0);
   // int lkj_prior_method = other_args(1);
   // bool grad_main = other_args(2);
   // bool grad_nuisance = other_args(3);
   // bool CI = other_args(4);
   // bool rough_approx = other_args(5);
   // bool homog_corr = other_args(6);
   // bool lkj_cholesky= other_args(7);
   // Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta = other_args(8);
   // Eigen::Matrix<double, -1, -1> prior_coeffs_mean = other_args(9);
   // Eigen::Matrix<double, -1, -1> prior_coeffs_sd = other_args(10);
   // int n_class = other_args(11);
   // int n_tests = other_args(12);
   // 
   // 
   // bool Phi_exact_indicator_if_not_using_rough_approx = other_args(16);
   // int lb_threshold_phi_approx = other_args(17);
   // int ub_threshold_phi_approx = other_args(18);
   
   // int n_chunks = other_args(26);
    
   int N = y.rows();
   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
   int n_coeffs = n_class * n_tests * 1;
   int n_us =  1 *  N * n_tests;
 
   int n_params = theta.rows() ; // n_corrs + n_coeffs + n_us + n_class;
   int n_params_main = n_params - n_us;
   
   // bool corr_force_positive = other_args(29);
   // 
   // std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a =  other_args(49);
   // std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b =  other_args(50);
   // 
   // bool corr_priors_LKJ_only = other_args(51);
   // bool corr_param_Archakov = other_args(52);
   // bool use_AD_for_chol_derivs = other_args(53);
   // double constant_1 = other_args(54);
   // double tol  = other_args(55);
   // 
   // bool corr_prior_beta =  other_args(56);
   // bool corr_prior_norm =  other_args(57);
   // 
   // std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr =   other_args(64);
   // std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr =   other_args(65);
   // 
   // 
   // std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator =  other_args(72);
   // std::vector<Eigen::Matrix<double, -1, -1 > >   known_values  =  other_args(73);
   // 
   // int  Spinkney_param  =  other_args(74);
   // 
   // double prev_prior_a = other_args(80);
   // double prev_prior_b = other_args(81);
   // 
   // Eigen::Matrix<double, -1, -1> y_new = other_args(100);
   // Eigen::Matrix<double, -1, 1>  y_indicator = other_args(101);
   
   
   
   
   stan::math::var target = 0.0;
   
   Eigen::Matrix<stan::math::var, -1, 1  >  theta_var = stan::math::to_var(theta);
   std::vector<stan::math::var> theta_var_std = eigen_vec_to_std_vec_var(theta_var); 
   
   // u's
   Eigen::Matrix<stan::math::var, -1, 1>  u_unconstrained_vec_var = theta_var.head(n_us);
   
   // corrs
   Eigen::Matrix<stan::math::var, -1, 1> theta_corrs_var = theta_var.segment(n_us, n_corrs);
   std::vector<stan::math::var>  Omega_unconstrained_vec_var(n_corrs, 0.0);
   Omega_unconstrained_vec_var = eigen_vec_to_std_vec_var(theta_corrs_var);
   
   // coeffs
   Eigen::Matrix<stan::math::var, -1, -1 >  beta_all_tests_class_var = mat_out_test_var(n_class, n_tests);
   
   {
     int i = n_us + n_corrs;
     for (int c = 0; c < n_class; ++c) {
       for (int t = 0; t < n_tests; ++t) {
         beta_all_tests_class_var(c,t) = theta_var(i);
         i = i + 1;
       }
     }
   }
   
   // prev
   stan::math::var u_prev_diseased_var = theta_var(n_params-1);
   
   
   ////////////////// u (double / manual diff)
   // constrained u
   std::vector<stan::math::var>  u_vec_var = eigen_vec_to_std_vec_var(u_unconstrained_vec_var);
   stan::math::var log_jac_u = 0.0;
   
   for (int i = 0; i < n_us; ++i) {
     
     stan::math::var exp_uu = stan::math::exp(u_unconstrained_vec_var[i]);
     stan::math::var  exp_m_uu = stan::math::exp(- u_unconstrained_vec_var[i]);
     
     stan::math::var   tanh_uu  =  ((exp_uu - exp_m_uu) / (exp_uu + exp_m_uu));
     
     u_vec_var[i] = 0.5 * ( tanh_uu  + 1);
     
     stan::math::var tanh_uu_deriv  = (1 - tanh_uu  *  tanh_uu  );
     stan::math::var tanh_uu_second_deriv  = -2 * tanh_uu  * tanh_uu_deriv;
     
     stan::math::var  deriv_u_wrt_uu_double  = 0.5 *  tanh_uu_deriv;
     
     log_jac_u +=   +  stan::math::log(  deriv_u_wrt_uu_double  );
     
   }
   
   
   
   ///////////////// get cholesky factor's (lower-triangular) of corr matrices
   ////// first need to convert Omega_unconstrained to var
   // then convert to 3d var array
   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > Omega_unconstrained_var = fn_convert_std_vec_of_corrs_to_3d_array_var(Omega_unconstrained_vec_var,
                                                                                                                               n_tests,
                                                                                                                               n_class);
   
   
   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > L_Omega_var = vec_of_mats_test_var(n_tests, n_tests, n_class);
   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  Omega_var  = vec_of_mats_test_var(n_tests, n_tests, n_class);
   
   
   for (int c = 0; c < n_class; ++c) {
     
     Eigen::Matrix<stan::math::var, -1, -1 >  ub = stan::math::to_var(ub_corr[c]);
     Eigen::Matrix<stan::math::var, -1, -1 >  lb = stan::math::to_var(lb_corr[c]);
     
     // if (Spinkney_param == 1) { 
     //   Eigen::Matrix<stan::math::var, -1, -1  >  Chol_Schur_outs =  Spinkney_cholesky_corr_transform_opt(n_tests, lb, ub, Omega_unconstrained_var[c], known_values_indicator[c], known_values[c]) ;
     //   L_Omega_var[c]   =  Chol_Schur_outs.block(1, 0, n_tests, n_tests);  // stan::math::cholesky_decompose( Omega_var[c]) ;
     //   target +=   Chol_Schur_outs(0, 0); // now can set prior directly on Omega
     // }
     // if (Spinkney_param == 2)  {
       Eigen::Matrix<stan::math::var, -1, -1  >  Chol_Schur_outs =  Spinkney_LDL_bounds_opt(n_tests, lb, ub, Omega_unconstrained_var[c], known_values_indicator[c], known_values[c]) ;
       L_Omega_var[c]   =  Chol_Schur_outs.block(1, 0, n_tests, n_tests);  // stan::math::cholesky_decompose( Omega_var[c]) ;
       target +=   Chol_Schur_outs(0, 0); // now can set prior directly on Omega
     // }
     
     Omega_var[c] =   L_Omega_var[c] * L_Omega_var[c].transpose() ;
     
   }
   
   
   
   
   // std::vector<stan::math::var> Omega_constrained_vec_var = fn_convert_3d_array_of_corrs_to_std_vec_var(Omega_var,
   //                                                                                                      n_tests,
   //                                                                                                      n_class);
   // 
   // Eigen::Matrix<stan::math::var, -1, 1  > L_Omega_inc_diag_constrained_vec_var =    Eigen::Matrix<stan::math::var, -1, 1  >::Zero(n_tests * (n_tests - 1) * 0.5 + n_tests);
   // 
   // int counter = 0;
   // for (int t1 = 0; t1 < n_tests; ++t1) {
   //   for (int t2 = 0; t2 < t1 + 1; ++t2) {
   //     L_Omega_inc_diag_constrained_vec_var(counter) = L_Omega_var[0](t1, t2) ;
   //     counter += 1;
   //   }
   // }
   
   // make prev var variable
   std::vector<stan::math::var> 	 u_prev_var_vec(n_class, 0.0);
   std::vector<stan::math::var> 	 prev_var_vec(n_class, 0.0);
   std::vector<stan::math::var> 	 tanh_u_prev(n_class, 0.0);
   Eigen::Matrix<stan::math::var, -1, -1>	 prev(1, n_class);
   
   u_prev_var_vec[1] = u_prev_diseased_var; //  stan::math::to_var(u_prev_diseased);
   
   stan::math::var exp_2_x_u_prev = stan::math::exp(2*u_prev_var_vec[1] ) ;
   
   tanh_u_prev[1] = ( exp_2_x_u_prev - 1 ) / ( exp_2_x_u_prev + 1 ) ;
   
   u_prev_var_vec[0] =   0.5 * stan::math::log( (1 + ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) )  ;
   
   tanh_u_prev[0] = (stan::math::exp(2*u_prev_var_vec[0] ) - 1) / (stan::math::exp(2*u_prev_var_vec[0] ) + 1) ;
   
   prev_var_vec[1] = 0.5 * ( tanh_u_prev[1] + 1);
   prev_var_vec[0] =  0.5 * ( tanh_u_prev[0] + 1);
   prev(0,1) =  prev_var_vec[1];
   prev(0,0) =  prev_var_vec[0];
   
   target += stan::math::beta_lpdf(  prev(0,1),  prev_prior_a, prev_prior_b  );
   
   //u_prev_var_vec[1] =   0.5 * stan::math::log( (1 + (prev_var_vec[1]*2 - 1) ) / (1 - (prev_var_vec[1]*2 - 1) ) )  ;
   
   stan::math::var tanh_pu_deriv = ( 1 - tanh_u_prev[1] * tanh_u_prev[1]  );
   stan::math::var tanh_pu_second_deriv  = -2 * tanh_u_prev[1]  * tanh_pu_deriv;
   
   stan::math::var deriv_p_wrt_pu_double = 0.5 *  tanh_pu_deriv;
   
   stan::math::var log_jac_p_deriv_wrt_pu  = ( 1 / deriv_p_wrt_pu_double) * 0.5 * tanh_pu_second_deriv; // for gradient of u's
   stan::math::var log_jac_p =    stan::math::log( deriv_p_wrt_pu_double );
   
   
   
   ///////////////////////////////////////////////////////////////////////// prior densities
   ///////////////////// priors for coeffs
   for (int c = 0; c < n_class; c++) {
     for (int t = 0; t < n_tests; t++) {
       target +=      - 0.9189385  - stan::math::log(prior_coeffs_sd(t,c)) - 0.5 * ( (beta_all_tests_class_var(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) *
         ( (beta_all_tests_class_var(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) )  ;
     }
   }
   
   
   
   target +=  stan::math::lkj_corr_cholesky_lpdf(L_Omega_var[0], lkj_cholesky_eta(0)) ;
   target +=  stan::math::lkj_corr_cholesky_lpdf(L_Omega_var[1], lkj_cholesky_eta(1)) ;
   
   
   
   /////////////////////////////////////////////////////////////////////////////////////////////////////
   ///////// likelihood
   //  stan::math::var log_prob_out = 0.0;
   
   
   Eigen::Matrix<stan::math::var, -1, -1>	 y1(n_tests, n_class);
   Eigen::Matrix<stan::math::var, -1, -1>	 Z_std_norm_var(n_tests, n_class);
   Eigen::Matrix<stan::math::var, -1, -1>	 inc(n_class, 1); // col vec (initialised at 0)
   Eigen::Matrix<stan::math::var, -1, 1>	 lp(n_class); // colvec
   Eigen::Matrix<stan::math::var, -1, -1>	 u_array(N, n_tests);
   
   int i = 0;
   for (int n = 0; n < N; n++ ) {
     for (int t = 0; t < n_tests; t++) {
       u_array(n, t) = u_vec_var[i];
       i = i + 1;
     }
   }
   
   
   //  if (prior_only == false) {
   for (int n = 0; n < N; n++ ) {
     
     
     for (int c = 0; c < n_class; c++) {
       inc(c, 0) = 0;
     }
     
     
     for (int t = 0; t < n_tests; t++) {
       
       int index = y(n,t);
       
       for (int c = 0; c < n_class; c++) {
         
         
         if (CI == true) {
           L_Omega_var[c](t,t) = 1;
           inc(c, 0)  = 0;
         }
         
         stan::math::var bound_bin = 0.0;
         stan::math::var stuff = 0.0;
         
         stuff = ( ((  0 - ( beta_all_tests_class_var(c,t) + inc(c, 0)   )  ) / L_Omega_var[c](t,t) )  );
         
         if (Phi_type == 3) { // mixed type (stable and accurate but slower)
           if  (stan::math::abs(stuff) < 5)   {
             bound_bin = stan::math::Phi( stuff );
           } else  {
             bound_bin = stan::math::inv_logit( 1.702 *  stuff );
           }
         } else if (Phi_type == 2) { // rough_approx (very stable but less accurate + efficient)
           bound_bin = stan::math::inv_logit( 1.702 * stuff );
         } else if (Phi_type == 1) {  // standard Phi (less stable but most accurate + efficient)
           bound_bin = stan::math::Phi( 1.702 * stuff );
         }
         
         
         
         stan::math::var Phi_Z_var  = 0.0;
         
         if (index == 1) {
           y1(t,c) = stan::math::log1m(bound_bin);
           Phi_Z_var  = bound_bin + (1 - bound_bin) * u_array(n, t);
         } else { // y == 0
           y1(t,c) = stan::math::log(bound_bin);
           Phi_Z_var  =  bound_bin * u_array(n, t);
         }
         
         
         if (Phi_type == 3) {  // mixed type (stable and accurate but slower)
             if  (stan::math::abs(stuff) < 5)   Z_std_norm_var(t, c) =  stan::math::inv_Phi(Phi_Z_var) ;
             else    Z_std_norm_var(t, c) =  stan::math::logit(Phi_Z_var) / 1.702 ;
         } else if (Phi_type == 2) {  // rough_approx (very stable but less accurate + efficient)
             Z_std_norm_var(t, c) =  stan::math::logit(Phi_Z_var) / 1.702 ;
         } else if (Phi_type == 1) {  // standard Phi (less stable but most accurate + efficient)
             Z_std_norm_var(t, c) =  stan::math::inv_Phi(Phi_Z_var) ;
         }
         
         
         if (CI == false) {
           if (t < n_tests - 1) {
             inc(c,0)  = (L_Omega_var[c].row(t+1).head(t+1) * Z_std_norm_var.col(c).head(t+1)).eval()(0,0);
           }
         }
         
         
         
         
       } // end of c loop
       
     } // end of t loop
     
     
     for (int c = 0; c < n_class; c++) {
       lp(c) = y1.colwise().sum().eval()(0,c) +  log(prev(0,c)) ;
     }
     
     stan::math::var log_posterior = stan::math::log_sum_exp(lp);
     
     target += log_posterior;
     
   } // end of n loop
   // }
   
   
   // if (prior_only == false)   target +=  log_jac_u;
   // if (prior_only == false)   target +=  log_jac_p;
   
   target +=  log_jac_u;
   target +=  log_jac_p;
   
   // corr_force_positive
   auto log_prob = target.val();
   
   //////////////////// calculate gradients
   
   ///// gradients
   std::vector<stan::math::var> theta_grad;
   
   for (int i = 0; i < n_params; i++) {
     theta_grad.push_back(theta_var_std[i]);    // Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
   }
   
   // for (int i = 0; i < 15; i++) {
   //   theta_grad.push_back( L_Omega_inc_diag_constrained_vec_var(i) );    // Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
   // }
   
   std::vector<double> gradient_std_vec;
   
   target.grad(theta_grad, gradient_std_vec);
   stan::math::recover_memory();
   
   Eigen::Matrix<double, -1, 1>  gradient_vec(n_params);
   //  Eigen::Matrix<double, -1, 1>  gradient_vec(15);
   
   gradient_vec = std_vec_to_eigen_vec(gradient_std_vec);
   
   //////////////// output
   Eigen::Matrix<double, -1, 1> out_mat  =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N) ;  // mat of zero's
   
   out_mat.segment(1, n_params) = gradient_vec.col(0);
   // out_mat.segment(1 + n_us, 15) = gradient_vec.col(0);
   out_mat(0) = log_prob;
   
   
   return(out_mat);
   
   
   
   
 }
 
 
 
 
 
 
 
 
 

// [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1 >    fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float(  Eigen::Matrix<double, -1, 1  > theta,
                                                                                          Eigen::Matrix<int, -1, -1>	 y,
                                                                                          Rcpp::List other_args

                                                                                              
 ) {




  bool exclude_priors = other_args(0); //////////
  // int lkj_prior_method = other_args(1);
 //  bool grad_main = other_args(2);
  // bool grad_nuisance = other_args(3);
   bool CI = other_args(4); //////////
 //  bool rough_approx = other_args(5);
 //  bool homog_corr = other_args(6);
 //  bool lkj_cholesky= other_args(7);
   Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta = other_args(8); //////////
    Eigen::Matrix<double, -1, -1> prior_coeffs_mean = other_args(9); //////////
   Eigen::Matrix<double, -1, -1> prior_coeffs_sd = other_args(10); //////////
    int n_class = other_args(11); //////////
   int n_tests = other_args(12); //////////


   //bool Phi_exact_indicator_if_not_using_rough_approx = other_args(16);
  // int lb_threshold_phi_approx = other_args(17);
   int ub_threshold_phi_approx = other_args(18); //////////

   int n_chunks = other_args(26); //////////

   int N = y.rows();
   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
   int n_coeffs = n_class * n_tests * 1;
   int n_us =  1 *  N * n_tests;

   int n_params = theta.rows() ; // n_corrs + n_coeffs + n_us + n_class;
   int n_params_main = n_params - n_us;

   bool corr_force_positive = other_args(29); ///////////
 
   std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a =  other_args(49); //////////
   std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b =  other_args(50); //////////


    bool corr_prior_beta =  other_args(56); //////////
   bool corr_prior_norm =  other_args(57); //////////

   std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr =   other_args(64); //////////
   std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr =   other_args(65); //////////


   std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator =  other_args(72); //////////
    std::vector<Eigen::Matrix<double, -1, -1 > >   known_values  =  other_args(73); //////////

   double prev_prior_a = other_args(80); //////////
    double prev_prior_b = other_args(81); //////////

 // Eigen::Matrix<int, -1, -1>  y_sign = other_args(100);

   bool CDA =  other_args(105); //////////
   Eigen::Matrix<double, -1, -1>  CDA_r =  other_args(106);   //////////
   Eigen::Matrix<double, -1, -1>  CDA_b =  other_args(107);  //////////


   // corrs
   Eigen::Matrix<double, -1, 1  >  Omega_raw_vec_double = theta.segment(n_us, n_corrs);

   Eigen::Matrix<stan::math::var, -1, 1  >  Omega_raw_vec_var =  stan::math::to_var(Omega_raw_vec_double) ;
   Eigen::Matrix<stan::math::var, -1, 1  >  Omega_constrained_raw_vec_var =  Eigen::Matrix<stan::math::var, -1, 1  >::Zero(n_corrs) ;

   Omega_constrained_raw_vec_var = ( (Omega_raw_vec_var)); // no transformation for Nump needed! done later on



   // coeffs
   Eigen::Matrix<double, -1, -1  > beta_double_array(n_class, n_tests);

   {
     int i = n_us + n_corrs;
     for (int c = 0; c < n_class; ++c) {
       for (int t = 0; t < n_tests; ++t) {
         beta_double_array(c, t) = theta(i);
         i = i + 1;
       }
     }
   }


   // prev
   double u_prev_diseased = (double) theta(n_params - 1);

   ////////////////// u (double / manual diff)
   Eigen::Matrix<double, -1, 1 > tanh_uu =    theta.head(n_us).array().tanh() ;   ///////////////////////
 //  Eigen::Matrix<double, -1, -1 > tanh_uu_mat =  ( Eigen::Map<Eigen::Matrix<double, -1, -1>>( tanh_uu.data(), N, n_tests) ) ; ///////////////////////

     double log_jac_u  =   +   (  0.5 *   (1 -  ( tanh_uu.array()   *  tanh_uu.array()   ) )   ).log().matrix().sum();


   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > Omega_unconstrained_var = fn_convert_std_vec_of_corrs_to_3d_array_var( eigen_vec_to_std_vec_var(Omega_constrained_raw_vec_var),
                                                                                                                                n_tests,
                                                                                                                                n_class);


   for (int t = 0; t < n_tests; ++t) {
        for (int c = 0; c < n_class; ++c) {
                if (CDA == false) {
                    CDA_b(c, t) = 0;
                    CDA_r(c, t) = 1;
                }

                beta_double_array(c, t) +=  CDA_b(c, t);
        }
   }

   int dim_choose_2 = n_tests * (n_tests - 1) * 0.5 ;

   stan::math::var target_AD = 0.0;

   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > L_Omega_var_copy = vec_of_mats_test_var(n_tests, n_tests, n_class);
   std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  Omega_var_copy  = vec_of_mats_test_var(n_tests, n_tests, n_class);

   for (int c = 0; c < n_class; ++c) {
       Eigen::Matrix<stan::math::var, -1, -1 >  ub = stan::math::to_var(ub_corr[c]);
       Eigen::Matrix<stan::math::var, -1, -1 >  lb = stan::math::to_var(lb_corr[c]);

       Eigen::Matrix<stan::math::var, -1, -1  >  Chol_Schur_outs =  Spinkney_LDL_bounds_opt(n_tests, lb, ub, Omega_unconstrained_var[c], known_values_indicator[c], known_values[c]) ; //   Omega_unconstrained_var[c], n_tests, tol )  ;

       L_Omega_var_copy[c]   =  Chol_Schur_outs.block(1, 0, n_tests, n_tests);
       Omega_var_copy[c] =   L_Omega_var_copy[c] * L_Omega_var_copy[c].transpose() ;

       if (CDA == true) {
           Omega_var_copy[c] = stan::math::diag_matrix( stan::math::sqrt( stan::math::to_var(CDA_r).row(c) ) ) *   Omega_var_copy[c] *   stan::math::diag_matrix( stan::math::sqrt( stan::math::to_var(CDA_r).row(c) ) ) ;
           L_Omega_var_copy[c]   = stan::math::cholesky_decompose(     Omega_var_copy[c]   );
       }

       target_AD +=   Chol_Schur_outs(0, 0); // now can set prior directly on Omega
   }



   for (int c = 0; c < n_class; ++c) {
     if ( (corr_prior_beta == false)   &&  (corr_prior_norm == false) ) {
       target_AD +=  stan::math::lkj_corr_cholesky_lpdf(L_Omega_var_copy[c], lkj_cholesky_eta(c)) ;
     } else if ( (corr_prior_beta == true)   &&  (corr_prior_norm == false) ) {
       for (int i = 1; i < n_tests; i++) {
         for (int j = 0; j < i; j++) {
           target_AD +=  stan::math::beta_lpdf(  (Omega_var_copy[c](i, j) + 1)/2, prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
         }
       }
       //  Jacobian for  Omega -> L_Omega transformation for prior log-densities (since both LKJ and truncated normal prior densities are in terms of Omega, not L_Omega)
       Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
       for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * log(L_Omega_var_copy[c](i, i));
       target_AD  += + (n_tests * stan::math::log(2) + jacobian_diag_elements.sum());  //  L -> Omega
     } else if  ( (corr_prior_beta == false)   &&  (corr_prior_norm == true) ) {
       for (int i = 1; i < n_tests; i++) {
         for (int j = 0; j < i; j++) {
           target_AD +=  stan::math::normal_lpdf(  Omega_var_copy[c](i, j), prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
         }
       }
       Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
       for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * log(L_Omega_var_copy[c](i, i));
       target_AD  += + (n_tests * stan::math::log(2) + jacobian_diag_elements.sum());  //  L -> Omega
     }
   }



   /////////////  prev stuff  ---- vars
   std::vector<stan::math::var> 	 u_prev_var_vec_var(n_class, 0.0);
   std::vector<stan::math::var> 	 prev_var_vec_var(n_class, 0.0);
   std::vector<stan::math::var> 	 tanh_u_prev_var(n_class, 0.0);
   Eigen::Matrix<stan::math::var, -1, -1>	 prev_var(1, n_class);

   u_prev_var_vec_var[1] =  stan::math::to_var(u_prev_diseased);
   tanh_u_prev_var[1] = ( exp(2*u_prev_var_vec_var[1] ) - 1) / ( exp(2*u_prev_var_vec_var[1] ) + 1) ;
   u_prev_var_vec_var[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1) ) )  ;
   tanh_u_prev_var[0] = (exp(2*u_prev_var_vec_var[0] ) - 1) / ( exp(2*u_prev_var_vec_var[0] ) + 1) ;

   prev_var_vec_var[1] = 0.5 * ( tanh_u_prev_var[1] + 1);
   prev_var_vec_var[0] =  0.5 * ( tanh_u_prev_var[0] + 1);
   prev_var(0,1) =  prev_var_vec_var[1];
   prev_var(0,0) =  prev_var_vec_var[0];



   target_AD += beta_lpdf(  prev_var(0,1), prev_prior_a, prev_prior_b  ); // weakly informative prior - helps avoid boundaries with slight negative skew (for lower N)

   Eigen::Matrix<double, -1, 1 >  target_AD_grad(n_corrs);

   ///////////////////////
   stan::math::set_zero_all_adjoints();
   target_AD.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
   target_AD_grad =  Omega_raw_vec_var.adj();    // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
   stan::math::set_zero_all_adjoints();
   //////////////////////////////////////////////////////////// end of AD part



   std::vector<Eigen::Matrix<double, -1, -1 > > deriv_L_wrt_unc_full = vec_of_mats_test(dim_choose_2 + n_tests, dim_choose_2, n_class);

   for (int c = 0; c < n_class; ++c) {
     int cnt_1 = 0;
     for (int k = 0; k < n_tests; k++) {
       for (int l = 0; l < k + 1; l++) {
         (  L_Omega_var_copy[c](k, l)).grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
         int cnt_2 = 0;
         for (int i = 1; i < n_tests; i++) {
           for (int j = 0; j < i; j++) {
             deriv_L_wrt_unc_full[c](cnt_1, cnt_2)  =   Omega_unconstrained_var[c](i, j).adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
             cnt_2 += 1;
           }
         }
         stan::math::set_zero_all_adjoints();
         cnt_1 += 1;
       }
     }
   }

   ///////////////// get cholesky factor's (lower-triangular) of corr matrices
   // convert to 3d var array
   std::vector<Eigen::Matrix<double, -1, -1 > > L_Omega_var_double = vec_of_mats_test(n_tests, n_tests, n_class);

   for (int c = 0; c < n_class; ++c) {
     for (int t1 = 0; t1 < n_tests; ++t1) {
       for (int t2 = 0; t2 < n_tests; ++t2) {
         L_Omega_var_double[c](t1, t2) =   L_Omega_var_copy[c](t1, t2).val()  ;
       }
     }
   }


   /////////////  prev stuff
   std::vector<double> 	 u_prev_var_vec(n_class, 0.0);
   std::vector<double> 	 prev_var_vec(n_class, 0.0);
   std::vector<double> 	 tanh_u_prev(n_class, 0.0);
   Eigen::Matrix<double, -1, -1>	 prev(1, n_class);

   u_prev_var_vec[1] =  (double) u_prev_diseased ;
   tanh_u_prev[1] = ( exp(2*u_prev_var_vec[1] ) - 1) / ( exp(2*u_prev_var_vec[1] ) + 1) ;
   u_prev_var_vec[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) )  ;
   tanh_u_prev[0] = (exp(2*u_prev_var_vec[0] ) - 1) / ( exp(2*u_prev_var_vec[0] ) + 1) ;

   prev_var_vec[1] = 0.5 * ( tanh_u_prev[1] + 1);
   prev_var_vec[0] =  0.5 * ( tanh_u_prev[0] + 1);
   prev(0,1) =  prev_var_vec[1];
   prev(0,0) =  prev_var_vec[0];


   double tanh_pu_deriv = ( 1 - tanh_u_prev[1] * tanh_u_prev[1]  );
   double deriv_p_wrt_pu_double = 0.5 *  tanh_pu_deriv;
   double tanh_pu_second_deriv  = -2 * tanh_u_prev[1]  * tanh_pu_deriv;
   double log_jac_p_deriv_wrt_pu  = ( 1 / deriv_p_wrt_pu_double) * 0.5 * tanh_pu_second_deriv; // for gradient of u's
   double  log_jac_p =    log( deriv_p_wrt_pu_double );



   ///////////////////////////////////////////////////////////////////////// prior densities
   double prior_densities = 0.0;


   if (exclude_priors == false) {
     ///////////////////// priors for coeffs
     double prior_densities_coeffs = 0.0;
     for (int c = 0; c < n_class; c++) {
       for (int t = 0; t < n_tests; t++) {
         double num_1 = 0.9189385;
         prior_densities_coeffs  +=  - num_1 - log(prior_coeffs_sd(t,c)) - 0.5 * ( (beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) *   ( (beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) )  ;
       }
     }
     double prior_densities_corrs = target_AD.val();
     prior_densities = prior_densities_coeffs  +      prior_densities_corrs ;     // total prior densities and Jacobian adjustments
   }


   /////////////////////////////////////////////////////////////////////////////////////////////////////
   ///////// likelihood
   double s = 1/1.702;
   double sqrt_2_recip = 1 / stan::math::sqrt(2);

   int chunk_counter = 0;
   int chunk_size  = std::round( N / n_chunks  / 2) * 2;  ; // N / n_chunks;


   double log_prob_out = 0.0;


   Eigen::Matrix<double, -1, -1 >  log_prev = prev;

   for (int c = 0; c < n_class; c++) {
     log_prev(0,c) =  log(prev(0,c));
     for (int t = 0; t < n_tests; t++) {
       if (CI == true)      L_Omega_var_double[c](t,t) = 1;
     }
   }



   ////////////////////////////////////////////////////////////////////////
   Eigen::Matrix<double, -1, 1> out_mat    =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N);     //////////////// output vec    //////////////////////////////////////////////////  definitely fine as float
          out_mat.segment(1 + n_us, n_corrs) = target_AD_grad.cast<double>();
   Eigen::Matrix<double, -1, -1> u_grad_array   =  Eigen::Matrix<double, -1, -1>::Zero(N, n_tests);    //////////////////////////////////////////////////  definitely fine as float
   Eigen::Matrix<double, -1, 1 >  log_lik   =   Eigen::Matrix<double, -1, 1>::Zero(N);   ////////////////////////////////////////////////// definitely fine as float
   ////////////////////////////////////////////////////////////////////////


   ///////////////////////////////////////////////
   Eigen::Matrix< double , -1, 1>  beta_grad_vec   =  Eigen::Matrix<double, -1, 1>::Zero(n_coeffs);  //
   Eigen::Matrix<double, -1, -1>   beta_grad_array  =  Eigen::Matrix<double, -1, -1>::Zero(n_class, n_tests); //
   std::vector<Eigen::Matrix<double, -1, -1 > > U_Omega_grad_array =  vec_of_mats_test(n_tests, n_tests, n_class); //
   Eigen::Matrix<double, -1, 1 > L_Omega_grad_vec(n_corrs + (n_class * n_tests)); //
   Eigen::Matrix<double, -1, 1 > U_Omega_grad_vec(n_corrs); //
   Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(n_class); //
   Eigen::Matrix<double, -1, 1>  prev_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(n_class); //
   Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec_out =   Eigen::Matrix<double, -1, 1>::Zero(n_class - 1); //
   ///////////////////////////////////////////////

   Eigen::Matrix<double, -1, -1>   lp_array  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_class);//////
   Eigen::Matrix<int, -1, -1>  y_sign_chunk  =  Eigen::Matrix<int, -1, -1>::Zero(chunk_size, n_tests); /////


   ///////////////////////////////////////////////
   std::vector<Eigen::Matrix<double, -1, -1 > >  prob   = vec_of_mats_test(chunk_size, n_tests, n_class); //////////////////////////////
   std::vector<Eigen::Matrix<double, -1, -1 > >  Z_std_norm =  vec_of_mats_test(chunk_size, n_tests, n_class); //////////////////////////////
   std::vector<Eigen::Matrix<double, -1, -1 > >  Bound_Z =  vec_of_mats_test(chunk_size, n_tests, n_class); //////////////////////////////
   ///////////////////////////////////////////////



   ///////////////////////////////////////////////
  // Eigen::Matrix<double, -1, -1>  Bound_Z =   Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;
   Eigen::Matrix<double, -1, -1>  y_m_ysign_x_u_array =   Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;
   Eigen::Matrix<double, -1, -1> y1_or_phi_Bound_Z =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   Eigen::Matrix<double, -1, -1> phi_Z_or_u_array = Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   Eigen::Matrix<double, -1, -1> common_grad_term_1   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   Eigen::Matrix<double, -1, -1> grad_prob =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   Eigen::Matrix<double, -1, -1> z_grad_term = Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   Eigen::Matrix<double, -1, -1 >    Phi_Z_temp   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;
   Eigen::Matrix<double, -1, -1 >    Bound_U_Bound_Phi_Z_temp   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   Eigen::Matrix<double, -1, -1 >    prop_rowwise_prod_temp   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 //  Eigen::Matrix<double, -1, -1 > tanh_uu_chunk =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size,  n_tests);
   Eigen::Array<double, -1, -1 >    Array_of_ones   = Eigen::Array<int, -1, -1>::Ones(chunk_size, n_tests);
   Eigen::Matrix<double, -1, -1 >    y_m_ysign_x_u_array_times_phi_Z   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   Eigen::Matrix<double, -1, -1 >    y_sign_chunk_times_phi_Bound_Z   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   ///////////////////////////////////////////////



   ///////////////////////////////////////////////
   Eigen::Matrix<double, -1, 1> prop_rowwise_prod_temp_all  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
   Eigen::Matrix<double, -1, 1> derivs_chain_container_vec  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
   Eigen::Matrix<double, -1, 1> prod_container_or_inc_array  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
   Eigen::Matrix<double, -1, 1> prob_n  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
   Eigen::Matrix<double, -1, 1> grad_bound_z = Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
   Eigen::Matrix<double, -1, 1> grad_Phi_bound_z = Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
   ///////////////////////////////////////////////



   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   int iiii = 0;
   int iiiiii = 0;
   double sqrt_2_pi_recip =   1 / sqrt(2 * M_PI) ; //  0.3989422804;



   ////////////////// u (double / manual diff)
  // Eigen::Matrix<double, -1, 1 > tanh_uu =    theta.head(n_us).array().tanh() ;   ///////////////////////
   //  Eigen::Matrix<double, -1, -1 > tanh_uu_mat =  ( Eigen::Map<Eigen::Matrix<double, -1, -1>>( tanh_uu.data(), N, n_tests) ) ; ///////////////////////

 //  double log_jac_u  =  0 ; //  +   (  0.5 *   (1 -  ( tanh_uu.array()   *  tanh_uu.array()   ) )   ).log().matrix().sum();




   for (int nc = 0; nc < n_chunks; nc++) {

             //
             // for (int t = 0; t < n_tests; t++) {
             //         tanh_uu_chunk.col(t).array() = theta.segment(n_tests * chunk_size * chunk_counter, n_tests * chunk_size).array().tanh() ;
             // }
             //
             // log_jac_u += (  0.5 *   (1 -  ( tanh_uu_chunk.array()   *  tanh_uu_chunk.array()   ) )   ).log().matrix().sum();
             //

           //  phi_Z_or_u_array = 0.5 * ( tanh_uu_chunk.array() + 1) ;


             for (int nc_index = 0; nc_index < chunk_size; nc_index++ ) {
                       for (int t = 0; t < n_tests; t++) {
                         phi_Z_or_u_array(nc_index, t) =   0.5 * ( tanh_uu(iiii) + 1) ;
                         iiii = iiii + 1;
                       }
             }
             
           // for (int t = 0; t < n_tests; t++) {
           //   // if (chunk_counter == 0)  phi_Z_or_u_array.col(t) =   ( 0.5 * ( tanh_uu.array() + 1 ) ).segment(0, chunk_size);
           //   // else                     phi_Z_or_u_array.col(t) =   ( 0.5 * ( tanh_uu.array() + 1 ) ).segment( (chunk_size * chunk_counter * t) - 1, chunk_size);
           //   for (int nc_index = 0; nc_index < chunk_size; nc_index++ ) {
           //       phi_Z_or_u_array(nc_index, t) =   0.5 * ( tanh_uu(iiii) + 1) ;
           //       iiii = iiii + 1;
           //     }
           //   }


                y_sign_chunk.array() =     Eigen::Select(  y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array()  == 1, Array_of_ones, - Array_of_ones) ;

                y_m_ysign_x_u_array.array()  =   ( (  (   y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array()   - y_sign_chunk.array()    *  phi_Z_or_u_array.array()    ).array() ) ) ; //////// checked
                  
                  

             for (int c = 0; c < n_class; c++) {

                          prod_container_or_inc_array.array()  = 0;
                          Phi_Z_temp.array()    =   0;
                          Bound_U_Bound_Phi_Z_temp.array()    =   0;
                          y1_or_phi_Bound_Z.array()    =   0;

                       for (int t = 0; t < n_tests; t++) {

                                   Bound_Z[c].col(t).array() =   ( ((  - ( beta_double_array(c, t) +      prod_container_or_inc_array.array()   )  ) / L_Omega_var_double[c](t, t) )  )  ;
                    
                                   Bound_U_Bound_Phi_Z_temp.col(t).array() =  Eigen::Select(  Bound_Z[c].col(t).array().abs() < ub_threshold_phi_approx  ,
                                                                0.5 *  ( -  sqrt_2_recip * Bound_Z[c].col(t).array() ).erfc().array()   ,
                                                                ( stan::math::inv_logit(  1.702 *  Bound_Z[c].col(t) )  ).array()          )  ; //////// checked
                                   

                                   Phi_Z_temp.col(t).array()    =     y.col(t).segment(chunk_size * chunk_counter, chunk_size).array()  *       Bound_U_Bound_Phi_Z_temp.col(t).array() +
                                                                    (  y.col(t).segment(chunk_size * chunk_counter, chunk_size).array()  -   Bound_U_Bound_Phi_Z_temp.col(t).array() ) * y_sign_chunk.col(t).array() * phi_Z_or_u_array.col(t).array()  ;  //////// checked

                                   y1_or_phi_Bound_Z.col(t).array() =  Eigen::Select(  y.col(t).segment(chunk_size * chunk_counter, chunk_size).array()   == 1,
                                                         stan::math::log1m(     Bound_U_Bound_Phi_Z_temp.col(t)   ).array()  ,
                                                         Bound_U_Bound_Phi_Z_temp.col(t).array().log()     ) ; //////// checked
                                   
                  
                                   Z_std_norm[c].col(t).array() =    Eigen::Select(   Bound_Z[c].col(t).array().abs() < ub_threshold_phi_approx ,
                                                     (  stan::math::inv_Phi(  Phi_Z_temp.col(t)    )    ).array()    ,
                                                     (  stan::math::logit(    Phi_Z_temp.col(t)   )   * s ).array()      ) ; //////// checked
                                   


                                   if (t < n_tests - 1)       prod_container_or_inc_array.array()  =   ( Z_std_norm[c].block(0, 0, chunk_size, t + 1)  *   ( L_Omega_var_double[c].row(t+1).head(t+1).transpose()  ) ) ; //////// checked

                          } // end of t loop

                       lp_array.col(c).array() =    y1_or_phi_Bound_Z.rowwise().sum().array() +  log_prev(0,c) ;


                       prob[c]  =      y1_or_phi_Bound_Z.array().exp() ; //////// checked
 
             } // end of c loop


             log_lik.segment(chunk_size * chunk_counter, chunk_size).array()   = (  lp_array.array().maxCoeff() + (lp_array.array() - lp_array.array().maxCoeff() ).array().exp().rowwise().sum().array().log() )  ;  //////// checked  //  log_sum_exp(lp);
             prob_n =   log_lik.segment(chunk_size * chunk_counter, chunk_size).array().exp().matrix();  //////// checked

       for (int c = 0; c < n_class; c++) {

               // for (int i = 0; i < n_tests - 1; i++) { // i goes from 1 to 3
               //   int t = n_tests - (i+2) ;
               //   prop_rowwise_prod_temp.col(t).array()   =   prob[c].block(0, t + 0, chunk_size, i + 2).rowwise().prod().array() ;
               // }
               
               for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
                 int t = n_tests - (i+1) ;
                 prop_rowwise_prod_temp.col(t).array()   =   prob[c].block(0, t + 0, chunk_size, i + 1).rowwise().prod().array() ;
               }
               
               prop_rowwise_prod_temp_all.array() = prob[c].block(0, 0, chunk_size, n_tests).rowwise().prod().array()  ; 
               

               for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
                 int t = n_tests - (i + 1) ;
               //   common_grad_term_1.col(t) =   (  ( prev(0,c) / prob_n.array() ) * ( prop_rowwise_prod_temp_all /  prob[c].block(0, t + 0, chunk_size, i + 1).rowwise().prod().array()  ).array() )  ;
                 common_grad_term_1.col(t) =   (  ( prev(0,c) / prob_n.array() ) * ( prop_rowwise_prod_temp_all.array() /  prop_rowwise_prod_temp.col(t).array()  ).array() )  ;
               }

               
               // for numerical stability
               phi_Z_or_u_array.array() =    Eigen::Select(   Bound_Z[c].array().abs() < ub_threshold_phi_approx ,
                                      sqrt_2_pi_recip *  ( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).exp().array()   ,
                                      1.702 * (1 / stan::math::square( stan::math::exp(Z_std_norm[c] * (1/(2*s)) ) + stan::math::exp( - Z_std_norm[c] *  (1/(2*s)) ) ).array()  ) ).array() ;
               
               // for numerical stability
               y1_or_phi_Bound_Z.array() =    Eigen::Select(   Bound_Z[c].array().abs() < ub_threshold_phi_approx ,
                                       sqrt_2_pi_recip *  ( - 0.5 * Bound_Z[c].array() *  Bound_Z[c].array() ).exp().array()   ,
                                       1.702 * (1 / stan::math::square( stan::math::exp(Bound_Z[c] *  (1/(2*s)) ) + stan::math::exp( - Bound_Z[c] *  (1/(2*s)) ) ).array()  ) ).array()  ;
               
               
               y_m_ysign_x_u_array_times_phi_Z.array() = y_m_ysign_x_u_array.array() * ( 1 /  phi_Z_or_u_array.array() );
               y_sign_chunk_times_phi_Bound_Z.array() =  y_sign_chunk.array() * y1_or_phi_Bound_Z.array() ;

            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grad of nuisance parameters / u's (manual)
             u_grad_array.col(n_tests - 1).segment( chunk_size * chunk_counter, chunk_size).array() = 0 ;//+  (  0.5 * (1 - tanh_uu_chunk.col(n_tests - 1).array() * tanh_uu_chunk.col(n_tests - 1).array()  )  - 2 * tanh_uu_chunk.col(n_tests - 1).array() )  ; //  tanh_uu_chunk.array()  ; // ----------   correct

             ///// then second-to-last term (test T - 1)
             int t = n_tests - 1;

             u_grad_array.col(n_tests - 2).segment( chunk_size * chunk_counter, chunk_size).array()  +=  (   common_grad_term_1.col(t).array()    *
                                                                                                           (  y_sign_chunk_times_phi_Bound_Z.col(t).array()   * (1 / L_Omega_var_double[c](t,t)  ) *  // lp(T)
                                                                                                             L_Omega_var_double[c](t, t - 1) * ( 1 / phi_Z_or_u_array.col(t-1).array()  )   * prob[c].col(t-1).array()  ).array() ) ;//  +
                                                                                                           //  (  0.5 * (1 - tanh_uu_chunk.col(n_tests - 2).array() * tanh_uu_chunk.col(n_tests - 2).array()  )  - 2 * tanh_uu_chunk.col(n_tests - 2).array() );
                                                                                                           
                                                                                                           
                                                                                                           
                 
                 // 
                 // { ///// then third-to-last term (test T - 2)
                 //     t = n_tests - 2;
                 //     
                 //     prod_container_or_inc_array.array() = 0;
                 //     grad_prob.array() = 0;
                 //     z_grad_term.array() = 0;
                 //     
                 //     z_grad_term.col(0).array() =  (1 / phi_Z_or_u_array.col(t-1).array())   * prob[c].col(t-1).array()   ;
                 //     grad_prob.col(0).array() =   (  y_sign_chunk.col(t).array()   *    y1_or_phi_Bound_Z.col(t).array() )   * ( (1 /  L_Omega_var_double[c](t,t)  ) *      L_Omega_var_double[c](t, t - 1) *    z_grad_term.col(0).array()    ) ;
                 //     z_grad_term.col(1).array()  =  ( (1 / phi_Z_or_u_array.col(t).array()  ) * y1_or_phi_Bound_Z.col(t).array() )  * ( (1 /  L_Omega_var_double[c](t,t)) ) *
                 //       ( L_Omega_var_double[c](t,t-1)   *    z_grad_term.col(0).array() ) *       y_m_ysign_x_u_array.col(t).array()   ;
                 //     
                 //     prod_container_or_inc_array.array()  =  (  z_grad_term.col(0).array()  *   L_Omega_var_double[c](t + 1,t - 1)  -   z_grad_term.col(1).array()   *  L_Omega_var_double[c](t+1,t)).array() ; 
                 //     
                 //     grad_prob.col(1).array()  =       y_sign_chunk.col(t + 1).array()    *   (   y1_or_phi_Bound_Z.col(t+1).array()    *  (1 /  L_Omega_var_double[c](t+1,t+1)  ) ).array() *   prod_container_or_inc_array.array()  ;
                 //     
                 //     u_grad_array.col(n_tests - 3).segment( chunk_size * chunk_counter, chunk_size).array()  +=  (    common_grad_term_1.col(t).array()   *
                 //       (  grad_prob.col(1).array()  * prob[c].col(t).array()  +      grad_prob.col(0).array()   *  prob[c].col(t+1).array()  ) ) ;//+ 
                 //     // (  0.5 * (1 - tanh_uu_chunk.col(n_tests - 3).array() * tanh_uu_chunk.col(n_tests - 3).array()  )  - 2 * tanh_uu_chunk.col(n_tests - 3).array() ) ; 
                 // }
                 // 
                 //                                                                                           
                                                                                                           

               { ///// then third-to-last term (test T - 2)
                 t = n_tests - 2;

                 prod_container_or_inc_array.array() = 0;
                 grad_prob.array() = 0;
                 z_grad_term.array() = 0;

                 z_grad_term.col(0).array() =  (1 / phi_Z_or_u_array.col(t-1).array())   * prob[c].col(t-1).array()   ;
                 
                 grad_prob.col(0).array() =   (  y_sign_chunk_times_phi_Bound_Z.col(t).array()   )   * ( (1 /  L_Omega_var_double[c](t,t)  ) *      L_Omega_var_double[c](t, t - 1) *    z_grad_term.col(0).array()    ) ;
                 
                 z_grad_term.col(1).array()  =  (  y1_or_phi_Bound_Z.col(t).array() )  * ( (1 /  L_Omega_var_double[c](t,t)) ) *
                                                     ( L_Omega_var_double[c](t,t-1)   *    z_grad_term.col(0).array() ) *       y_m_ysign_x_u_array_times_phi_Z.col(t).array()   ;

                 prod_container_or_inc_array.array()  =  (  z_grad_term.col(0).array()  *   L_Omega_var_double[c](t + 1,t - 1)  -   z_grad_term.col(1).array()   *  L_Omega_var_double[c](t+1,t)).array() ;

                 grad_prob.col(1).array()  =        (   y_sign_chunk_times_phi_Bound_Z.col(t+1).array()    *  (1 /  L_Omega_var_double[c](t+1,t+1)  ) ).array() *   prod_container_or_inc_array.array()  ;

                 u_grad_array.col(n_tests - 3).segment( chunk_size * chunk_counter, chunk_size).array()  +=  (    common_grad_term_1.col(t).array()   *
                                                                                                               (  grad_prob.col(1).array()  * prob[c].col(t).array()  +      grad_prob.col(0).array()   *  prob[c].col(t+1).array()  ) ) ;//+
                                                                                                              // (  0.5 * (1 - tanh_uu_chunk.col(n_tests - 3).array() * tanh_uu_chunk.col(n_tests - 3).array()  )  - 2 * tanh_uu_chunk.col(n_tests - 3).array() ) ;
               }

               // // then rest of terms
               for (int i = 1; i < n_tests - 2; i++) { // i goes from 1 to 3

                 grad_prob.array() = 0;
                 z_grad_term.array() = 0;


                   int t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)

                   z_grad_term.col(0) = (1 / phi_Z_or_u_array.col(t-1).array() )  * prob[c].col(t-1).array() ;
                   grad_prob.col(0) =         y_sign_chunk_times_phi_Bound_Z.col(t).array()  * (1 /   L_Omega_var_double[c](t,t)  ) *     L_Omega_var_double[c](t, t - 1) *   z_grad_term.col(0).array()   ;

                  // prod_container_or_inc_array.array()   =  0;
                  prod_container_or_inc_array.array()   = (   (z_grad_term.block(0, 0, chunk_size, 0 + 1) ) *  (fn_first_element_neg_rest_pos(  L_Omega_var_double[c].row( t + (0-1) + 1).segment(t - 1, 0 + 1))).transpose()   ).array()      ;
                  // prod_container_or_inc_array    = ( fn_first_element_neg_rest_pos(  L_Omega_var_double[c].row( t + (0-1) + 1).segment(t - 1, 0 + 1)).transpose() *  (z_grad_term.block(0, 0, chunk_size, 0 + 1).transpose()  ) ).transpose() ; 
                   
                     for (int ii = 0; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1 u_grad_z u_grad_term
                         z_grad_term.col(ii+1)  =   ( (1 /phi_Z_or_u_array.col( t+(ii-1)+1).array()   ).array() * y1_or_phi_Bound_Z.col(t+(ii-1)+1).array()   * (1 /   L_Omega_var_double[c](t+(ii-1)+1,t+(ii-1)+1))   *   y_m_ysign_x_u_array.col(t + ii).array()  *  -   prod_container_or_inc_array.array() )  ;
                       prod_container_or_inc_array  = (   (z_grad_term.block(0, 0, chunk_size, ii + 2) ) *  (fn_first_element_neg_rest_pos(  L_Omega_var_double[c].row( t + (ii) + 1).segment(t - 1, ii + 2))).transpose()   )      ;
                    //   prod_container_or_inc_array  =  ( (fn_first_element_neg_rest_pos(  L_Omega_var_double[c].row( t + (ii) + 1).segment(t - 1, ii + 2))) *     z_grad_term.block(0, 0, chunk_size, ii + 2).transpose() ).transpose() ; // *  (fn_first_element_neg_rest_pos(  L_Omega_var_double[c].row( t + (ii) + 1).segment(t - 1, ii + 2))).transpose()   )      ;
 
                         grad_prob.col(ii+1)  =    y_sign_chunk_times_phi_Bound_Z.col(t + ii + 1).array()   *   (    (1 /   L_Omega_var_double[c](t+ii+1,t+ii+1)  ) ) *     -    prod_container_or_inc_array.array()  ;
                     } // end of ii loop

                     derivs_chain_container_vec.array() = 0;

                     for (int ii = 0; ii < i + 2; ii++) {
                      derivs_chain_container_vec.array()  +=  ( grad_prob.col(ii).array()    * (       prop_rowwise_prod_temp.col(t).array() /  prob[c].col(t + ii).array()  ).array() ).array()  ;
                     }
                       u_grad_array.col(n_tests - (i+3)).segment( chunk_size * chunk_counter, chunk_size).array()  +=   ( (   common_grad_term_1.col(t).array()   *  derivs_chain_container_vec.array() ) ).array() ;

               }

       // }

  // for (int c = 0; c < n_class; c++) {
     // /////////////////////////////////////////////////////////////////////////// Grad of intercepts / coefficients (beta's)
         // ///// last term first (test T)

               grad_bound_z.array() = 0 ;
               grad_Phi_bound_z.array() = 0;
               z_grad_term.array() = 0 ;
               grad_prob.array() = 0;
 

 
 
     ///// last term first (test T)

    {
     int t = n_tests - 1;

     beta_grad_array(c, t) +=     (common_grad_term_1.col(t).array()  *   ( - y_sign_chunk.col(t).array()   * y1_or_phi_Bound_Z.col(t).array()  * ( - 1 / L_Omega_var_double[c](t,t)  ))).sum();

     ///// then second-to-last term (test T - 1)
     {
       t = n_tests - 2;
       grad_prob.col(0) =       (   -  y_sign_chunk_times_phi_Bound_Z.col(t).array() * (- 1 / L_Omega_var_double[c](t,t)  ) ) ;
       
       z_grad_term.col(1)   =      y_m_ysign_x_u_array_times_phi_Z.col(t).array() *   y1_or_phi_Bound_Z.col(t).array()  * (- 1 / L_Omega_var_double[c](t,t))     ;
       
       grad_prob.col(1)  =       ( - y_sign_chunk_times_phi_Bound_Z.col(t+1).array()    ) *  (     (- 1 / L_Omega_var_double[c](t+1,t+1)  ) ) * (   L_Omega_var_double[c](t + 1,t) *      z_grad_term.col(1).array() ) ;

       beta_grad_array(c, t) +=  (common_grad_term_1.col(t).array()   * ( grad_prob.col(1).array() * prob[c].col(t).array() +         grad_prob.col(0).array() *  prob[c].col(t+1).array() ) ).sum() ;
     }

     // then rest of terms
     for (int i = 1; i < n_tests - 1; i++) { // i goes from 1 to 3

       t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)

       grad_prob.col(0)  =    ( ( - y_sign_chunk_times_phi_Bound_Z.col(t).array()  )     * (- 1 / L_Omega_var_double[c](t,t)  ) ) ;


       // component 2 (second-to-earliest test)
       z_grad_term.col(1)  =        y_m_ysign_x_u_array_times_phi_Z.col(t).array() *    y1_or_phi_Bound_Z.col(t).array()  * (- 1 / L_Omega_var_double[c](t,t))    ;
       grad_prob.col(1) =        - y_sign_chunk_times_phi_Bound_Z.col(t + 1).array()   * (    (- 1 / L_Omega_var_double[c](t+1,t+1)  ) ) *    (   L_Omega_var_double[c](t + 1,t) *   z_grad_term.col(1).array() ) ;

       // rest of components
       for (int ii = 1; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1
    
             if (ii == 1)  prod_container_or_inc_array  = (    z_grad_term.block(0, 1, chunk_size, ii)  *   L_Omega_var_double[c].row( t + (ii - 1) + 1).segment(t + 0, ii + 0).transpose()  );
            // if (ii == 1)  prod_container_or_inc_array  =  ( L_Omega_var_double[c].row( t + (ii - 1) + 1).segment(t + 0, ii + 0) * z_grad_term.block(0, 1, chunk_size, ii) .transpose() ).transpose() ;
    
             z_grad_term.col(ii+1)  =        y_m_ysign_x_u_array_times_phi_Z.col(t + ii).array() *
                                               y1_or_phi_Bound_Z.col(t+(ii-1)+1).array() * (- 1 / L_Omega_var_double[c](t+(ii-1)+1,t+(ii-1)+1))  *   prod_container_or_inc_array.array();
    
            prod_container_or_inc_array  = (    z_grad_term.block(0, 1, chunk_size, ii + 1)  *   L_Omega_var_double[c].row( t + (ii) + 1).segment(t + 0, ii + 1).transpose()  );
           //  prod_container_or_inc_array  = (  L_Omega_var_double[c].row( t + (ii) + 1).segment(t + 0, ii + 1) *   z_grad_term.block(0, 1, chunk_size, ii + 1).transpose()  ).transpose();
    
             grad_prob.col(ii+1) =      (  - y_sign_chunk_times_phi_Bound_Z.col(t + ii + 1).array()  ).array() *   (    (- 1 / L_Omega_var_double[c](t+ii+1,t+ii+1)  ) )    *  prod_container_or_inc_array.array();

       }


                        derivs_chain_container_vec.array() = 0;

                        ///// attempt at vectorising  // bookmark
                        for (int ii = 0; ii < i + 2; ii++) {
                           derivs_chain_container_vec.array() +=  ( grad_prob.col(ii).array()  * (      prop_rowwise_prod_temp.col(t).array() /  prob[c].col(t + ii).array()  ).array() ).array() ;
                        }
                        beta_grad_array(c, t) +=        ( common_grad_term_1.col(t).array()   *  derivs_chain_container_vec.array() ).sum();
     }

               }



     ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grad of L_Omega ('s)
   //   for (int c = 0; c < n_class; c++) {

       grad_bound_z.array() = 0 ;
       grad_Phi_bound_z.array() = 0;
       z_grad_term.array() = 0 ;
       grad_prob.array() = 0;


       
       
         {
         ///////////////////////// deriv of diagonal elements (not needed if using the "standard" or "Stan" Cholesky parameterisation of Omega)

         //////// w.r.t last diagonal first
         {
           int  t1 = n_tests - 1;

           U_Omega_grad_array[c](t1, t1) +=   ( ( common_grad_term_1.col(t1).array()   *    -  y_sign_chunk_times_phi_Bound_Z.col(t1).array() ).array() *
                                                     (  Bound_Z[c].col(t1).array() * L_Omega_var_double[c](t1,t1) *  - ( 1 / ( L_Omega_var_double[c](t1,t1)  *  L_Omega_var_double[c](t1,t1) ) )    )   ).sum() ;
         }


         //////// then w.r.t the second-to-last diagonal
           int  t1 = n_tests - 2;

           double deriv_L_Omega_Tm1_Tm1_inv =    - stan::math::pow( L_Omega_var_double[c](t1, t1), -2) ;

           grad_bound_z.array() =   ( Bound_Z[c].col(t1).array()  *  L_Omega_var_double[c](t1, t1) )  *  (   deriv_L_Omega_Tm1_Tm1_inv    )   ; //  check (standard form, but varies depending on gradient)
           grad_Phi_bound_z.array() =  ( y1_or_phi_Bound_Z.col(t1).array()  *  ( grad_bound_z.array() )  ) ;   // correct  (standard form)
           grad_prob.col(0).array()  =  (   - y_sign_chunk.col(t1).array()  *  grad_Phi_bound_z.array() )  ;     // correct  (standard form)


           z_grad_term.col(0).array()  =      (  ( (  y_m_ysign_x_u_array_times_phi_Z.col(t1).array()   ).array()    * y1_or_phi_Bound_Z.col(t1).array()  *  grad_bound_z.array()  ).array() )   ;  // correct

           prod_container_or_inc_array.array()  =   (  L_Omega_var_double[c](t1 + 1, t1)    *   z_grad_term.col(0).array()   ) ; // sequence
           grad_bound_z.array() =   (   ( - 1 /  L_Omega_var_double[c](t1 + 1, t1 + 1) ) *  prod_container_or_inc_array.array()   )   ;  // correct  (standard form)
           grad_Phi_bound_z.array() =   ( y1_or_phi_Bound_Z.col(t1 + 1).array()  *  (   grad_bound_z.array()   ) ) ;   // correct  (standard form)
           grad_prob.col(1).array()  =   (  - y_sign_chunk.col(t1 + 1).array()   *    grad_Phi_bound_z.array()  ).array()  ;    // correct   (standard form)

           U_Omega_grad_array[c](t1, t1) +=   ( (   common_grad_term_1.col(t1).array() )     *    ( prob[c].col(t1 + 1).array()  *   grad_prob.col(0).array()  +   prob[c].col(t1).array()  *      grad_prob.col(1).array()   )  ).sum()   ;

       }



         // //////// then w.r.t the third-to-last diagonal .... etc
       {

         for (int i = 3; i < n_tests + 1; i++) {

           int  t1 = n_tests - i;

           //////// 1st component
           // 1st grad_Z term and 1st grad_prob term (simplest terms)
           grad_bound_z.array()  =   ( Bound_Z[c].col(t1).array()  *  ( - 1 / L_Omega_var_double[c](t1, t1)  ) ).matrix() ; //  check (standard form, but varies depending on gradient)
           grad_Phi_bound_z.array()  =     y1_or_phi_Bound_Z.col(t1).array() *  grad_bound_z.array() ; // correct  (standard form)
           grad_prob.col(0).array()  =   ( - y_sign_chunk.col(t1).array() ) *    grad_Phi_bound_z.array() ; // correct  (standard form)

           z_grad_term.col(0).array()  =    y_m_ysign_x_u_array_times_phi_Z.col(t1).array()   *   grad_Phi_bound_z.array()  ;   // correct  (standard form)

           // 2nd   grad_Z term and 2nd grad_prob  (more complicated than 1st term)
           prod_container_or_inc_array.array() =    L_Omega_var_double[c](t1 + 1, t1)   * z_grad_term.col(0).array()  ; // correct  (standard form)
           grad_bound_z.array()  = ( - 1 / L_Omega_var_double[c](t1 + 1, t1 + 1) ) * prod_container_or_inc_array.array() ;  // correct  (standard form)
           grad_Phi_bound_z.array()  =     y1_or_phi_Bound_Z.col(t1 + 1).array()  *  grad_bound_z.array() ;    // correct  (standard form)
           grad_prob.col(1).array()  =   ( - y_sign_chunk.col(t1 + 1).array()  ) *    grad_Phi_bound_z.array() ; // correct  (standard form)


           for (int ii = 1; ii < i - 1; ii++) {
             // grad_z term
             z_grad_term.col(ii).array()  =    y_m_ysign_x_u_array_times_phi_Z.col(t1 + ii).array()    *   grad_Phi_bound_z.array()  ;   // correct  (standard form)
             //    grad_prob term
            prod_container_or_inc_array.matrix() =   (  L_Omega_var_double[c].row(t1 + ii + 1).segment(t1, ii + 1) *   z_grad_term.block(0, 0, chunk_size, ii + 1).transpose() ).transpose().matrix(); // correct  (standard form)
            // prod_container_or_inc_array.matrix() =   (  z_grad_term.block(0, 0, chunk_size, ii + 1) *  L_Omega_var_double[c].row(t1 + ii + 1).segment(t1, ii + 1).transpose() ).matrix() ;  // correct  (standard form)
          
             grad_bound_z.array()  = ( - 1 / L_Omega_var_double[c](t1 + ii + 1, t1 + ii + 1)  ) * prod_container_or_inc_array.array(); // correct  (standard form)
             grad_Phi_bound_z.array()  =     y1_or_phi_Bound_Z.col(t1 + ii + 1).array()  *  grad_bound_z.array() ;   // correct  (standard form)
             grad_prob.col(ii + 1).array()  =   ( - y_sign_chunk.col(t1 + ii + 1).array()  ) *   grad_Phi_bound_z.array() ;  // correct  (standard form)
           }

           derivs_chain_container_vec.array() = 0;

           ///// attempt at vectorising  // bookmark
           for (int iii = 0; iii <  i; iii++) {
               derivs_chain_container_vec.array()  +=    grad_prob.col(iii).array()  * (       prop_rowwise_prod_temp.col(t1).array()    /  prob[c].col(t1 + iii).array()  ).array()  ;  // correct  (standard form)
           }

            U_Omega_grad_array[c](t1, t1)   +=       ( common_grad_term_1.col(t1).array()   * derivs_chain_container_vec.array() ).sum()  ; // correct  (standard form)

         }



       }



         
         
         {

         grad_bound_z.array() = 0 ;
         grad_Phi_bound_z.array() = 0;
         z_grad_term.array() = 0 ;
         grad_prob.array() = 0;



               { ///////////////////// last row first
                 int t1_dash = 0;  // t1 = n_tests - 1

                 int t1 = n_tests - (t1_dash + 1); //  starts at n_tests - 1;  // if t1_dash = 0 -> t1 = T - 1
                 int t2 = n_tests - (t1_dash + 2); //  starts at n_tests - 2;

                 U_Omega_grad_array[c](t1,t2) +=      ( ( common_grad_term_1.col(t1).array()      * - y_sign_chunk_times_phi_Bound_Z.col(t1).array() ).array() *
                                                            (    (1 / L_Omega_var_double[c](t1,t1)  ) * (-  Z_std_norm[c].col(t2).array()  )   ).array() ).sum() ;


                 if (t1 > 1) { // starts at  L_{T, T-2}

                   {

                     t2 =   n_tests - (t1_dash + 3); // starts at n_tests - 3;

                     U_Omega_grad_array[c](t1,t2) +=     (  common_grad_term_1.col(t1).array()  *   (  - y_sign_chunk_times_phi_Bound_Z.col(t1).array()  ).array()  *
                                                         ( (  (1 / L_Omega_var_double[c](t1,t1) ) *  ( - Z_std_norm[c].col(t2).array() )  ).array() ) ).sum()  ;


                   }

                 }

                 if (t1 > 2) {// starts at  L_{T, T-3}

                   for (int t2_dash = 3; t2_dash < n_tests; t2_dash++ ) { // t2 < t1

                     t2 = n_tests - (t1_dash + t2_dash + 1); // starts at T - 4

                     if (t2 < n_tests - 1) {

                       U_Omega_grad_array[c](t1,t2)  +=   (common_grad_term_1.col(t1).array() *   (  - y_sign_chunk_times_phi_Bound_Z.col(t1).array() ).array() *
                                                          ( (  ( 1 / L_Omega_var_double[c](t1,t1) ) * - Z_std_norm[c].col(t2).array()  ) ).array()).sum() ;

                     }

                   }

                 }

               }

         }




       {
           Eigen::Matrix<double, -1, 1>  deriv_L_t1 =     Eigen::Matrix<double, -1, 1>::Zero(n_tests);

       /////////////////// then rest of rows (second-to-last row, then third-to-last row, .... , then first row)

       grad_bound_z.array() = 0 ;
       grad_Phi_bound_z.array() = 0;
       z_grad_term.array() = 0 ;
       grad_prob.array() = 0;


       

       for (int t1_dash = 1; t1_dash <  n_tests - 1;  t1_dash++) {
         int  t1 = n_tests - (t1_dash + 1);

             for (int t2_dash = t1_dash + 1; t2_dash <  n_tests;  t2_dash++) {
               int t2 = n_tests - (t2_dash + 1); // starts at t1 - 1, then t1 - 2, up to 0

               grad_prob.array() = 0;
               z_grad_term.array() = 0;

                 {
                   deriv_L_t1(0) = 1;

                   for (int t2_dash_dash = 1; t2_dash_dash < t1 - t2; t2_dash_dash++ ) {
                     deriv_L_t1(t2_dash_dash) = 0;
                   }


                   prod_container_or_inc_array.array()  =  Z_std_norm[c].block(0, t2, chunk_size, t1 - t2) * deriv_L_t1.head(t1 - t2) ;
                   grad_prob.col(0) =      (( -  y_sign_chunk_times_phi_Bound_Z.col(t1).array()   ).array() *   (      ( ( 1/L_Omega_var_double[c](t1,t1) ) *  -    prod_container_or_inc_array.array() ) ).array())  ;


                   z_grad_term.col(0).array()  =               ( (  y_m_ysign_x_u_array_times_phi_Z.col(t1).array()    ).array()   *   y1_or_phi_Bound_Z.col(t1).array()  ).array()  *
                                                                   ( (   ( ( 1 / L_Omega_var_double[c](t1,t1) ) *   -    prod_container_or_inc_array.array()     ).array()  )   ).array()  ;

                   if (t1_dash > 0) {
                     for (int t1_dash_dash = 1; t1_dash_dash <  t1_dash + 1;  t1_dash_dash++) {
                             if (t1_dash_dash > 1) {
                               z_grad_term.col(t1_dash_dash - 1)   =           (  (  y_m_ysign_x_u_array_times_phi_Z.col(t1 + t1_dash_dash - 1).array()    ).array()   *
                                                                               y1_or_phi_Bound_Z.col(t1+t1_dash_dash - 1).array()   *  ( 1/L_Omega_var_double[c](t1+t1_dash_dash - 1,t1+t1_dash_dash - 1) ) ).array()  *  ( - prod_container_or_inc_array.array() )    ;
                             }
                             prod_container_or_inc_array.array()  =            (   z_grad_term.block(0, 0, chunk_size, t1_dash_dash) *   L_Omega_var_double[c].row(t1 + t1_dash_dash).segment(t1, t1_dash_dash).transpose()   ) ;
                             grad_prob.col(t1_dash_dash)  =            (  ( ( -  y_sign_chunk_times_phi_Bound_Z.col(t1 + t1_dash_dash).array()     ).array() ) *
                                                                         ( 1 / L_Omega_var_double[c](t1+t1_dash_dash,t1+t1_dash_dash) )  *    (  -    prod_container_or_inc_array).array()  ) ;
                     }
                   }

                   derivs_chain_container_vec.array() = 0;

                   ///// attempt at vectorising  // bookmark
                   for (int ii = 0; ii <  t1_dash + 1; ii++) {
                       derivs_chain_container_vec.array() += ( grad_prob.col(ii).array()  * ( prop_rowwise_prod_temp.col(t1).array()     /  prob[c].col(t1 + ii).array()  ).array() ).array() ; // correct i think
                   }
                   U_Omega_grad_array[c](t1, t2)   +=       ( common_grad_term_1.col(t1).array()   * derivs_chain_container_vec.array() ).sum()  ; // correct  (standard form)



                 }
             }
       }

     }


          prev_grad_vec(c)  +=  ( ( 1 / prob_n.array() ) * prob[c].rowwise().prod().array() ).matrix().sum()  ;




     } // end of c loop


     chunk_counter += 1;


   }  // end of chunk loop


   //////////////////////// gradients for latent class membership probabilitie(s) (i.e. disease prevalence)
     for (int c = 0; c < n_class; c++) {
       prev_unconstrained_grad_vec(c)  =   prev_grad_vec(c)   * deriv_p_wrt_pu_double ;
     }
     prev_unconstrained_grad_vec(0) = prev_unconstrained_grad_vec(1) - prev_unconstrained_grad_vec(0) - 2 * tanh_u_prev[1];
     prev_unconstrained_grad_vec_out(0) = prev_unconstrained_grad_vec(0);


   log_prob_out += log_lik.sum();

   if (exclude_priors == false)  log_prob_out += prior_densities;

   log_prob_out +=  log_jac_u;

   double log_prob = (double) log_prob_out;

   int i = 0; // probs_all_range.prod() cancels out
   for (int c = 0; c < n_class; c++) {
     for (int t = 0; t < n_tests; t++) {
       if (exclude_priors == false) {
         beta_grad_array(c, t) +=  - ((beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) * (1/ prior_coeffs_sd(t,c) ) ;     // add normal prior density derivative to gradient
       }
       beta_grad_vec(i) = beta_grad_array(c, t);
       i += 1;
     }
   }

// 
   iiiiii = 0;
   for (int n = 0; n < N; n++ ) {
     for (int t = 0; t < n_tests; t++) {
       out_mat(iiiiii + 1) = u_grad_array(n, t);
       iiiiii += 1;
     }
   }
   
   
   // iiiiii = 0;
   // for (int t = 0; t < n_tests; t++) {
   //   for (int n = 0; n < N; n++ ) {
   //     out_mat(iiiiii + 1) = u_grad_array(n, t);
   //     iiiiii += 1;
   //   }
   // }
   
   // 
   // for (int t = 0; t < n_tests; t++) {
   //   if (t == 0) out_mat.segment(0, N)   = u_grad_array.col(t) ; //    phi_Z_or_u_array.col(t) =   ( 0.5 * ( tanh_uu.array() + 1 ) ).array().matrix().segment(chunk_size * chunk_counter * t, chunk_size);
   //   else        out_mat.segment( (N*t) - 1, N)   = u_grad_array.col(t) ;
   //   // for (int nc_index = 0; nc_index < chunk_size; nc_index++ ) {
   //   //     phi_Z_or_u_array(nc_index, t) =   0.5 * ( tanh_uu(iiii) + 1) ;
   //   //     iiii = iiii + 1;
   //   //   }
   // }
   

  //  Eigen::Matrix<float, -1, -1> matrix(3,2);
  //  matrix << 1,2,3,4,5,6;
  //  A.transposeInPlace(); // or ordered row-by-row

     // Eigen::Matrix<float, -1, 1>  vector(Eigen::Map<Eigen::Matrix<float, -1, 1>>(u_grad_array.data(), u_grad_array.cols() * u_grad_array.rows()));

    //   out_mat.segment(1, n_us) =   Eigen::Map<Eigen::Matrix<float, -1, 1>>(u_grad_array.data(), u_grad_array.cols() * u_grad_array.rows());


   {
     i = 0;
     for (int c = 0; c < n_class; c++ ) {
       for (int t1 = 0; t1 < n_tests; t1++ ) {
         for (int t2 = 0; t2 < t1 + 1; t2++ ) {
           L_Omega_grad_vec(i) = U_Omega_grad_array[c](t1,t2);
           i += 1;
         }
       }
     }
   }



   Eigen::Matrix<double, -1, 1>  grad_wrt_L_Omega_nd =   L_Omega_grad_vec.segment(0, dim_choose_2 + n_tests);
   Eigen::Matrix<double, -1, 1>  grad_wrt_L_Omega_d =   L_Omega_grad_vec.segment(dim_choose_2 + n_tests, dim_choose_2 + n_tests);

   U_Omega_grad_vec.segment(0, dim_choose_2) =  ( grad_wrt_L_Omega_nd.transpose()  *  deriv_L_wrt_unc_full[0].cast<double>() ).transpose() ;
   U_Omega_grad_vec.segment(dim_choose_2, dim_choose_2) =   ( grad_wrt_L_Omega_d.transpose()  *  deriv_L_wrt_unc_full[1].cast<double>() ).transpose()  ;

   ////////////////////////////  outputs



   out_mat(0) = log_prob;


   out_mat.segment(1 + n_us, n_corrs) += U_Omega_grad_vec  ;

   out_mat.segment(1 + n_us + n_corrs, n_coeffs) = beta_grad_vec ;
   out_mat(n_params) += prev_unconstrained_grad_vec_out(0); ;
   out_mat.segment(1, n_us).array() =   (out_mat.segment(1, n_us).array() )   *   ( 0.5 * (1 - tanh_uu.array() * tanh_uu.array()  )  ) - 2 * tanh_uu.array()   ;
 //  out_mat.segment(1, n_us).array() =   (out_mat.segment(1, n_us).array() *   0.5 * (1 -     ( Eigen::Map<Eigen::Matrix<float, -1, 1>>(tanh_uu.data(), tanh_uu.cols() * tanh_uu.rows()) ).array() *     ( Eigen::Map<Eigen::Matrix<float, -1, 1>>(tanh_uu.data(), tanh_uu.cols() * tanh_uu.rows()) ).array().array()  )  - 2 *     ( Eigen::Map<Eigen::Matrix<float, -1, 1>>(tanh_uu.data(), tanh_uu.cols() * tanh_uu.rows()) ).array().array()) ;

   out_mat.segment( 1 + n_params, N) = log_lik ;

 //
 stan::math::recover_memory();

   return(out_mat);


   //
   // // // //
   //   Rcpp::List out_list(20);
   //
   //   out_list(0) = out_mat;
   //
   //  // out_list(1) = u_array;
   //   out_list(2) = prob;
   //   out_list(3) = Z_std_norm;
   // //  out_list(4) = Phi_Z;
   //   out_list(5) = Bound_Z;
   // //  out_list(6) = Bound_U_Bound_Phi_Z;
   //   out_list(7) = y_sign;
   //   out_list(8) = prob_n;
   //   out_list(9) = lp_array;
   //  // out_list(10) = inc_array;
   //  // out_list(11) = y1_array;
   //  // out_list(12) = phi_Z;
   // //  out_list(13) = phi_Bound_Z;
   //   out_list(14) = common_grad_term_1;
   //   out_list(15) = y_m_ysign_x_u_array;
   //   out_list(16) = U_Omega_grad_array;
   //
   //   return(out_list);
   // //
   //
 }




 
 
 
 
 
 
 
 
 
 
 
// [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1 >    fn_wo_list_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float(  int n_cores, 
                                                                                                     Eigen::Matrix<double, -1, 1  > theta,
                                                                                             Eigen::Matrix<int, -1, -1>	 y,
                                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  X,
                                                                                             bool exclude_priors,
                                                                                             bool CI,
                                                                                             Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                                               Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                                               Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                                               int n_class, // 10 
                                                                                               int n_tests,
                                                                                               int ub_threshold_phi_approx,
                                                                                               int n_chunks,
                                                                                               bool corr_force_positive,
                                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                                               bool corr_prior_beta ,
                                                                                               bool corr_prior_norm ,
                                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr, // 20
                                                                                               std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                                               double prev_prior_a,
                                                                                               double prev_prior_b,
                                                                                               int Phi_type
                                                                                               
                                                                                               
 ) {
   
   
   

   
   int N = y.rows();
   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
   int n_coeffs = n_class * n_tests * 1;
   int n_us =  1 *  N * n_tests;
   
   int n_params = theta.rows() ; // n_corrs + n_coeffs + n_us + n_class;
   int n_params_main = n_params - n_us;
   

   
   // corrs
   Eigen::Matrix<double, -1, 1  >  Omega_raw_vec_double = theta.segment(n_us, n_corrs);
   
   Eigen::Matrix<stan::math::var, -1, 1  >  Omega_raw_vec_var =  stan::math::to_var(Omega_raw_vec_double) ;
   Eigen::Matrix<stan::math::var, -1, 1  >  Omega_constrained_raw_vec_var =  Eigen::Matrix<stan::math::var, -1, 1  >::Zero(n_corrs) ;
   
   Omega_constrained_raw_vec_var = ( (Omega_raw_vec_var)); // no transformation for Nump needed! done later on
   
   
   
   // coeffs
   Eigen::Matrix<double, -1, -1  > beta_double_array(n_class, n_tests);
   
   {
     int i = n_us + n_corrs;
     for (int c = 0; c < n_class; ++c) {
       for (int t = 0; t < n_tests; ++t) {
         beta_double_array(c, t) = theta(i);
         i = i + 1;
       }
     }
   }
   
   
   // prev
   double u_prev_diseased = theta(n_params - 1);
   

   
   Eigen::Matrix<double, -1, 1 >  target_AD_grad(n_corrs);
 
   
   int dim_choose_2 = n_tests * (n_tests - 1) * 0.5 ;
   
   stan::math::var target_AD = 0.0;
   double grad_prev_AD = 0;
   
   std::vector<Eigen::Matrix<double, -1, -1 > > L_Omega_var_double = vec_of_mats_test(n_tests, n_tests, n_class);
   std::vector<Eigen::Matrix<double, -1, -1 > > deriv_L_wrt_unc_full = vec_of_mats_test(dim_choose_2 + n_tests, dim_choose_2, n_class);
   
   
      {
     
     
             std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > Omega_unconstrained_var = fn_convert_std_vec_of_corrs_to_3d_array_var( eigen_vec_to_std_vec_var(Omega_constrained_raw_vec_var),
                                                                                                                                  n_tests,
                                                                                                                                  n_class);
     
     
               std::vector<Eigen::Matrix<stan::math::var, -1, -1 > > L_Omega_var_copy = vec_of_mats_test_var(n_tests, n_tests, n_class);
               std::vector<Eigen::Matrix<stan::math::var, -1, -1 > >  Omega_var_copy  = vec_of_mats_test_var(n_tests, n_tests, n_class);
               
               for (int c = 0; c < n_class; ++c) {
                 Eigen::Matrix<stan::math::var, -1, -1 >  ub = stan::math::to_var(ub_corr[c]);
                 Eigen::Matrix<stan::math::var, -1, -1 >  lb = stan::math::to_var(lb_corr[c]);
                 
                 Eigen::Matrix<stan::math::var, -1, -1  >  Chol_Schur_outs =  Spinkney_LDL_bounds_opt(n_tests, lb, ub, Omega_unconstrained_var[c], known_values_indicator[c], known_values[c]) ; //   Omega_unconstrained_var[c], n_tests, tol )  ;
                 
                 L_Omega_var_copy[c]   =  Chol_Schur_outs.block(1, 0, n_tests, n_tests);
                 Omega_var_copy[c] =   L_Omega_var_copy[c] * L_Omega_var_copy[c].transpose() ;
                 
 
                 target_AD +=   Chol_Schur_outs(0, 0); // now can set prior directly on Omega
               }
               
               
               
               for (int c = 0; c < n_class; ++c) {
                 if ( (corr_prior_beta == false)   &&  (corr_prior_norm == false) ) {
                   target_AD +=  stan::math::lkj_corr_cholesky_lpdf(L_Omega_var_copy[c], lkj_cholesky_eta(c)) ;
                 } else if ( (corr_prior_beta == true)   &&  (corr_prior_norm == false) ) {
                   for (int i = 1; i < n_tests; i++) {
                     for (int j = 0; j < i; j++) {
                       target_AD +=  stan::math::beta_lpdf(  (Omega_var_copy[c](i, j) + 1)/2, prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
                     }
                   }
                   //  Jacobian for  Omega -> L_Omega transformation for prior log-densities (since both LKJ and truncated normal prior densities are in terms of Omega, not L_Omega)
                   Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
                   for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * log(L_Omega_var_copy[c](i, i));
                   target_AD  += + (n_tests * stan::math::log(2) + jacobian_diag_elements.sum());  //  L -> Omega
                 } else if  ( (corr_prior_beta == false)   &&  (corr_prior_norm == true) ) {
                   for (int i = 1; i < n_tests; i++) {
                     for (int j = 0; j < i; j++) {
                       target_AD +=  stan::math::normal_lpdf(  Omega_var_copy[c](i, j), prior_for_corr_a[c](i, j), prior_for_corr_b[c](i, j));
                     }
                   }
                   Eigen::Matrix<stan::math::var, -1, 1 >  jacobian_diag_elements(n_tests);
                   for (int i = 0; i < n_tests; ++i)     jacobian_diag_elements(i) = ( n_tests + 1 - (i+1) ) * log(L_Omega_var_copy[c](i, i));
                   target_AD  += + (n_tests * stan::math::log(2) + jacobian_diag_elements.sum());  //  L -> Omega
                 }
               }
 
               
       ///////////////////////
       stan::math::set_zero_all_adjoints();
       target_AD.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
       target_AD_grad =  Omega_raw_vec_var.adj();    // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
       stan::math::set_zero_all_adjoints();
       //////////////////////////////////////////////////////////// end of AD part
       
               
   
     /////////////  prev stuff  ---- vars
     std::vector<stan::math::var> 	 u_prev_var_vec_var(n_class, 0.0);
     std::vector<stan::math::var> 	 prev_var_vec_var(n_class, 0.0);
     std::vector<stan::math::var> 	 tanh_u_prev_var(n_class, 0.0);
     Eigen::Matrix<stan::math::var, -1, -1>	 prev_var(1, n_class);
     
     u_prev_var_vec_var[1] =  stan::math::to_var(u_prev_diseased);
     tanh_u_prev_var[1] = ( exp(2*u_prev_var_vec_var[1] ) - 1) / ( exp(2*u_prev_var_vec_var[1] ) + 1) ;
     u_prev_var_vec_var[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev_var[1] + 1))*2 - 1) ) )  ;
     tanh_u_prev_var[0] = (exp(2*u_prev_var_vec_var[0] ) - 1) / ( exp(2*u_prev_var_vec_var[0] ) + 1) ;
     
     prev_var_vec_var[1] = 0.5 * ( tanh_u_prev_var[1] + 1);
     prev_var_vec_var[0] =  0.5 * ( tanh_u_prev_var[0] + 1);
     prev_var(0,1) =  prev_var_vec_var[1];
     prev_var(0,0) =  prev_var_vec_var[0];
     
     stan::math::var tanh_pu_deriv_var = ( 1 - tanh_u_prev_var[1] * tanh_u_prev_var[1]  );
     stan::math::var deriv_p_wrt_pu_var = 0.5 *  tanh_pu_deriv_var;
     stan::math::var tanh_pu_second_deriv_var  = -2 * tanh_u_prev_var[1]  * tanh_pu_deriv_var;
     stan::math::var log_jac_p_deriv_wrt_pu_var  = ( 1 / deriv_p_wrt_pu_var) * 0.5 * tanh_pu_second_deriv_var; // for gradient of u's
     stan::math::var  log_jac_p_var =    log( deriv_p_wrt_pu_var );
     
     
     stan::math::var  target_AD_prev = beta_lpdf(  prev_var(0,1), prev_prior_a, prev_prior_b  ); // weakly informative prior - helps avoid boundaries with slight negative skew (for lower N)
     target_AD_prev += log_jac_p_var;
     
     target_AD  +=  target_AD_prev;
     
     ///////////////////////
     target_AD_prev.grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
     grad_prev_AD  =  u_prev_var_vec_var[1].adj() - u_prev_var_vec_var[0].adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
     stan::math::set_zero_all_adjoints();
     //////////////////////////////////////////////////////////// end of AD part
     
     

   
   for (int c = 0; c < n_class; ++c) {
     int cnt_1 = 0;
     for (int k = 0; k < n_tests; k++) {
       for (int l = 0; l < k + 1; l++) {
         (  L_Omega_var_copy[c](k, l)).grad() ;   // differentiating this (i.e. NOT wrt this!! - this is the subject)
         int cnt_2 = 0;
         for (int i = 1; i < n_tests; i++) {
           for (int j = 0; j < i; j++) {
             deriv_L_wrt_unc_full[c](cnt_1, cnt_2)  =   Omega_unconstrained_var[c](i, j).adj();     // differentiating WRT this - Note: theta_var_std is the parameter vector - a std::vector of stan::math::var's
             cnt_2 += 1;
           }
         }
         stan::math::set_zero_all_adjoints();
         cnt_1 += 1;
       }
     }
   }
   
   
   ///////////////// get cholesky factor's (lower-triangular) of corr matrices
   // convert to 3d var array
   
   for (int c = 0; c < n_class; ++c) {
     for (int t1 = 0; t1 < n_tests; ++t1) {
       for (int t2 = 0; t2 < n_tests; ++t2) {
         L_Omega_var_double[c](t1, t2) =   L_Omega_var_copy[c](t1, t2).val()  ;
       }
     }
   }
   
   stan::math::recover_memory();
   }
      
   
   /////////////  prev stuff
   std::vector<double> 	 u_prev_var_vec(n_class, 0.0);
   std::vector<double> 	 prev_var_vec(n_class, 0.0);
   std::vector<double> 	 tanh_u_prev(n_class, 0.0);
   Eigen::Matrix<double, -1, -1>	 prev(1, n_class);
   
   u_prev_var_vec[1] =  (double) u_prev_diseased ;
   tanh_u_prev[1] = ( exp(2*u_prev_var_vec[1] ) - 1) / ( exp(2*u_prev_var_vec[1] ) + 1) ;
   u_prev_var_vec[0] =   0.5 *  log( (1 + ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) / (1 - ( (1 - 0.5 * ( tanh_u_prev[1] + 1))*2 - 1) ) )  ;
   tanh_u_prev[0] = (exp(2*u_prev_var_vec[0] ) - 1) / ( exp(2*u_prev_var_vec[0] ) + 1) ;
   
   prev_var_vec[1] = 0.5 * ( tanh_u_prev[1] + 1);
   prev_var_vec[0] =  0.5 * ( tanh_u_prev[0] + 1);
   prev(0,1) =  prev_var_vec[1];
   prev(0,0) =  prev_var_vec[0];
   
   
   double tanh_pu_deriv = ( 1 - tanh_u_prev[1] * tanh_u_prev[1]  );
   double deriv_p_wrt_pu_double = 0.5 *  tanh_pu_deriv;
   double tanh_pu_second_deriv  = -2 * tanh_u_prev[1]  * tanh_pu_deriv;
   double log_jac_p_deriv_wrt_pu  = ( 1 / deriv_p_wrt_pu_double) * 0.5 * tanh_pu_second_deriv; // for gradient of u's
   double  log_jac_p =    log( deriv_p_wrt_pu_double );
   
   
   
   ///////////////////////////////////////////////////////////////////////// prior densities
   double prior_densities = 0.0;
   
   
   if (exclude_priors == false) {
     ///////////////////// priors for coeffs
     double prior_densities_coeffs = 0.0;
     for (int c = 0; c < n_class; c++) {
       for (int t = 0; t < n_tests; t++) {
         double num_1 = 0.9189385;
         prior_densities_coeffs  +=  - num_1 - log(prior_coeffs_sd(t,c)) - 0.5 * ( (beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) *   ( (beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) )  ;
       }
     }
     double prior_densities_corrs = target_AD.val();
     prior_densities = prior_densities_coeffs  +      prior_densities_corrs ;     // total prior densities and Jacobian adjustments
   }
   
   
   /////////////////////////////////////////////////////////////////////////////////////////////////////
   ///////// likelihood
   double s = 1/1.702;
   double sqrt_2_recip = 1 / stan::math::sqrt(2);
   
   int chunk_counter = 0;
   int chunk_size  = std::round( N / n_chunks  / 2) * 2;  ; // N / n_chunks;
   
   
   double log_prob_out = 0.0;
   
   
   Eigen::Matrix<double, -1, -1 >  log_prev = prev;
   
   for (int c = 0; c < n_class; c++) {
     log_prev(0,c) =  log(prev(0,c));
     for (int t = 0; t < n_tests; t++) {
       if (CI == true)      L_Omega_var_double[c](t,t) = 1;
     }
   }
   
   
   ///////////////////////////////////////////////
   Eigen::Matrix<double, -1, 1 >  log_lik   =   Eigen::Matrix<double, -1, 1>::Zero(N);   //////////////////////////////////////////////////  
   Eigen::Matrix< double , -1, 1>  beta_grad_vec   =  Eigen::Matrix<double, -1, 1>::Zero(n_coeffs);  //
   Eigen::Matrix<double, -1, -1>   beta_grad_array  =  Eigen::Matrix<double, -1, -1>::Zero(n_class, n_tests); //
   std::vector<Eigen::Matrix<double, -1, -1 > > U_Omega_grad_array =  vec_of_mats_test(n_tests, n_tests, n_class); //
   Eigen::Matrix<double, -1, 1 > L_Omega_grad_vec(n_corrs + (n_class * n_tests)); //
   Eigen::Matrix<double, -1, 1 > U_Omega_grad_vec(n_corrs); //
   Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(n_class); //
   Eigen::Matrix<double, -1, 1>  prev_grad_vec =   Eigen::Matrix<double, -1, 1>::Zero(n_class); //
   Eigen::Matrix<double, -1, 1>  prev_unconstrained_grad_vec_out =   Eigen::Matrix<double, -1, 1>::Zero(n_class - 1); //
  // Eigen::Matrix<double, -1, -1, Eigen::RowMajor> u_grad_array_RM   =  Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(N, n_tests);  //////////////////////////////////////////////// 
   Eigen::Matrix<double, -1, -1> u_grad_array_CM   =  Eigen::Matrix<double, -1, -1>::Zero(N, n_tests);  //////////////////////////////////////////////// 
   ///////////////////////////////////////////////
   

   
   double log_prob = 0;
   
   
   ////////////////// u (double / manual diff)
 //  Eigen::Matrix<double, -1, 1 > tanh_uu =    theta.head(n_us).array().tanh() ;   //////////////////////////////////////////
  // double log_jac_u  =    (  0.5 *   (1 -  ( tanh_uu.array()   *  tanh_uu.array()   ) )   ).log().matrix().sum();
  
   theta.head(n_us) =    theta.head(n_us).array().tanh() ;    
   double log_jac_u  =    (  0.5 *   (1 -  ( theta.head(n_us).array()   *  theta.head(n_us).array()   ) )   ).log().matrix().sum();
 
 
 // ////////////////////////////////////////////////////////////////////////////////////// output vec 
 // Eigen::Matrix<double, -1, 1> out_mat    =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N);     
 // ////////////////////////////////////////////////////////////////////////////////////// 
 
   
   {  
     
 
   
   ///////////////////////////////////////////////
   std::vector<Eigen::Matrix<double, -1, -1 > >  prob   = vec_of_mats_test(chunk_size, n_tests, n_class); //////////////////////////////
   std::vector<Eigen::Matrix<double, -1, -1 > >  Z_std_norm =  vec_of_mats_test(chunk_size, n_tests, n_class); //////////////////////////////
   std::vector<Eigen::Matrix<double, -1, -1 > >  Bound_Z =  vec_of_mats_test(chunk_size, n_tests, n_class); //////////////////////////////
   ///////////////////////////////////////////////
   
   
   
   ///////////////////////////////////////////////
    Eigen::Matrix<int, -1, -1>  y_sign_chunk  =  Eigen::Matrix<int, -1, -1>::Zero(chunk_size, n_tests); /////
   Eigen::Matrix<double, -1, -1>  y_m_ysign_x_u_array =   Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;
   Eigen::Matrix<double, -1, -1> y1_or_phi_Bound_Z =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   Eigen::Matrix<double, -1, -1> phi_Z_or_u_array = Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
   // Eigen::Matrix<double, -1, -1, Eigen::RowMajor>  u_array_RM =   Eigen::Matrix<double, -1, -1, Eigen::RowMajor>::Zero(chunk_size, n_tests) ;
   // Eigen::Matrix<double, -1, -1>  u_array_CM =   Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;
   ///////////////////////////////////////////////
   
   
   ///////////////////////////////////////////////
   Eigen::Matrix<double, -1, 1> prod_container_or_inc_array  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
   Eigen::Matrix<double, -1, 1> prob_n  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
   ///////////////////////////////////////////////
   
   
 ///////////////////////////////////////////////
 Eigen::Matrix<double, -1, -1>     common_grad_term_1   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 Eigen::Matrix<double, -1, -1 >    prop_rowwise_prod_temp   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 Eigen::Matrix<double, -1, -1 >    y_sign_chunk_times_phi_Bound_Z   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 Eigen::Matrix<double, -1, -1 >    y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 Eigen::Matrix<double, -1, -1> grad_prob =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 Eigen::Matrix<double, -1, -1> z_grad_term = Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
 Eigen::Matrix<double, -1, 1> derivs_chain_container_vec  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
 Eigen::Matrix<double, -1, 1> prop_rowwise_prod_temp_all  =  Eigen::Matrix<double, -1, 1>::Zero(chunk_size);
 ///////////////////////////////////////////////
   
   
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   int iiii = 0;
   int iiiiii = 0;
   double sqrt_2_pi_recip =   1 / sqrt(2 * M_PI) ; //  0.3989422804;
   
 
   for (int nc = 0; nc < n_chunks; nc++) {
 
    int chunk_counter = nc; 
 
     phi_Z_or_u_array.array() = 0.5 * (  theta.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).reshaped(chunk_size, n_tests).array() + 1 ).array() ;
       
 
      y_sign_chunk.array() =     ( y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array() + (  y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array() - 1).array() ).array() ; 
      y_m_ysign_x_u_array.array()  =   ( (  (   y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array()   - y_sign_chunk.array()    *  phi_Z_or_u_array.array()    ).array() ) ) ; //////// checked
     
     
     {
       
         Eigen::Matrix<double, -1, -1>    lp_array  =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_class);//////
         Eigen::Matrix<double, -1, -1 >    Phi_Z_temp   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests) ;
         Eigen::Matrix<double, -1, -1 >    Bound_U_Bound_Phi_Z_temp   =  Eigen::Matrix<double, -1, -1>::Zero(chunk_size, n_tests);
       
         for (int c = 0; c < n_class; c++) {
           
           prod_container_or_inc_array.array()  = 0; // needs to be reset to 0
           
           for (int t = 0; t < n_tests; t++) {
                 
                   Bound_Z[c].col(t).array() =   ( ((  - ( beta_double_array(c, t) +      prod_container_or_inc_array.array()   )  ) / L_Omega_var_double[c](t, t) )  )  ;
 
               if (Phi_type == 3) { // stable and accurate but slower
                   Bound_U_Bound_Phi_Z_temp.col(t).array() =  Eigen::Select(    stan::math::abs(Bound_Z[c].col(t).array()) < ub_threshold_phi_approx ,
                                                                              0.5 *  ( -  sqrt_2_recip * Bound_Z[c].col(t).array() ).erfc().array()  ,
                                                                              stan::math::inv_logit(1.702 *  Bound_Z[c].col(t) )    ) ; 
               } else if (Phi_type == 2) { // rough_approx
                   Bound_U_Bound_Phi_Z_temp.col(t).array() =    stan::math::inv_logit(1.702 *  Bound_Z[c].col(t) ) ; 
               } else if (Phi_type == 1) { // standard Phi
                   Bound_U_Bound_Phi_Z_temp.col(t).array() =  0.5 *  ( -  sqrt_2_recip * Bound_Z[c].col(t).array() ).erfc().array()  ; // Phi
               }
                 
 
               
                   Phi_Z_temp.col(t).array()    =  (   y.col(t).segment(chunk_size * chunk_counter, chunk_size).array()  *       Bound_U_Bound_Phi_Z_temp.col(t).array() +
                                                    (  y.col(t).segment(chunk_size * chunk_counter, chunk_size).array()  -   Bound_U_Bound_Phi_Z_temp.col(t).array() ) * y_sign_chunk.col(t).array() * phi_Z_or_u_array.col(t).array()  ).array()   ;  //////// checked
 
                 
 
                  if (Phi_type == 3) { // stable and accurate but slower
                     Z_std_norm[c].col(t).array() =  Eigen::Select(     stan::math::abs(Bound_Z[c].col(t).array()) < ub_threshold_phi_approx ,
                                                                        stan::math::inv_Phi(   Phi_Z_temp.col(t) ).array()  ,
                                                                        stan::math::logit(   Phi_Z_temp.col(t) ).array() / 1.702    ) ;  
                 } else if (Phi_type == 2) { // rough_approx
                   Z_std_norm[c].col(t).array() =  stan::math::logit(   Phi_Z_temp.col(t) ).array() / 1.702  ; 
                 } else if (Phi_type == 1) { // standard Phi
                   Z_std_norm[c].col(t).array() =  stan::math::inv_Phi(   Phi_Z_temp.col(t) ).array()  ;  
                 }
                 
         
                 if (t < n_tests - 1)       prod_container_or_inc_array.array()  =   ( Z_std_norm[c].block(0, 0, chunk_size, t + 1)  *   ( L_Omega_var_double[c].row(t+1).head(t+1).transpose()  ) ) ; //////// checked
                 
           } // end of t loop
           
 
            y1_or_phi_Bound_Z.array() =   (  y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array() * ( 1 - Bound_U_Bound_Phi_Z_temp.array() ) + 
                                          (  y.block( chunk_size * chunk_counter, 0, chunk_size,  n_tests ).array() - 1  ).array()   * Bound_U_Bound_Phi_Z_temp.array() * y_sign_chunk.array() ).array().log() ; 
   
   
            lp_array.col(c).array() =    y1_or_phi_Bound_Z.rowwise().sum().array() +  log_prev(0,c) ;
 
            prob[c] =   y1_or_phi_Bound_Z.array().exp();
 
         } // end of c loop
     
       log_lik.segment(chunk_size * chunk_counter, chunk_size).array()   = (  lp_array.array().maxCoeff() + (lp_array.array() - lp_array.array().maxCoeff() ).array().exp().rowwise().sum().array().log() )  ; // correct & stable
       prob_n =   log_lik.segment(chunk_size * chunk_counter, chunk_size).array().exp().matrix(); // correct & stable
 
     
 
     }
     
     
  //  #pragma omp critical 
  
    {
  //  #pragma omp parallel for   num_threads(n_cores)    schedule(auto)
     for (int c = 0; c < n_class; c++) {
       
       for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
         int t = n_tests - (i+1) ;
         prop_rowwise_prod_temp.col(t).array()   =   prob[c].block(0, t + 0, chunk_size, i + 1).rowwise().prod().array() ;
       }
       
       prop_rowwise_prod_temp_all.array() = prob[c].block(0, 0, chunk_size, n_tests).rowwise().prod().array()  ; 
       
       
       for (int i = 0; i < n_tests; i++) { // i goes from 1 to 3
         int t = n_tests - (i + 1) ;
         common_grad_term_1.col(t) =   (  ( prev(0,c) / prob_n.array() ) * ( prop_rowwise_prod_temp_all.array() /  prop_rowwise_prod_temp.col(t).array()  ).array() )  ;
       }
       
       
       if (Phi_type == 3) { // stable and accurate but slower
         // for numerical stability
         phi_Z_or_u_array.array() =    Eigen::Select(   Bound_Z[c].array().abs() < ub_threshold_phi_approx ,
                                sqrt_2_pi_recip *  ( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).exp().array()   ,
                                1.702 * (1 / stan::math::square( stan::math::exp(Z_std_norm[c] * (1/(2*s)) ) + stan::math::exp( - Z_std_norm[c] *  (1/(2*s)) ) ).array()  ) ).array() ;
         
         // for numerical stability
         y1_or_phi_Bound_Z.array() =    Eigen::Select(   Bound_Z[c].array().abs() < ub_threshold_phi_approx ,
                                 sqrt_2_pi_recip *  ( - 0.5 * Bound_Z[c].array() *  Bound_Z[c].array() ).exp().array()   ,
                                 1.702 * (1 / stan::math::square( stan::math::exp(Bound_Z[c] *  (1/(2*s)) ) + stan::math::exp( - Bound_Z[c] *  (1/(2*s)) ) ).array()  ) ).array()  ;
         
       } else if (Phi_type == 2) { // rough_approx
         phi_Z_or_u_array.array() =                 1.702 * (1 / stan::math::square( stan::math::exp(Z_std_norm[c] *  (1/(2*s)) ) + stan::math::exp( - Z_std_norm[c] *  (1/(2*s)) ) ).array()  )  ; 
         y1_or_phi_Bound_Z.array() =                1.702 * (1 / stan::math::square( stan::math::exp(Bound_Z[c] *  (1/(2*s)) )    + stan::math::exp( - Bound_Z[c] *  (1/(2*s)) ) ).array()  ) ; 
         
       } else if (Phi_type == 1) { // standard Phi
         phi_Z_or_u_array.array()  =       sqrt_2_pi_recip *  ( - 0.5 * Z_std_norm[c].array() *  Z_std_norm[c].array() ).exp().array() ;
         y1_or_phi_Bound_Z.array() =       sqrt_2_pi_recip *  ( - 0.5 * Bound_Z[c].array()    *  Bound_Z[c].array()    ).exp().array() ;
       }
       
       
     
       

       
      // y_m_ysign_x_u_array_times_phi_Z.array() = y_m_ysign_x_u_array.array() * ( 1 /  phi_Z_or_u_array.array() );
       y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.array() =   y_m_ysign_x_u_array.array() * ( 1 /  phi_Z_or_u_array.array() ).array()  * y1_or_phi_Bound_Z.array() ;  
       y_sign_chunk_times_phi_Bound_Z.array() =  y_sign_chunk.array() * y1_or_phi_Bound_Z.array() ;
       
         
       ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grad of nuisance parameters / u's (manual)
       u_grad_array_CM.col(n_tests - 1).segment( chunk_size * chunk_counter, chunk_size).array() +=  0;  
       
       ///// then second-to-last term (test T - 1)
       int t = n_tests - 1;
 
      
      u_grad_array_CM.col(n_tests - 2).segment( chunk_size * chunk_counter, chunk_size).array()  +=  (  common_grad_term_1.col(t).array()  * (y_sign_chunk_times_phi_Bound_Z.col(t).array()   * (1 / L_Omega_var_double[c](t,t)  ) *   
                                                                                                     L_Omega_var_double[c](t,t - 1) * ( 1 /phi_Z_or_u_array.col(t-1).array() )  * prob[c].col(t-1).array()) ).array();  
 
 
         { ///// then third-to-last term (test T - 2)
           t = n_tests - 2;
           
           z_grad_term.col(0) = (1 / phi_Z_or_u_array.col(t-1).array())  * prob[c].col(t-1).array() ;
           grad_prob.col(0) =        y_sign_chunk_times_phi_Bound_Z.col(t).array() * (1 / L_Omega_var_double[c](t,t)  ) *     L_Omega_var_double[c](t, t - 1) *   z_grad_term.col(0).array() ; // lp(T-1) - part 2;
           z_grad_term.col(1).array()  =  (1 / L_Omega_var_double[c](t,t))  * L_Omega_var_double[c](t,t-1) *   z_grad_term.col(0).array() *       y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t).array() ;
           
           grad_prob.col(1)  =         (   y_sign_chunk_times_phi_Bound_Z.col(t+1).array()  *  (1 / L_Omega_var_double[c](t+1,t+1)  ) ) *  (  z_grad_term.col(0).array() *  L_Omega_var_double[c](t + 1,t - 1)  -   z_grad_term.col(1).array()  * L_Omega_var_double[c](t+1,t)) ;
           
           u_grad_array_CM.col(n_tests - 3).segment( chunk_size * chunk_counter, chunk_size).array()  +=  common_grad_term_1.col(t).array()   *  (  grad_prob.col(1).array() * prob[c].col(t).array()  +      grad_prob.col(0).array() *  prob[c].col(t+1).array()  );  // ----------   correct
         }
 

         
         // then rest of terms
         for (int i = 1; i < n_tests - 2; i++) { // i goes from 1 to 3
           
           
           grad_prob.array() = 0;
           z_grad_term.array() = 0;
           
           int t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)
           
           z_grad_term.col(0) = (1 / phi_Z_or_u_array.col(t-1).array())  * prob[c].col(t-1).array() ;
 
           grad_prob.col(0) =         y_sign_chunk_times_phi_Bound_Z.col(t).array() * (1 / L_Omega_var_double[c](t,t)  ) *   L_Omega_var_double[c](t, t - 1) *   z_grad_term.col(0).array() ; // lp(T-1) - part 2;
           
           for (int ii = 0; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1 u_grad_z u_grad_term
             if (ii == 0)    prod_container_or_inc_array  = (   (z_grad_term.block(0, 0, chunk_size, ii + 1) ) *  (fn_first_element_neg_rest_pos(L_Omega_var_double[c].row( t + (ii-1) + 1).segment(t - 1, ii + 1))).transpose()  )      ;
           //   z_grad_term.col(ii+1)  =  (1 /phi_Z_or_u_array.col( t+(ii-1)+1).array() ).array() * y1_or_phi_Bound_Z.col(t+(ii-1)+1).array() * (1 / L_Omega_var_double[c](t+(ii-1)+1,t+(ii-1)+1))   *   y_m_ysign_x_u_array.col(t + ii).array() *  -   prod_container_or_inc_array.array() ;
           z_grad_term.col(ii+1)  =     (1 / L_Omega_var_double[c](t+(ii-1)+1,t+(ii-1)+1))   *   y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t + ii).array() *  -   prod_container_or_inc_array.array() ;
             prod_container_or_inc_array  = (   (z_grad_term.block(0, 0, chunk_size, ii + 2) ) *  (fn_first_element_neg_rest_pos(L_Omega_var_double[c].row( t + (ii) + 1).segment(t - 1, ii + 2))).transpose()  )      ;
             grad_prob.col(ii+1)  =       (    y_sign_chunk_times_phi_Bound_Z.col(t+ii+1).array() *  (1 / L_Omega_var_double[c](t+ii+1,t+ii+1)  )) *     -    prod_container_or_inc_array.array()  ;
           } // end of ii loop
      
                   {
                     derivs_chain_container_vec.array() = 0;
      
                       for (int ii = 0; ii < i + 2; ii++) {
                           derivs_chain_container_vec.array()  +=  ( grad_prob.col(ii).array()    * (       prop_rowwise_prod_temp.col(t).array() /  prob[c].col(t + ii).array()  ).array() ).array()  ;
                       }
                       u_grad_array_CM.col(n_tests - (i+3)).segment( chunk_size * chunk_counter, chunk_size).array()    +=   (  ( (   common_grad_term_1.col(t).array()   *  derivs_chain_container_vec.array() ) ).array()  ).array() ;  
                   }
           
         }
         
       //    out_mat.segment(1, n_us).segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)  +=        u_grad_array_RM.reshaped<RowMajor>() ; 
       //   out_mat.segment(1, n_us).segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)  +=        u_grad_array_CM.reshaped() ; 
         
 
         // out_mat.segment(1, n_us).segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)  =    u_grad_array_RM.block(chunk_size * chunk_counter, 0, chunk_size, n_tests).reshaped<RowMajor>()     ; 
 
         
         // /////////////////////////////////////////////////////////////////////////// Grad of intercepts / coefficients (beta's)
         // ///// last term first (test T)
         
         {
           
           int t = n_tests - 1;
           
           beta_grad_array(c, t) +=     (common_grad_term_1.col(t).array()  *   ( - y_sign_chunk_times_phi_Bound_Z.col(t).array()    * ( - 1 / L_Omega_var_double[c](t,t)  ))).sum();
           
           ///// then second-to-last term (test T - 1)
           {
             t = n_tests - 2;
             grad_prob.col(0) =       (   -  y_sign_chunk_times_phi_Bound_Z.col(t).array() * (- 1 / L_Omega_var_double[c](t,t)  ) ) ;
             z_grad_term.col(1)   =      y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t).array()   * (- 1 / L_Omega_var_double[c](t,t))     ;
             grad_prob.col(1)  =       ( - y_sign_chunk_times_phi_Bound_Z.col(t+1).array()    ) *  (     (- 1 / L_Omega_var_double[c](t+1,t+1)  ) ) * (   L_Omega_var_double[c](t + 1,t) *      z_grad_term.col(1).array() ) ;
             beta_grad_array(c, t) +=  (common_grad_term_1.col(t).array()   * ( grad_prob.col(1).array() * prob[c].col(t).array() +         grad_prob.col(0).array() *  prob[c].col(t+1).array() ) ).sum() ;
           }
           
           // then rest of terms
           for (int i = 1; i < n_tests - 1; i++) { // i goes from 1 to 3
             
             t = n_tests - (i+2) ; // starts at t = 6 - (1+2) = 3, ends at t = 6 - (3+2) = 6 - 5 = 1 (when i = 3)
             
             grad_prob.col(0)  =    ( ( - y_sign_chunk_times_phi_Bound_Z.col(t).array()  )     * (- 1 / L_Omega_var_double[c](t,t)  ) ) ;
             
             
             // component 2 (second-to-earliest test)
             z_grad_term.col(1)  =        y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t).array()    * (- 1 / L_Omega_var_double[c](t,t))    ;
             grad_prob.col(1) =        - y_sign_chunk_times_phi_Bound_Z.col(t + 1).array()   * (    (- 1 / L_Omega_var_double[c](t+1,t+1)  ) ) *    (   L_Omega_var_double[c](t + 1,t) *   z_grad_term.col(1).array() ) ;
             
             // rest of components
             for (int ii = 1; ii < i+1; ii++) { // if i = 1, ii goes from 0 to 1
               if (ii == 1)  prod_container_or_inc_array  = (    z_grad_term.block(0, 1, chunk_size, ii)  *   L_Omega_var_double[c].row( t + (ii - 1) + 1).segment(t + 0, ii + 0).transpose()  );
               z_grad_term.col(ii+1)  =        y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t + ii).array()  * (- 1 / L_Omega_var_double[c](t+(ii-1)+1,t+(ii-1)+1))  *   prod_container_or_inc_array.array();
               prod_container_or_inc_array  = (    z_grad_term.block(0, 1, chunk_size, ii + 1)  *   L_Omega_var_double[c].row( t + (ii) + 1).segment(t + 0, ii + 1).transpose()  );
               //  prod_container_or_inc_array  = (  L_Omega_var_double[c].row( t + (ii) + 1).segment(t + 0, ii + 1) *   z_grad_term.block(0, 1, chunk_size, ii + 1).transpose()  ).transpose();
               grad_prob.col(ii+1) =      (  - y_sign_chunk_times_phi_Bound_Z.col(t + ii + 1).array()  ).array() *   (    (- 1 / L_Omega_var_double[c](t+ii+1,t+ii+1)  ) )    *  prod_container_or_inc_array.array();
             
             }
             
             {
      
                 derivs_chain_container_vec.array() = 0;
               
                 ///// attempt at vectorising  // bookmark
                 for (int ii = 0; ii < i + 2; ii++) {
                   derivs_chain_container_vec.array() +=  ( grad_prob.col(ii).array()  * (      prop_rowwise_prod_temp.col(t).array() /  prob[c].col(t + ii).array()  ).array() ).array() ;
                 }
                 beta_grad_array(c, t) +=        ( common_grad_term_1.col(t).array()   *  derivs_chain_container_vec.array() ).sum();
             }
             
           }
           
         }
         

         
         ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grad of L_Omega ('s)
         
         
         {
 
         
         {
           ///////////////////////// deriv of diagonal elements (not needed if using the "standard" or "Stan" Cholesky parameterisation of Omega)
           
           //////// w.r.t last diagonal first
           {
             int  t1 = n_tests - 1;
             
             U_Omega_grad_array[c](t1, t1) +=   ( ( common_grad_term_1.col(t1).array()   *    -  y_sign_chunk_times_phi_Bound_Z.col(t1).array() ).array() *
               (  Bound_Z[c].col(t1).array() * L_Omega_var_double[c](t1,t1) *  - ( 1 / ( L_Omega_var_double[c](t1,t1)  *  L_Omega_var_double[c](t1,t1) ) )    )   ).sum() ;
           }
           
           
           //////// then w.r.t the second-to-last diagonal
           int  t1 = n_tests - 2;
           
           double deriv_L_Omega_Tm1_Tm1_inv =    - stan::math::pow( L_Omega_var_double[c](t1, t1), -2) ;
           
         //  grad_bound_z.array() =    (   ( Bound_Z[c].col(t1).array()  *  L_Omega_var_double[c](t1, t1) )  *  (   deriv_L_Omega_Tm1_Tm1_inv    )  )    ; //  check (standard form, but varies depending on gradient)
           grad_prob.col(0).array()  =  (   - y_sign_chunk_times_phi_Bound_Z.col(t1).array()  *   (   (  (   ( Bound_Z[c].col(t1).array()  *  L_Omega_var_double[c](t1, t1) )  *  (   deriv_L_Omega_Tm1_Tm1_inv    )  )  .array() )  )  )  ;     // correct  (standard form)
           
           
           z_grad_term.col(0).array()  =      (  ( (  y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t1).array()   ).array()     *  (   ( Bound_Z[c].col(t1).array()  *  L_Omega_var_double[c](t1, t1) )  *  (   deriv_L_Omega_Tm1_Tm1_inv    )  ).array()  ).array() )   ;  // correct
           
           prod_container_or_inc_array.array()  =   (  L_Omega_var_double[c](t1 + 1, t1)    *   z_grad_term.col(0).array()   ) ; // sequence
           // grad_bound_z.array() =   (   ( - 1 /  L_Omega_var_double[c](t1 + 1, t1 + 1) ) *  prod_container_or_inc_array.array()   )   ;  // correct  (standard form)
           grad_prob.col(1).array()  =   (  - y_sign_chunk_times_phi_Bound_Z.col(t1 + 1).array()   *     (   (   (   ( - 1 /  L_Omega_var_double[c](t1 + 1, t1 + 1) ) *  prod_container_or_inc_array.array()   ) .array()   ) )  ).array()  ;    // correct   (standard form)
           
           U_Omega_grad_array[c](t1, t1) +=   ( (   common_grad_term_1.col(t1).array() )     *    ( prob[c].col(t1 + 1).array()  *   grad_prob.col(0).array()  +   prob[c].col(t1).array()  *      grad_prob.col(1).array()   )  ).sum()   ;
           
         }
         
         
         
         // //////// then w.r.t the third-to-last diagonal .... etc
         {
           
           for (int i = 3; i < n_tests + 1; i++) {
             
             int  t1 = n_tests - i;
             
             //////// 1st component
             // 1st grad_Z term and 1st grad_prob term (simplest terms)
           // grad_bound_z.array()  =   ( Bound_Z[c].col(t1).array()  *  ( - 1 / L_Omega_var_double[c](t1, t1)  ) ).array() ; //  check (standard form, but varies depending on gradient)
             grad_prob.col(0).array()  =   ( - y_sign_chunk_times_phi_Bound_Z.col(t1).array() )  *  ( Bound_Z[c].col(t1).array()  *  ( - 1 / L_Omega_var_double[c](t1, t1)  ) ).array()  ; // correct  (standard form)
             
             z_grad_term.col(0).array()  =    y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t1).array()   *  ( Bound_Z[c].col(t1).array()  *  ( - 1 / L_Omega_var_double[c](t1, t1)  ) ).array()   ;   // correct  (standard form)
             
             // 2nd   grad_Z term and 2nd grad_prob  (more complicated than 1st term)
             prod_container_or_inc_array.array() =    L_Omega_var_double[c](t1 + 1, t1)   * z_grad_term.col(0).array()  ; // correct  (standard form)
           //   grad_bound_z.array()  =  (  ( - 1 / L_Omega_var_double[c](t1 + 1, t1 + 1) ) * prod_container_or_inc_array.array() )  ;  // correct  (standard form)
             grad_prob.col(1).array()  =   ( - y_sign_chunk_times_phi_Bound_Z.col(t1 + 1).array()  )   *  (  ( - 1 / L_Omega_var_double[c](t1 + 1, t1 + 1) ) * prod_container_or_inc_array.array() ).array()  ; // correct  (standard form)
             
             
             for (int ii = 1; ii < i - 1; ii++) {
               z_grad_term.col(ii).array()  =    y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t1 + ii).array()     *   ( ( - 1 / L_Omega_var_double[c](t1 + ii + 1, t1 + ii + 1)  ) * prod_container_or_inc_array.array() ).array()  ;   // correct  (standard form)       // grad_z term 
               prod_container_or_inc_array.matrix() =   (  L_Omega_var_double[c].row(t1 + ii + 1).segment(t1, ii + 1) *   z_grad_term.block(0, 0, chunk_size, ii + 1).transpose() ).transpose().matrix(); // correct  (standard form)
              // grad_bound_z.array()  =  ( ( - 1 / L_Omega_var_double[c](t1 + ii + 1, t1 + ii + 1)  ) * prod_container_or_inc_array.array() ) ; // correct  (standard form)
               grad_prob.col(ii + 1).array()  =   ( - y_sign_chunk_times_phi_Bound_Z.col(t1 + ii + 1).array()  )   *   ( ( - 1 / L_Omega_var_double[c](t1 + ii + 1, t1 + ii + 1)  ) * prod_container_or_inc_array.array() ).array() ;  // correct  (standard form)     //    grad_prob term 
             }
             
             {
               
               derivs_chain_container_vec.array() = 0;
  
                 ///// attempt at vectorising  // bookmark
                 for (int iii = 0; iii <  i; iii++) {
                   derivs_chain_container_vec.array()  +=    grad_prob.col(iii).array()  * (       prop_rowwise_prod_temp.col(t1).array()    /  prob[c].col(t1 + iii).array()  ).array()  ;  // correct  (standard form)
                 }
                 
                 U_Omega_grad_array[c](t1, t1)   +=       ( common_grad_term_1.col(t1).array()   * derivs_chain_container_vec.array() ).sum()  ; // correct  (standard form)
             }
             
           }
           
           
           
         }
         
         }
         
         
         
         
         {
           
           { ///////////////////// last row first
             int t1_dash = 0;  // t1 = n_tests - 1
             
             int t1 = n_tests - (t1_dash + 1); //  starts at n_tests - 1;  // if t1_dash = 0 -> t1 = T - 1
             int t2 = n_tests - (t1_dash + 2); //  starts at n_tests - 2;
             
             U_Omega_grad_array[c](t1,t2) +=      ( ( common_grad_term_1.col(t1).array()      * - y_sign_chunk_times_phi_Bound_Z.col(t1).array() ).array() *   (    (1 / L_Omega_var_double[c](t1,t1)  ) * (-  Z_std_norm[c].col(t2).array()  )   ).array() ).sum() ;
             
             if (t1 > 1) { // starts at  L_{T, T-2}
               {
                 t2 =   n_tests - (t1_dash + 3); // starts at n_tests - 3;
                 U_Omega_grad_array[c](t1,t2) +=     (  common_grad_term_1.col(t1).array()  *   (  - y_sign_chunk_times_phi_Bound_Z.col(t1).array()  ).array()  *   ( (  (1 / L_Omega_var_double[c](t1,t1) ) *  ( - Z_std_norm[c].col(t2).array() )  ).array() ) ).sum()  ;
               }
             }
             
             if (t1 > 2) {// starts at  L_{T, T-3}
               for (int t2_dash = 3; t2_dash < n_tests; t2_dash++ ) { // t2 < t1
                 t2 = n_tests - (t1_dash + t2_dash + 1); // starts at T - 4
                 if (t2 < n_tests - 1) {
                   U_Omega_grad_array[c](t1,t2)  +=   (common_grad_term_1.col(t1).array() *   (  - y_sign_chunk_times_phi_Bound_Z.col(t1).array() ).array() * ( (  ( 1 / L_Omega_var_double[c](t1,t1) ) * - Z_std_norm[c].col(t2).array()  ) ).array()).sum() ;
                 }
               }
             }
           }
         }
         
         
         
         
         {
           /////////////////// then rest of rows (second-to-last row, then third-to-last row, .... , then first row)
           for (int t1_dash = 1; t1_dash <  n_tests - 1;  t1_dash++) {
             int  t1 = n_tests - (t1_dash + 1);
             
             for (int t2_dash = t1_dash + 1; t2_dash <  n_tests;  t2_dash++) {
               int t2 = n_tests - (t2_dash + 1); // starts at t1 - 1, then t1 - 2, up to 0
 
               
               {
 
                 
                //prod_container_or_inc_array.array()  =  Z_std_norm[c].block(0, t2, chunk_size, t1 - t2) * deriv_L_t1.head(t1 - t2) ;
                 prod_container_or_inc_array.array()  =  Z_std_norm[c].col(t2) ; // block(0, t2, chunk_size, t1 - t2) * deriv_L_t1.head(t1 - t2) ;
                 grad_prob.col(0) =      (( -  y_sign_chunk_times_phi_Bound_Z.col(t1).array()   ).array() *   (      ( ( 1/L_Omega_var_double[c](t1,t1) ) *  -    prod_container_or_inc_array.array() ) ).array())  ;
                 
                 
                 z_grad_term.col(0).array()  =               ( (  y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t1).array()    ).array()   ).array()  *
                                                       ( (   ( ( 1 / L_Omega_var_double[c](t1,t1) ) *   -    prod_container_or_inc_array.array()     ).array()  )   ).array()  ;
                 
                 if (t1_dash > 0) {
                   for (int t1_dash_dash = 1; t1_dash_dash <  t1_dash + 1;  t1_dash_dash++) {
                     if (t1_dash_dash > 1) {
                       z_grad_term.col(t1_dash_dash - 1)   =           (  (  y_m_ysign_x_u_array_times_phi_Z_times_phi_Bound_Z.col(t1 + t1_dash_dash - 1).array()    ).array()   *
                                                                          ( 1/L_Omega_var_double[c](t1+t1_dash_dash - 1,t1+t1_dash_dash - 1) ) ).array()  *  ( - prod_container_or_inc_array.array() )    ;
                     }
                     prod_container_or_inc_array.array()  =            (   z_grad_term.block(0, 0, chunk_size, t1_dash_dash) *   L_Omega_var_double[c].row(t1 + t1_dash_dash).segment(t1, t1_dash_dash).transpose()   ) ;
                     grad_prob.col(t1_dash_dash)  =            (  ( ( -  y_sign_chunk_times_phi_Bound_Z.col(t1 + t1_dash_dash).array()     ).array() ) *
                                                               ( 1 / L_Omega_var_double[c](t1+t1_dash_dash,t1+t1_dash_dash) )  *    (  -    prod_container_or_inc_array).array()  ) ;
                   }
                 }
                 
                 {
 
               derivs_chain_container_vec.array() = 0;
                   
                     ///// attempt at vectorising  // bookmark
                     for (int ii = 0; ii <  t1_dash + 1; ii++) {
                       derivs_chain_container_vec.array() += ( grad_prob.col(ii).array()  * ( prop_rowwise_prod_temp.col(t1).array()     /  prob[c].col(t1 + ii).array()  ).array() ).array() ; // correct i think
                     }
                     U_Omega_grad_array[c](t1, t2)   +=       ( common_grad_term_1.col(t1).array()   * derivs_chain_container_vec.array() ).sum()  ; // correct  (standard form)
                 
                 }
                 
                 
                 
               }
             }
           }
           
         }
         
         
         prev_grad_vec(c)  +=  ( ( 1 / prob_n.array() ) * prob[c].rowwise().prod().array() ).matrix().sum()  ;
         
         
         
         
     } // end of c loop
     
    }
     
 
     
   }  // end of chunk loop
   
   

   
   
   //////////////////////// gradients for latent class membership probabilitie(s) (i.e. disease prevalence)
   for (int c = 0; c < n_class; c++) {
     prev_unconstrained_grad_vec(c)  =   prev_grad_vec(c)   * deriv_p_wrt_pu_double ;
   }
   prev_unconstrained_grad_vec(0) = prev_unconstrained_grad_vec(1) - prev_unconstrained_grad_vec(0) - 2 * tanh_u_prev[1];
   prev_unconstrained_grad_vec_out(0) = prev_unconstrained_grad_vec(0);
   
   
   log_prob_out += log_lik.sum();
   
   if (exclude_priors == false)  log_prob_out += prior_densities;
   
   log_prob_out +=  log_jac_u;
   
   log_prob = (double) log_prob_out;
   
   int i = 0; // probs_all_range.prod() cancels out
   for (int c = 0; c < n_class; c++) {
     for (int t = 0; t < n_tests; t++) {
       if (exclude_priors == false) {
         beta_grad_array(c, t) +=  - ((beta_double_array(c,t) - prior_coeffs_mean(t,c)) / prior_coeffs_sd(t,c) ) * (1/ prior_coeffs_sd(t,c) ) ;     // add normal prior density derivative to gradient
       }
       beta_grad_vec(i) = beta_grad_array(c, t);
       i += 1;
     }
   }
   
   
   
   
   {
     int i = 0;
     for (int c = 0; c < n_class; c++ ) {
       for (int t1 = 0; t1 < n_tests; t1++ ) {
         for (int t2 = 0; t2 < t1 + 1; t2++ ) {
           L_Omega_grad_vec(i) = U_Omega_grad_array[c](t1,t2);
           i += 1;
         }
       }
     }
   }
   
   
   
   Eigen::Matrix<double, -1, 1>  grad_wrt_L_Omega_nd =   L_Omega_grad_vec.segment(0, dim_choose_2 + n_tests);
   Eigen::Matrix<double, -1, 1>  grad_wrt_L_Omega_d =   L_Omega_grad_vec.segment(dim_choose_2 + n_tests, dim_choose_2 + n_tests);
   
   U_Omega_grad_vec.segment(0, dim_choose_2) =  ( grad_wrt_L_Omega_nd.transpose()  *  deriv_L_wrt_unc_full[0].cast<double>() ).transpose() ;
   U_Omega_grad_vec.segment(dim_choose_2, dim_choose_2) =   ( grad_wrt_L_Omega_d.transpose()  *  deriv_L_wrt_unc_full[1].cast<double>() ).transpose()  ;
   

   

   
   }
   
   ////////////////////////////////////////////////////////////////////////////////////// output vec
   Eigen::Matrix<double, -1, 1> out_mat    =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N);
   //////////////////////////////////////////////////////////////////////////////////////
   
   
   {


     // out_mat.segment(1, n_us).array() =    u_grad_array_RM.reshaped<RowMajor>()      ;

     for (int nc = 0; nc < n_chunks; nc++) {

       int chunk_counter = nc;

     //    out_mat.segment(1, n_us).segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)  =    u_grad_array_RM.block(chunk_size * chunk_counter, 0, chunk_size, n_tests).reshaped<RowMajor>()     ;
       out_mat.segment(1, n_us).segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests)  =    u_grad_array_CM.block(chunk_size * chunk_counter, 0, chunk_size, n_tests).reshaped()     ;

     //  u_array_RM.array() = 0.5 * (  tanh_uu.segment(chunk_size * n_tests * chunk_counter , chunk_size * n_tests).reshaped(chunk_size, n_tests).array() + 1 ).array() ;

     }

   }
 
    

   
   
   ////////////////////////////  outputs
   out_mat(0) = log_prob;
   
   out_mat.segment(1 + n_us, n_corrs) = target_AD_grad.cast<double>();
   out_mat.segment(1 + n_us, n_corrs) += U_Omega_grad_vec  ;
   
   out_mat.segment(1 + n_us + n_corrs, n_coeffs) = beta_grad_vec ;
   
   out_mat(n_params) = grad_prev_AD +  prev_unconstrained_grad_vec_out(0);   
   
  //  out_mat.segment(1, n_us).array() =  out_mat.segment(1, n_us).array() ; //  (out_mat.segment(1, n_us).array() )   *   ( 0.5 * (1 - tanh_uu.array() * tanh_uu.array()  )  ) - 2 * tanh_uu.array()   ;
     out_mat.segment(1, n_us).array() =     out_mat.segment(1, n_us).array() *  ( 0.5 * (1 - theta.head(n_us).array() * theta.head(n_us).array()  )  ) - 2 * theta.head(n_us).array()   ;
   //  out_mat.segment(1, n_us).array() =     out_mat.segment(1, n_us).array();
   
   out_mat.segment( 1 + n_params, N) = log_lik ;
 
   
   return(out_mat);
   
   
 
   
 }
 
 
 
 
 
 

 
  
  
  

 
 
 
 
 
 
 
 
 
 // [[Rcpp::export]]
 Rcpp::List   Rcpp_fn_ELMC_multiple_leapfrogs_EUC_EFISH_HI_with_MIXED_M_NT_us(              Eigen::Matrix<double, -1, 1  > theta,
                                                                                            Eigen::Matrix<int, -1, -1>	 y,
                                                                                            Rcpp::List lp_and_grad_args,
                                                                                            bool dense_G_indicator,
                                                                                            Eigen::Matrix<double, -1, 1  > velocity_0,  //////////////////////////////////////////////
                                                                                            double numerical_diff_e,
                                                                                            int L,
                                                                                            double eps,
                                                                                            Eigen::Matrix<double, -1, 1  > grad,  //////////////////////////////////////////////
                                                                                            double log_posterior,
                                                                                            Eigen::Matrix<double, -1, 1  > M_main_vec_if_Euclidean,
                                                                                            Eigen::Matrix<double, -1, 1  > M_inv_us_vec_if_Euclidean, //////////////////////////////////////////////
                                                                                            Eigen::Matrix<double, -1, -1  > M_dense_main,
                                                                                            Eigen::Matrix<double, -1, -1  > M_inv_dense_main,
                                                                                            Eigen::Matrix<double, -1, -1  > M_inv_dense_main_chol,
                                                                                            int n_us,
                                                                                            int n_params_main
 )  {
   
   
   
   
   int n_params = theta.rows() ;
   int n_tests = y.cols();
   int n_class = 2;
   int n_bs_LT = n_tests * n_class;
   int n_corrs = n_class * n_tests * (n_tests - 1) * 0.5 ;
   int N = y.rows();
   
   
   ////////////////////// make complete parameter vector (log_diffs then coeffs)
   double half_eps = eps/2;
   
   double log_posterior_0 = 0.0;
   Eigen::Matrix<double, -1, 1> grad_0 = grad;  ///////////////////////////////////////////////
   
   int sampling_option = lp_and_grad_args(60);
   
   Eigen::Matrix<double, -1, 1>  std_norm_vec_1(n_params_main);
   for (int d = 0; d < n_params_main; d++) {
     std_norm_vec_1(d) = R::rnorm(0, 1);
   }
   velocity_0.segment(n_us, n_params_main)  = M_inv_dense_main_chol * std_norm_vec_1;
   
   
   Eigen::Array<double, -1, 1  > M_inv_us_vec_if_Euclidean_sqrt = M_inv_us_vec_if_Euclidean.array().sqrt() ;  //////////////////////////////////////////////
   
   for (int d = 0; d < n_us; d++) {
     velocity_0(d)  = R::rnorm(0,  M_inv_us_vec_if_Euclidean_sqrt(d));
   }
   
   
   Eigen::Matrix<double, -1, 1> velocity = velocity_0;   //////////////////////////////////////////////
   
   
   // Perform L leapfrogs
   Eigen::Matrix<double, -1, 1> lp_and_grad_outs  =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N);   ///////////////////////////////////////////////
   
   
   for (int l = -1; l < L; l++) {
     
     if (l > -1) {
       velocity.head(n_us).array()   = velocity.head(n_us).array()  - half_eps * grad.head(n_us).array() * (M_inv_us_vec_if_Euclidean.array()  );
       theta.head(n_us).array()  = theta.head(n_us).array()  + eps  * velocity.head(n_us).array();
     }
     
     if (l > -1) {
       velocity.segment(n_us, n_params_main) = velocity.segment(n_us, n_params_main) - half_eps *  M_inv_dense_main *  grad.segment(n_us, n_params_main)  ;
       theta.segment(n_us, n_params_main).array()  = theta.segment(n_us, n_params_main).array()  + eps  * velocity.segment(n_us, n_params_main).array();
     }
     
     
     
     if (sampling_option == 1) {
       // lp_and_grad_outs.array()  =    fn_log_posterior_and_gradient_vectorised_chunking_NT_us_2(       theta ,
       //                                                                     y,
       //                                                                     lp_and_grad_args);
     }  else if (sampling_option == 10) {
       // lp_and_grad_outs   =    fn_log_posterior_and_gradient_Chol_Schur_AD(       theta ,
       //                                                                            y,
       //                                                                            lp_and_grad_args) ;
     }  else if (sampling_option == 11) {
       lp_and_grad_outs   =    fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float(       theta ,
                                                                                               y,
                                                                                               lp_and_grad_args) ;
     } else if (sampling_option == 12) {
       // lp_and_grad_outs.array()  =    fn_log_posterior_and_gradient_latent_trait_MD_and_AD(       theta ,
       //                                                                                  y,
       //                                                                                  lp_and_grad_args);
     } else if (sampling_option == 20) {
       // lp_and_grad_outs   =    fn_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float_debug(       theta ,
       //                                                                                               y,
       //                                                                                               lp_and_grad_args) ;
       
     }
     
     
     grad.array() = - lp_and_grad_outs.segment(1, n_params).array();
     
     if (l == -1) {
       grad_0 = grad;
       log_posterior_0 = lp_and_grad_outs(0);
     }
     
     
     if (l > -1)    velocity.head(n_us).array()   = velocity.head(n_us).array()  - half_eps * grad.head(n_us).array() * (M_inv_us_vec_if_Euclidean.array()  );
     if (l > -1)    velocity.segment(n_us, n_params_main) = velocity.segment(n_us, n_params_main) - half_eps *  M_inv_dense_main *  grad.segment(n_us, n_params_main)  ;  
     
     
   }
   
   
   log_posterior =  lp_and_grad_outs(0);
   
   
   if  ((sampling_option > 11)  && (sampling_option < 15)  )  { // for latent trait
     for (int i = n_us + n_bs_LT; i < n_us + n_corrs; i++) {
       grad(i) = 0;
       grad_0(i) = 0;
       velocity(i) = 0 ;
       velocity_0(i) = 0 ;
       theta(i) =   R::rnorm(0, 1);
     }
   }
   
   
   
   List  out_list(20);
   
   int div = 0;
   
   out_list(0) = div;
   
   out_list(1) = theta;
   
   out_list(2) = velocity_0;  //////////
   out_list(3) = velocity;  //////////
   
   out_list(4) = log_posterior;
   out_list(5) = log_posterior_0;
   
   out_list(6) = grad;  //////////
   out_list(7) = grad_0;  //////////
   
   out_list(10) = M_dense_main;
   out_list(11) = M_inv_dense_main;  
   out_list(12) = M_inv_dense_main_chol;
   
   out_list(13) =  lp_and_grad_outs.segment(1 + n_params, N); // log-lik
   
   return(out_list);
   
 }
 
 
 
 
 
 

  

  
  
 
 
// [[Rcpp::export]]
Eigen::Matrix<double, -1, -1>    Rcpp_fn_wo_list_ELMC_multiple_leapfrogs_EUC_EFISH_HI_with_MIXED_M_NT_us( int n_cores, 
                                                                                                          Eigen::Matrix<double, -1, 1  > theta,
                                                                                      Eigen::Matrix<int, -1, -1>	 y,
                                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  X,
                                                                                      bool dense_G_indicator,
                                                                                      double numerical_diff_e,
                                                                                      int L,
                                                                                      double eps,
                                                                                      double log_posterior,
                                                                                      Eigen::Matrix<double, -1, 1  > M_main_vec_if_Euclidean,
                                                                                      Eigen::Matrix<double, -1, 1  > M_inv_us_vec_if_Euclidean, //////////////////////////////////////////////
                                                                                      Eigen::Matrix<double, -1, -1  > M_dense_main,
                                                                                      Eigen::Matrix<double, -1, -1  > M_inv_dense_main,
                                                                                      Eigen::Matrix<double, -1, -1  > M_inv_dense_main_chol,
                                                                                      int n_us,
                                                                                      int n_params_main,
                                                                                      bool exclude_priors,
                                                                                      bool CI,
                                                                                      Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                                      Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                                      Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                                      int n_class,
                                                                                      int n_tests,
                                                                                      int ub_threshold_phi_approx,
                                                                                      int n_chunks,
                                                                                      bool corr_force_positive,
                                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                                      bool corr_prior_beta ,
                                                                                      bool corr_prior_norm ,
                                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
                                                                                      std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                                      double prev_prior_a,
                                                                                      double prev_prior_b,
                                                                                      int Phi_type,
                                                                                      int sampling_option,
                                                                                      bool generate_velocity,
                                                                                      Eigen::Matrix<double, -1, 1  > velocity_0
 )  {  




   int n_params = theta.rows() ;
 //  int n_tests = y.cols();
  // int n_class = 2;
   int n_bs_LT = n_tests * n_class;
   int n_corrs = n_class * n_tests * (n_tests - 1) * 0.5 ;
   int N = y.rows();


   ////////////////////// make complete parameter vector (log_diffs then coeffs)
   double half_eps = eps/2;

   double log_posterior_0 = 0.0;
 
  // Eigen::Matrix<double, -1, 1  > velocity_0(n_params) ;   //////////////////////////////////////////////
   
   if (generate_velocity == true)  {
     
           Eigen::Matrix<double, -1, 1>  std_norm_vec_1(n_params_main);
           for (int d = 0; d < n_params_main; d++) {
             std_norm_vec_1(d) = R::rnorm(0, 1);
           }
           velocity_0.segment(n_us, n_params_main)  = M_inv_dense_main_chol * std_norm_vec_1;
      
     
         Eigen::Array<double, -1, 1  > M_inv_us_vec_if_Euclidean_sqrt = M_inv_us_vec_if_Euclidean.array().sqrt() ;  //////////////////////////////////////////////
    
         for (int d = 0; d < n_us; d++) {
           velocity_0(d)  = R::rnorm(0,  M_inv_us_vec_if_Euclidean_sqrt(d));
         }
         
   }

    Eigen::Matrix<double, -1, 1> velocity = velocity_0;   //////////////////////////////////////////////
    Eigen::Matrix<double, -1, 1>   individual_log_lik(N);


   // Perform L leapfrogs

    
    {
   
     Eigen::Matrix<double, -1, 1>  grad(n_params);
     Eigen::Matrix<double, -1, 1> lp_and_grad_outs  =  Eigen::Matrix<double, -1, 1>::Zero(n_params + 1 + N);   ///////////////////////////////////////////////
              
           for (int l = -1; l < L; l++) {
             
        
                             if (l > -1) {
                               velocity.segment(n_us, n_params_main)  = velocity.segment(n_us, n_params_main) - half_eps *  M_inv_dense_main *  grad.segment(n_us, n_params_main)  ;  // update velocity for MAIN params (DENSE G)
                               velocity.head(n_us).array()  = velocity.head(n_us).array() - half_eps * grad.head(n_us).array() * (M_inv_us_vec_if_Euclidean.head(n_us).array()  );  // update velocity for NUISANCE params (diag G)
        
        
                               theta.array()  = theta.array()  + eps  * velocity.array(); //// update params by full step
                             }
        
        
                               if (sampling_option == 11) {
        
                                   lp_and_grad_outs   =      fn_wo_list_log_posterior_and_gradient_Chol_Schur_MD_and_AD_float( n_cores, 
                                                                                                                               theta,
                                                                                                                                y,
                                                                                                                                X,
                                                                                                                               exclude_priors,
                                                                                                                                CI,
                                                                                                                               lkj_cholesky_eta,
                                                                                                                                prior_coeffs_mean ,
                                                                                                                               prior_coeffs_sd,
                                                                                                                                n_class,
                                                                                                                                n_tests,
                                                                                                                                ub_threshold_phi_approx,
                                                                                                                                n_chunks,
                                                                                                                                corr_force_positive,
                                                                                                                              prior_for_corr_a,
                                                                                                                                 prior_for_corr_b,
                                                                                                                                corr_prior_beta ,
                                                                                                                                corr_prior_norm ,
                                                                                                                                lb_corr,
                                                                                                                                 ub_corr,
                                                                                                                                  known_values_indicator,
                                                                                                                                known_values,
                                                                                                                                prev_prior_a,
                                                                                                                                prev_prior_b,
                                                                                                                                Phi_type) ;
                               } else if (sampling_option == 10) {  // AD - Schur
                                 
                                 lp_and_grad_outs   =      fn_wo_list_log_posterior_and_gradient_Chol_Schur_AD_float( n_cores, 
                                                                                                                             theta,
                                                                                                                             y,
                                                                                                                             X,
                                                                                                                             exclude_priors,
                                                                                                                             CI,
                                                                                                                             lkj_cholesky_eta,
                                                                                                                             prior_coeffs_mean ,
                                                                                                                             prior_coeffs_sd,
                                                                                                                             n_class,
                                                                                                                             n_tests,
                                                                                                                             ub_threshold_phi_approx,
                                                                                                                             n_chunks,
                                                                                                                             corr_force_positive,
                                                                                                                             prior_for_corr_a,
                                                                                                                             prior_for_corr_b,
                                                                                                                             corr_prior_beta ,
                                                                                                                             corr_prior_norm ,
                                                                                                                             lb_corr,
                                                                                                                             ub_corr,
                                                                                                                             known_values_indicator,
                                                                                                                             known_values,
                                                                                                                             prev_prior_a,
                                                                                                                             prev_prior_b,
                                                                                                                             Phi_type) ;
                                 
                               }
                               
        
        
        
        
                             grad.array() = - lp_and_grad_outs.segment(1, n_params).array();
                             log_posterior =  lp_and_grad_outs(0);
        
                             if (l == -1)     log_posterior_0 = lp_and_grad_outs(0);
                             
        
                             if (l > -1) {
                                velocity.segment(n_us, n_params_main)  = velocity.segment(n_us, n_params_main) - half_eps *  M_inv_dense_main *  grad.segment(n_us, n_params_main)  ;  // update velocity for MAIN params (DENSE G)
                                velocity.head(n_us)  = velocity.head(n_us).array() - half_eps * grad.head(n_us).array() * (M_inv_us_vec_if_Euclidean.head(n_us).array()  );  // update velocity for NUISANCE params (diag G)
                             }
                             
                        
        
           }
           
           individual_log_lik = lp_and_grad_outs.segment(1 + n_params, N); 

    }

 

  int div = 0; // handles in R currently

   if  ((sampling_option > 11)  && (sampling_option < 15)  )  { // for latent trait
     for (int i = n_us + n_bs_LT; i < n_us + n_corrs; i++) {
           velocity(i) = 0 ;
           velocity_0(i) = 0 ;
           theta(i) =   R::rnorm(0, 1);
     }
   }

 
   Eigen::Matrix<double, -1, -1>  out_mat =   Eigen::Matrix<double, -1, -1>::Zero(n_params, 4); //////////////////////////////////////////////

   out_mat(0, 0) = log_posterior_0; 
   out_mat(1, 0) = log_posterior;
   out_mat.col(1) = theta;
   out_mat.col(2) = velocity_0;
   out_mat.col(3) = velocity;
 
   out_mat.col(0).segment(2, N) =  individual_log_lik; 
   

   return(out_mat);

 }

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

 
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, 1>    Rcpp_fn_no_list_HMC_single_iter(         int n_cores, 
                                                                           Eigen::Matrix<double, -1, 1 >  theta_initial,  //////////////////////////////////////////////
                                                                               Eigen::Matrix<int, -1, -1>	 y,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  X,
                                                                               bool dense_G_indicator,
                                                                               int L,
                                                                               double eps,
                                                                               double log_posterior_initial,
                                                                               Eigen::Matrix<double, -1, 1  > M_main_vec_if_Euclidean,
                                                                               Eigen::Matrix<double, -1, 1  > M_inv_us_vec_if_Euclidean, //////////////////////////////////////////////
                                                                               Eigen::Matrix<double, -1, -1  > M_dense_main,
                                                                               Eigen::Matrix<double, -1, -1  > M_inv_dense_main,
                                                                               Eigen::Matrix<double, -1, -1  > M_inv_dense_main_chol,
                                                                               int n_us,
                                                                               int n_params_main,
                                                                               bool exclude_priors,
                                                                               bool CI,
                                                                               Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                               Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                               Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                               int n_class,
                                                                               int n_tests,
                                                                               int ub_threshold_phi_approx,
                                                                               int n_chunks,
                                                                               bool corr_force_positive,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                               bool corr_prior_beta ,
                                                                               bool corr_prior_norm ,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
                                                                               std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                               std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                               double prev_prior_a,
                                                                               double prev_prior_b,
                                                                               int Phi_type,
                                                                               int sampling_option,
                                                                               bool generate_velocity,
                                                                               Eigen::Matrix<double, -1, 1  > velocity_0
                                                                                 
                                                                                 
 )  {
 
   int N = y.rows();
   int n_params = n_us + n_params_main;
   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
   int n_coeffs = n_class * n_tests * 1;
 

      Eigen::Matrix<double, -1, 1 >  theta = theta_initial;  //////////////////////////////////////////////
 
     
     double U_x_initial = - log_posterior_initial;
     double U_x = - log_posterior_initial;
     
     double log_posterior  =   log_posterior_initial;
     double log_posterior_prop = log_posterior;
   
   
   
   Eigen::Matrix<double, -1, 1 >   individual_log_lik(N);
   
   {
 
     
     Eigen::Matrix<double, -1, -1>  out_mat_for_leapfrog  =   Rcpp_fn_wo_list_ELMC_multiple_leapfrogs_EUC_EFISH_HI_with_MIXED_M_NT_us(                 n_cores, 
                                                                                                                                                       theta_initial,  //////////////////////////////////////////////
                                                                                                                                            y,
                                                                                                                                            X,
                                                                                                                                            dense_G_indicator,
                                                                                                                                            0.0001, // num_diff_e
                                                                                                                                            L,
                                                                                                                                            eps,
                                                                                                                                            log_posterior_initial, /// 
                                                                                                                                            M_main_vec_if_Euclidean,
                                                                                                                                            M_inv_us_vec_if_Euclidean, //////////////////////////////////////////////
                                                                                                                                            M_dense_main,
                                                                                                                                            M_inv_dense_main,
                                                                                                                                            M_inv_dense_main_chol,
                                                                                                                                            n_us,
                                                                                                                                            n_params_main,
                                                                                                                                            exclude_priors,
                                                                                                                                            CI,
                                                                                                                                            lkj_cholesky_eta,
                                                                                                                                            prior_coeffs_mean ,
                                                                                                                                            prior_coeffs_sd,
                                                                                                                                            n_class,
                                                                                                                                            n_tests,
                                                                                                                                            ub_threshold_phi_approx,
                                                                                                                                            n_chunks,
                                                                                                                                            corr_force_positive,
                                                                                                                                            prior_for_corr_a,
                                                                                                                                            prior_for_corr_b,
                                                                                                                                            corr_prior_beta ,
                                                                                                                                            corr_prior_norm ,
                                                                                                                                            lb_corr,
                                                                                                                                            ub_corr,
                                                                                                                                            known_values_indicator,
                                                                                                                                            known_values,
                                                                                                                                            prev_prior_a,
                                                                                                                                            prev_prior_b,
                                                                                                                                            Phi_type, 
                                                                                                                                            sampling_option,
                                                                                                                                            generate_velocity,
                                                                                                                                            velocity_0);
           
       
           log_posterior = out_mat_for_leapfrog(1, 0) ;
           log_posterior_prop = log_posterior ; 
           U_x = - log_posterior;
           log_posterior_initial = out_mat_for_leapfrog(0, 0) ; 
           U_x_initial =  - log_posterior_initial;
           
           
           individual_log_lik =  out_mat_for_leapfrog.col(0).segment(2, N);
           

              
              double energy_old = U_x_initial ;
              energy_old +=  0.5 * ( out_mat_for_leapfrog.col(2).segment(n_us, n_params_main).array() * Rcpp_mult_mat_by_col_vec(M_dense_main, out_mat_for_leapfrog.col(2).segment(n_us, n_params_main)).array()).matrix().sum() ;
              energy_old +=  0.5 * ( stan::math::square( out_mat_for_leapfrog.col(2).head(n_us) ).array() * ( 1 / M_inv_us_vec_if_Euclidean.array() ) ).array().sum() ; 
              
              double energy_new = U_x ; 
              energy_new +=  0.5  * (out_mat_for_leapfrog.col(3).segment(n_us, n_params_main).array() * Rcpp_mult_mat_by_col_vec(M_dense_main, out_mat_for_leapfrog.col(3).segment(n_us, n_params_main)).array()).matrix().sum() ;
              energy_new +=  0.5 * ( stan::math::square( out_mat_for_leapfrog.col(3).head(n_us) ).array() * ( 1 / M_inv_us_vec_if_Euclidean.array() ) ).array().sum() ; 
              
              double log_ratio = - energy_new + energy_old; 
              
              Eigen::Matrix<double, -1, 1 >  p_jump_vec(2);
              p_jump_vec(0) = 1;
              p_jump_vec(1) = std::exp(log_ratio);
              
              double p_jump = stan::math::min(p_jump_vec); 
              
              double accept = 0;
              
              int div = 0;
              
              
              if  ((R::runif(0, 1) > p_jump) || (div == 1)) {  // # reject proposal
        
                           accept = 0;
                           theta =    theta_initial ; 
  
              } else {   // # accept proposal
                
                
                           accept = 1;
                           theta = out_mat_for_leapfrog.col(1) ; //  theta_prop ; // out_mat_for_leapfrog.col(1).segment(1, n_params) ; 
 
              }
 
    }
     
 
   
//   Eigen::Matrix<double, -1, -1>  out_mat =   Eigen::Matrix<double, -1, -1>::Zero(n_params, 2);  //////////////////////////////////////////////
   
   Eigen::Matrix<double, -1, 1>  out_mat =   Eigen::Matrix<double, -1, 1>::Zero(n_params + N);  //////////////////////////////////////////////
   
   out_mat.head(n_params) = theta;
   out_mat.segment(n_params, N) = individual_log_lik;
   
   return(out_mat); 
   
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 // [[Rcpp::export]]
 Eigen::Matrix<double, -1, -1>    Rcpp_fn_no_list_HMC_single_iter_burnin(     int n_cores, 
                                                                              Eigen::Matrix<double, -1, 1 >  theta_initial,  //////////////////////////////////////////////
                                                                             Eigen::Matrix<int, -1, -1>	 y,
                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  X,
                                                                             bool dense_G_indicator,
                                                                             int L,
                                                                             double eps,
                                                                             double log_posterior_initial,
                                                                             Eigen::Matrix<double, -1, 1  > M_main_vec_if_Euclidean,
                                                                             Eigen::Matrix<double, -1, 1  > M_inv_us_vec_if_Euclidean, //////////////////////////////////////////////
                                                                             Eigen::Matrix<double, -1, -1  > M_dense_main,
                                                                             Eigen::Matrix<double, -1, -1  > M_inv_dense_main,
                                                                             Eigen::Matrix<double, -1, -1  > M_inv_dense_main_chol,
                                                                             int n_us,
                                                                             int n_params_main,
                                                                             bool exclude_priors,
                                                                             bool CI,
                                                                             Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                             Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                             Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                             int n_class,
                                                                             int n_tests,
                                                                             int ub_threshold_phi_approx,
                                                                             int n_chunks,
                                                                             bool corr_force_positive,
                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                             bool corr_prior_beta ,
                                                                             bool corr_prior_norm ,
                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
                                                                             std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                             std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                             double prev_prior_a,
                                                                             double prev_prior_b,
                                                                             int Phi_type,
                                                                             int sampling_option,
                                                                             bool generate_velocity,
                                                                             Eigen::Matrix<double, -1, 1  > velocity_0
                                                                               
                                                                               
 )  {
   
   int N = y.rows();
   int n_params = n_us + n_params_main;
   int n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
   int n_coeffs = n_class * n_tests * 1;
   
   
   Eigen::Matrix<double, -1, 1 >  theta = theta_initial;  //////////////////////////////////////////////
   Eigen::Matrix<double, -1, 1 >  theta_prop = theta_initial;  //////////////////////////////////////////////
   
   double U_x_initial = - log_posterior_initial;
   double U_x = - log_posterior_initial;
   
   double log_posterior  =   log_posterior_initial;
   double log_posterior_prop = log_posterior;
   
   

     //Eigen::Matrix<double, -1, 1 >    velocity_0(n_params) ;  //  (n_params);  //////////////////////////////////////////////
     Eigen::Matrix<double, -1, 1 >    velocity_prop = velocity_0 ; // (n_params) ;  // (n_params);  //////////////////////////////////////////////
     Eigen::Matrix<double, -1, 1 >    velocity = velocity_0; // (n_params) ;  // (n_params);  //////////////////////////////////////////////
     
     int div = 0;
     double p_jump = 0;
     double accept = 0;
   
   
   {
        Eigen::Matrix<double, -1, -1>  out_mat_for_leapfrog =   Eigen::Matrix<double, -1, -1>::Zero(n_params, 4);
 
     // try {
                        out_mat_for_leapfrog  =   Rcpp_fn_wo_list_ELMC_multiple_leapfrogs_EUC_EFISH_HI_with_MIXED_M_NT_us(             n_cores, 
                                                                                                                                       theta_initial,  //////////////////////////////////////////////
                                                                                                                                      y,
                                                                                                                                      X,
                                                                                                                                      dense_G_indicator,
                                                                                                                                      0.0001, // num_diff_e
                                                                                                                                      L,
                                                                                                                                      eps,
                                                                                                                                      log_posterior_initial, /// 
                                                                                                                                      M_main_vec_if_Euclidean,
                                                                                                                                      M_inv_us_vec_if_Euclidean, //////////////////////////////////////////////
                                                                                                                                      M_dense_main,
                                                                                                                                      M_inv_dense_main,
                                                                                                                                      M_inv_dense_main_chol,
                                                                                                                                      n_us,
                                                                                                                                      n_params_main,
                                                                                                                                      exclude_priors,
                                                                                                                                      CI,
                                                                                                                                      lkj_cholesky_eta,
                                                                                                                                      prior_coeffs_mean ,
                                                                                                                                      prior_coeffs_sd,
                                                                                                                                      n_class,
                                                                                                                                      n_tests,
                                                                                                                                      ub_threshold_phi_approx,
                                                                                                                                      n_chunks,
                                                                                                                                      corr_force_positive,
                                                                                                                                      prior_for_corr_a,
                                                                                                                                      prior_for_corr_b,
                                                                                                                                      corr_prior_beta ,
                                                                                                                                      corr_prior_norm ,
                                                                                                                                      lb_corr,
                                                                                                                                      ub_corr,
                                                                                                                                      known_values_indicator,
                                                                                                                                      known_values,
                                                                                                                                      prev_prior_a,
                                                                                                                                      prev_prior_b,
                                                                                                                                      Phi_type, 
                                                                                                                                      sampling_option,
                                                                                                                                      generate_velocity,
                                                                                                                                      velocity_0);
                        
      div = 0;


     // } catch (...) {
     //   div = 1;
     // }
     
     
     
     theta_prop = out_mat_for_leapfrog.col(1);
     
     log_posterior = out_mat_for_leapfrog(1, 0) ;
     log_posterior_prop = log_posterior ; 
     U_x = - log_posterior_prop;
     
     log_posterior_initial = out_mat_for_leapfrog(0, 0) ; 
     U_x_initial =  - log_posterior_initial;
   
   //if (generate_velocity == true) {
          velocity_0 = out_mat_for_leapfrog.col(2);
          velocity_prop = out_mat_for_leapfrog.col(3);
  // }
     
     
     
     double energy_old = U_x_initial ;
     energy_old +=  0.5 * ( velocity_0.segment(n_us, n_params_main).array() * Rcpp_mult_mat_by_col_vec(M_dense_main, velocity_0.segment(n_us, n_params_main)).array()).matrix().sum() ;
     energy_old +=  0.5 * ( stan::math::square( velocity_0.head(n_us) ).array() * ( 1 / M_inv_us_vec_if_Euclidean.array() ) ).array().sum() ; 
     
     double energy_new = U_x ; 
     energy_new +=  0.5  * (velocity_prop.segment(n_us, n_params_main).array() * Rcpp_mult_mat_by_col_vec(M_dense_main, velocity_prop.segment(n_us, n_params_main)).array()).matrix().sum() ;
     energy_new +=  0.5 * ( stan::math::square( velocity_prop.head(n_us) ).array() * ( 1 / M_inv_us_vec_if_Euclidean.array() ) ).array().sum() ; 
     
     double log_ratio = - energy_new + energy_old; 
     
     Eigen::Matrix<double, -1, 1 >  p_jump_vec(2);
     p_jump_vec(0) = 1;
     p_jump_vec(1) = std::exp(log_ratio);
     
     p_jump = stan::math::min(p_jump_vec); 
     
     accept = 0;
     
     
     if  ((R::runif(0, 1) > p_jump) || (div == 1)) {  // # reject proposal
       
             accept = 0;
             theta =    theta_initial ; 
             
             U_x  = U_x_initial  ;
             log_posterior = log_posterior_initial ;
      
             velocity = velocity_0; 
             
     } else {   // # accept proposal
       
             accept = 1;
             theta = theta_prop; 
      
             log_posterior = log_posterior_prop;
             U_x  = - log_posterior;
               
             velocity = velocity_prop;
             
     }
     
     
     
   }
   
   
   Eigen::Matrix<double, -1, -1>  out_mat =   Eigen::Matrix<double, -1, -1>::Zero(n_params, 7);  //////////////////////////////////////////////
   
   out_mat(0, 0) = log_posterior; 
   out_mat(1, 0) = log_posterior_initial;
   out_mat(2, 0) = log_posterior_prop;
   out_mat(3, 0) = div;
   out_mat(4, 0) = p_jump;
   out_mat(5, 0) = accept;
   
   out_mat.col(1) = theta; 
   out_mat.col(2) = theta_initial; 
   out_mat.col(3) = theta_prop; 
   
   out_mat.col(4) = velocity; 
   out_mat.col(5) = velocity_0; 
   out_mat.col(6) = velocity_prop; 
   

   
   return(out_mat); 
   
 }
 
 
 
 
 
 
 
 // class ProgressBar {
 // public:
 //   virtual ~ProgressBar() = 0;
 //   virtual void display() = 0;
 //   virtual void update(float progress) = 0;
 //   virtual void end_display() = 0;
 // };
 
 
 
 // class MinimalProgressBar: public ProgressBar{
 // public:
 //   MinimalProgressBar()  {
 //     _finalized = false;
 //   }
 //   
 //   ~MinimalProgressBar() {}
 //   
 //   void display() {
 //     REprintf("Progress: ");
 //   }
 //   
 //   void update(float progress) {
 //     if (_finalized) return;
 //     REprintf("+");
 //   }
 //   
 //   void end_display() {
 //     if (_finalized) return;
 //     REprintf("\n");
 //     _finalized = true;
 //   }
 //   
 // private:
 //   
 //   bool _finalized;
 //   
 // };
 
// Rcpp::List 
// 




 
 // [[Rcpp::export]]
Rcpp::List   Rcpp_fn_run_leapfrog_integrator_non_parellel_test(      int n_cores, 
                                                                     int n_iter_test,
                                                                      int n_chain_for_loading_bar,
                                                                                            double tau, 
                                                                                            Eigen::Matrix<double, -1, 1 >  theta_initial,  //////////////////////////////////////////////
                                                                                            Eigen::Matrix<int, -1, -1>	 y,
                                                                                            std::vector<Eigen::Matrix<double, -1, -1 > >  X,
                                                                                            bool dense_G_indicator,
                                                                                            double numerical_diff_e,
                                                                                            int L,
                                                                                            double eps,
                                                                                            double log_posterior,
                                                                                            Eigen::Matrix<double, -1, 1  > M_main_vec_if_Euclidean,
                                                                                            Eigen::Matrix<double, -1, 1  > M_inv_us_vec_if_Euclidean, //////////////////////////////////////////////
                                                                                            Eigen::Matrix<double, -1, -1  > M_dense_main,
                                                                                            Eigen::Matrix<double, -1, -1  > M_inv_dense_main,
                                                                                            Eigen::Matrix<double, -1, -1  > M_inv_dense_main_chol,
                                                                                            int n_us,
                                                                                            int n_params_main,
                                                                                            bool exclude_priors,
                                                                                            bool CI,
                                                                                            Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                                            Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                                            Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                                            int n_class,
                                                                                            int n_tests,
                                                                                            int ub_threshold_phi_approx,
                                                                                            int n_chunks,
                                                                                            bool corr_force_positive,
                                                                                            std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                                            std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                                            bool corr_prior_beta ,
                                                                                            bool corr_prior_norm ,
                                                                                            std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                                            std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
                                                                                            std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                                            std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                                            double prev_prior_a,
                                                                                            double prev_prior_b,
                                                                                            int Phi_type,
                                                                                            int sampling_option,
                                                                                            bool generate_velocity,
                                                                                            Eigen::Matrix<double, -1, 1  > velocity_0,
                                                                                            bool tau_jittered
                                                                                              
 )  {
   
   
   int n_params = n_us + n_params_main;
   int N = y.rows(); 
 
   Eigen::Matrix<double, -1, -1 >   theta_main_trace  = Eigen::Matrix<double, -1, -1  >::Zero(n_params_main, n_iter_test);
 //  Eigen::Matrix<double, -1, -1 >   log_lik_trace  = Eigen::Matrix<double, -1, -1  >::Zero(N, n_iter_test);
   Eigen::Matrix<double, -1, 1 >       theta_previous_iter = theta_initial;
   
   Eigen::Matrix<int, -1, 1 >   div_vec  = Eigen::Matrix<int, -1, 1  >::Zero(n_iter_test);
 
     bool display_progress = false;
     if (n_chain_for_loading_bar == 1)    display_progress = true;
     
     
      Progress p(n_iter_test, display_progress); 
 

     double tau_main_ii = tau;
 
 
 for (int ii = 0; ii < n_iter_test; ++ii)  {
     
     if (n_chain_for_loading_bar == 1)  { 
         p.increment(); // update progress
     }
     
     if (Progress::check_abort() )    return -1;
     
     
     
     
              if (tau_jittered == true)     tau_main_ii = R::runif(0,  2*tau); 
              else                          tau_main_ii = tau; 
 
              double L_main_ii = std::ceil(tau_main_ii / eps);
                 
                 
                 
                 
                 
              //   if (L_main_ii < 1) L_main_ii == 1;
                  
          
                 
                 {
                   
 
               try {
         
                     Eigen::Matrix<double, -1, 1 >   single_iter_out =   Rcpp_fn_no_list_HMC_single_iter(    n_cores, 
                                                                                                              theta_previous_iter,   //////////////////////////////////////////////
                                                                                                                 y,
                                                                                                                 X,
                                                                                                                 dense_G_indicator, //  5
                                                                                                                 L_main_ii,
                                                                                                                 eps,
                                                                                                                 log_posterior,
                                                                                                                 M_main_vec_if_Euclidean,
                                                                                                                 M_inv_us_vec_if_Euclidean,  //  10    //////////////////////////////////////////////
                                                                                                                 M_dense_main,
                                                                                                                 M_inv_dense_main,
                                                                                                                 M_inv_dense_main_chol,
                                                                                                                 n_us,
                                                                                                                 n_params_main ,   //  15
                                                                                                                 exclude_priors,
                                                                                                                 CI,
                                                                                                                 lkj_cholesky_eta,
                                                                                                                 prior_coeffs_mean ,
                                                                                                                 prior_coeffs_sd,   //  20
                                                                                                                 n_class,
                                                                                                                 n_tests,
                                                                                                                 ub_threshold_phi_approx,
                                                                                                                 n_chunks,
                                                                                                                 corr_force_positive,   //  25
                                                                                                                 prior_for_corr_a,
                                                                                                                 prior_for_corr_b,
                                                                                                                 corr_prior_beta ,
                                                                                                                 corr_prior_norm ,
                                                                                                                 lb_corr,           //  30
                                                                                                                 ub_corr,
                                                                                                                 known_values_indicator,
                                                                                                                 known_values,
                                                                                                                 prev_prior_a,
                                                                                                                 prev_prior_b,       //  35
                                                                                                                 Phi_type,       
                                                                                                                 sampling_option,
                                                                                                                 generate_velocity,
                                                                                                                 velocity_0) ; // //  40
                     
                     theta_previous_iter = single_iter_out.head(n_params) ; // .cast<float>(); 
                  //   theta_previous_previous_iter = theta_previous_iter;
                     theta_main_trace.col(ii) = single_iter_out.head(n_params).segment(n_us, n_params_main) ; // .cast<float>();
                   //  log_lik_trace.col(ii) = single_iter_out.col(1).head(N);  
 
                     
                   } catch (...) {
                     div_vec(ii) = 1;
                    //   theta_previous_iter =  theta_previous_previous_iter;
                       theta_main_trace.col(ii) =   theta_main_trace.col(ii - 1); 
                     //  log_lik_trace.col(ii) =   log_lik_trace.col(ii - 1); 
                       theta_previous_iter = theta_previous_iter;
                   }
                   
      
                 }
                 
   
                 
     
   }
   
   
 
   
   Rcpp::List out_list(5);

   out_list(0) = theta_main_trace;
 //  out_list(1) = log_lik_trace;
   out_list(2) = div_vec;
   
   return(out_list);
   
 }
 
 
 
 
 
 
 
 
 
 // [[Rcpp::export]]
 Rcpp::List   Rcpp_fn_post_burnin_HMC_post_adaptation_phase(      int n_cores, 
                                                                      int n_iter_test,
                                                                      int n_chain_for_loading_bar,
                                                                      double tau, 
                                                                      Eigen::Matrix<double, -1, 1 >  theta_initial,  //////////////////////////////////////////////
                                                                      Eigen::Matrix<int, -1, -1>	 y,
                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  X,
                                                                      bool dense_G_indicator,
                                                                      double numerical_diff_e,
                                                                      int L,
                                                                      double eps,
                                                                      double log_posterior,
                                                                      Eigen::Matrix<double, -1, 1  > M_main_vec_if_Euclidean,
                                                                      Eigen::Matrix<double, -1, 1  > M_inv_us_vec_if_Euclidean, //////////////////////////////////////////////
                                                                      Eigen::Matrix<double, -1, -1  > M_dense_main,
                                                                      Eigen::Matrix<double, -1, -1  > M_inv_dense_main,
                                                                      Eigen::Matrix<double, -1, -1  > M_inv_dense_main_chol,
                                                                      int n_us,
                                                                      int n_params_main,
                                                                      bool exclude_priors,
                                                                      bool CI,
                                                                      Eigen::Matrix<double, -1, 1>  lkj_cholesky_eta,
                                                                      Eigen::Matrix<double, -1, -1> prior_coeffs_mean ,
                                                                      Eigen::Matrix<double, -1, -1> prior_coeffs_sd,
                                                                      int n_class,
                                                                      int n_tests,
                                                                      int ub_threshold_phi_approx,
                                                                      int n_chunks,
                                                                      bool corr_force_positive,
                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_a,
                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  prior_for_corr_b,
                                                                      bool corr_prior_beta ,
                                                                      bool corr_prior_norm ,
                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  lb_corr,
                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >  ub_corr,
                                                                      std::vector<Eigen::Matrix<int, -1, -1 > >      known_values_indicator,
                                                                      std::vector<Eigen::Matrix<double, -1, -1 > >   known_values,
                                                                      double prev_prior_a,
                                                                      double prev_prior_b,
                                                                      int Phi_type,
                                                                      int sampling_option
                                                                      )  {
   
   
   int n_params = n_us + n_params_main;
   int N = y.rows(); 
   
   Eigen::Matrix<double, -1, -1 >   theta_main_trace  = Eigen::Matrix<double, -1, -1  >::Zero(n_params_main, n_iter_test);
   //  Eigen::Matrix<double, -1, -1 >   log_lik_trace  = Eigen::Matrix<double, -1, -1  >::Zero(N, n_iter_test);
   Eigen::Matrix<double, -1, 1 >       theta_previous_iter = theta_initial;
   
   Eigen::Matrix<int, -1, 1 >   div_vec  = Eigen::Matrix<int, -1, 1  >::Zero(n_iter_test);
   
   bool display_progress = false;
   if (n_chain_for_loading_bar == 1)    display_progress = true;
   
   
   Progress p(n_iter_test, display_progress); 

   int Phi_type_original = Phi_type;
   
   for (int ii = 0; ii < n_iter_test; ++ii)  {
     
     
                         
                         Eigen::Matrix<double, -1, 1  > velocity_0(n_params) ;   //////////////////////////////////////////////
                         
                         {
                           
                                 Eigen::Matrix<double, -1, 1>  std_norm_vec_1(n_params_main);
                                 for (int d = 0; d < n_params_main; d++) {
                                   std_norm_vec_1(d) = R::rnorm(0, 1);
                                 }
                                 velocity_0.segment(n_us, n_params_main)  = M_inv_dense_main_chol * std_norm_vec_1;
                                 
                                 
                                 Eigen::Array<double, -1, 1  > M_inv_us_vec_if_Euclidean_sqrt = M_inv_us_vec_if_Euclidean.array().sqrt() ;  //////////////////////////////////////////////
                                 
                                 for (int d = 0; d < n_us; d++) {
                                   velocity_0(d)  = R::rnorm(0,  M_inv_us_vec_if_Euclidean_sqrt(d));
                                 }
                           
                         }
                        
                     
                     if (n_chain_for_loading_bar == 1)  { 
                       p.increment(); // update progress
                     }
                     
                     if (Progress::check_abort() )    return -1;
                     
                     double tau_main_ii = R::runif(0,  2*tau); 
                     double L_main_ii = std::ceil(tau_main_ii / eps);
                   //  if (L_main_ii < 1) L_main_ii == 1;
                     
                     bool skip = false;
                     for (int attempt = 0; attempt < 2; ++attempt)  {
                     
                               
                                       if (skip == true) {
                                         skip = false;
                                         continue;
                                       }
                                       
                                       if (attempt == 0)   { 
                                         Phi_type = Phi_type_original;
                                       } else { 
                                         Phi_type = 3;
                                       }
                                       
                                       div_vec(ii) = 0;
                                       
                                       
                               {
                                 
                                 
                                 try {
                                   
                                   Eigen::Matrix<double, -1, 1 >   single_iter_out =   Rcpp_fn_no_list_HMC_single_iter(    n_cores, 
                                                                                                                           theta_previous_iter,   //////////////////////////////////////////////
                                                                                                                           y,
                                                                                                                           X,
                                                                                                                           dense_G_indicator, //  5
                                                                                                                           L_main_ii,
                                                                                                                           eps,
                                                                                                                           log_posterior,
                                                                                                                           M_main_vec_if_Euclidean,
                                                                                                                           M_inv_us_vec_if_Euclidean,  //  10    //////////////////////////////////////////////
                                                                                                                           M_dense_main,
                                                                                                                           M_inv_dense_main,
                                                                                                                           M_inv_dense_main_chol,
                                                                                                                           n_us,
                                                                                                                           n_params_main ,   //  15
                                                                                                                           exclude_priors,
                                                                                                                           CI,
                                                                                                                           lkj_cholesky_eta,
                                                                                                                           prior_coeffs_mean ,
                                                                                                                           prior_coeffs_sd,   //  20
                                                                                                                           n_class,
                                                                                                                           n_tests,
                                                                                                                           ub_threshold_phi_approx,
                                                                                                                           n_chunks,
                                                                                                                           corr_force_positive,   //  25
                                                                                                                           prior_for_corr_a,
                                                                                                                           prior_for_corr_b,
                                                                                                                           corr_prior_beta ,
                                                                                                                           corr_prior_norm ,
                                                                                                                           lb_corr,           //  30
                                                                                                                           ub_corr,
                                                                                                                           known_values_indicator,
                                                                                                                           known_values,
                                                                                                                           prev_prior_a,
                                                                                                                           prev_prior_b,       //  35
                                                                                                                           Phi_type,       
                                                                                                                           sampling_option,
                                                                                                                           false, // generate_velocity
                                                                                                                           velocity_0) ; // //  40
                                   
                                   theta_previous_iter = single_iter_out.head(n_params) ; 
                                   theta_main_trace.col(ii) = single_iter_out.head(n_params).segment(n_us, n_params_main) ; 
                                   //  log_lik_trace.col(ii) = single_iter_out.col(1).head(N);  
                                   div_vec(ii) = 0;
                                   
                                   
                                 } catch (...) {
                                   div_vec(ii) = 1;
                                   //   theta_previous_iter =  theta_previous_previous_iter;
                                   theta_main_trace.col(ii) =   theta_main_trace.col(ii - 1); 
                                   //  log_lik_trace.col(ii) =   log_lik_trace.col(ii - 1); 
                                   theta_previous_iter = theta_previous_iter;
                                 }
                                 
                                 
                                 
                                 
                                 if  ( (attempt == 0) ) { 
                                   
                                         if  ( ( div_vec(ii)  == 0) && (Phi_type_original == 1)   ) { 
                                           skip = true;
                                           Phi_type = Phi_type_original;
                                         }
                                         
                                         if  ( ( div_vec(ii)  == 1) && (Phi_type_original == 1)   ) {   //  # if div  on  attempt 1, try attempt 2
                                         skip = false;
                                         Phi_type = 3;
                                         }
                                         
                                 }
                                 
                            
                               }
                 
                   }
                     
     
     
   }
     
   
   
   
   
   Rcpp::List out_list(5);
   
   out_list(0) = theta_main_trace;
   //  out_list(1) = log_lik_trace;
   out_list(2) = div_vec;
   
   return(out_list);
   
 }
 
 
 
 
 
 
 
 
 
 
 