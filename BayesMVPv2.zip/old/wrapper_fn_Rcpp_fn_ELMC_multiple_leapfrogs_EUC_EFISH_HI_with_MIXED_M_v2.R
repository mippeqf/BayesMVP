# fn_softabs_dense <- function(soft_abs_alpha.,
#                              G_dense_main.) {
#   
#   softabs_attempt_success_indicator <- 0
#   try({
#     {
#       
#       Hessian_dense_eigen_vals <- eigen(-  G_dense_main.)$values
#       Hessian_dense_eigen_vecs <- eigen(-  G_dense_main.)$vectors
#       
#       lambda <-  diag(Hessian_dense_eigen_vals)
#       lambda_tilde <- diag(Hessian_dense_eigen_vals * pracma::coth( soft_abs_alpha. * Hessian_dense_eigen_vals ) )
#       
#       
#       Hessian_dense_SoftAbs <- - Hessian_dense_eigen_vecs %*%  lambda_tilde %*%  t(Hessian_dense_eigen_vecs)
#       
#       
#       G_dense_main. = - as.matrix(Matrix::forceSymmetric(Hessian_dense_SoftAbs))
#       G_inv_dense_main =  as.matrix(Matrix::forceSymmetric(BayesMVP::Rcpp_solve(G_dense_main.)))
#       
#       softabs_attempt_success_indicator <- 1
#     }
#     
#   })
#   
#   if (softabs_attempt_success_indicator == 0) {  # force PD first then do softabs if softabs attempt not successful
#     
#     try({
#       comment(print("aa"))
#       G_inv_dense_main <-  as.matrix(nearPD(G_inv_dense_main)$mat)
#       G_inv_dense_main <- (G_inv_dense_main + G_inv_dense_main)/2
#       
#       G_dense_main. <- BayesMVP::Rcpp_solve(G_inv_dense_main)
#       G_dense_main. = - as.matrix(Matrix::forceSymmetric(Hessian_dense_SoftAbs))
#     })
#     
#     
#     try({
#       Hessian_dense_eigen_vals <- eigen(-  G_dense_main.)$values
#       Hessian_dense_eigen_vecs <- eigen(-  G_dense_main.)$vectors
#       
#       lambda <-  diag(Hessian_dense_eigen_vals)
#       lambda_tilde <- diag(Hessian_dense_eigen_vals * pracma::coth( soft_abs_alpha. * Hessian_dense_eigen_vals ) )
#       
#       
#       Hessian_dense_SoftAbs <- - Hessian_dense_eigen_vecs %*%  lambda_tilde %*%  t(Hessian_dense_eigen_vecs)
#       
#       
#       G_inv_dense_main =  as.matrix(Matrix::forceSymmetric(BayesMVP::Rcpp_solve(G_dense_main.)))
#     })
#   }
#   
#   try({
#     G_dense_main. <-  as.matrix(Matrix::forceSymmetric(G_dense_main.))
#     G_inv_dense_main <-  as.matrix(Matrix::forceSymmetric(G_inv_dense_main))
#   })
#   
#   
#   return(list(G_dense_main = G_dense_main.,
#               G_inv_dense_main = G_inv_dense_main))
#   
# }
# 
# 
# 



 





wr_fn_LMC_multiple_leapfrogs_main_only_diag_G_simple_GHK_MVP_USING_RCPP <- function(theta.,
                                                                                    autodiff.,
                                                                                    dense_G_indicator.,
                                                                                    n_burnin.,
                                                                                    lp_and_grad_args.,
                                                                                    iter.,
                                                                                    velocity_0.,
                                                                                    M_main_vec_if_Euclidean.,
                                                                                    M_us_vec_if_Euclidean.,
                                                                                    M_dense_main., ##
                                                                                    M_inv_dense_main., ##
                                                                                    M_inv_dense_main_chol., ## 
                                                                                    numerical_diff_e.,
                                                                                    L.,
                                                                                    epsilon.,
                                                                                    grad_initial.,
                                                                                    log_posterior_initial.,
                                                                                    y.,
                                                                                    individual_log_lik_initial.
) {  
  

    n_class = 2 # lp_and_grad_args.[[12]];
    n_tests = lp_and_grad_args.[[13]]
  
    N =  nrow(y.)
    n_corrs =  n_class * n_tests * (n_tests - 1) * 0.5;
    n_coeffs = n_class * n_tests * 1;
    n_us =  1 *  N * n_tests;
  
    n_params = length(theta.)
    n_params_main = n_params - n_us;
  
  
  
        # 
        # n_params_main <- length(index_main.)
        # n_us <- length(index_us.)
        
        # lcmMVPbetav3::
        # lcmMVPbetav2::
        
        Rcpp_leapfrog_outs <- c(NA)
        
        
            try({  
              Rcpp_leapfrog_outs <- BayesMVP::Rcpp_fn_ELMC_multiple_leapfrogs_EUC_EFISH_HI_with_MIXED_M_NT_us(theta = theta.,
                                                                                                                  y = y.,
                                                                                                                  lp_and_grad_args = lp_and_grad_args.,
                                                                                                                  dense_G_indicator = TRUE,
                                                                                                                  velocity_0 = velocity_0.,
                                                                                                                  numerical_diff_e = numerical_diff_e.,
                                                                                                                  L = L.,
                                                                                                                  eps = epsilon.,
                                                                                                                  grad = grad_initial.,
                                                                                                                  log_posterior = log_posterior_initial.,
                                                                                                                  M_main_vec_if_Euclidean =  M_main_vec_if_Euclidean.,
                                                                                                                  M_inv_us_vec_if_Euclidean =  1 / M_us_vec_if_Euclidean.,
                                                                                                                  M_dense_main = M_dense_main.,
                                                                                                                  M_inv_dense_main = M_inv_dense_main.,
                                                                                                                  M_inv_dense_main_chol = M_inv_dense_main_chol.,
                                                                                                                  n_us = n_us,
                                                                                                                  n_params_main = n_params_main)
            })
            
          
        # }
        
        individual_log_lik =   individual_log_lik_initial.
 
        if  ( (length(Rcpp_leapfrog_outs) == 1)  &&  (is.na(Rcpp_leapfrog_outs[1]) ) ) { 
            
            
        } else { 
              
          
          theta_full = Rcpp_leapfrog_outs[[2]]
          
          velocity_0 = Rcpp_leapfrog_outs[[3]]
          velocity = Rcpp_leapfrog_outs[[4]]
          
          # momentum_0 = Rcpp_leapfrog_outs[[3]]
          # momentum = Rcpp_leapfrog_outs[[4]]
          
          log_posterior = Rcpp_leapfrog_outs[[5]]
          log_posterior_0 = Rcpp_leapfrog_outs[[6]]
          
          grad <- grad_0 <- grad_initial.
          
          grad = Rcpp_leapfrog_outs[[7]]
          grad_0 = Rcpp_leapfrog_outs[[8]]
          
          individual_log_lik = Rcpp_leapfrog_outs[[14]]
          
          
        }
        
       
        

        
        
        
          
          if (!(any(is.na(Rcpp_leapfrog_outs)))) {
          
 
                div <- 0
                
                
               # u_neg_hessian_diag_double <-  Empirical_Fisher_mat.
                
                
                
             #   neg_Hessian_proposed =  u_neg_hessian_diag_double # Empirical_Fisher_mat. # Rcpp_leapfrog_outs[[9]]
            #    neg_Hessian_proposed <-  as.matrix( Matrix::forceSymmetric(neg_Hessian_proposed) )
                
                # if (any(is.nan(neg_Hessian_proposed))) { 
                #   neg_Hessian_proposed <- Empirical_Fisher_mat.
                # }
                
                
              #   G_dense_main <- G_inv_dense_main <- G_inv_chol_dense_main <- G_dense_main_initial.
              #     
              #   G_dense_main =   Rcpp_leapfrog_outs[[11]]
              # #  if (iter. < n_burnin. + 5 ) G_dense_main <-  as.matrix( Matrix::forceSymmetric(G_dense_main) )
              # 
              #   
              #   G_inv_dense_main =   Rcpp_leapfrog_outs[[12]]
              # #  if (iter. < n_burnin. + 5 ) G_inv_dense_main <-  as.matrix( Matrix::forceSymmetric(G_inv_dense_main) )
              # 
              #   
              #   G_inv_chol_dense_main =   Rcpp_leapfrog_outs[[13]]
        
        } else { 
          
          comment(print(paste("div div div")))
          
          div <- 1
          
          
          
          if  ( (length(Rcpp_leapfrog_outs) == 1)  &&  (is.na(Rcpp_leapfrog_outs[1]) ) ) { 
            
            
                  theta.[1] <- NA
                  
                  theta = theta.
                  grad_x = grad_initial.
                  grad_0 = grad_initial.
                  grad = grad_initial. 
                  
                  G_diag_full = NA
                  theta_full = NA
                  neg_Hessian_proposed = NA
                  
                  log_posterior = log_posterior_initial.
                  log_posterior_0 = log_posterior_initial.
                  
                  diag_Hessian = NA
                  G_full_diag_vec = NA
                  G_full_diag_vec_subset = NA
                  G_initial_full_diag_vec. = NA
                  
                  # momentum = momentum_0.
                  # momentum_0 = momentum_0.
                  
                  
                  velocity_0 =  velocity_0.
                  velocity =  velocity_0.
                  
                  G_dense_main = NA
                  G_inv_dense_main = NA
                  G_inv_chol_dense_main = NA
                  G_dense_main_initial = NA
                  G_inv_dense_main_initial = NA
                  G_inv_chol_dense_main_initial = NA
                  delta_log_det = NA
                  log_acceptance_prob = NA
                  
               #   G_dense_main <- G_inv_dense_main <- G_inv_chol_dense_main <- G_dense_main_initial.

            
            
            
          } else { 
            
            
                  
                  theta.[1] <- NA
                  
                  theta = theta.
                  grad_x = grad_initial.
                  grad_0 = grad_initial.
                  
                  G_diag_full = NA
                  theta_full = NA
                  neg_Hessian_proposed = NA
                  log_posterior = log_posterior_0
                  log_posterior_0 = log_posterior_0
                  diag_Hessian = NA
                  G_full_diag_vec = NA
                  G_full_diag_vec_subset = NA
                  G_initial_full_diag_vec. = NA
                  
                  # momentum = momentum_0
                  # momentum_0 = momentum_0
                  
                  G_dense_main = NA
                  G_inv_dense_main = NA
                  G_inv_chol_dense_main = NA
                  G_dense_main_initial = NA
                  G_inv_dense_main_initial = NA
                  G_inv_chol_dense_main_initial = NA
                  delta_log_det = NA
                  log_acceptance_prob = NA
                  
                #  G_dense_main <- G_inv_dense_main <- G_inv_chol_dense_main <- G_dense_main_initial.
                  
                  velocity_0 =  velocity_0
                  velocity =  velocity_0
            
            
          }
          
          
          
          

          
        }
        
          
        return(list(
          
                theta = theta_full,
 
                grad_x = grad,
                grad_0 = grad_0,
                
                log_posterior= log_posterior,
                log_posterior_0 = log_posterior_0,
                
                velocity_0 = velocity_0,
                velocity = velocity,
                
                div = div,
              
              individual_log_lik = individual_log_lik
          
          
        ))
        
        
  
  
  
}
